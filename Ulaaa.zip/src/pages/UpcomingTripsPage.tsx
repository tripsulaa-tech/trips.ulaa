import { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Sparkle } from '@phosphor-icons/react';
import { Link } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import TripCard from '../components/ui/TripCard';
import BrowseShell from '../components/ui/BrowseShell';
import { getUpcomingTrips } from '../services/api';
import { subscribeToTable } from '../services/realtime';
import { useScrollRestoration } from '../hooks/useScrollRestoration';
import { useMonthFilteredTrips } from '../hooks/useMonthFilteredTrips';
import { useLiveNavLabel } from '../hooks/useLiveNavLabel';
import { usePageMeta } from '../hooks/usePageMeta';
import { DEFAULT_BOTTOM_NAV_ITEMS } from '../constants/bottomNav';
import { getActivePrice, specialOfferDaysLeft } from '../utils/utils-index';
import type { UpcomingTrip } from '../types/types-index';


const HERO_IMAGE = 'https://images.unsplash.com/photo-1488085061387-422e29b40080?w=1600&q=80';

// Module-level (not inline) so useMonthFilteredTrips' memoization gets a
// stable function reference across renders.
const getStartDate = (trip: UpcomingTrip) => trip.start_date;
// Coming Soon trips don't have a confirmed date yet, so they only ever show
// up under "All" — picking a specific month pill hides them, matching that
// month's pill count.
const isComingSoon = (trip: UpcomingTrip) => trip.status === 'coming_soon';

// This page is the "Upcoming" tab in the bottom nav bar (see
// constants/bottomNav.ts) — its route below is used to pull that tab's
// admin-editable label for the "Showing N trips" line, so renaming the tab
// (e.g. via the Home Page admin) updates this text automatically too.
const NAV_ROUTE = '/trips';
const DEFAULT_NAV_LABEL = DEFAULT_BOTTOM_NAV_ITEMS.find(i => i.to === NAV_ROUTE)?.label ?? 'Upcoming';

export default function UpcomingTripsPage() {
  const [trips, setTrips] = useState<UpcomingTrip[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [month, setMonth] = useState('All');
  const [showFilters, setShowFilters] = useState(false);
  // This tab's label in the bottom nav bar (e.g. "Upcoming") — admin-editable
  // in the Home Page admin, shown in front of "Showing N trips" below.
  const navLabel = useLiveNavLabel(NAV_ROUTE, DEFAULT_NAV_LABEL);

  useEffect(() => {
    getUpcomingTrips()
      .then(data => setTrips(data))
      .catch(() => setTrips([]))
      .finally(() => setLoading(false));
  }, []);

  // Remember and restore scroll position — wherever the user goes from
  // here and however they get back (trip detail's back link, bottom nav
  // tab switch, browser back), they land where they left off.
  useScrollRestoration('/trips', !loading);

  usePageMeta({
    title: 'Upcoming Trips | Ulaa Trips',
    description: "Handpicked, girls-only adventures to India's most beautiful hidden destinations. Browse upcoming trips and book your seat.",
    path: '/trips',
  });

  // Live publish/draft + coming-soon status — re-pulls the public list the
  // moment an admin publishes a trip, unpublishes/deletes one, or flips
  // "Coming Soon", so anyone already on this page sees it appear/disappear
  // or switch to the coming-soon layout without refreshing.
  useEffect(() => {
    const unsubscribe = subscribeToTable('upcoming_trips', () => {
      getUpcomingTrips()
        .then(data => setTrips(data))
        .catch(() => {});
    });
    return unsubscribe;
  }, []);

  const { filtered, monthCounts } = useMonthFilteredTrips(trips, search, month, getStartDate, isComingSoon);

  // Trips with a named special offer live right now (e.g. "Diwali
  // Dhamaka") — drives the banner strip below. Recomputed only when the
  // trip list changes, not on every render, since "today" only actually
  // changes once a day.
  const activeSpecialOfferTrips = useMemo(
    () => trips.filter(trip => getActivePrice(trip.price, trip.early_bird_price, trip.early_bird_deadline, trip.special_offer_price, trip.special_offer_date, trip.special_offer_end_date).isSpecialOffer),
    [trips]
  );

  return (
    <Layout>
      <BrowseShell
        hero={{
          image: HERO_IMAGE,
          imageAlt: 'Upcoming Trips',
          label: 'Plan Your Journey',
          title: 'Upcoming Trips',
          subtitle: "Handpicked adventures to India's most beautiful hidden destinations.",
        }}
        filters={{
          search,
          onSearchChange: setSearch,
          month,
          onMonthChange: setMonth,
          monthCounts,
          showFilters,
          onToggleFilters: () => setShowFilters(!showFilters),
        }}
        filterBarClassName="bg-white"
        afterFilters={
          // Live special offer(s) — only rendered when at least one trip has
          // a flash offer live right now; disappears on its own once the
          // offer's end date passes.
          activeSpecialOfferTrips.length > 0 && (
            <div className="px-4 sm:px-6 lg:px-8 pt-6">
              <div className="max-w-[1344px] mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                  className="bg-gradient-to-r from-primary-dark to-primary rounded-xl px-4 sm:px-6 py-4 flex flex-wrap items-center gap-3"
                >
                  <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-white/15 text-white shrink-0">
                    <Sparkle size={18} weight="fill" />
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-button font-bold text-sm sm:text-base leading-tight">
                      {activeSpecialOfferTrips.length === 1
                        ? (() => {
                            const t = activeSpecialOfferTrips[0];
                            const daysLeft = specialOfferDaysLeft(t.special_offer_date!, t.special_offer_end_date);
                            return `${t.special_offer_name} — ${daysLeft <= 1 ? 'ends today!' : `ends in ${daysLeft} days!`}`;
                          })()
                        : `${activeSpecialOfferTrips.length} special offers live now!`}
                    </p>
                    <p className="text-white/80 text-xs sm:text-sm mt-0.5">
                      {activeSpecialOfferTrips.length === 1
                        ? 'Grab this trip at the offer price before it\'s gone.'
                        : activeSpecialOfferTrips.map(t => t.special_offer_name).join(' · ')}
                    </p>
                  </div>
                  {activeSpecialOfferTrips.length === 1 && (
                    <Link
                      to={`/trips/${activeSpecialOfferTrips[0].slug}`}
                      className="shrink-0 bg-white text-primary-dark font-button font-semibold text-xs sm:text-sm px-4 py-2 rounded-md hover:bg-white/90 transition-colors"
                    >
                      View Trip
                    </Link>
                  )}
                </motion.div>
              </div>
            </div>
          )
        }
        loading={loading}
        skeletonType="trip"
        items={trips}
        filteredItems={filtered}
        emptyState={{ title: 'No upcoming trips yet.', message: 'Check back soon — new adventures are on the way.' }}
        noResultsState={{ title: 'No trips found.', message: 'Try adjusting your search or filters.' }}
        hasActiveFilters={search !== '' || month !== 'All'}
        onClearFilters={() => { setSearch(''); setMonth('All'); }}
        countLabel={navLabel}
        countNoun="trip"
        itemKey={trip => trip.id}
        renderItem={(trip, i) => <TripCard trip={trip} index={i} />}
      />
    </Layout>
  );
}
