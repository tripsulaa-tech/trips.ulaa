import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import {
  Envelope as Mail,
  InstagramLogo as Instagram,
  MapPin,
  CheckCircle,
  WarningCircle as AlertCircle,
  PaperPlaneTilt as Send,
  Clock,
  ArrowRight,
  Airplane as Plane,
} from '@phosphor-icons/react';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import { WhatsAppIcon } from '../components/icons/WhatsAppIcon';
import { submitContactEnquiry } from '../services/api';
import { getWhatsAppLink } from '../utils/utils-index';
import { useScrollRestoration } from '../hooks/useScrollRestoration';
import { validateEmail, validateFullName, validateOptionalPhone } from '../utils/formValidation';
import { fadeUp } from '../utils/animation';

interface ContactForm {
  name: string;
  email: string;
  phone?: string;
  message: string;
}

const WHATSAPP_NUMBER = '916381336772';
const MESSAGE_SOFT_LIMIT = 500;

// Shared floating-label field styling. `pt-6 pb-2` (rather than the usual
// symmetric padding) leaves room above the text baseline for the label to
// dock into once it floats, without needing a second wrapper element.
const fieldClass = (hasError: boolean) => `
  peer w-full rounded-xl border-2 bg-white px-4 pt-6 pb-2.5 font-body text-dark
  placeholder-transparent outline-none transition-colors duration-200
  ${hasError ? 'border-red-300 focus:border-red-400' : 'border-background-warm focus:border-primary'}
`;

const labelClass = `
  absolute left-4 top-4 text-dark-muted/60 text-base transition-all duration-200 ease-out
  pointer-events-none origin-left
  peer-focus:top-2.5 peer-focus:text-[11px] peer-focus:text-primary peer-focus:font-medium
  peer-[:not(:placeholder-shown)]:top-2.5 peer-[:not(:placeholder-shown)]:text-[11px] peer-[:not(:placeholder-shown)]:text-dark-muted peer-[:not(:placeholder-shown)]:font-medium
`;

export default function ContactPage() {
  // Remember and restore scroll position when leaving/returning via the
  // bottom nav, same as the trips pages. The form is static, so there's no
  // async load to wait on before restoring.
  useScrollRestoration('/contact', true);

  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const { register, handleSubmit, watch, formState: { errors }, reset } = useForm<ContactForm>();

  const messageLength = watch('message', '')?.length ?? 0;

  const onSubmit = async (data: ContactForm) => {
    try {
      setStatus('loading');
      await submitContactEnquiry({
        full_name: data.name,
        email: data.email,
        phone: data.phone,
        message: data.message,
      });
      setStatus('success');
      reset();
    } catch (err) {
      setStatus('error');
      if (err instanceof Error && err.message === 'DUPLICATE_ENQUIRY') {
        setErrorMsg("Looks like you've already sent this exact message — we've got it and will get back to you shortly.");
      } else {
        setErrorMsg('Something went wrong. Please try again.');
      }
    }
  };

  return (
    <Layout>
      {/* Header — a light, on-brand banner (no stock photo) with a single
          orchestrated motion moment: a plane drifting along a dotted flight
          path, echoing the travel theme without competing for attention. */}
      <div className="relative h-64 sm:h-72 overflow-hidden bg-gradient-to-br from-background-warm via-background to-cream">
        <div className="absolute -top-16 -left-16 w-72 h-72 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-20 -right-10 w-80 h-80 rounded-full bg-secondary/10 blur-3xl" />

        <svg
          className="absolute inset-0 w-full h-full opacity-40"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M -5 70 C 20 92, 30 8, 50 40 S 82 92, 105 22"
            stroke="#A85A2A"
            strokeWidth="0.4"
            strokeDasharray="1.4 2.4"
            strokeLinecap="round"
          />
        </svg>

        <motion.div
          className="absolute"
          style={{ marginLeft: '-14px', marginTop: '-14px' }}
          animate={{
            left: ['-5%', '20%', '35%', '50%', '65%', '82%', '105%'],
            top: ['70%', '84%', '50%', '40%', '55%', '84%', '22%'],
            rotate: [25, -20, 5, -15, 25, -25, 15],
          }}
          transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }}
          aria-hidden="true"
        >
          <Plane size={28} weight="fill" className="text-primary/70 rotate-45" />
        </motion.div>

        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4 sm:px-6">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <span className="font-script text-secondary text-2xl sm:text-3xl block">Say hello</span>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-dark mt-2">
              Let's plan something great
            </h1>
            <p className="text-dark-muted mt-3 max-w-md mx-auto text-base sm:text-lg">
              Trip questions, custom plans, or just fancy a chat — drop us a line and we'll get right back to you.
            </p>
            <div className="mt-5 inline-flex items-center gap-2 bg-white/70 backdrop-blur-sm border border-white px-4 py-2 rounded-full shadow-card text-sm font-medium text-dark">
              <Clock size={16} className="text-primary" weight="bold" />
              Usually replies within a few hours
            </div>
          </motion.div>
        </div>
      </div>

      <div className="relative isolate px-4 sm:px-6 lg:px-8 py-14 sm:py-16">
        <div className="max-w-[1344px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
            {/* Contact info */}
            <motion.div {...fadeUp()} className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-dark mb-3">
                  Reach us however's easiest
                </h2>
                <p className="text-dark-muted leading-relaxed">
                  Have questions about a trip? Want to plan something special? Or just want to say hi?
                  We're always happy to chat.
                </p>
              </div>

              {/* Priority WhatsApp CTA */}
              <a
                href={getWhatsAppLink(WHATSAPP_NUMBER)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between gap-4 rounded-2xl bg-gradient-to-r from-primary to-primary-light text-white px-5 py-4 shadow-warm hover:shadow-warm-lg transition-shadow group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 shrink-0 rounded-xl bg-white/20 flex items-center justify-center">
                    <WhatsAppIcon className="w-5 h-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold">Fastest — WhatsApp us</p>
                    <p className="text-white/80 text-sm truncate">+91 63813 36772</p>
                  </div>
                </div>
                <ArrowRight size={20} className="shrink-0 group-hover:translate-x-1 transition-transform" />
              </a>

              {/* Quick-contact tiles */}
              <div className="grid grid-cols-2 gap-3">
                <a
                  href="mailto:trips.ulaa@gmail.com"
                  className="flex flex-col gap-3 bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-shadow group"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <Mail size={19} />
                  </div>
                  <div>
                    <p className="font-semibold text-dark text-sm">Email</p>
                    <p className="text-dark-muted text-xs mt-0.5 group-hover:text-primary transition-colors break-all">
                      trips.ulaa@gmail.com
                    </p>
                  </div>
                </a>

                <a
                  href="https://www.instagram.com/ulaa.trips?igsh=MXhpbHdwOXhmamZsZw=="
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex flex-col gap-3 bg-white rounded-xl p-4 shadow-card hover:shadow-card-hover transition-shadow group"
                >
                  <div className="w-10 h-10 rounded-lg bg-pink-50 text-pink-600 flex items-center justify-center">
                    <Instagram size={19} />
                  </div>
                  <div>
                    <p className="font-semibold text-dark text-sm">Instagram</p>
                    <p className="text-dark-muted text-xs mt-0.5 group-hover:text-primary transition-colors">
                      @ulaa.trips
                    </p>
                  </div>
                </a>

                <div className="flex flex-col gap-3 bg-white rounded-xl p-4 shadow-card">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <MapPin size={19} />
                  </div>
                  <div>
                    <p className="font-semibold text-dark text-sm">Based in</p>
                    <p className="text-dark-muted text-xs mt-0.5">India — exploring everywhere</p>
                  </div>
                </div>

                <div className="flex flex-col gap-3 bg-white rounded-xl p-4 shadow-card">
                  <div className="w-10 h-10 rounded-lg bg-secondary/10 text-secondary flex items-center justify-center">
                    <Clock size={19} weight="bold" />
                  </div>
                  <div>
                    <p className="font-semibold text-dark text-sm">Response time</p>
                    <p className="text-dark-muted text-xs mt-0.5">Within a few hours</p>
                  </div>
                </div>
              </div>

              {/* Honest "no storefront" banner, replacing the old dead map placeholder */}
              <div className="relative overflow-hidden rounded-2xl bg-dark text-white p-6">
                <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-primary/20 blur-2xl" />
                <p className="font-script text-secondary text-lg relative">Based in India</p>
                <p className="font-display text-lg sm:text-xl font-semibold mt-1 relative">
                  Exploring everywhere, one trip at a time
                </p>
                <p className="text-white/70 text-sm mt-2 relative leading-relaxed">
                  We don't have a storefront to visit — we run every trip from the road (and from WhatsApp).
                  That's how we keep things personal.
                </p>
              </div>
            </motion.div>

            {/* Contact form */}
            <motion.div {...fadeUp(0.1)} className="lg:col-span-3">
              <div className="relative bg-white rounded-3xl shadow-warm-lg border border-background-warm overflow-hidden">
                <div className="h-1.5 bg-gradient-to-r from-primary via-secondary to-primary" />

                <div className="p-6 sm:p-8 md:p-10">
                  {status === 'success' ? (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center py-8 sm:py-10"
                    >
                      <motion.div
                        initial={{ scale: 0.6, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ type: 'spring', stiffness: 260, damping: 18 }}
                        className="inline-flex"
                      >
                        <CheckCircle size={64} weight="fill" className="text-green-500 mx-auto mb-4" />
                      </motion.div>
                      <h4 className="font-display text-xl sm:text-2xl font-bold text-dark mb-2">Message sent!</h4>
                      <p className="text-dark-muted max-w-sm mx-auto">
                        Thanks for reaching out — we'll get back to you within 24 hours.
                      </p>

                      <div className="mt-6 bg-background-warm/60 rounded-xl p-4 text-left max-w-sm mx-auto space-y-2">
                        <p className="text-sm font-semibold text-dark">What happens next</p>
                        <p className="text-sm text-dark-muted">1. We read every message ourselves — no bots.</p>
                        <p className="text-sm text-dark-muted">2. You'll hear back by email or WhatsApp, usually within a few hours.</p>
                      </div>

                      <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
                        <Button variant="outline" size="md" onClick={() => setStatus('idle')}>
                          Send another message
                        </Button>
                        <a
                          href={getWhatsAppLink(WHATSAPP_NUMBER)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-md font-button font-semibold text-sm text-green-700 bg-green-50 hover:bg-green-100 transition-colors min-h-[44px]"
                        >
                          <WhatsAppIcon className="w-4 h-4" />
                          Chat on WhatsApp instead
                        </a>
                      </div>
                    </motion.div>
                  ) : (
                    <>
                      <h3 className="font-display text-xl sm:text-2xl font-bold text-dark mb-1">Send a message</h3>
                      <p className="text-dark-muted text-sm mb-6">Fill this in and we'll take it from there.</p>

                      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                          <div className="relative">
                            <input
                              id="contact-name"
                              placeholder=" "
                              className={fieldClass(!!errors.name)}
                              {...register('name', { required: 'Enter your full name', validate: validateFullName })}
                            />
                            <label htmlFor="contact-name" className={labelClass}>Your name</label>
                            {errors.name && (
                              <p className="mt-1.5 flex items-center gap-1 text-xs text-red-500">
                                <AlertCircle size={13} /> {errors.name.message}
                              </p>
                            )}
                          </div>

                          <div className="relative">
                            <input
                              id="contact-phone"
                              type="tel"
                              placeholder=" "
                              className={fieldClass(!!errors.phone)}
                              {...register('phone', { validate: (value) => validateOptionalPhone(value ?? '') })}
                            />
                            <label htmlFor="contact-phone" className={labelClass}>Phone (optional)</label>
                            {errors.phone && (
                              <p className="mt-1.5 flex items-center gap-1 text-xs text-red-500">
                                <AlertCircle size={13} /> {errors.phone.message}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="relative">
                          <input
                            id="contact-email"
                            type="email"
                            placeholder=" "
                            className={fieldClass(!!errors.email)}
                            {...register('email', { required: 'Enter your email', validate: validateEmail })}
                          />
                          <label htmlFor="contact-email" className={labelClass}>Email</label>
                          {errors.email && (
                            <p className="mt-1.5 flex items-center gap-1 text-xs text-red-500">
                              <AlertCircle size={13} /> {errors.email.message}
                            </p>
                          )}
                        </div>

                        <div className="relative">
                          <textarea
                            id="contact-message"
                            rows={5}
                            placeholder=" "
                            maxLength={MESSAGE_SOFT_LIMIT}
                            className={`${fieldClass(!!errors.message)} resize-none`}
                            {...register('message', {
                              required: 'Tell us a little about what you need',
                              minLength: { value: 10, message: 'A few more words would help us help you' },
                            })}
                          />
                          <label htmlFor="contact-message" className={labelClass}>
                            Tell us about your travel dreams...
                          </label>
                          <div className="flex items-center justify-between mt-1.5">
                            <span>
                              {errors.message && (
                                <p className="flex items-center gap-1 text-xs text-red-500">
                                  <AlertCircle size={13} /> {errors.message.message}
                                </p>
                              )}
                            </span>
                            <span className="text-xs text-dark-muted/60">{messageLength}/{MESSAGE_SOFT_LIMIT}</span>
                          </div>
                        </div>

                        {status === 'error' && (
                          <div className="flex items-center gap-2 text-red-600 bg-red-50 rounded-lg p-3">
                            <AlertCircle size={16} />
                            <p className="text-sm">{errorMsg}</p>
                          </div>
                        )}

                        <Button type="submit" variant="primary" size="lg" fullWidth loading={status === 'loading'}>
                          <Send size={18} weight="fill" />
                          Send message
                        </Button>
                      </form>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
