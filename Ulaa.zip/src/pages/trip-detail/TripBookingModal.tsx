import Modal from '../../components/ui/Modal';
import BookingForm from '../../components/ui/BookingForm';
import { useConfirm } from '../../components/ui/useConfirm';
import { isBookingDraftDirty } from '../../utils/bookingDraft';
import type { UpcomingTrip, ButtonLabelsConfig, BookingFormDraft } from '../../types/types-index';
import { getPackageBase } from '../../utils/tripOptions';

// How long the success message stays up before the booking modal closes itself.
const SUCCESS_CLOSE_DELAY_MS = 3000;

interface TripBookingModalProps {
  trip: UpcomingTrip;
  buttonLabels: ButtonLabelsConfig;
  isFull: boolean;
  remaining: number;
  isOpen: boolean;
  onClose: () => void;
  bookingDraft: BookingFormDraft | null;
  onDraftChange: (draft: BookingFormDraft | null) => void;
  // Package the visitor tapped on the trip page's package cards, if any.
  initialPackageId?: string | null;
}

// Routes to an enquiry or the waitlist depending on whether what's
// requested (solo seat, or N for a group) actually fits in what's left;
// see BookingForm.
export default function TripBookingModal({
  trip,
  buttonLabels,
  isFull,
  remaining,
  isOpen,
  onClose,
  bookingDraft,
  onDraftChange,
  initialPackageId,
}: TripBookingModalProps) {
  const confirm = useConfirm();

  const handleClose = async () => {
    // Closing (backdrop click, Escape, or the X button all funnel through
    // this same handler) with unsaved details entered would otherwise
    // silently discard them with no warning — most often an accidental
    // backdrop click. Confirm first when there's actually something to
    // lose. The draft itself is kept either way (see bookingDraft/
    // onDraftChange below), so even a deliberate close doesn't lose what
    // was typed — reopening the form brings it right back.
    if (isBookingDraftDirty(bookingDraft)) {
      const ok = await confirm({
        title: 'Close without submitting?',
        message: "You've entered some details for this booking. If you close now they won't be submitted — but we'll keep them ready for you if you come back to this form.",
        confirmLabel: 'Close',
        cancelLabel: 'Keep editing',
        variant: 'default',
      });
      if (!ok) return;
    }
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      ariaLabel={isFull ? buttonLabels.waitlistCta : buttonLabels.primaryCta}
      size="xl"
      flush
    >
      <BookingForm
        tripId={trip.id}
        tripTitle={trip.title}
        tripDate={trip.start_date}
        terms={trip.terms_and_conditions}
        remainingSeats={remaining}
        minAge={trip.min_age}
        maxAge={trip.max_age}
        initialDraft={bookingDraft}
        onDraftChange={onDraftChange}
        tripOptions={trip.trip_options}
        packageBase={getPackageBase(trip)}
        initialPackageId={initialPackageId}
        onSuccess={() => setTimeout(onClose, SUCCESS_CLOSE_DELAY_MS)}
      />
    </Modal>
  );
}
