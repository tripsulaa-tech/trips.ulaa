import Button from '../../components/ui/Button';
import type { UpcomingTrip, ButtonLabelsConfig } from '../../types/types-index';
import { formatDate, formatPrice, specialOfferDaysLeft } from '../../utils/utils-index';
import { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Clock, Sparkle, Gift } from '@phosphor-icons/react';

/** The "Save ₹X" + "PLUS ₹Y OFFER" badge pair — identical in both the
 *  advance_amount and no-advance_amount price layouts below, just at a
 *  different point in each layout's row sequence. */
function SaveAndPlusOfferBadges({
  saveAmount,
  showPlusOffer,
  plusOfferAmount,
}: {
  saveAmount: number | null;
  showPlusOffer: boolean;
  plusOfferAmount: number | null;
}) {
  if (saveAmount == null && !showPlusOffer) return null;
  return (
    <div className="flex items-center gap-1.5 mt-0.5">
      {saveAmount != null && (
        <span className="bg-green-50 border border-green-200 text-green-700 text-2xs font-button font-medium px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
          Save {formatPrice(saveAmount)}
        </span>
      )}
      {showPlusOffer && (
        <span className="inline-flex items-center gap-1 bg-pink-50 border border-pink-200 text-pink-600 text-2xs font-button font-bold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
          <Gift size={10} weight="fill" className="shrink-0" />
          PLUS {formatPrice(plusOfferAmount as number)} OFFER
        </span>
      )}
    </div>
  );
}

interface TripStickyBookingBarProps {
  trip: UpcomingTrip;
  buttonLabels: ButtonLabelsConfig;
  activePrice: number | null | undefined;
  strikeThroughPrice: number | null | undefined;
  isEarlyBird: boolean;
  isSpecialOffer: boolean;
  isFull: boolean;
  isAlmostFull: boolean;
  remaining: number;
  onBook: () => void;
}

export default function TripStickyBookingBar({
  trip,
  buttonLabels,
  activePrice,
  strikeThroughPrice,
  isEarlyBird,
  isSpecialOffer,
  isFull,
  isAlmostFull,
  remaining,
  onBook,
}: TripStickyBookingBarProps) {
  // The countdown card's plane flies along this button once and lands; after
  // that the button keeps a flash-and-wipe going (see TripCountdownCard).
  const reduceMotion = useReducedMotion();
  const [planeLanded, setPlaneLanded] = useState(false);
  useEffect(() => {
    const onLanded = (e: Event) => setPlaneLanded(Boolean((e as CustomEvent<boolean>).detail));
    window.addEventListener('ulaa:plane-landed', onLanded);
    return () => window.removeEventListener('ulaa:plane-landed', onLanded);
  }, []);
  const animateButton = planeLanded && !reduceMotion;

  // Save = strikeThroughPrice - activePrice (marketing "was ₹X" price vs
  // what they pay). PLUS OFFER = trip.price - activePrice (actual regular
  // price vs what they pay) — same formula and gating as TripCard/
  // SpecialOfferPopupCard: only shown for a live, non-hidden special
  // offer, and only when it says something the green badge doesn't.
  const showSpecialOfferPromo = isSpecialOffer && !trip.hide_special_offer_promo;
  const saveAmount = strikeThroughPrice != null && activePrice != null
    ? strikeThroughPrice - activePrice
    : null;
  const plusOfferAmount = trip.price != null && activePrice != null
    ? trip.price - activePrice
    : null;
  const showPlusOffer = showSpecialOfferPromo && plusOfferAmount != null && plusOfferAmount > 0 && plusOfferAmount !== saveAmount;

  return (
    <div
      data-sticky-booking-bar
      className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-background-warm shadow-warm-lg px-3 py-2.5"
    >
      <div className="flex items-center justify-between gap-2">
        {/* Left: price + meta */}
        <div className="min-w-0 flex-1">
          {activePrice != null ? (
            trip.advance_amount != null ? (
              <>
                {/* Row 1: advance amount is now the hero figure */}
                <div className="flex items-baseline gap-1.5">
                  <span className="font-display text-lg font-bold text-primary shrink-0">{formatPrice(trip.advance_amount)}</span>
                  <span className="text-dark-muted text-2xs shrink-0">to reserve</span>
                </div>

                {/* Row 2: total price + strike-through + Save badge,
                    grouped together so the discount reads right next to
                    the price it applies to. */}
                <div className="flex items-baseline gap-1.5 mt-0.5 flex-wrap">
                  {strikeThroughPrice != null && (
                    <span className="text-dark-muted line-through text-2xs shrink-0">{formatPrice(strikeThroughPrice)}</span>
                  )}
                  <span className="text-dark text-2xs font-semibold shrink-0">{formatPrice(activePrice)} total</span>
                  {saveAmount != null && (
                    <span className="bg-green-50 border border-green-200 text-green-700 text-2xs font-button font-medium px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
                      Save {formatPrice(saveAmount)}
                    </span>
                  )}
                </div>

                {/* Row 3: PLUS OFFER, its own line, same reasoning as
                    before — Save has moved up next to the total. */}
                {showPlusOffer && (
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="inline-flex items-center gap-1 bg-pink-50 border border-pink-200 text-pink-600 text-2xs font-button font-bold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
                      <Gift size={10} weight="fill" className="shrink-0" />
                      PLUS {formatPrice(plusOfferAmount as number)} OFFER
                    </span>
                  </div>
                )}

                {/* Row 4: Special Offer / Early Bird + Ends date, its own
                    line for the same reason — a predictable line break
                    instead of an unpredictable wrap point. */}
                {isSpecialOffer ? (
                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                    <span className="offer-badge-gradient-shift inline-flex items-center gap-1 text-white text-2xs font-button font-bold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
                      <Sparkle size={9} weight="fill" />
                      {trip.special_offer_name || 'Special Offer'}
                    </span>
                    {trip.special_offer_date && (
                      <span className="flex items-center gap-0.5 text-orange-600 text-2xs font-medium shrink-0 whitespace-nowrap">
                        <Clock size={9} className="shrink-0" />
                        Ends {formatDate(trip.special_offer_end_date || trip.special_offer_date, { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    )}
                  </div>
                ) : isEarlyBird && (
                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                    <span className="bg-secondary text-white text-2xs font-button font-semibold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
                      Early Bird
                    </span>
                    {trip.early_bird_deadline && (
                      <span className="flex items-center gap-0.5 text-orange-600 text-2xs font-medium shrink-0 whitespace-nowrap">
                        <Clock size={9} className="shrink-0" />
                        Ends {formatDate(trip.early_bird_deadline, { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    )}
                  </div>
                )}
              </>
            ) : (
              <>
                {/* No advance_amount configured for this trip. Price on its
                    own line, badges grouped on the next — same
                    predictable-row approach as the advance_amount branch
                    above, instead of one big auto-wrapping row. */}
                <div className="flex items-baseline gap-1.5 flex-wrap">
                  <span className="font-display text-base font-bold text-dark shrink-0">{formatPrice(activePrice)}</span>
                  {strikeThroughPrice != null && (
                    <span className="text-dark-muted line-through text-xs shrink-0">{formatPrice(strikeThroughPrice)}</span>
                  )}
                </div>
                <SaveAndPlusOfferBadges saveAmount={saveAmount} showPlusOffer={showPlusOffer} plusOfferAmount={plusOfferAmount} />
                <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                  {isSpecialOffer ? (
                    <>
                      <span className="offer-badge-gradient-shift inline-flex items-center gap-1 text-white text-2xs font-button font-bold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
                        <Sparkle size={10} weight="fill" />
                        {trip.special_offer_name || 'Special Offer'}
                      </span>
                      {trip.special_offer_date && (
                        <span className="flex items-center gap-0.5 text-orange-600 text-2xs font-medium shrink-0 whitespace-nowrap">
                          <Clock size={10} className="shrink-0" />
                          {specialOfferDaysLeft(trip.special_offer_date, trip.special_offer_end_date) <= 1
                            ? 'Offer ends today'
                            : `Offer ends ${formatDate(trip.special_offer_end_date || trip.special_offer_date, { day: 'numeric', month: 'short', year: 'numeric' })}`}
                        </span>
                      )}
                    </>
                  ) : (
                    <>
                      {isEarlyBird && (
                        <span className="bg-secondary text-white text-2xs font-button font-semibold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap">
                          Early Bird
                        </span>
                      )}
                      {isEarlyBird && trip.early_bird_deadline && (
                        <span className="flex items-center gap-0.5 text-orange-600 text-2xs font-medium shrink-0 whitespace-nowrap">
                          <Clock size={10} className="shrink-0" />
                          Offer ends {formatDate(trip.early_bird_deadline, { day: 'numeric', month: 'short', year: 'numeric' })}
                        </span>
                      )}
                    </>
                  )}
                </div>
              </>
            )
          ) : (
            <span className="text-sm text-dark-muted">Enquire for pricing</span>
          )}
        </div>

        {/* Right: CTA with seats-left inside */}
        <Button
          variant="primary"
          size="sm"
          onClick={onBook}
          className="relative overflow-hidden !rounded-lg !px-4 !py-2 shrink-0 flex flex-col items-center !gap-0 leading-tight"
        >
          {animateButton && (
            <>
              {/* The plane has just flown along the button. It leaves a flash
                  behind, then a slow wipe keeps going. */}
              <motion.span
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 0.35, 0] }}
                transition={{ duration: 0.5 }}
              />
              <motion.span
                aria-hidden="true"
                className="pointer-events-none absolute inset-y-0 w-1/4 -skew-x-12 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                initial={{ left: '-30%' }}
                animate={{ left: '130%' }}
                transition={{ duration: 0.9, delay: 0.6, ease: 'easeInOut', repeat: Infinity, repeatDelay: 2.4 }}
              />
            </>
          )}
          <span className="relative text-sm font-bold whitespace-nowrap">
            {isFull ? buttonLabels.waitlistCta : buttonLabels.primaryCta}
          </span>
          {isAlmostFull && (
            <span className="relative text-2xs font-normal text-white/85 mt-0.5">
              Only {remaining} left!
            </span>
          )}
        </Button>
      </div>
    </div>
  );
}
