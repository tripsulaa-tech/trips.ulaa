import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Envelope as Mail,
  Phone,
  MapPin,
  Heart,
  House as Home,
  CaretRight as ChevronRight,
} from '@phosphor-icons/react';
import { getWhatsAppLink } from '../../utils/utils-index';
import { WhatsAppIcon } from '../icons/WhatsAppIcon';
import { getSiteContent } from '../../services/api';
import { useNavIconResolver } from '../../hooks/useNavIcons';
import { DEFAULT_BOTTOM_NAV_ITEMS } from '../../constants/bottomNav';
import type { BottomNavItemConfig } from '../../types/types-index';
import { useBranding } from '../../hooks/useBranding';
import { SITE_HOST, SITE_ORIGIN, SITE_SHORT_NAME, BRAND_MOTTO, CONTACT_EMAIL, CONTACT_PHONE_E164, CONTACT_PHONE_DISPLAY, INSTAGRAM_URL, WHATSAPP_NUMBER, FOOTER_TAGLINE, FOOTER_TAGLINE_SUB, FOOTER_BLURB, FOOTER_REGION, FOOTER_REGION_LONG, FOOTER_SIGNOFF } from '../../constants/site';

const socialItems = [
  {
    label: 'Instagram',
    href: INSTAGRAM_URL,
    external: true,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
      </svg>
    ),
  },
  {
    label: 'WhatsApp',
    href: getWhatsAppLink(WHATSAPP_NUMBER),
    external: true,
    icon: <WhatsAppIcon className="w-5 h-5" />,
  },
  {
    label: 'Email',
    href: `mailto:${CONTACT_EMAIL}`,
    external: false,
    icon: <Mail className="w-5 h-5" />,
  },
];

export default function Footer() {
  const { urls: brand } = useBranding();
  const year = new Date().getFullYear();

  // Mirrors the same admin-configurable tabs used by the mobile BottomNav
  // (see the Home Page admin's "Bottom Nav Bar" tab) so the footer's nav links —
  // icon and label alike — always stay in sync with the site's bottom nav
  // bar instead of drifting out of consistency with it.
  const [navConfig, setNavConfig] = useState<BottomNavItemConfig[]>(DEFAULT_BOTTOM_NAV_ITEMS);
  const resolveIcon = useNavIconResolver(navConfig.map(item => item.icon));

  useEffect(() => {
    getSiteContent<BottomNavItemConfig[]>('bottom_nav')
      .then(data => {
        if (data && data.length > 0) setNavConfig(data);
      })
      .catch(() => {
        // Fetch failed — keep the defaults already in state.
      });
  }, []);

  // Mobile nav row excludes Home (there's already a dedicated logo/home
  // link above it), matching the bottom nav bar's remaining tabs.
  const navItems = navConfig
    .filter(item => item.to !== '/')
    .map(item => ({
      label: item.label,
      to: item.to,
      icon: resolveIcon(item.icon),
    }));

  // Desktop "Quick Links" column includes Home in addition to the same tabs.
  const quickLinks = [
    { label: 'Home', to: '/', icon: Home },
    ...navItems,
  ];

  return (
    <footer className="bg-dark text-cream/95 overflow-hidden">
      {/* ===================== MOBILE / TABLET ===================== */}
      <div className="lg:hidden">
        <div className="max-w-md mx-auto px-6 sm:px-8 pt-6 pb-10 text-center">
          {/* Logo */}
          <Link to="/" className="inline-block">
            <img
              src={brand.footer_logo}
              alt={`${SITE_SHORT_NAME} — ${BRAND_MOTTO}`}
              className="w-full max-w-[260px] mx-auto h-auto -mb-3"
            />
          </Link>

          {/* Tagline */}
          <p className="mt-4 text-cream/60 text-base leading-relaxed">
            {FOOTER_TAGLINE}
            <br />
            {FOOTER_TAGLINE_SUB}
          </p>

        {/* Social icons */}
        <div className="mt-6 flex items-center justify-center gap-8 sm:gap-10">
          {socialItems.map(({ label, href, external, icon }) => (
            <a
              key={label}
              href={href}
              {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
              aria-label={label}
              className="flex flex-col items-center gap-2 group"
            >
              <span className="w-16 h-16 rounded-full border border-primary/40 flex items-center justify-center text-secondary transition-colors group-hover:bg-primary/10">
                {icon}
              </span>
            </a>
          ))}
        </div>

        {/* Ornamental divider */}
        <div className="mt-6 flex items-center gap-3">
          <span className="h-px flex-1 bg-primary/40" />
          <svg viewBox="0 0 24 24" className="w-4 h-4 text-secondary" fill="currentColor">
            <path d="M12 2c1 3 3 5 6 6-3 1-5 3-6 6-1-3-3-5-6-6 3-1 5-3 6-6z" />
          </svg>
          <span className="h-px flex-1 bg-primary/40" />
        </div>

        {/* Nav row */}
        <div className="mt-8 grid grid-cols-4">
          {navItems.map(({ label, to, icon: Icon }, i) => (
            <Link
              key={to}
              to={to}
              className={`flex flex-col items-center gap-2 px-1 ${i !== 0 ? 'border-l border-white/10' : ''}`}
            >
              <Icon className="w-5 h-5 text-cream" strokeWidth={1.75} />
              <span className="text-xs sm:text-sm leading-tight text-cream">
                {label.split(' ').map((word, idx) => (
                  <span key={idx} className="block">{word}</span>
                ))}
              </span>
            </Link>
          ))}
        </div>

        {/* Contact box */}
        <div className="mt-8 rounded-lg border border-white/10 bg-white/[0.03] py-3.5 px-3 flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
          <a
            href={`mailto:${CONTACT_EMAIL}`}
            className="flex items-center gap-1 text-2xs sm:text-2xs text-cream/95 hover:text-secondary transition-colors whitespace-nowrap shrink-0"
          >
            <Mail className="w-3.5 h-3.5 text-secondary shrink-0" strokeWidth={1.75} />
            {CONTACT_EMAIL}
          </a>
          <span className="h-6 w-px bg-white/10 shrink-0" />
          <a
            href={`tel:${CONTACT_PHONE_E164}`}
            className="flex items-center gap-1 text-2xs sm:text-2xs text-cream/95 hover:text-secondary transition-colors whitespace-nowrap shrink-0"
          >
            <Phone className="w-3.5 h-3.5 text-secondary shrink-0" strokeWidth={1.75} />
            {CONTACT_PHONE_DISPLAY}
          </a>
          <span className="h-6 w-px bg-white/10 shrink-0" />
          <div className="flex items-center gap-1 text-2xs sm:text-2xs text-cream/95 whitespace-nowrap shrink-0">
            <MapPin className="w-3.5 h-3.5 text-secondary shrink-0" strokeWidth={1.75} />
            {FOOTER_REGION}
          </div>
        </div>

          {/* Bottom */}
          <p className="mt-8 text-sm text-cream/60 flex items-center justify-center gap-1.5">
            Made with <Heart className="w-3.5 h-3.5 text-secondary fill-secondary" /> {FOOTER_SIGNOFF}
          </p>
          <p className="mt-2 text-xs text-cream/50">
            © {year} {SITE_SHORT_NAME} · <a href={SITE_ORIGIN} className="hover:text-secondary transition-colors">{SITE_HOST}</a> · All rights reserved.
          </p>
        </div>
      </div>

      {/* ===================== DESKTOP ===================== */}
      <div className="hidden lg:block relative px-6 xl:px-10 py-10">
        <div className="relative max-w-[1344px] mx-auto grid grid-cols-[1.3fr_1fr_1fr_1fr] gap-x-10 xl:gap-x-16">
          {/* Logo + description */}
          <div>
            <Link to="/" className="inline-block">
              <img
                src={brand.footer_logo}
                alt={`${SITE_SHORT_NAME} — ${BRAND_MOTTO}`}
                className="w-full max-w-[210px] h-auto"
              />
            </Link>
            <p className="mt-3 text-cream/60 text-base leading-relaxed max-w-sm">
              {FOOTER_BLURB}
            </p>
          </div>

          {/* Quick Links */}
          <div className="border-l border-white/10 pl-10 xl:pl-14">
            <h3 className="text-secondary text-sm font-button font-semibold tracking-[0.15em] uppercase">
              Quick Links
            </h3>
            <span className="mt-2 block w-8 h-px bg-secondary" />
            <ul className="mt-4 space-y-5">
              {quickLinks.map(({ label, to, icon: Icon }) => (
                <li key={to}>
                  <Link
                    to={to}
                    className="group flex items-center gap-2.5 text-cream/90 hover:text-secondary transition-colors text-base"
                  >
                    <Icon className="w-4 h-4 text-secondary shrink-0" strokeWidth={1.75} />
                    {label}
                    <ChevronRight
                      className="w-4 h-4 text-cream/40 group-hover:text-secondary group-hover:translate-x-0.5 transition-all"
                      strokeWidth={2}
                    />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="border-l border-white/10 pl-10 xl:pl-14">
            <h3 className="text-secondary text-sm font-button font-semibold tracking-[0.15em] uppercase">
              Contact
            </h3>
            <span className="mt-2 block w-8 h-px bg-secondary" />
            <ul className="mt-4 space-y-5 text-base">
              <li>
                <a
                  href={`mailto:${CONTACT_EMAIL}`}
                  className="flex items-center gap-2.5 text-cream/90 hover:text-secondary transition-colors"
                >
                  <Mail className="w-4 h-4 text-secondary shrink-0" strokeWidth={1.75} />
                  {CONTACT_EMAIL}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${CONTACT_PHONE_E164}`}
                  className="flex items-center gap-2.5 text-cream/90 hover:text-secondary transition-colors"
                >
                  <Phone className="w-4 h-4 text-secondary shrink-0" strokeWidth={1.75} />
                  {CONTACT_PHONE_DISPLAY}
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-cream/90">
                <MapPin className="w-4 h-4 text-secondary shrink-0 mt-0.5" strokeWidth={1.75} />
                {FOOTER_REGION_LONG}
              </li>
            </ul>
          </div>

          {/* Follow Us */}
          <div className="border-l border-white/10 pl-10 xl:pl-14">
            <h3 className="text-secondary text-sm font-button font-semibold tracking-[0.15em] uppercase">
              Follow Us
            </h3>
            <span className="mt-2 block w-8 h-px bg-secondary" />
            <div className="mt-4 flex items-center gap-3">
              {socialItems.map(({ label, href, external, icon }) => (
                <a
                  key={label}
                  href={href}
                  {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                  aria-label={label}
                  className="w-11 h-11 rounded-full border border-primary/40 flex items-center justify-center text-cream/90 hover:text-secondary hover:bg-primary/10 transition-colors"
                >
                  {icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="relative max-w-[1344px] mx-auto mt-8 pt-5 border-t border-white/10 flex items-center justify-center gap-3 text-sm text-cream/60">
          <span className="flex items-center gap-1.5">
            Made with <Heart className="w-3.5 h-3.5 text-secondary fill-secondary" /> {FOOTER_SIGNOFF}
          </span>
          <span className="h-3.5 w-px bg-white/15" />
          <span>© {year} {SITE_SHORT_NAME} · <a href={SITE_ORIGIN} className="hover:text-secondary transition-colors">{SITE_HOST}</a> · All rights reserved.</span>
        </div>
      </div>
    </footer>
  );
}
