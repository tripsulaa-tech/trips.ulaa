﻿import { useState, type MouseEvent } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  List as Menu,
  X,
} from '@phosphor-icons/react';
import Button from '../ui/Button';
import { useAuth } from '../../context/useAuth';

const navLinks = [
  { label: 'Home', to: '/' },
  { label: 'Upcoming Trips', to: '/trips' },
  { label: 'Completed Trips', to: '/completed-trips' },
  { label: 'About', to: '/about' },
  { label: 'Contact', to: '/contact' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();

  // Close the mobile menu whenever the route changes. Adjusted during render
  // (rather than in an effect) to avoid an extra cascading render.
  const [prevLocationKey, setPrevLocationKey] = useState(location.key);
  if (location.key !== prevLocationKey) {
    setPrevLocationKey(location.key);
    if (isOpen) setIsOpen(false);
  }

  const handleLogoClick = (e: MouseEvent) => {
    // Admin-only: toggle logo between the public home page and the admin dashboard.
    if (!user) return;
    e.preventDefault();
    if (location.pathname === '/') {
      navigate('/admin');
    } else {
      navigate('/');
    }
  };

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-40 transition-all duration-400 bg-white/95 backdrop-blur-md border-b border-background-warm shadow-card px-4 sm:px-6 lg:px-8"
    >
      <nav className="max-w-[1344px] mx-auto">
        <div className="flex items-center justify-between h-20 py-2">
          <Link to="/" onClick={handleLogoClick} className="flex items-center gap-3 group">
            <img
              src="/ULAA-logo.png"
              alt="ULAA Logo"
              className="h-14 sm:h-16 w-auto transition-transform duration-300 group-hover:scale-105"
            />
          </Link>

          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map(({ label, to }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) => `
                  relative font-body text-sm font-medium transition-colors duration-200
                  ${isActive ? 'text-primary' : 'text-dark hover:text-primary'}
                  after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-0.5
                  after:bg-primary after:transition-all after:duration-200
                  hover:after:w-full
                  ${isActive ? 'after:w-full' : ''}
                `}
              >
                {label}
              </NavLink>
            ))}
          </div>

          <div className="hidden lg:block">
            <Link to="/trips">
              <Button variant="primary" size="sm">
                Book Now
              </Button>
            </Link>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2.5 rounded-lg transition-colors text-dark hover:bg-background min-w-[44px] min-h-[44px] flex items-center justify-center"
            aria-label={isOpen ? 'Close menu' : 'Open menu'}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="lg:hidden bg-white border-t border-background-warm overflow-hidden"
          >
            <div className="px-4 py-6 space-y-1">
              {navLinks.map(({ label, to }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/'}
                  className={({ isActive }) => `
                    block px-4 py-3.5 min-h-[44px] flex items-center rounded-lg font-body font-medium text-base transition-colors
                    ${isActive ? 'text-primary bg-background-warm' : 'text-dark hover:bg-background-warm hover:text-primary'}
                  `}
                >
                  {label}
                </NavLink>
              ))}
              <div className="pt-2">
                <Link to="/trips" className="block">
                  <Button variant="primary" size="md" fullWidth>
                    Book Now
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
