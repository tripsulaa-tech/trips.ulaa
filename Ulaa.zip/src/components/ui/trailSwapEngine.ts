// Pure game logic for "Trail Swap" (match-3). No React, no DOM.

export const ROWS = 8;
export const COLS = 8;
export const KINDS = 6;

export type Special = 'none' | 'heli' | 'color';
export interface Cell { id: number; kind: number; special: Special }
export type Grid = (Cell | null)[][];
export interface Pos { r: number; c: number }

let nextId = 1;
export const newId = () => nextId++;
const rand = (n: number) => Math.floor(Math.random() * n);
const mk = (kind: number, special: Special = 'none'): Cell => ({ id: newId(), kind, special });

export const adjacent = (a: Pos, b: Pos) => Math.abs(a.r - b.r) + Math.abs(a.c - b.c) === 1;

export function cloneGrid(g: Grid): Grid { return g.map(row => row.slice()); }

/** A fresh board with no matches already on it and at least one move. */
export function createGrid(): Grid {
  for (;;) {
    const g: Grid = Array.from({ length: ROWS }, () => Array<Cell | null>(COLS).fill(null));
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        let kind: number;
        do {
          kind = rand(KINDS);
        } while (
          (c >= 2 && g[r][c - 1]?.kind === kind && g[r][c - 2]?.kind === kind) ||
          (r >= 2 && g[r - 1][c]?.kind === kind && g[r - 2][c]?.kind === kind)
        );
        g[r][c] = mk(kind);
      }
    }
    if (findMove(g)) return g;
  }
}

export interface Run { cells: Pos[]; horizontal: boolean }

/** Every horizontal/vertical run of 3+ same-kind cells. */
export function findRuns(g: Grid): Run[] {
  const runs: Run[] = [];
  for (let r = 0; r < ROWS; r++) {
    let c = 0;
    while (c < COLS) {
      const k = g[r][c]?.kind;
      let e = c + 1;
      while (k !== undefined && e < COLS && g[r][e]?.kind === k) e++;
      if (k !== undefined && e - c >= 3) runs.push({ horizontal: true, cells: Array.from({ length: e - c }, (_, i) => ({ r, c: c + i })) });
      c = Math.max(e, c + 1);
    }
  }
  for (let c = 0; c < COLS; c++) {
    let r = 0;
    while (r < ROWS) {
      const k = g[r][c]?.kind;
      let e = r + 1;
      while (k !== undefined && e < ROWS && g[e][c]?.kind === k) e++;
      if (k !== undefined && e - r >= 3) runs.push({ horizontal: false, cells: Array.from({ length: e - r }, (_, i) => ({ r: r + i, c })) });
      r = Math.max(e, r + 1);
    }
  }
  return runs;
}

const key = (p: Pos) => p.r * COLS + p.c;

function swapInPlace(g: Grid, a: Pos, b: Pos) {
  const t = g[a.r][a.c];
  g[a.r][a.c] = g[b.r][b.c];
  g[b.r][b.c] = t;
}

/** Would swapping a and b do anything (a match, or a colour tile)? */
export function isValidSwap(g: Grid, a: Pos, b: Pos): boolean {
  const ca = g[a.r][a.c], cb = g[b.r][b.c];
  if (!ca || !cb) return false;
  if (ca.special === 'color' || cb.special === 'color') return true;
  const t = cloneGrid(g);
  swapInPlace(t, a, b);
  return findRuns(t).length > 0;
}

/** First valid move on the board, scanning right/down neighbours. */
export function findMove(g: Grid): [Pos, Pos] | null {
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const a = { r, c };
      for (const b of [{ r, c: c + 1 }, { r: r + 1, c }]) {
        if (b.r < ROWS && b.c < COLS && isValidSwap(g, a, b)) return [a, b];
      }
    }
  }
  return null;
}

/** Reshuffles the existing tiles until there is a move and no ready matches. */
export function shuffleGrid(g: Grid): Grid {
  const cells = g.flat().filter((x): x is Cell => !!x);
  for (let tries = 0; tries < 200; tries++) {
    for (let i = cells.length - 1; i > 0; i--) {
      const j = rand(i + 1);
      [cells[i], cells[j]] = [cells[j], cells[i]];
    }
    const out: Grid = Array.from({ length: ROWS }, (_, r) => cells.slice(r * COLS, r * COLS + COLS));
    if (findRuns(out).length === 0 && findMove(out)) return out;
  }
  return createGrid();
}

export interface Step {
  /** Cells that pop this step (includes chain-reaction clears). */
  cleared: Pos[];
  /** Cells that turn into a special instead of popping. */
  created: Array<Pos & { special: Special }>;
  points: number;
  cascade: number;
  usedSpecial: boolean;
  /** Helicopters that fly from one tile to another before it pops. */
  flights: Array<{ from: Pos; to: Pos }>;
}

/** Works out what one match round clears, given where the player swapped. */
export function planStep(g: Grid, cascade: number, swapped: Pos[] = [], forcedColor?: { at: Pos; kind: number }): Step | null {
  const runs = findRuns(g);
  const clear = new Set<number>();
  const created: Array<Pos & { special: Special }> = [];
  const keep = new Set<number>();

  // Specials made by 4- and 5-runs (placed where the player swapped, else the middle).
  for (const run of runs) {
    if (run.cells.length < 4) continue;
    const spot = run.cells.find(p => swapped.some(s => s.r === p.r && s.c === p.c)) ?? run.cells[Math.floor(run.cells.length / 2)];
    const special: Special = run.cells.length >= 5 ? 'color' : 'heli';
    if (keep.has(key(spot))) continue;
    keep.add(key(spot));
    created.push({ ...spot, special });
  }
  for (const run of runs) for (const p of run.cells) clear.add(key(p));

  if (forcedColor) {
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      if (g[r][c]?.kind === forcedColor.kind) clear.add(r * COLS + c);
    }
    clear.add(key(forcedColor.at));
  }
  if (clear.size === 0) return null;

  // Chain reaction: specials caught in the clear fire their effect.
  let usedSpecial = !!forcedColor;
  const flights: Array<{ from: Pos; to: Pos }> = [];
  const queue = [...clear];
  const fired = new Set<number>();
  while (queue.length) {
    const k = queue.pop() as number;
    if (fired.has(k)) continue;
    fired.add(k);
    const r = Math.floor(k / COLS), c = k % COLS;
    const cell = g[r][c];
    if (!cell || cell.special === 'none' || keep.has(k)) continue;
    usedSpecial = true;
    const add = (rr: number, cc: number) => { if (rr < 0 || rr >= ROWS || cc < 0 || cc >= COLS) return; const kk = rr * COLS + cc; if (!clear.has(kk)) { clear.add(kk); queue.push(kk); } };
    if (cell.special === 'heli') {
      // Clears the four neighbours, then flies to a random tile and clears it too.
      add(r - 1, c); add(r + 1, c); add(r, c - 1); add(r, c + 1);
      const pool: Pos[] = [];
      for (let rr = 0; rr < ROWS; rr++) for (let cc = 0; cc < COLS; cc++) {
        const kk = rr * COLS + cc;
        if (g[rr][cc] && !clear.has(kk) && !keep.has(kk)) pool.push({ r: rr, c: cc });
      }
      if (pool.length) {
        const to = pool[rand(pool.length)];
        flights.push({ from: { r, c }, to });
        add(to.r, to.c);
      }
    } else {
      for (let rr = 0; rr < ROWS; rr++) for (let cc = 0; cc < COLS; cc++) if (g[rr][cc]?.kind === cell.kind) add(rr, cc);
    }
  }
  for (const k of keep) clear.delete(k);

  const cleared = [...clear].map(k => ({ r: Math.floor(k / COLS), c: k % COLS }));
  const bonus = usedSpecial ? 1.5 : 1;
  const points = Math.round(cleared.length * 10 * cascade * bonus) + created.length * 20;
  return { cleared, created, points, cascade, usedSpecial, flights };
}

/** Removes cleared cells, applies created specials. */
export function applyStep(g: Grid, step: Step): Grid {
  const out = cloneGrid(g);
  for (const p of step.cleared) out[p.r][p.c] = null;
  for (const p of step.created) {
    const base = g[p.r][p.c];
    if (base) out[p.r][p.c] = { id: base.id, kind: base.kind, special: p.special };
  }
  return out;
}

export interface Fall { id: number; fromR: number }

/** Drops tiles into gaps and fills the top with new ones. `spawned` maps each
 *  new tile id to the (negative) row it should enter from. */
export function collapse(g: Grid): { grid: Grid; spawned: Map<number, number> } {
  const out: Grid = Array.from({ length: ROWS }, () => Array<Cell | null>(COLS).fill(null));
  const spawned = new Map<number, number>();
  for (let c = 0; c < COLS; c++) {
    let write = ROWS - 1;
    for (let r = ROWS - 1; r >= 0; r--) {
      const cell = g[r][c];
      if (cell) { out[write][c] = cell; write--; }
    }
    const missing = write + 1;
    for (let r = write; r >= 0; r--) {
      const cell = mk(rand(KINDS));
      out[r][c] = cell;
      spawned.set(cell.id, r - missing);
    }
  }
  return { grid: out, spawned };
}

/** Swaps and returns the new grid, plus the colour-tile effect if any. */
export function doSwap(g: Grid, a: Pos, b: Pos): { grid: Grid; forcedColor?: { at: Pos; kind: number } } {
  const out = cloneGrid(g);
  const ca = out[a.r][a.c], cb = out[b.r][b.c];
  let forcedColor: { at: Pos; kind: number } | undefined;
  if (ca?.special === 'color' && cb) forcedColor = { at: a, kind: cb.kind };
  else if (cb?.special === 'color' && ca) forcedColor = { at: b, kind: ca.kind };
  swapInPlace(out, a, b);
  if (forcedColor) {
    // The colour tile sits where it was moved to.
    forcedColor = { at: ca?.special === 'color' ? b : a, kind: forcedColor.kind };
  }
  return { grid: out, forcedColor };
}
