import { useEffect, useRef, useState } from 'react';
import {
  MagnifyingGlass as Search,
  X,
  CaretUp as ChevronUp,
  CaretDown as ChevronDown,
  CaretLeft,
  CaretRight,
  Phone,
  Envelope as Mail,
  Download,
} from '@phosphor-icons/react';
import { getWhatsAppLink } from '../../utils/utils-index';
import type { SortDirection } from './dataTableUtils';

// Shared "table card" header — title + live "Showing X–Y of N" subtitle on
// the left, search bar aligned to the right in the same row. Used by both
// AdminEnquiries and AdminWaitlist so their table cards look and behave
// identically (title row lives *inside* the card, above the table itself,
// with the search box that used to live in the filter bar now living here
// instead).
interface TableHeaderBarProps {
  title: string;
  rangeStart: number;
  rangeEnd: number;
  total: number;
  itemLabel: string;
  searchValue: string;
  onSearchChange: (value: string) => void;
  searchPlaceholder?: string;
  // Optional — pages that support CSV export pass a handler here and get an
  // "Export CSV" button next to the search box for free. Omitted entirely
  // (not just disabled) on pages that don't wire it up.
  onExport?: () => void;
  exportLabel?: string;
}

export function TableHeaderBar({
  title,
  rangeStart,
  rangeEnd,
  total,
  itemLabel,
  searchValue,
  onSearchChange,
  searchPlaceholder = 'Search...',
  onExport,
  exportLabel = 'Export CSV',
}: TableHeaderBarProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 sm:px-5 pt-4 sm:pt-5 pb-4">
      <div className="flex items-baseline flex-wrap gap-x-2 gap-y-0.5 min-w-0">
        <h2 className="font-button font-bold text-dark text-base truncate">{title}</h2>
        <p className="text-dark-muted text-xs whitespace-nowrap">
          {total === 0 ? `No ${itemLabel.toLowerCase()} found` : `Showing ${rangeStart}\u2013${rangeEnd} of ${total} ${itemLabel}`}
        </p>
      </div>
      <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
        <div className="relative flex-1 sm:w-72">
          <label htmlFor={`table-search-${title.replace(/\s+/g, '-').toLowerCase()}`} className="sr-only">{searchPlaceholder}</label>
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-muted pointer-events-none" aria-hidden="true" />
          <input
            id={`table-search-${title.replace(/\s+/g, '-').toLowerCase()}`}
            type="text"
            value={searchValue}
            onChange={ev => onSearchChange(ev.target.value)}
            placeholder={searchPlaceholder}
            className="w-full pl-9 pr-8 py-1.5 rounded-md border-2 border-background-warm bg-background font-body text-dark text-sm focus:border-primary outline-none transition-colors"
          />
          {searchValue && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-dark-muted hover:text-dark"
              aria-label="Clear search"
            >
              <X size={14} aria-hidden="true" />
            </button>
          )}
        </div>
        {onExport && (
          <button
            onClick={onExport}
            disabled={total === 0}
            title={total === 0 ? 'Nothing to export' : `${exportLabel} — exports exactly what's currently filtered`}
            aria-label={exportLabel}
            className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border-2 border-background-warm text-dark text-sm font-button font-semibold hover:border-primary/40 hover:text-primary disabled:opacity-40 disabled:hover:border-background-warm disabled:hover:text-dark transition-colors"
          >
            <Download size={14} aria-hidden="true" />
            <span className="hidden sm:inline">{exportLabel}</span>
          </button>
        )}
      </div>
    </div>
  );
}

// Mobile card-list footer: "Showing X–Y of N" summary line + Prev/Next
// pagination underneath, wrapped in the same white card. Used by both
// AdminEnquiriesMobileCards and AdminWaitlistMobileCards so their footers
// stay identical. The summary line gets real breathing room below it
// (pb-3.5, on top of TablePagination's own top padding) instead of the
// text nearly touching the border above the buttons, and the actual
// counts (the range and the total) are set apart from the surrounding
// "Showing"/"of"/itemLabel words — bolder and darker — so the numbers a
// person actually scans for are the first thing that stands out.
interface MobilePaginationFooterProps {
  rangeStart: number;
  rangeEnd: number;
  total: number;
  itemLabel: string;
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function MobilePaginationFooter({
  rangeStart,
  rangeEnd,
  total,
  itemLabel,
  currentPage,
  totalPages,
  onPageChange,
}: MobilePaginationFooterProps) {
  return (
    <div className="sm:hidden bg-white rounded-lg shadow-card overflow-hidden">
      <p className="text-dark-muted text-xs text-center px-4 pt-3 pb-3.5">
        {total === 0 ? (
          `No ${itemLabel} found`
        ) : (
          <>
            Showing{' '}
            <span className="font-button font-semibold text-dark">
              {rangeStart}&ndash;{rangeEnd}
            </span>{' '}
            of <span className="font-button font-semibold text-dark">{total}</span> {itemLabel}
          </>
        )}
      </p>
      <TablePagination currentPage={currentPage} totalPages={totalPages} onPageChange={onPageChange} />
    </div>
  );
}

// Builds the "1 2 3 … 20" (or, given enough room, the full "1 2 3 4 5 6 7")
// page-number window shown between Prev/Next — always keeps first, last,
// current, and current's immediate neighbours, collapsing everything else
// behind an ellipsis once the list can't fit within `maxVisible` slots.
// `maxVisible` is computed from the actual available row width (see
// TablePagination below), so on a wide desktop table this naturally shows
// every page number, while a narrow phone-width row still collapses down
// to the compact windowed form instead of forcing Prev/Next off-screen.
function getPageWindow(current: number, total: number, maxVisible: number): (number | 'ellipsis')[] {
  if (total <= maxVisible) return Array.from({ length: total }, (_, i) => i + 1);

  // Reserve slots for the first page, the last page, and (worst case) the
  // two ellipsis markers between them; whatever's left of the budget is
  // split evenly as "sibling" pages shown on either side of current.
  const reserved = 4;
  const siblingBudget = Math.max(1, maxVisible - reserved);
  const siblingCount = Math.max(1, Math.floor(siblingBudget / 2));

  const pages = new Set<number>([1, total, current]);
  for (let i = 1; i <= siblingCount; i++) {
    if (current - i >= 1) pages.add(current - i);
    if (current + i <= total) pages.add(current + i);
  }
  const sorted = Array.from(pages).sort((a, b) => a - b);
  const result: (number | 'ellipsis')[] = [];
  sorted.forEach((p, i) => {
    if (i > 0 && p - sorted[i - 1] > 1) result.push('ellipsis');
    result.push(p);
  });
  return result;
}

interface TablePaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

// Approx width (px) of one page-number pill (min-w-[34px] pill + the row's
// gap-1.5/gap-2 spacing) — used to work out how many pills the available
// row width can actually hold before falling back to the collapsed window.
const PILL_SLOT_PX = 40;

// Prev and Next live outside the scrollable region (shrink-0, never inside
// the overflow-x-auto strip) so they can never get scrolled out of view or
// clipped — that was the bug: a flat-out row of page pills + Prev + Next
// with `justify-end` + `overflow-x-auto` pinned Next fully in view and left
// Prev hanging off the edge on narrow screens. Now only the page-number
// pills scroll (and only if the window genuinely can't fit), the active
// page auto-scrolls into view, and the number of pills shown adapts to
// whatever room the row actually has (via ResizeObserver below) instead of
// always collapsing past 5 pages — a wide desktop table shows every page
// number, a narrow one still collapses down to keep Prev/Next on-screen.
export function TablePagination({ currentPage, totalPages, onPageChange }: TablePaginationProps) {
  const activePageRef = useRef<HTMLButtonElement>(null);
  const pagesContainerRef = useRef<HTMLDivElement>(null);
  const [maxVisible, setMaxVisible] = useState(5);

  useEffect(() => {
    const el = pagesContainerRef.current;
    if (!el) return;
    const updateMaxVisible = () => setMaxVisible(Math.max(5, Math.floor(el.clientWidth / PILL_SLOT_PX)));
    updateMaxVisible();
    const observer = new ResizeObserver(updateMaxVisible);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    activePageRef.current?.scrollIntoView({ block: 'nearest', inline: 'center' });
  }, [currentPage]);

  if (totalPages <= 1) return null;
  const pages = getPageWindow(currentPage, totalPages, maxVisible);
  return (
    <nav
      aria-label="Table pagination"
      className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-5 py-3.5 border-t border-background-warm"
    >
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        aria-label="Previous page"
        className="shrink-0 inline-flex items-center gap-1 text-xs font-button font-semibold pl-2 pr-2.5 sm:px-3 h-9 rounded-md border-2 border-background-warm text-dark hover:border-primary/30 disabled:text-dark-muted/40 disabled:hover:border-background-warm disabled:cursor-default transition-colors"
      >
        <CaretLeft size={12} weight="bold" aria-hidden="true" />
        <span className="hidden sm:inline">Prev</span>
      </button>

      <div ref={pagesContainerRef} className="flex-1 min-w-0 flex items-center justify-center gap-1.5 overflow-x-auto scrollbar-hide">
        {pages.map((p, i) =>
          p === 'ellipsis' ? (
            <span key={`ellipsis-${i}`} className="shrink-0 px-0.5 text-dark-muted text-xs select-none">
              &hellip;
            </span>
          ) : (
            <button
              key={p}
              ref={p === currentPage ? activePageRef : undefined}
              onClick={() => onPageChange(p)}
              aria-current={p === currentPage ? 'page' : undefined}
              aria-label={`Page ${p}`}
              className={`shrink-0 min-w-[34px] h-9 px-2 inline-flex items-center justify-center text-xs font-button font-semibold rounded-md border-2 transition-colors ${
                p === currentPage
                  ? 'bg-primary border-primary text-white'
                  : 'border-background-warm text-dark hover:border-primary/30'
              }`}
            >
              {p}
            </button>
          )
        )}
      </div>

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        aria-label="Next page"
        className="shrink-0 inline-flex items-center gap-1 text-xs font-button font-semibold pr-2 pl-2.5 sm:px-3 h-9 rounded-md border-2 border-background-warm text-dark hover:border-primary/30 disabled:text-dark-muted/40 disabled:hover:border-background-warm disabled:cursor-default transition-colors"
      >
        <span className="hidden sm:inline">Next</span>
        <CaretRight size={12} weight="bold" aria-hidden="true" />
      </button>
    </nav>
  );
}

// paginate() and SortDirection moved to dataTableUtils.ts alongside useDragScroll.

// Clickable column header with an up/down indicator — the up arrow lights
// up when that column is the active ascending sort, the down arrow when
// it's the active descending sort, so the current state is visible at a
// glance rather than just on hover.
interface SortableThProps<K extends string> {
  label: string;
  sortKey: K;
  activeKey: K | null;
  direction: SortDirection;
  onSort: (key: K) => void;
  className?: string;
}

export function SortableTh<K extends string>({ label, sortKey, activeKey, direction, onSort, className = '' }: SortableThProps<K>) {
  const isActive = activeKey === sortKey;
  const ariaSort: 'ascending' | 'descending' | 'none' = isActive
    ? (direction === 'asc' ? 'ascending' : 'descending')
    : 'none';
  const nextDirectionLabel = isActive && direction === 'asc' ? 'descending' : 'ascending';
  return (
    <th className={className} aria-sort={ariaSort}>
      <button
        type="button"
        onClick={() => onSort(sortKey)}
        aria-label={`Sort by ${label}, ${nextDirectionLabel}`}
        className="inline-flex items-center gap-1 hover:text-primary transition-colors"
      >
        <span>{label}</span>
        <span className="flex flex-col justify-center leading-none" aria-hidden="true">
          <ChevronUp size={10} className={`-mb-0.5 ${isActive && direction === 'asc' ? 'text-primary' : 'text-dark-muted/30'}`} />
          <ChevronDown size={10} className={isActive && direction === 'desc' ? 'text-primary' : 'text-dark-muted/30'} />
        </span>
      </button>
    </th>
  );
}

// Reach-out shortcuts shown next to a lead/waitlist row's phone and email —
// tel:, mailto:, and a WhatsApp deep-link prefilled with a short templated
// message. Shared by AdminEnquiries and AdminWaitlist so both tables get
// identical behavior instead of each hand-rolling its own contact markup.
// Stops propagation on click so this can sit inside a clickable row without
// also triggering the row's own click handler (e.g. "open details").
interface ContactQuickLinksProps {
  phone?: string | null;
  email?: string | null;
  // First-name only is plenty for a WhatsApp opener and keeps the
  // prefilled text from reading like a form letter.
  name?: string | null;
  tripTitle?: string | null;
  size?: 'sm' | 'md';
}

export function ContactQuickLinks({ phone, email, name, tripTitle, size = 'sm' }: ContactQuickLinksProps) {
  const hasPhone = !!phone && phone.trim().length > 0;
  const hasEmail = !!email && email.trim().length > 0;
  if (!hasPhone && !hasEmail) return null;

  const dim = size === 'sm' ? 'w-6 h-6' : 'w-7 h-7';
  const iconSize = size === 'sm' ? 12 : 13;
  const firstName = name?.trim().split(/\s+/)[0];
  const greeting = firstName ? `Hi ${firstName}` : 'Hi';
  const whatsappMessage = tripTitle
    ? `${greeting}, following up on your ${tripTitle} enquiry with ULAA — `
    : `${greeting}, following up on your enquiry with ULAA — `;

  const btnClass = `shrink-0 inline-flex items-center justify-center ${dim} rounded-full border border-background-warm text-dark-muted hover:border-primary/40 hover:text-primary transition-colors`;

  // Labels include the person's name (falling back to a generic form when
  // no name was passed in) so that repeated rows of these icon-only links
  // — one set per person in a table — are distinguishable from one another
  // to a screen reader user, not just "Call" / "Email" with no indication
  // of which row it belongs to.
  const whatsappLabel = name ? `Message ${name} on WhatsApp` : 'Message on WhatsApp';
  const callLabel = name ? `Call ${name}` : 'Call';
  const emailLabel = name ? `Email ${name}` : 'Email';

  return (
    <span className="inline-flex items-center gap-1" onClick={e => e.stopPropagation()}>
      {hasPhone && (
        <a
          href={getWhatsAppLink(phone!, whatsappMessage)}
          target="_blank"
          rel="noopener noreferrer"
          title={whatsappLabel}
          aria-label={whatsappLabel}
          className={btnClass}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" width={iconSize} height={iconSize}>
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
          </svg>
        </a>
      )}
      {hasPhone && (
        <a href={`tel:${phone}`} title={callLabel} aria-label={callLabel} className={btnClass}>
          <Phone size={iconSize} aria-hidden="true" />
        </a>
      )}
      {hasEmail && (
        <a href={`mailto:${email}`} title={emailLabel} aria-label={emailLabel} className={btnClass}>
          <Mail size={iconSize} aria-hidden="true" />
        </a>
      )}
    </span>
  );
}
