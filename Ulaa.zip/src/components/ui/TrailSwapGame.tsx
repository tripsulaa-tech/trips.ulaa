import { useCallback, useEffect, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import {
  Play, ArrowCounterClockwise, ShareNetwork, Star, Trophy, SpeakerHigh, SpeakerSlash, Path,
  Backpack, Compass, Mountains, Camera, Tent, Campfire, Sparkle, ArrowsLeftRight, SignOut, Fire,
} from '@phosphor-icons/react';
import type { Icon as PhosphorIcon } from '@phosphor-icons/react';
import Modal from './Modal';
import { SITE_HOST, SITE_ORIGIN } from '../../constants/site';
import { getWhatsAppLink } from '../../utils/utils-index';
import { buildScoreCard } from './packBagScoreCard';
import { useSynth } from './gameAudio';
import { haptic } from './haptics';
import { ScoreRing, Confetti, GameTile, NameField, BrandMark } from './gameParts';
import { GOLD_GRAD_TEXT, primaryBtn, ghostBtn, glass, eyebrow, shareCardImage, cleanName, loadPlayerName, savePlayerName } from './gameUi';
import {
  ROWS, COLS, createGrid, cloneGrid, adjacent, isValidSwap, findMove, shuffleGrid, planStep,
  applyStep, collapse, doSwap,
} from './trailSwapEngine';
import type { Grid, Pos, Special } from './trailSwapEngine';

// "Trail Swap": an original match-3 puzzle in Ulaa's travel style. Swap two
// neighbouring tiles (tap, tap, or drag) to line up 3+ of a kind. Four in a
// row turns a tile into a Helicopter (clears its neighbours, then flies off and
// clears one more tile), five makes a golden Sparkle (clears one whole kind). Chain cascades for a multiplier.
// You get a fixed number of moves; invalid swaps are free and bounce back.
// Front-end only: best score and sound setting live in localStorage.

// Phosphor has no helicopter, so this one is drawn here (filled, currentColor).
function Helicopter({ className, size, ...rest }: { className?: string; size?: number | string; weight?: string; 'aria-label'?: string; 'aria-hidden'?: boolean | 'true' }) {
  const label = rest['aria-label'];
  return (
    <svg viewBox="0 0 64 64" width={size} height={size} className={className} fill="currentColor" role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true}>
      <rect x="6" y="9" width="44" height="3.5" rx="1.75" />
      <rect x="26" y="12" width="4" height="7" />
      <ellipse cx="28" cy="31" rx="16" ry="12" />
      <path d="M40 27 L58 23 L58 29 L40 35 Z" />
      <rect x="55.5" y="15" width="3.5" height="16" rx="1.75" />
      <path d="M13 29 Q15 21 25 21 V31 H13 Z" fill="rgba(0,0,0,0.28)" />
      <rect x="22" y="42" width="3.5" height="7" />
      <rect x="34" y="42" width="3.5" height="7" />
      <rect x="12" y="48" width="32" height="3.5" rx="1.75" />
    </svg>
  );
}

const MOVES = 25;
const STAR_AT = [1200, 2400];     // score for 2 and 3 stars
const RING_MAX = 3000;
const MUTE_KEY = 'ulaa:packbag:muted'; // one sound setting for every game
const HINT_AFTER = 6000;

const KINDS_UI: Array<{ Icon: PhosphorIcon; label: string; tile: string }> = [
  { Icon: Backpack, label: 'Backpack', tile: 'from-[#F7E08F] to-[#C8962A] text-dark' },
  { Icon: Compass, label: 'Compass', tile: 'from-[#E9A05C] to-[#A85A2A] text-white' },
  { Icon: Mountains, label: 'Mountains', tile: 'from-[#8FD694] to-[#3E8F4A] text-white' },
  { Icon: Camera, label: 'Camera', tile: 'from-[#8CCBE8] to-[#3A86AE] text-white' },
  { Icon: Tent, label: 'Tent', tile: 'from-[#F2A3A3] to-[#C45A66] text-white' },
  { Icon: Campfire, label: 'Campfire', tile: 'from-[#BBA5EE] to-[#7254B8] text-white' },
];

function rating(score: number): { title: string; blurb: string; stars: number } {
  if (score >= STAR_AT[1]) return { title: 'Ulaa Trailblazer', blurb: 'Every swap counted. What a route!', stars: 3 };
  if (score >= STAR_AT[0]) return { title: 'Seasoned explorer', blurb: 'Great chains. A few more cascades and it is gold.', stars: 2 };
  return { title: 'Fresh explorer', blurb: 'Every trail starts somewhere. Swap again!', stars: 1 };
}

interface Tile { id: number; kind: number; special: Special; r: number; c: number; clearing: boolean }
interface Flyer { id: number; from: Pos; to: Pos }
interface Pop { id: number; x: number; y: number; text: string }

function gridToTiles(g: Grid, spawn?: Map<number, number>, clearing?: Set<number>): Tile[] {
  const out: Tile[] = [];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const cell = g[r][c];
      if (cell) out.push({ id: cell.id, kind: cell.kind, special: cell.special, r: spawn?.get(cell.id) ?? r, c, clearing: !!clearing?.has(cell.id) });
    }
  }
  return out;
}

const sleep = (ms: number) => new Promise<void>(res => window.setTimeout(res, ms));
const frame = () => new Promise<void>(res => requestAnimationFrame(() => requestAnimationFrame(() => res())));

interface TrailSwapGameProps {
  tripId: string;
  tripSlug: string;
  tripTitle: string;
  className?: string;
  compact?: boolean;
  thumb?: boolean;
}

export default function TrailSwapGame({ tripId, tripSlug, tripTitle, className = '', compact = false, thumb = false }: TrailSwapGameProps) {
  const bestKey = `ulaa:trailswap:${tripId}`;
  const reduce = useReducedMotion();
  const [open, setOpen] = useState(false);
  const [phase, setPhase] = useState<'idle' | 'playing' | 'done'>('idle');
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [selected, setSelected] = useState<Pos | null>(null);
  const [hint, setHint] = useState<number[]>([]);
  const [shaking, setShaking] = useState<number[]>([]);
  const [moves, setMoves] = useState(MOVES);
  const [score, setScore] = useState(0);
  const [bestCascade, setBestCascade] = useState(1);
  const [specials, setSpecials] = useState(0);
  const [pops, setPops] = useState<Pop[]>([]);
  const [flyers, setFlyers] = useState<Flyer[]>([]);
  const [banner, setBanner] = useState<{ id: number; text: string } | null>(null);
  const [name, setName] = useState(loadPlayerName);
  const playerName = cleanName(name);
  const [muted, setMuted] = useState<boolean>(() => {
    try { return localStorage.getItem(MUTE_KEY) === '1'; } catch { return false; }
  });
  const [best, setBest] = useState<number>(() => {
    try { return Number(localStorage.getItem(bestKey)) || 0; } catch { return 0; }
  });
  const [prevBest, setPrevBest] = useState(0);
  const [isNewBest, setIsNewBest] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [sharing, setSharing] = useState(false);
  const [idleTick, setIdleTick] = useState(0);

  const gridRef = useRef<Grid>([]);
  const busyRef = useRef(false);
  const runRef = useRef(0);          // bumps to cancel in-flight animations
  const movesRef = useRef(MOVES);
  const scoreRef = useRef(0);
  const cascadeRef = useRef(1);
  const specialsRef = useRef(0);
  const popId = useRef(1);
  const mutedRef = useRef(muted);
  const boardRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{ pos: Pos; x: number; y: number; done: boolean } | null>(null);
  const cardBlobRef = useRef<Blob | null>(null);
  const previewUrlRef = useRef<string | null>(null);
  const { ensure, play, onPressCapture } = useSynth(mutedRef);

  const fall = reduce ? 0 : 260;
  const popMs = reduce ? 0 : 190;

  const toggleMute = () => {
    const next = !muted;
    mutedRef.current = next;
    setMuted(next);
    try { localStorage.setItem(MUTE_KEY, next ? '1' : '0'); } catch { /* not remembered */ }
    if (!next) { ensure(); play('tick'); }
  };

  const showPop = (cells: Pos[], text: string) => {
    const x = (cells.reduce((s, p) => s + p.c, 0) / cells.length + 0.5) / COLS * 100;
    const y = (cells.reduce((s, p) => s + p.r, 0) / cells.length + 0.5) / ROWS * 100;
    const id = popId.current++;
    setPops(p => [...p, { id, x, y, text }]);
    window.setTimeout(() => setPops(p => p.filter(q => q.id !== id)), 800);
  };

  const finish = useCallback(() => {
    const final = scoreRef.current;
    setPrevBest(best);
    if (final > best) {
      setIsNewBest(best > 0);
      setBest(final);
      try { localStorage.setItem(bestKey, String(final)); } catch { /* not remembered */ }
    }
    play(rating(final).stars >= 2 ? 'win' : 'end');
    setPhase('done');
  }, [best, bestKey, play]);

  // Plays out every match, fall and cascade until the board is calm.
  const resolve = useCallback(async (start: Grid, swapped: Pos[], forced?: { at: Pos; kind: number }) => {
    const run = runRef.current;
    let g = start;
    let cascade = 1;
    let fc = forced;
    let sw = swapped;
    for (;;) {
      const step = planStep(g, cascade, sw, fc);
      fc = undefined; sw = [];
      if (!step) break;

      const idOf = (p: Pos) => g[p.r][p.c]?.id;
      const targetKeys = new Set(step.flights.map(f => f.to.r * COLS + f.to.c));
      const firstIds = new Set(step.cleared.filter(p => !targetKeys.has(p.r * COLS + p.c)).map(idOf).filter((x): x is number => x !== undefined));
      const targetIds = new Set(step.flights.map(f => idOf(f.to)).filter((x): x is number => x !== undefined));
      setTiles(gridToTiles(g, undefined, firstIds));
      play(step.created.length || step.usedSpecial ? 'power' : cascade >= 2 ? 'gold' : 'good');
      if (cascade >= 2 || step.usedSpecial) haptic('gold');
      scoreRef.current += step.points;
      setScore(scoreRef.current);
      cascadeRef.current = Math.max(cascadeRef.current, cascade);
      setBestCascade(cascadeRef.current);
      if (step.created.length) { specialsRef.current += step.created.length; setSpecials(specialsRef.current); }
      showPop(step.cleared, `+${step.points}`);
      if (cascade >= 2) { const id = popId.current++; setBanner({ id, text: `Cascade ×${cascade}` }); window.setTimeout(() => setBanner(b => (b?.id === id ? null : b)), 900); }
      await sleep(popMs);
      if (run !== runRef.current) return;

      if (step.flights.length) {
        // Helicopters take off, land on their target, then it pops.
        const fl = step.flights.map(f => ({ id: popId.current++, from: f.from, to: f.to }));
        setFlyers(fl);
        const flightMs = reduce ? 0 : 380;
        await sleep(flightMs);
        if (run !== runRef.current) return;
        setTiles(gridToTiles(g, undefined, new Set([...firstIds, ...targetIds])));
        play('gold');
        haptic('power');
        await sleep(popMs);
        if (run !== runRef.current) return;
        setFlyers([]);
      }

      g = applyStep(g, step);
      const { grid, spawned } = collapse(g);
      setTiles(gridToTiles(grid, spawned));
      await frame();
      if (run !== runRef.current) return;
      setTiles(gridToTiles(grid));
      await sleep(fall + 40);
      if (run !== runRef.current) return;
      g = grid;
      cascade += 1;
    }

    // Stuck board: reshuffle so the player always has a move.
    if (movesRef.current > 0 && !findMove(g)) {
      g = shuffleGrid(g);
      play('go');
      const id = popId.current++;
      setBanner({ id, text: 'No moves. Shuffling!' });
      window.setTimeout(() => setBanner(b => (b?.id === id ? null : b)), 1200);
      setTiles(gridToTiles(g));
      await sleep(fall + 120);
      if (run !== runRef.current) return;
    }

    gridRef.current = g;
    busyRef.current = false;
    setIdleTick(t => t + 1);
    if (movesRef.current <= 0) {
      await sleep(350);
      if (run !== runRef.current) return;
      finish();
    }
  }, [fall, popMs, reduce, play, finish]);

  const attemptSwap = useCallback(async (a: Pos, b: Pos) => {
    if (busyRef.current || phase !== 'playing') return;
    busyRef.current = true;
    setSelected(null);
    setHint([]);
    const run = runRef.current;
    const g = gridRef.current;
    const ca = g[a.r][a.c], cb = g[b.r][b.c];

    if (!ca || !cb || !isValidSwap(g, a, b)) {
      // Bounce: swap visually, then swap back. Costs nothing.
      play('miss');
      const t = cloneGrid(g);
      t[a.r][a.c] = cb ?? null; t[b.r][b.c] = ca ?? null;
      setTiles(gridToTiles(t));
      await sleep(reduce ? 0 : 170);
      if (run !== runRef.current) return;
      setTiles(gridToTiles(g));
      if (ca && cb) { setShaking([ca.id, cb.id]); window.setTimeout(() => setShaking([]), 350); }
      await sleep(reduce ? 0 : 170);
      busyRef.current = false;
      return;
    }

    movesRef.current -= 1;
    setMoves(movesRef.current);
    haptic('select');
    const { grid, forcedColor } = doSwap(g, a, b);
    setTiles(gridToTiles(grid));
    await sleep(reduce ? 0 : 190);
    if (run !== runRef.current) return;
    await resolve(grid, [a, b], forcedColor);
  }, [phase, play, reduce, resolve]);

  const begin = useCallback(() => {
    ensure();
    savePlayerName(name);
    runRef.current += 1;
    const g = createGrid();
    gridRef.current = g;
    busyRef.current = false;
    movesRef.current = MOVES; scoreRef.current = 0; cascadeRef.current = 1; specialsRef.current = 0;
    setMoves(MOVES); setScore(0); setBestCascade(1); setSpecials(0);
    setSelected(null); setHint([]); setPops([]); setBanner(null); setIsNewBest(false);
    setPreviewUrl(null); cardBlobRef.current = null;
    setTiles(gridToTiles(g));
    play('go');
    setPhase('playing');
  }, [ensure, name, play]);

  // Gentle hint after a few idle seconds.
  useEffect(() => {
    if (phase !== 'playing') return;
    const id = window.setTimeout(() => {
      if (busyRef.current) return;
      const mv = findMove(gridRef.current);
      if (!mv) return;
      const ids = mv.map(p => gridRef.current[p.r][p.c]?.id).filter((x): x is number => x !== undefined);
      setHint(ids);
    }, HINT_AFTER);
    return () => window.clearTimeout(id);
  }, [phase, idleTick]);

  // Score card for the share button, built as soon as the round ends.
  useEffect(() => {
    if (phase !== 'done') return;
    let cancelled = false;
    const rt = rating(score);
    void buildScoreCard({
      score, stars: rt.stars, title: rt.title, tripTitle, host: SITE_HOST, best, isNewBest,
      eyebrow: 'TRAIL SWAP  ·  PUZZLE', ringMax: RING_MAX, playerName,
      tiles: [
        { v: `×${bestCascade}`, l: 'BEST CASCADE' },
        { v: String(specials), l: 'POWER TILES' },
        { v: String(Math.max(best, score)), l: 'PERSONAL BEST' },
      ],
    }).then(blob => {
      if (cancelled || !blob) return;
      cardBlobRef.current = blob;
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
      previewUrlRef.current = URL.createObjectURL(blob);
      setPreviewUrl(previewUrlRef.current);
    }).catch(() => { /* share falls back to text */ });
    return () => { cancelled = true; };
  }, [phase, score, bestCascade, specials, best, isNewBest, tripTitle, playerName]);

  useEffect(() => () => {
    runRef.current += 1;
    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
  }, []);

  // ── Input: tap-tap or drag ──
  const cellAt = (clientX: number, clientY: number): Pos | null => {
    const el = boardRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    const c = Math.floor(((clientX - rect.left) / rect.width) * COLS);
    const r = Math.floor(((clientY - rect.top) / rect.height) * ROWS);
    if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return null;
    return { r, c };
  };

  const onDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (busyRef.current || phase !== 'playing') return;
    const pos = cellAt(e.clientX, e.clientY);
    if (!pos) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    setHint([]);
    if (selected && adjacent(selected, pos)) {
      dragRef.current = null;
      void attemptSwap(selected, pos);
      return;
    }
    dragRef.current = { pos, x: e.clientX, y: e.clientY, done: false };
    setSelected(pos);
    play('flip');
  };

  const onMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    const el = boardRef.current;
    if (!d || d.done || !el || busyRef.current) return;
    const cell = el.getBoundingClientRect().width / COLS;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < cell * 0.4) return;
    d.done = true;
    const target = Math.abs(dx) > Math.abs(dy)
      ? { r: d.pos.r, c: d.pos.c + (dx > 0 ? 1 : -1) }
      : { r: d.pos.r + (dy > 0 ? 1 : -1), c: d.pos.c };
    if (target.r < 0 || target.r >= ROWS || target.c < 0 || target.c >= COLS) return;
    void attemptSwap(d.pos, target);
  };

  const onUp = () => { dragRef.current = null; };

  const close = () => { runRef.current += 1; busyRef.current = false; setOpen(false); setPhase('idle'); };
  const quit = () => { runRef.current += 1; busyRef.current = false; setPhase('idle'); };

  const r = rating(score);
  const themed = Boolean(tripSlug);
  const shareUrl = themed ? `${SITE_ORIGIN}/trips/${tripSlug}` : `${SITE_ORIGIN}/games`;
  const shareText = playerName
    ? `${playerName} scored ${score} (${r.title}) in Ulaa's "Trail Swap" puzzle! Think you can beat that? ${shareUrl}`
    : `I scored ${score} (${r.title}) in Ulaa's "Trail Swap" puzzle! Think you can beat me? ${shareUrl}`;

  const share = async () => {
    if (sharing) return;
    setSharing(true);
    let blob: Blob | null = cardBlobRef.current;
    if (!blob) {
      try {
        blob = await buildScoreCard({
          score, stars: r.stars, title: r.title, tripTitle, host: SITE_HOST, best, isNewBest,
          eyebrow: 'TRAIL SWAP  ·  PUZZLE', ringMax: RING_MAX, playerName,
          tiles: [
            { v: `×${bestCascade}`, l: 'BEST CASCADE' },
            { v: String(specials), l: 'POWER TILES' },
            { v: String(Math.max(best, score)), l: 'PERSONAL BEST' },
          ],
        });
      } catch { blob = null; }
    }
    setSharing(false);
    await shareCardImage(blob, {
      filename: 'ulaa-trail-swap.png',
      title: 'Trail Swap',
      text: shareText,
      fallbackLink: getWhatsAppLink('', shareText),
    });
  };

  const progress = Math.min(1, score / STAR_AT[1]);
  const starsNow = rating(score).stars;
  const cellW = 100 / COLS;
  const cellH = 100 / ROWS;

  return (
    <div className={className}>
      <GameTile
        onClick={() => setOpen(true)}
        compact={compact}
        thumb={thumb}
        Icon={Path}
        accent="gold"
        title="Trail swap"
        subtitle={best > 0 ? `Your best: ${best}` : 'Swap, match, explore'}
        chip="New · Puzzle"
      />

      <Modal isOpen={open} onClose={close} ariaLabel="Trail swap game" size="sm" flush fullScreen>
        <div onPointerDownCapture={onPressCapture} className="[-webkit-tap-highlight-color:transparent] touch-manipulation relative overflow-hidden bg-gradient-to-b from-dark via-footer to-[#1B130E] text-cream px-4 pt-[max(4rem,calc(env(safe-area-inset-top)+3.5rem))] pb-[max(1.5rem,env(safe-area-inset-bottom))] min-h-[100dvh] flex justify-center">
          <div className="relative w-full max-w-md">
            <span className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-72 rounded-full bg-primary/35 blur-3xl pointer-events-none" aria-hidden="true" />
            <span className="absolute -top-10 -right-16 w-56 h-56 rounded-full bg-gold/20 blur-3xl pointer-events-none" aria-hidden="true" />

            {/* ── Start screen ── */}
            {phase === 'idle' && (
              <div className="relative text-center pt-3">
                <BrandMark />
                <motion.div
                  className="w-20 h-20 mx-auto mb-4 rounded-[28px] bg-gradient-to-br from-[#F0CE7A] to-gold text-dark flex items-center justify-center shadow-[0_14px_36px_rgba(200,150,42,0.45)]"
                  animate={reduce ? undefined : { y: [0, -6, 0], rotate: [-3, 3, -3] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  aria-hidden="true"
                >
                  <Path size={46} weight="duotone" />
                </motion.div>
                <span className="inline-block text-[10px] font-bold uppercase tracking-[0.2em] text-[#F0CE7A] bg-gold/15 border border-gold/30 rounded-full px-3 py-1 mb-2">{MOVES}-move puzzle</span>
                <h2 className="font-display text-4xl font-extrabold text-white leading-tight">Trail swap</h2>
                <p className="text-sm text-cream/60 mt-1 mb-4 px-6">Line up your travel gear and chain big cascades</p>

                <div className="flex items-center justify-center gap-1.5 mb-4" aria-hidden="true">
                  {KINDS_UI.map(k => (
                    <span key={k.label} className={`w-10 h-10 rounded-xl bg-gradient-to-br ${k.tile} flex items-center justify-center shadow-[0_4px_10px_rgba(0,0,0,0.3)]`}>
                      <k.Icon size={22} weight="duotone" />
                    </span>
                  ))}
                </div>

                <ul className={`${glass} text-left divide-y divide-white/10 mb-4`}>
                  <li className="flex items-center gap-3 px-3 py-2.5 text-[13px] text-cream/75">
                    <span className="w-7 h-7 shrink-0 rounded-lg bg-primary/25 text-[#F4B183] flex items-center justify-center"><ArrowsLeftRight size={16} weight="bold" /></span>
                    <span><strong className="text-white">Swap</strong> two neighbours (tap, tap or drag) to match <strong className="text-white">3 or more</strong>.</span>
                  </li>
                  <li className="flex items-center gap-3 px-3 py-2.5 text-[13px] text-cream/75">
                    <span className="w-7 h-7 shrink-0 rounded-lg bg-gold/20 text-[#F0CE7A] flex items-center justify-center"><Helicopter size={16} weight="fill" /></span>
                    <span>Match <strong className="text-white">4</strong> and the tile becomes a <strong className="text-white">Helicopter</strong>. Match <strong className="text-white">5</strong> for a golden Sparkle.</span>
                  </li>
                  <li className="flex items-center gap-3 px-3 py-2.5 text-[13px] text-cream/75">
                    <span className="w-7 h-7 shrink-0 rounded-lg bg-secondary/25 text-[#F4B183] flex items-center justify-center"><Fire size={16} weight="fill" /></span>
                    <span>Cascades multiply points. You have <strong className="text-white">{MOVES} moves</strong>.</span>
                  </li>
                </ul>

                {best > 0 && (
                  <p className="inline-flex items-center gap-1.5 text-sm text-cream/70 mb-3">
                    <Trophy size={16} weight="fill" className="text-[#F0CE7A]" /> Your best <strong className="text-[#F0CE7A]">{best}</strong>. Can you beat it?
                  </p>
                )}
                <NameField value={name} onChange={setName} onEnter={begin} />
                <button type="button" onClick={begin} className={primaryBtn}><Play size={18} weight="fill" /> Start swapping</button>
                <button type="button" onClick={toggleMute} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-cream/50 hover:text-cream transition-colors">
                  {muted ? <SpeakerSlash size={14} /> : <SpeakerHigh size={14} />} Sound {muted ? 'off' : 'on'}
                </button>
              </div>
            )}

            {/* ── Playing ── */}
            {phase === 'playing' && (
              <div className="relative">
                <div className="flex items-stretch gap-2.5 mb-2.5 pr-12">
                  <div className={`${glass} flex-1 px-3.5 py-2`}>
                    <p className={eyebrow}>Score</p>
                    <motion.p key={score} initial={reduce ? false : { scale: 1.18 }} animate={{ scale: 1 }} className="origin-left font-display text-3xl font-extrabold leading-none text-white tabular-nums">{score}</motion.p>
                  </div>
                  <div className={`${glass} px-4 py-2 text-center ${moves <= 5 ? '!border-red-400/50' : ''}`} role="status" aria-label={`${moves} moves left`}>
                    <p className={eyebrow}>Moves</p>
                    <motion.p key={moves} initial={reduce ? false : { scale: 1.25 }} animate={{ scale: 1 }} className={`font-display text-3xl font-extrabold leading-none tabular-nums ${moves <= 5 ? 'text-red-300' : 'text-[#F0CE7A]'}`}>{moves}</motion.p>
                  </div>
                </div>

                {/* Trail progress with star markers */}
                <div className="relative h-2.5 rounded-full bg-white/10 mb-3 mx-1" aria-hidden="true">
                  <motion.div className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-primary to-[#F0CE7A]" animate={{ width: `${progress * 100}%` }} transition={{ duration: reduce ? 0 : 0.4, ease: 'easeOut' }} />
                  {[0.5, 1].map((p, i) => (
                    <span key={p} className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2" style={{ left: `${p * 100 - (p === 1 ? 2 : 0)}%` }}>
                      <Star size={18} weight="fill" className={starsNow >= i + 2 ? 'text-[#F0CE7A] drop-shadow-[0_0_6px_rgba(240,206,122,0.8)]' : 'text-white/25'} />
                    </span>
                  ))}
                </div>

                {/* Board */}
                <div className="relative rounded-3xl bg-black/25 border border-white/10 p-1.5 shadow-[inset_0_0_40px_rgba(0,0,0,0.35)]">
                  <div
                    ref={boardRef}
                    className="relative w-full aspect-square touch-none select-none"
                    onPointerDown={onDown}
                    onPointerMove={onMove}
                    onPointerUp={onUp}
                    onPointerCancel={onUp}
                    role="application"
                    aria-label="Trail swap board. Swap neighbouring tiles to match three or more."
                  >
                    {tiles.map(t => {
                      const k = KINDS_UI[t.kind];
                      const isSel = selected && gridRef.current[selected.r]?.[selected.c]?.id === t.id;
                      const hinted = hint.includes(t.id);
                      const special = t.special;
                      return (
                        <div
                          key={t.id}
                          className="absolute left-0 top-0 p-[2.5%] pointer-events-none"
                          style={{
                            width: `${cellW}%`, height: `${cellH}%`,
                            transform: `translate3d(${t.c * 100}%, ${t.r * 100}%, 0)`,
                            transition: `transform ${fall}ms cubic-bezier(0.34, 1.18, 0.5, 1)`,
                            zIndex: isSel ? 5 : 1,
                            willChange: 'transform',
                          }}
                        >
                          <div
                            className={`relative w-full h-full rounded-[28%] flex items-center justify-center bg-gradient-to-br ${special === 'color' ? 'from-[#FFF6CC] via-[#F0CE7A] to-gold text-dark' : k.tile} shadow-[0_3px_6px_rgba(0,0,0,0.35),inset_0_1px_0_rgba(255,255,255,0.35)] ${special !== 'none' ? 'ring-2 ring-white/90' : ''} ${hinted ? 'animate-pulse' : ''} ${shaking.includes(t.id) ? 'ring-2 ring-red-400/80' : ''}`}
                            style={{
                              transform: t.clearing ? 'scale(0)' : isSel ? 'scale(1.12)' : 'scale(1)',
                              opacity: t.clearing ? 0 : 1,
                              transition: `transform ${t.clearing ? popMs : 140}ms ease-out, opacity ${popMs}ms ease-out`,
                              filter: special !== 'none' ? 'drop-shadow(0 0 8px rgba(240,206,122,0.9))' : undefined,
                            }}
                          >
                            <span className="absolute inset-x-[10%] top-[6%] h-[30%] rounded-full bg-gradient-to-b from-white/35 to-transparent pointer-events-none" aria-hidden="true" />
                            {special === 'color'
                              ? <Sparkle className="relative w-[58%] h-[58%]" weight="fill" aria-label="Sparkle tile" />
                              : special === 'heli'
                                ? <Helicopter className="relative w-[64%] h-[64%]" weight="fill" aria-label="Helicopter tile" />
                                : <k.Icon className="relative w-[56%] h-[56%]" weight="duotone" aria-label={k.label} />}
                          </div>
                        </div>
                      );
                    })}

                    {pops.map(p => (
                      <motion.span
                        key={p.id}
                        className="absolute pointer-events-none -translate-x-1/2 -translate-y-1/2 z-10 font-display text-xl font-extrabold text-[#F0CE7A] whitespace-nowrap [text-shadow:0_2px_8px_rgba(0,0,0,0.7)]"
                        style={{ left: `${p.x}%`, top: `${p.y}%` }}
                        initial={{ y: 0, opacity: 1, scale: 0.8 }}
                        animate={{ y: reduce ? 0 : -30, opacity: 0, scale: 1.15 }}
                        transition={{ duration: 0.75, ease: 'easeOut' }}
                      >
                        {p.text}
                      </motion.span>
                    ))}

                    {flyers.map(f => (
                      <motion.span
                        key={f.id}
                        className="absolute pointer-events-none z-20 flex items-center justify-center text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.6)]"
                        style={{ width: `${cellW}%`, height: `${cellH}%` }}
                        initial={{ left: `${f.from.c * cellW}%`, top: `${f.from.r * cellH}%`, scale: 1, rotate: 0 }}
                        animate={{ left: `${f.to.c * cellW}%`, top: `${f.to.r * cellH}%`, scale: [1, 1.5, 1.1], rotate: [0, -12, 8] }}
                        transition={{ duration: reduce ? 0 : 0.36, ease: 'easeInOut' }}
                        aria-hidden="true"
                      >
                        <Helicopter size="70%" weight="fill" className="text-[#FFF6CC]" />
                      </motion.span>
                    ))}

                    <AnimatePresence>
                      {banner && (
                        <motion.div
                          key={banner.id}
                          initial={{ opacity: 0, scale: 0.7 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 1.1 }}
                          className="absolute inset-x-0 top-1/2 -translate-y-1/2 z-20 flex justify-center pointer-events-none"
                        >
                          <span className="rounded-full bg-gradient-to-r from-secondary to-primary text-white font-display font-extrabold px-5 py-2 text-lg shadow-[0_8px_24px_rgba(0,0,0,0.5)]">{banner.text}</span>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-3">
                  <button type="button" onClick={quit} className="inline-flex items-center gap-1.5 text-xs font-semibold text-cream/50 hover:text-cream transition-colors">
                    <SignOut size={14} /> Quit
                  </button>
                  <p className="text-[11px] text-cream/40">Tap two neighbours or drag a tile</p>
                  <button type="button" onClick={toggleMute} className="inline-flex items-center gap-1.5 text-xs font-semibold text-cream/50 hover:text-cream transition-colors" aria-label={muted ? 'Turn sound on' : 'Turn sound off'}>
                    {muted ? <SpeakerSlash size={14} /> : <SpeakerHigh size={14} />}
                  </button>
                </div>
              </div>
            )}

            {/* ── Result ── */}
            {phase === 'done' && (
              <div className="relative text-center pt-1">
                {r.stars >= 2 && <Confetti />}
                <p className={eyebrow}>Out of moves</p>
                {isNewBest && (
                  <motion.p initial={reduce ? false : { scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-dark bg-gradient-to-r from-[#F0CE7A] to-gold rounded-full px-3 py-1 mt-1">
                    <Trophy size={13} weight="fill" /> New best
                  </motion.p>
                )}
                <div className="mt-2"><ScoreRing score={score} reduce={!!reduce} max={RING_MAX} /></div>

                <div className="flex justify-center gap-1.5 mt-2 mb-2" aria-label={`${r.stars} out of 3 stars`}>
                  {[1, 2, 3].map(n => (
                    <motion.span key={n} initial={reduce ? false : { scale: 0, rotate: -40 }} animate={{ scale: 1, rotate: 0 }} transition={{ delay: 0.5 + n * 0.18, type: 'spring', stiffness: 260, damping: 12 }}>
                      <Star size={32} weight="fill" className={n <= r.stars ? 'text-[#F0CE7A] drop-shadow-[0_0_10px_rgba(240,206,122,0.6)]' : 'text-white/15'} />
                    </motion.span>
                  ))}
                </div>

                <p className={`font-display text-2xl font-extrabold ${GOLD_GRAD_TEXT}`}>{r.title}</p>
                <p className="text-sm text-cream/60 mt-0.5">{r.blurb}</p>
                {!isNewBest && prevBest > 0 && (
                  <p className="text-sm text-[#F0CE7A] font-medium mt-1">
                    {prevBest - score <= 200 ? `So close! Just ${prevBest - score + 1} more to beat your best.` : `Your best is ${prevBest}. Go get it!`}
                  </p>
                )}

                <div className="grid grid-cols-3 gap-2 mt-4 mb-3">
                  {[
                    { v: `×${bestCascade}`, l: 'Best cascade' },
                    { v: String(specials), l: 'Power tiles' },
                    { v: String(Math.max(best, score)), l: 'Your best' },
                  ].map(s => (
                    <div key={s.l} className={`${glass} py-2.5`}>
                      <p className="font-display text-xl font-extrabold text-white tabular-nums">{s.v}</p>
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-cream/50">{s.l}</p>
                    </div>
                  ))}
                </div>

                <button type="button" onClick={() => void share()} disabled={sharing} className={`${glass} group w-full flex items-center gap-3 p-2.5 text-left hover:bg-white/10 transition-colors disabled:opacity-70 mb-3`}>
                  <span className="relative w-14 shrink-0 aspect-[4/5] rounded-lg overflow-hidden bg-white/10 border border-white/15">
                    {previewUrl
                      ? <img src={previewUrl} alt="Your score card" className="absolute inset-0 w-full h-full object-cover" />
                      : <span className="absolute inset-0 animate-pulse bg-white/10" aria-hidden="true" />}
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-sm font-bold text-white">{sharing ? 'Preparing…' : 'Share your score card'}</span>
                    <span className="block text-xs text-cream/55">Post it and dare your friends to beat you.</span>
                  </span>
                  <span className="w-10 h-10 shrink-0 rounded-full bg-gradient-to-b from-primary-light to-primary text-white flex items-center justify-center group-hover:scale-105 transition-transform" aria-hidden="true">
                    <ShareNetwork size={18} weight="bold" />
                  </span>
                </button>

                <button type="button" onClick={begin} className={`${primaryBtn} mb-3`}><ArrowCounterClockwise size={18} weight="bold" /> Play again</button>
                <button type="button" onClick={() => setPhase('idle')} className={ghostBtn}>Back to menu</button>
              </div>
            )}
          </div>
        </div>
      </Modal>
    </div>
  );
}
