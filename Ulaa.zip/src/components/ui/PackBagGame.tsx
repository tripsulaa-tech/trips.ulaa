import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence, useAnimationControls, useReducedMotion } from 'framer-motion';
import {
  Play, Pause, ArrowCounterClockwise, ShareNetwork, WhatsappLogo, Star, Fire, Backpack,
  BatteryCharging, Drop, FirstAid, Sun, Sneaker, Boot, CloudRain, Footprints, Flashlight,
  Sunglasses, Waves, BaseballCap, Hand, Snowflake, Thermometer, Camera, Wind, HighHeel,
  SuitcaseRolling, Television, Guitar, Hamburger, Laptop, Hourglass, Magnet, SpeakerHigh,
  SpeakerSlash, HandTap,
} from '@phosphor-icons/react';
import type { Icon as PhosphorIcon } from '@phosphor-icons/react';
import Modal from './Modal';
import { WHATSAPP_NUMBER } from '../../constants/site';
import { getWhatsAppLink } from '../../utils/utils-index';

// "Pack the bag": a 30-second tap game for Coming Soon trips. Things fall;
// tap what you'd really pack for THIS trip, skip the rest. Chain correct taps
// for a combo, grab the golden star, use the hourglass (slow-mo) and magnet
// (packs everything useful on screen) power-ups, and beat your best.
// Front-end only: best score and settings live in localStorage, sounds are
// synthesised with the Web Audio API (no audio files), the share button makes
// a score-card image, and "notify me" is a prefilled WhatsApp message.
// No backend, no discounts promised.

interface PackItem { Icon: PhosphorIcon; label: string }
interface Profile { good: PackItem[]; bad: PackItem[] }

// Refined line icons (Phosphor duotone). Good and bad items share exactly the
// same look, so the game stays a real "spot the right one".
const BAD: PackItem[] = [
  { Icon: HighHeel, label: 'High heels' },
  { Icon: SuitcaseRolling, label: 'Giant suitcase' },
  { Icon: Television, label: 'Television' },
  { Icon: Guitar, label: 'Guitar' },
  { Icon: Hamburger, label: 'Fast food' },
  { Icon: Laptop, label: 'Work laptop' },
];

const COMMON: PackItem[] = [
  { Icon: BatteryCharging, label: 'Power bank' },
  { Icon: Drop, label: 'Water bottle' },
  { Icon: FirstAid, label: 'First-aid kit' },
  { Icon: Sun, label: 'Sunscreen' },
];

// Pick a themed set from the trip title; falls back to a general one.
function profileFor(title: string): Profile {
  const t = title.toLowerCase();
  if (/waterfall|trek|forest|wild|jungle|falls|hike|trail/.test(t)) {
    return { good: [...COMMON, { Icon: Sneaker, label: 'Trek shoes' }, { Icon: CloudRain, label: 'Rain jacket' }, { Icon: Footprints, label: 'Quick-dry socks' }, { Icon: Flashlight, label: 'Torch' }], bad: BAD };
  }
  if (/beach|island|lanka|goa|coast|sea/.test(t)) {
    return { good: [...COMMON, { Icon: Sunglasses, label: 'Sunglasses' }, { Icon: Waves, label: 'Swimwear' }, { Icon: BaseballCap, label: 'Sun cap' }, { Icon: Footprints, label: 'Flip-flops' }], bad: BAD };
  }
  if (/snow|himalaya|ladakh|spiti|kashmir|winter|mountain|camp/.test(t)) {
    return { good: [...COMMON, { Icon: Hand, label: 'Gloves' }, { Icon: Snowflake, label: 'Warm scarf' }, { Icon: Thermometer, label: 'Thermal jacket' }, { Icon: Boot, label: 'Boots' }], bad: BAD };
  }
  return { good: [...COMMON, { Icon: Backpack, label: 'Day backpack' }, { Icon: Camera, label: 'Camera' }, { Icon: Wind, label: 'Light jacket' }, { Icon: Sneaker, label: 'Walking shoes' }], bad: BAD };
}

const DURATION = 30;      // seconds
const AREA_H = 320;       // px, matches h-80 below
const ITEM = 64;          // px, hit box of a falling item
const GOOD_POINTS = 10;
const GOLD_POINTS = 30;
const BAD_POINTS = -5;
const COMBO_STEP = 3;     // correct taps in a row per extra multiplier
const MAX_MULT = 3;
const SLOW_SECONDS = 5;
const SLOW_FACTOR = 0.45;

const MUTE_KEY = 'ulaa:packbag:muted';
const SEEN_KEY = 'ulaa:packbag:seen';

function rating(score: number): { title: string; blurb: string; stars: number } {
  if (score >= 130) return { title: 'Ulaa Pro Packer', blurb: 'Nothing forgotten, nothing extra. Trip-ready!', stars: 3 };
  if (score >= 70) return { title: 'Trail-ready traveller', blurb: 'Solid packing. A couple of tweaks and you are perfect.', stars: 2 };
  return { title: 'Beginner backpacker', blurb: 'Every great trip starts with a lighter bag. Try again!', stars: 1 };
}

type Kind = 'normal' | 'golden' | 'slow' | 'magnet';
interface Falling extends PackItem { id: number; good: boolean; kind: Kind; x: number; y: number; speed: number }
interface Pop { id: number; x: number; y: number; text: string; good: boolean }
interface Flying { id: number; Icon: PhosphorIcon; golden: boolean; x: number; y: number }

const isPowerUp = (k: Kind) => k === 'slow' || k === 'magnet';

// ── Sound: tiny Web Audio synth (no files). Created lazily on the first tap
// of "Start" so browsers allow it; respects the mute toggle. ──
type Sfx = 'good' | 'bad' | 'gold' | 'power' | 'tick' | 'go' | 'win' | 'end';

function useSynth(mutedRef: React.MutableRefObject<boolean>) {
  const ctxRef = useRef<AudioContext | null>(null);

  const ensure = useCallback(() => {
    if (!ctxRef.current) {
      const AC = window.AudioContext
        ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      ctxRef.current = new AC();
    }
    if (ctxRef.current.state === 'suspended') void ctxRef.current.resume();
    return ctxRef.current;
  }, []);

  const tone = useCallback((freq: number, dur: number, opts: { type?: OscillatorType; gain?: number; delay?: number; to?: number } = {}) => {
    const ctx = ctxRef.current;
    if (!ctx || mutedRef.current) return;
    const { type = 'sine', gain = 0.12, delay = 0, to } = opts;
    const t = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (to) osc.frequency.exponentialRampToValueAtTime(to, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }, [mutedRef]);

  const play = useCallback((name: Sfx) => {
    if (mutedRef.current) return;
    switch (name) {
      case 'good': tone(660, 0.09, { type: 'triangle' }); tone(880, 0.12, { type: 'triangle', delay: 0.07 }); break;
      case 'bad': tone(190, 0.22, { type: 'sawtooth', gain: 0.09, to: 110 }); break;
      case 'gold': [784, 988, 1175, 1568].forEach((f, i) => tone(f, 0.16, { type: 'triangle', delay: i * 0.07 })); break;
      case 'power': tone(440, 0.28, { type: 'sine', to: 1040 }); break;
      case 'tick': tone(520, 0.1, { type: 'sine' }); break;
      case 'go': tone(880, 0.3, { type: 'triangle', gain: 0.15 }); break;
      case 'win': [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.28, { type: 'triangle', delay: i * 0.12 })); break;
      case 'end': tone(440, 0.2, { type: 'sine' }); tone(330, 0.3, { type: 'sine', delay: 0.18 }); break;
    }
  }, [tone, mutedRef]);

  return { ensure, play };
}

// ── Shareable score card: a portrait PNG drawn on a canvas. ──
function drawStar(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const rad = i % 2 === 0 ? r : r * 0.45;
    const a = (Math.PI / 5) * i - Math.PI / 2;
    const x = cx + Math.cos(a) * rad;
    const y = cy + Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.fill();
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let line = '';
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = w; } else line = test;
  }
  if (line) lines.push(line);
  return lines.slice(0, 3);
}

async function buildScoreCard(opts: { score: number; stars: number; title: string; tripTitle: string; host: string }): Promise<Blob | null> {
  const W = 1080;
  const H = 1350;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, '#FFFBF2');
  bg.addColorStop(1, '#F3E6C8');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = '#C8962A';
  ctx.lineWidth = 8;
  ctx.strokeRect(40, 40, W - 80, H - 80);
  ctx.lineWidth = 2;
  ctx.strokeRect(58, 58, W - 116, H - 116);

  const logo = await new Promise<HTMLImageElement | null>(res => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => res(null);
    img.src = `${window.location.origin}/ULAA-logo.png`;
  });
  let y = 140;
  if (logo) {
    const lw = 240;
    const lh = (logo.height / logo.width) * lw;
    ctx.drawImage(logo, (W - lw) / 2, y, lw, lh);
    y += lh + 50;
  } else {
    ctx.fillStyle = '#A85A2A';
    ctx.font = '700 72px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.fillText('ULAA', W / 2, y + 60);
    y += 130;
  }

  ctx.textAlign = 'center';
  ctx.fillStyle = '#8A6508';
  ctx.font = '700 34px Inter, system-ui, sans-serif';
  ctx.fillText('PACK THE BAG', W / 2, y);
  y += 70;

  ctx.fillStyle = '#2D2118';
  ctx.font = '700 50px Georgia, serif';
  const lines = wrapText(ctx, opts.tripTitle, 860);
  lines.forEach((l, i) => ctx.fillText(l, W / 2, y + i * 62));
  y += lines.length * 62 + 60;

  ctx.fillStyle = '#2D2118';
  ctx.font = '800 280px Georgia, serif';
  ctx.fillText(String(opts.score), W / 2, y + 220);
  y += 290;

  for (let i = 0; i < 3; i++) {
    ctx.fillStyle = i < opts.stars ? '#C8962A' : '#E6D8BE';
    drawStar(ctx, W / 2 + (i - 1) * 130, y + 50, 52);
  }
  y += 150;

  ctx.fillStyle = '#A85A2A';
  ctx.font = '700 58px Georgia, serif';
  ctx.fillText(opts.title, W / 2, y);
  y += 70;
  ctx.fillStyle = '#4A3728';
  ctx.font = '500 38px Inter, system-ui, sans-serif';
  ctx.fillText('Think you can beat me?', W / 2, y);

  ctx.fillStyle = '#8A6508';
  ctx.font = '600 34px Inter, system-ui, sans-serif';
  ctx.fillText(opts.host, W / 2, H - 100);

  return new Promise(res => canvas.toBlob(res, 'image/png'));
}

// ── Confetti (deterministic, render-pure) ──
const CONFETTI_COLORS = ['#C8962A', '#E9C25A', '#A85A2A', '#D98A3A', '#8A6508', '#4CAF50'];
const seeded = (i: number, k: number) => {
  const x = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453;
  return x - Math.floor(x);
};

function Confetti() {
  const bits = useMemo(
    () => Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: seeded(i, 1) * 100,
      delay: seeded(i, 2) * 0.5,
      dur: 1.6 + seeded(i, 3) * 1.4,
      rot: (seeded(i, 4) - 0.5) * 720,
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      size: 6 + seeded(i, 5) * 6,
    })),
    [],
  );
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
      {bits.map(b => (
        <motion.span
          key={b.id}
          className="absolute top-0 rounded-sm"
          style={{ left: `${b.x}%`, width: b.size, height: b.size * 1.6, background: b.color }}
          initial={{ y: -20, opacity: 1, rotate: 0 }}
          animate={{ y: 520, opacity: [1, 1, 0], rotate: b.rot }}
          transition={{ duration: b.dur, delay: b.delay, ease: 'easeIn' }}
        />
      ))}
    </div>
  );
}

interface PackBagGameProps {
  tripId: string;
  tripSlug: string;
  tripTitle: string;
  coverImage?: string | null;
  className?: string;
}

export default function PackBagGame({ tripId, tripSlug, tripTitle, coverImage, className = '' }: PackBagGameProps) {
  const bestKey = `ulaa:packbag:${tripId}`;
  // Memoised: the game loop effect depends on it, and a fresh object each
  // render would restart the loop every frame.
  const profile = useMemo(() => profileFor(tripTitle), [tripTitle]);
  const reduce = useReducedMotion();

  const [open, setOpen] = useState(false);
  const [phase, setPhase] = useState<'idle' | 'countdown' | 'playing' | 'done'>('idle');
  const [paused, setPaused] = useState(false);
  const [count, setCount] = useState(3);
  const [items, setItems] = useState<Falling[]>([]);
  const [pops, setPops] = useState<Pop[]>([]);
  const [flying, setFlying] = useState<Flying[]>([]);
  const [flash, setFlash] = useState<'good' | 'bad' | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [packed, setPacked] = useState(0);
  const [bestCombo, setBestCombo] = useState(1);
  const [progress, setProgress] = useState(0);
  const [slowActive, setSlowActive] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [muted, setMuted] = useState<boolean>(() => {
    try { return localStorage.getItem(MUTE_KEY) === '1'; } catch { return false; }
  });
  const [best, setBest] = useState<number>(() => {
    try { return Number(localStorage.getItem(bestKey)) || 0; } catch { return 0; }
  });
  const [prevBest, setPrevBest] = useState(0);
  const [isNewBest, setIsNewBest] = useState(false);

  const itemsRef = useRef<Falling[]>([]);
  const scoreRef = useRef(0);
  const streakRef = useRef(0);
  const packedRef = useRef(0);
  const comboRef = useRef(1);
  const elapsedRef = useRef(0);
  const accRef = useRef(0);
  const slowLeftRef = useRef(0);
  const firstPlayRef = useRef(false);
  const firstSpawnRef = useRef(false);
  const nextId = useRef(1);
  const mutedRef = useRef(muted);
  const stage = useAnimationControls();
  const bag = useAnimationControls();
  const { ensure, play } = useSynth(mutedRef);

  const toggleMute = () => {
    const next = !muted;
    mutedRef.current = next;
    setMuted(next);
    try { localStorage.setItem(MUTE_KEY, next ? '1' : '0'); } catch { /* not remembered */ }
    if (!next) { ensure(); play('tick'); }
  };

  const reset = useCallback(() => {
    scoreRef.current = 0; streakRef.current = 0; packedRef.current = 0; comboRef.current = 1;
    elapsedRef.current = 0; accRef.current = 0; slowLeftRef.current = 0; itemsRef.current = [];
    setScore(0); setStreak(0); setPacked(0); setBestCombo(1); setProgress(0);
    setItems([]); setPops([]); setFlying([]); setFlash(null); setIsNewBest(false);
    setSlowActive(false); setPaused(false);
  }, []);

  const begin = useCallback(() => {
    ensure(); // creating/resuming audio must happen inside this click
    reset();
    let seen = false;
    try { seen = localStorage.getItem(SEEN_KEY) === '1'; } catch { /* treat as first play */ }
    firstPlayRef.current = !seen;
    firstSpawnRef.current = !seen;
    setShowHint(!seen);
    if (!seen) { try { localStorage.setItem(SEEN_KEY, '1'); } catch { /* not remembered */ } }
    setCount(3);
    setPhase('countdown');
  }, [ensure, reset]);

  // 3 · 2 · 1 · GO, then the real game starts.
  useEffect(() => {
    if (phase !== 'countdown') return;
    play('tick');
    const ids = [
      window.setTimeout(() => { setCount(2); play('tick'); }, 800),
      window.setTimeout(() => { setCount(1); play('tick'); }, 1600),
      window.setTimeout(() => { setCount(0); play('go'); }, 2400),
      window.setTimeout(() => setPhase('playing'), 3000),
    ];
    return () => ids.forEach(clearTimeout);
  }, [phase, play]);

  // The first-play tip disappears on its own.
  useEffect(() => {
    if (!showHint || phase !== 'playing') return;
    const id = window.setTimeout(() => setShowHint(false), 5000);
    return () => clearTimeout(id);
  }, [showHint, phase]);

  // Pause automatically if the tab/app goes to the background.
  useEffect(() => {
    if (phase !== 'playing') return;
    const onHide = () => { if (document.hidden) setPaused(true); };
    document.addEventListener('visibilitychange', onHide);
    return () => document.removeEventListener('visibilitychange', onHide);
  }, [phase]);

  const finish = useCallback(() => {
    itemsRef.current = [];
    setItems([]);
    const final = scoreRef.current;
    setPrevBest(best);
    if (final > best) {
      setIsNewBest(best > 0);
      setBest(final);
      try { localStorage.setItem(bestKey, String(final)); } catch { /* not remembered */ }
    }
    play(rating(final).stars >= 2 ? 'win' : 'end');
    setPhase('done');
  }, [best, bestKey, play]);

  // Game loop: spawn, fall, and end after DURATION seconds of *played* time
  // (elapsed is accumulated, so pausing doesn't lose or gain time). Spawning
  // gets faster and items fall quicker as the clock runs down.
  useEffect(() => {
    if (phase !== 'playing' || paused) return;
    let raf = 0;
    let prev = performance.now();
    const spawn = (elapsed: number) => {
      let kind: Kind = 'normal';
      let good = Math.random() < 0.65;
      if (firstSpawnRef.current) {
        good = true; // first-ever item is always a right one
        firstSpawnRef.current = false;
      } else {
        const roll = Math.random();
        if (roll < 0.04) kind = 'slow';
        else if (roll < 0.08) kind = 'magnet';
        else if (good && Math.random() < 0.1) kind = 'golden';
      }
      let it: PackItem;
      if (kind === 'slow') { it = { Icon: Hourglass, label: 'Slow-mo' }; good = true; }
      else if (kind === 'magnet') { it = { Icon: Magnet, label: 'Magnet' }; good = true; }
      else if (kind === 'golden') it = { Icon: Star, label: 'Bonus' };
      else { const pool = good ? profile.good : profile.bad; it = pool[Math.floor(Math.random() * pool.length)]; }
      itemsRef.current.push({
        ...it,
        id: nextId.current++,
        good,
        kind,
        x: 3 + Math.random() * 75,
        y: -ITEM,
        speed: 120 + Math.random() * 60 + elapsed * 3.5,
      });
    };
    const tick = (now: number) => {
      const dt = Math.min((now - prev) / 1000, 0.05);
      prev = now;
      elapsedRef.current += dt;
      const elapsed = elapsedRef.current;
      if (elapsed >= DURATION) { setProgress(1); finish(); return; }
      setProgress(elapsed / DURATION);

      let mul = 1;
      if (slowLeftRef.current > 0) {
        slowLeftRef.current = Math.max(0, slowLeftRef.current - dt);
        mul = SLOW_FACTOR;
        if (slowLeftRef.current === 0) setSlowActive(false);
      }
      accRef.current += dt;
      if (accRef.current >= Math.max(0.4, 0.8 - elapsed * 0.012)) { accRef.current = 0; spawn(elapsed); }

      itemsRef.current = itemsRef.current
        .map(i => ({ ...i, y: i.y + i.speed * dt * mul }))
        .filter(i => i.y < AREA_H);
      setItems(itemsRef.current);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase, paused, profile, finish]);

  const buzz = (pattern: number | number[]) => {
    try { navigator.vibrate?.(pattern); } catch { /* unsupported */ }
  };

  const addPop = (x: number, y: number, text: string, good: boolean, id: number) => {
    setPops(p => [...p, { id, x, y, text, good }]);
    window.setTimeout(() => setPops(p => p.filter(q => q.id !== id)), 650);
  };

  // Awards one correct item (shared by a normal tap and the magnet).
  const award = (item: Falling): number => {
    streakRef.current += 1;
    const mult = Math.min(MAX_MULT, 1 + Math.floor(streakRef.current / COMBO_STEP));
    comboRef.current = Math.max(comboRef.current, mult);
    const pts = (item.kind === 'golden' ? GOLD_POINTS : GOOD_POINTS) * mult;
    packedRef.current += 1;
    scoreRef.current += pts;
    addPop(item.x, item.y, `+${pts}`, true, item.id);
    if (!reduce) {
      setFlying(f => [...f, { id: item.id, Icon: item.Icon, golden: item.kind === 'golden', x: item.x, y: item.y }]);
      window.setTimeout(() => setFlying(f => f.filter(q => q.id !== item.id)), 450);
    }
    return pts;
  };

  const tap = (item: Falling) => {
    if (phase !== 'playing' || paused) return;
    setShowHint(false);
    let flashKind: 'good' | 'bad' = 'good';

    if (item.kind === 'slow') {
      slowLeftRef.current = SLOW_SECONDS;
      setSlowActive(true);
      play('power');
      buzz(15);
      addPop(item.x, item.y, 'Slow-mo!', true, item.id);
      itemsRef.current = itemsRef.current.filter(i => i.id !== item.id);
    } else if (item.kind === 'magnet') {
      play('power');
      buzz([15, 30, 15]);
      const pulled = itemsRef.current.filter(i => i.id !== item.id && !isPowerUp(i.kind) && i.good);
      pulled.forEach(award);
      addPop(item.x, item.y, pulled.length ? `Magnet! ×${pulled.length}` : 'Magnet!', true, item.id);
      const gone = new Set([item.id, ...pulled.map(i => i.id)]);
      itemsRef.current = itemsRef.current.filter(i => !gone.has(i.id));
      if (!reduce) void bag.start({ scale: [1, 1.3, 1], transition: { duration: 0.3 } });
    } else if (item.good) {
      award(item);
      play(item.kind === 'golden' ? 'gold' : 'good');
      buzz(12);
      if (!reduce) void bag.start({ scale: [1, 1.25, 1], transition: { duration: 0.25 } });
      itemsRef.current = itemsRef.current.filter(i => i.id !== item.id);
    } else {
      streakRef.current = 0;
      scoreRef.current = Math.max(0, scoreRef.current + BAD_POINTS);
      addPop(item.x, item.y, `${BAD_POINTS}`, false, item.id);
      play('bad');
      buzz([30, 40, 30]);
      if (!reduce) void stage.start({ x: [0, -8, 8, -5, 5, 0], transition: { duration: 0.3 } });
      itemsRef.current = itemsRef.current.filter(i => i.id !== item.id);
      flashKind = 'bad';
    }

    setScore(scoreRef.current);
    setStreak(streakRef.current);
    setPacked(packedRef.current);
    setBestCombo(comboRef.current);
    setItems(itemsRef.current);
    setFlash(flashKind);
    window.setTimeout(() => setFlash(null), 180);
  };

  const close = () => { setOpen(false); setPhase('idle'); setPaused(false); itemsRef.current = []; setItems([]); };

  const mult = Math.min(MAX_MULT, 1 + Math.floor(streak / COMBO_STEP));
  const secondsLeft = Math.max(0, Math.ceil(DURATION * (1 - progress)));
  const r = rating(score);
  const shareUrl = `${window.location.origin}/trips/${tripSlug}`;
  const shareText = `I scored ${score} (${r.title}) in Ulaa's "Pack the bag" game for ${tripTitle}! Think you can beat me? ${shareUrl}`;

  const share = async () => {
    if (sharing) return;
    setSharing(true);
    let blob: Blob | null;
    try {
      blob = await buildScoreCard({ score, stars: r.stars, title: r.title, tripTitle, host: window.location.host });
    } catch { blob = null; }
    setSharing(false);

    if (blob) {
      const file = new File([blob], 'ulaa-pack-the-bag.png', { type: 'image/png' });
      try {
        if (navigator.canShare?.({ files: [file] })) {
          await navigator.share({ files: [file], title: 'Pack the bag', text: shareText });
          return;
        }
      } catch { return; /* user closed the share sheet */ }
      // No file sharing here (most desktops): save the card so it can be posted.
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'ulaa-pack-the-bag.png';
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      return;
    }
    try {
      if (navigator.share) { await navigator.share({ title: 'Pack the bag', text: shareText }); return; }
    } catch { return; }
    window.open(getWhatsAppLink('', shareText), '_blank', 'noopener,noreferrer');
  };
  const notifyHref = getWhatsAppLink(WHATSAPP_NUMBER, `Hi Ulaa! Please let me know when "${tripTitle}" opens for booking.`);

  const primaryBtn = 'w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary hover:bg-primary-light text-white font-semibold py-3.5 transition-colors';
  const ghostBtn = 'w-full inline-flex items-center justify-center gap-2 rounded-xl bg-white hover:bg-cream border border-gold/40 text-dark font-semibold py-3 transition-colors disabled:opacity-60';
  const iconBtn = 'w-9 h-9 rounded-full bg-white/80 border border-gold/30 text-dark-muted hover:text-dark hover:bg-white flex items-center justify-center transition-colors';
  const floatAnim = reduce ? undefined : { y: [0, -5, 0] };

  return (
    <div className={className}>
      {/* Tile on the Coming Soon card */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="relative w-full h-24 rounded-xl overflow-hidden px-4 flex items-center gap-3 text-left text-dark bg-gradient-to-br from-cream to-gold/25 border border-gold/40 shadow-warm hover:shadow-warm-lg transition-shadow"
      >
        <span className="absolute -right-6 -top-8 w-28 h-28 rounded-full bg-gold/35 blur-2xl pointer-events-none" aria-hidden="true" />
        <motion.span
          className="relative w-12 h-12 shrink-0 rounded-full bg-white/70 border border-gold/50 text-primary flex items-center justify-center shadow-sm"
          animate={floatAnim}
          transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
          aria-hidden="true"
        >
          <Backpack size={28} weight="duotone" />
        </motion.span>
        <span className="relative flex-1 min-w-0">
          <span className="inline-block text-[10px] font-bold uppercase tracking-[0.14em] bg-gold text-dark rounded-full px-2 py-0.5 mb-1">New · 30-sec game</span>
          <span className="block font-display text-lg font-bold leading-tight">Pack the bag</span>
          <span className="block text-xs text-dark-muted">{best > 0 ? `Your best: ${best}` : 'Beat the clock. Win bragging rights.'}</span>
        </span>
        <span className="relative w-10 h-10 shrink-0 rounded-full bg-primary text-white flex items-center justify-center" aria-hidden="true">
          <Play size={18} weight="fill" />
        </span>
      </button>

      <Modal isOpen={open} onClose={close} ariaLabel="Pack the bag game" size="sm" flush>
        <div className="relative overflow-hidden bg-gradient-to-b from-cream via-cream to-gold/20 text-dark p-4 pt-5 min-h-[28rem]">
          <span className="absolute -top-16 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full bg-gold/25 blur-3xl pointer-events-none" aria-hidden="true" />

          {/* ── Start screen ── */}
          {phase === 'idle' && (
            <div className="relative text-center pt-4">
              <motion.div
                className="w-20 h-20 mx-auto mb-3 rounded-full bg-white/80 border border-gold/50 text-primary flex items-center justify-center shadow-[0_8px_24px_rgba(200,150,42,0.25)]"
                animate={reduce ? undefined : { y: [0, -6, 0] }}
                transition={{ duration: 2.6, repeat: Infinity, ease: 'easeInOut' }}
                aria-hidden="true"
              >
                <Backpack size={44} weight="duotone" />
              </motion.div>
              <h2 className="font-display text-3xl font-bold">Pack the bag</h2>
              <p className="text-sm text-dark-muted mt-1 mb-5 px-4">Packing for {tripTitle}</p>

              <div className="grid grid-cols-2 gap-2 text-left mb-3">
                <div className="rounded-xl bg-green-50 border border-green-200 p-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-green-700 mb-1.5">Tap these (+{GOOD_POINTS})</p>
                  <div className="flex gap-2 text-green-700">{profile.good.slice(0, 4).map(g => <g.Icon key={g.label} size={24} weight="duotone" />)}</div>
                </div>
                <div className="rounded-xl bg-red-50 border border-red-200 p-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-red-700 mb-1.5">Skip these ({BAD_POINTS})</p>
                  <div className="flex gap-2 text-red-700">{profile.bad.slice(0, 4).map(g => <g.Icon key={g.label} size={24} weight="duotone" />)}</div>
                </div>
              </div>
              <div className="rounded-xl bg-white/70 border border-gold/30 p-3 text-left text-sm text-dark-muted space-y-1.5 mb-4">
                <p><Fire size={14} weight="fill" className="inline text-primary -mt-0.5" /> Pack {COMBO_STEP} right in a row for <strong className="text-dark">×2</strong>, <strong className="text-dark">×3</strong> after {COMBO_STEP * 2}.</p>
                <p><Star size={14} weight="fill" className="inline text-gold -mt-0.5" /> Golden star: <strong className="text-dark">+{GOLD_POINTS}</strong>.</p>
                <p><Hourglass size={14} weight="duotone" className="inline text-primary -mt-0.5" /> Hourglass slows time. <Magnet size={14} weight="duotone" className="inline text-primary -mt-0.5" /> Magnet packs everything useful on screen.</p>
              </div>

              {best > 0 && <p className="text-sm text-dark-muted mb-3">Your best: <strong className="text-gold-deep">{best}</strong>. Can you beat it?</p>}
              <button type="button" onClick={begin} className={primaryBtn}><Play size={18} weight="fill" /> Start packing</button>
              <button type="button" onClick={toggleMute} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-dark-muted hover:text-dark transition-colors">
                {muted ? <SpeakerSlash size={14} /> : <SpeakerHigh size={14} />} Sound {muted ? 'off' : 'on'}
              </button>
            </div>
          )}

          {/* ── Countdown ── */}
          {phase === 'countdown' && (
            <div className="relative h-[24rem] flex items-center justify-center">
              <AnimatePresence mode="wait">
                <motion.span
                  key={count}
                  className="font-display text-8xl font-extrabold text-primary"
                  initial={reduce ? { opacity: 0 } : { scale: 0.3, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={reduce ? { opacity: 0 } : { scale: 1.6, opacity: 0 }}
                  transition={{ duration: 0.35 }}
                >
                  {count === 0 ? 'GO!' : count}
                </motion.span>
              </AnimatePresence>
            </div>
          )}

          {/* ── Playing ── */}
          {phase === 'playing' && (
            <div className="relative">
              {/* HUD (right padding keeps the time clear of the modal's close button) */}
              <div className="flex items-center justify-between mb-2 pr-11">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-dark-muted/70">Score</p>
                  <motion.p key={score} initial={reduce ? false : { scale: 1.3 }} animate={{ scale: 1 }} className="font-display text-3xl font-extrabold leading-none">{score}</motion.p>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <AnimatePresence>
                    {mult > 1 && (
                      <motion.span
                        key={mult}
                        initial={{ scale: 0.4, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.4, opacity: 0 }}
                        className="inline-flex items-center gap-1 rounded-full bg-primary text-white font-extrabold text-xs px-2.5 py-1 shadow"
                      >
                        <Fire size={12} weight="fill" /> ×{mult} combo
                      </motion.span>
                    )}
                  </AnimatePresence>
                  <AnimatePresence>
                    {slowActive && (
                      <motion.span
                        initial={{ scale: 0.4, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.4, opacity: 0 }}
                        className="inline-flex items-center gap-1 rounded-full bg-gold text-dark font-extrabold text-xs px-2.5 py-1 shadow"
                      >
                        <Hourglass size={12} weight="fill" /> Slow-mo
                      </motion.span>
                    )}
                  </AnimatePresence>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-dark-muted/70">Time</p>
                  <p className={`font-display text-3xl font-extrabold leading-none ${secondsLeft <= 5 ? 'text-red-600' : ''}`}>{secondsLeft}</p>
                </div>
              </div>
              <div className="h-1.5 rounded-full bg-gold/20 overflow-hidden mb-3" aria-hidden="true">
                <div
                  className={`h-full rounded-full ${secondsLeft <= 5 ? 'bg-red-500' : 'bg-gold'}`}
                  style={{ width: `${(1 - progress) * 100}%` }}
                />
              </div>

              {/* Stage */}
              <motion.div
                animate={stage}
                className="relative h-80 rounded-2xl overflow-hidden select-none touch-none bg-gradient-to-b from-white/80 to-gold/15 border border-gold/30 shadow-inner"
              >
                {/* Trip-themed backdrop: the cover photo, softened */}
                {coverImage && (
                  <div
                    className="absolute inset-0 bg-cover bg-center opacity-[0.16] blur-[2px] scale-110 pointer-events-none"
                    style={{ backgroundImage: `url("${coverImage}")` }}
                    aria-hidden="true"
                  />
                )}

                {items.map(i => {
                  const power = isPowerUp(i.kind);
                  return (
                    <button
                      key={i.id}
                      type="button"
                      onPointerDown={e => { e.preventDefault(); tap(i); }}
                      aria-label={i.label}
                      className="absolute flex flex-col items-center justify-center gap-0.5 leading-none"
                      style={{ width: ITEM, height: ITEM, left: `${i.x}%`, top: 0, transform: `translateY(${i.y}px)` }}
                    >
                      {power ? (
                        <span className="w-11 h-11 rounded-full bg-gold/25 ring-2 ring-gold text-primary flex items-center justify-center shadow-[0_0_14px_rgba(200,150,42,0.6)]">
                          <i.Icon size={26} weight="duotone" aria-hidden="true" />
                        </span>
                      ) : (
                        <i.Icon
                          size={i.kind === 'golden' ? 46 : 42}
                          weight={i.kind === 'golden' ? 'fill' : 'duotone'}
                          className={i.kind === 'golden' ? 'text-gold drop-shadow-[0_0_10px_rgba(200,150,42,0.9)]' : 'text-primary drop-shadow-[0_2px_3px_rgba(45,33,24,0.18)]'}
                          aria-hidden="true"
                        />
                      )}
                      <span className="text-[10px] font-semibold text-dark">{i.label}</span>
                    </button>
                  );
                })}

                {/* Items flying into the bag */}
                {flying.map(f => (
                  <motion.span
                    key={f.id}
                    className={`absolute pointer-events-none ${f.golden ? 'text-gold' : 'text-primary'}`}
                    initial={{ left: `${f.x}%`, top: f.y, scale: 1, opacity: 1 }}
                    animate={{ left: '44%', top: AREA_H - 64, scale: 0.3, opacity: 0 }}
                    transition={{ duration: 0.4, ease: 'easeIn' }}
                    aria-hidden="true"
                  >
                    <f.Icon size={36} weight={f.golden ? 'fill' : 'duotone'} />
                  </motion.span>
                ))}

                {pops.map(p => (
                  <motion.span
                    key={p.id}
                    className={`absolute pointer-events-none text-xl font-extrabold whitespace-nowrap drop-shadow ${p.good ? 'text-green-600' : 'text-red-600'}`}
                    style={{ left: `${p.x}%`, top: Math.max(p.y, 0) }}
                    initial={{ y: 0, opacity: 1, scale: 0.8 }}
                    animate={{ y: reduce ? 0 : -34, opacity: 0, scale: 1.2 }}
                    transition={{ duration: 0.6 }}
                  >
                    {p.text}
                  </motion.span>
                ))}

                {/* The bag */}
                <motion.div
                  animate={bag}
                  className="absolute bottom-2 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-gradient-to-b from-gold/40 to-gold/10 border border-gold/50 flex items-center justify-center shadow-[0_6px_20px_rgba(200,150,42,0.35)] pointer-events-none"
                  aria-hidden="true"
                >
                  <Backpack size={36} weight="duotone" className="text-primary" />
                </motion.div>

                {flash && (
                  <div className={`absolute inset-0 pointer-events-none ${flash === 'bad' ? 'bg-red-500/20' : 'bg-green-500/10'}`} aria-hidden="true" />
                )}

                {/* First-play tip */}
                <AnimatePresence>
                  {showHint && !paused && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="absolute top-3 inset-x-3 flex items-center justify-center gap-2 rounded-full bg-dark/85 text-white text-xs font-semibold px-3 py-2 pointer-events-none"
                    >
                      <HandTap size={16} weight="fill" /> Tap what you&apos;d really pack. Skip the rest!
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Pause overlay */}
                {paused && (
                  <div className="absolute inset-0 bg-cream/90 backdrop-blur-sm flex flex-col items-center justify-center gap-3 p-6">
                    <p className="font-display text-2xl font-bold">Paused</p>
                    <button type="button" onClick={() => setPaused(false)} className={primaryBtn}><Play size={18} weight="fill" /> Resume</button>
                    <button type="button" onClick={() => { setPaused(false); setPhase('idle'); itemsRef.current = []; setItems([]); }} className={ghostBtn}>Quit game</button>
                  </div>
                )}
              </motion.div>

              <div className="flex items-center justify-between mt-3">
                <button type="button" onClick={() => setPaused(true)} className={iconBtn} aria-label="Pause game"><Pause size={16} weight="fill" /></button>
                <p className="text-xs text-dark-muted">Packed so far: {packed}</p>
                <button type="button" onClick={toggleMute} className={iconBtn} aria-label={muted ? 'Turn sound on' : 'Turn sound off'}>
                  {muted ? <SpeakerSlash size={16} /> : <SpeakerHigh size={16} />}
                </button>
              </div>
            </div>
          )}

          {/* ── Result ── */}
          {phase === 'done' && (
            <div className="relative text-center pt-2">
              {!reduce && (r.stars >= 2 || isNewBest) && <Confetti />}
              <span className={`inline-block text-[11px] font-bold uppercase tracking-[0.16em] rounded-full px-3 py-1 mb-2 ${isNewBest ? 'bg-gold text-dark' : 'bg-white text-dark-muted border border-gold/30'}`}>
                {isNewBest ? 'New best!' : "Time's up"}
              </span>
              <motion.p
                className="font-display text-6xl font-extrabold leading-none"
                initial={reduce ? false : { scale: 0.4, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 220, damping: 14 }}
              >
                {score}
              </motion.p>

              <div className="flex justify-center gap-1.5 my-3" aria-label={`${r.stars} out of 3 stars`}>
                {[1, 2, 3].map(n => (
                  <motion.span
                    key={n}
                    initial={reduce ? false : { scale: 0, rotate: -40 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.25 + n * 0.18, type: 'spring', stiffness: 260, damping: 12 }}
                  >
                    <Star size={34} weight="fill" className={n <= r.stars ? 'text-gold' : 'text-gold/20'} />
                  </motion.span>
                ))}
              </div>

              <p className="font-display text-xl font-bold">{r.title}</p>
              <p className="text-sm text-dark-muted mb-1">{r.blurb}</p>
              {!isNewBest && prevBest > 0 && (
                <p className="text-sm text-gold-deep font-medium mb-1">
                  {prevBest - score <= 20 ? `So close! Just ${prevBest - score + 1} more to beat your best.` : `Your best is ${prevBest}. Go get it!`}
                </p>
              )}

              <div className="grid grid-cols-2 gap-2 my-4">
                <div className="rounded-xl bg-white/70 border border-gold/30 py-2.5">
                  <p className="font-display text-2xl font-bold">{packed}</p>
                  <p className="text-[10px] uppercase tracking-wider text-dark-muted">Items packed</p>
                </div>
                <div className="rounded-xl bg-white/70 border border-gold/30 py-2.5">
                  <p className="font-display text-2xl font-bold">×{bestCombo}</p>
                  <p className="text-[10px] uppercase tracking-wider text-dark-muted">Best combo</p>
                </div>
              </div>

              <div className="text-left rounded-xl bg-white/70 border border-gold/30 p-3 mb-4">
                <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-dark-muted/70 mb-2">Your real packing list</p>
                <div className="flex flex-wrap gap-1.5">
                  {profile.good.map(g => (
                    <span key={g.label} className="inline-flex items-center gap-1 text-xs bg-white/80 border border-gold/30 rounded-full px-2.5 py-1">
                      <g.Icon size={14} weight="duotone" className="text-primary" /> {g.label}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mb-3">
                <button type="button" onClick={begin} className={primaryBtn.replace('py-3.5', 'py-3')}><ArrowCounterClockwise size={18} /> Play again</button>
                <button type="button" onClick={() => void share()} disabled={sharing} className={ghostBtn}><ShareNetwork size={18} /> {sharing ? 'Preparing…' : 'Share score card'}</button>
              </div>
              <a
                href={notifyHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-dark transition-colors"
              >
                <WhatsappLogo size={16} weight="fill" aria-hidden="true" />
                Notify me when this trip opens
              </a>
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}
