import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import SectionTitle from '../../components/ui/SectionTitle';
import { getSiteContent } from '../../services/api';
import { DEFAULT_WHY_ULAA } from '../../constants/why-ulaa';
import type { WhyUlaaContent } from '../../types/types-index';

export default function WhyULAA() {
  const [content, setContent] = useState<WhyUlaaContent>(DEFAULT_WHY_ULAA);

  useEffect(() => {
    getSiteContent<WhyUlaaContent>('why_ulaa')
      .then(data => { if (data) setContent(data); })
      .catch(() => {});
  }, []);

  const { features, sub_heading, heading, subheading } = content;

  return (
    <section className="relative isolate pt-6 pb-12 sm:py-12 px-4 sm:px-6 lg:px-8 bg-cream">
      <div className="max-w-[1344px] mx-auto">
        <div className="mb-8 sm:mb-16 flex justify-center">
          <SectionTitle
            label={sub_heading}
            title={heading}
            subtitle={subheading}
            align="center"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 md:gap-8">
          {features.map(({ image, title, description }, index) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              whileHover={{ y: -4 }}
              className="relative aspect-[4/3] rounded-lg sm:rounded-xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 group"
            >
              <img
                src={image}
                alt={title}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div
                className="absolute inset-0"
                style={{
                  background: 'rgba(0, 0, 0, 0.4)',
                }}
              />
              <div className="relative h-full flex flex-col justify-end p-3 sm:p-4">
                <h3 className="font-display text-sm sm:text-base font-bold text-white mb-1">
                  {title}
                </h3>
                <p className="text-white/90 text-xs leading-snug">
                  {description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}