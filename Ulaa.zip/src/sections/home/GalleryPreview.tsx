import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  MagnifyingGlassPlus as ZoomIn,
} from '@phosphor-icons/react';
import SectionTitle from '../../components/ui/SectionTitle';
import GalleryViewer from '../../components/ui/GalleryViewer';
import { getGalleryImages } from '../../services/api';

const FALLBACK_IMAGES = [
  'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=500&q=80',
  'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=400&q=80',
  'https://images.unsplash.com/photo-1619546813926-a78fa6372cd2?w=500&q=80',
  'https://images.unsplash.com/photo-1598091381862-6a65b2a36ab4?w=400&q=80',
  'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=500&q=80',
  'https://images.unsplash.com/photo-1519922639192-e73293ca430e?w=400&q=80',
  'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=500&q=80',
  'https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=400&q=80',
  'https://images.unsplash.com/photo-1591017403997-beeee1ec6981?w=500&q=80',
];

export default function GalleryPreview() {
  const [images, setImages] = useState<string[]>(FALLBACK_IMAGES);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    getGalleryImages()
      .then(data => {
        if (data.length > 0) {
          setImages(data.map(img => img.image_url).slice(0, 9));
        }
      })
      .catch(console.error);
  }, []);

  const open = (i: number) => {
    setSelectedIndex(i);
    setLightboxOpen(true);
  };

  return (
    <section className="pt-12 pb-12 sm:py-12 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-[1344px] mx-auto">
        <div className="flex flex-col items-center mb-8 sm:mb-16">
          <SectionTitle
            label="Instagram Moments"
            title="Frame by frame."
            subtitle="Every destination. Every memory. Every woman who dared to explore."
            align="center"
          />
        </div>

        {/* Uniform Instagram-style grid — every tile is the same square
            aspect ratio, so the grid always fills perfectly edge-to-edge
            no matter how many images there are. (The earlier row-span
            "masonry" grid, and then a CSS-columns masonry attempt, both
            left a gap: fixed spans only tile cleanly for specific image
            counts, and CSS columns strand empty space whenever an image
            with break-inside-avoid doesn't fit the remaining column
            height and gets pushed whole to the next column. A uniform
            grid has no such failure mode.) */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
          {images.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.06 }}
              onClick={() => open(i)}
              className="group relative aspect-square overflow-hidden rounded-lg cursor-pointer"
            >
              <motion.img
                layoutId={`home-gallery-${i}`}
                src={img}
                alt={`Ulaa Gallery ${i + 1}`}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/30 transition-all duration-300 flex items-center justify-center">
                <ZoomIn
                  size={28}
                  className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                />
              </div>
            </motion.div>
          ))}
        </div>

        <GalleryViewer
          images={images}
          initialIndex={selectedIndex}
          isOpen={lightboxOpen}
          onClose={() => setLightboxOpen(false)}
          openLayoutId={`home-gallery-${selectedIndex}`}
        />
      </div>
    </section>
  );
}
