import { supabase } from '../../supabase';
import { formatPrice } from '../../../utils/utils-index';
import type { Enquiry, Payment } from '../../../types/types-index';
import { PAYMENT_TYPE_LOG_LABEL, refreshJourneyStage, autoSendBookingEmail } from './shared';
import { logActivity } from './activity';
import { getPaymentsForEnquiry } from './payments';

// =============================================
// Enquiries — invoices
// =============================================

// Raises an invoice for money that hasn't been collected yet — e.g. a
// Balance or Installment invoice generated ahead of the customer actually
// paying it (Scenario 2/3 in the invoicing flow). Inserted with
// status = 'pending', so sync_enquiry_amount_paid() leaves
// enquiries.amount_paid untouched until markInvoicePaid flips it later.
export async function generatePendingInvoice(
  enquiryId: string,
  type: 'full_payment' | 'advance' | 'balance' | 'installment',
  amount: number,
  notes?: string
): Promise<Payment> {
  if (amount <= 0) {
    throw new Error('Invoice amount must be greater than zero.');
  }
  const { data, error } = await supabase
    .from('payments')
    .insert({ enquiry_id: enquiryId, amount, payment_type: type, status: 'pending', notes })
    .select()
    .single();
  if (error) throw error;
  await logActivity(enquiryId, `Invoice generated · ${PAYMENT_TYPE_LOG_LABEL[type] || type}`, `${formatPrice(amount)} · pending`);
  return data;
}

// Adds an add-on charge to an existing booking (e.g. a hotel upgrade) —
// bumps enquiries.total_amount by the charge amount right away, since
// that's now part of what's owed whether or not it's been collected yet,
// and logs an 'addon' invoice for it. Pass collectedNow: true if the
// customer paid on the spot; otherwise the invoice is raised as 'pending'
// and can be settled later via markInvoicePaid.
export async function addAddonCharge(
  current: Enquiry,
  amount: number,
  options?: { collectedNow?: boolean; payment_method?: string; utr_number?: string; notes?: string; markAsChildAddon?: boolean }
): Promise<Enquiry> {
  if (amount <= 0) {
    throw new Error('Add-on amount must be greater than zero.');
  }
  const newTotal = (current.total_amount || 0) + amount;

  const { error: totalError } = await supabase
    .from('enquiries')
    .update(options?.markAsChildAddon ? { total_amount: newTotal, has_child_addon: true } : { total_amount: newTotal })
    .eq('id', current.id);
  if (totalError) throw totalError;

  const { error: paymentError } = await supabase.from('payments').insert({
    enquiry_id: current.id,
    amount,
    payment_type: 'addon',
    status: options?.collectedNow ? 'paid' : 'pending',
    payment_method: options?.payment_method,
    utr_number: options?.collectedNow ? (options?.utr_number || null) : null,
    notes: options?.notes,
  });
  if (paymentError) throw paymentError;

  const { data, error } = await supabase.from('enquiries').select('*').eq('id', current.id).single();
  if (error) throw error;
  const updated = await refreshJourneyStage(data.id);
  await logActivity(current.id, 'Add-on added', `${formatPrice(amount)}${options?.collectedNow ? ' · collected' : ' · pending'}`);
  // Only when the add-on was actually collected on the spot — a pending
  // add-on invoice hasn't moved any money yet, so there's nothing to
  // confirm receipt of (see markInvoicePaid for when that money comes in
  // later instead).
  if (options?.collectedNow) {
    await autoSendBookingEmail(updated, await getPaymentsForEnquiry(current.id));
  }
  return updated;
}

// Settles a 'pending' invoice (a balance/installment invoice raised ahead of
// collection, or an extra charge not yet paid) once the money actually comes
// in. Flips status to 'paid' and stamps paid_at — the existing
// sync_amount_paid_on_payments_change trigger fires on this UPDATE the same
// way it does on insert, folding the amount into enquiries.amount_paid.
export async function markInvoicePaid(
  paymentId: string,
  options?: { payment_method?: string; utr_number?: string }
): Promise<Payment> {
  // NOTE: this was previously updating the `enquiries` table by paymentId
  // (a payments.id, not an enquiries.id) with columns (`status: 'paid'`,
  // `paid_at`) that don't exist on `enquiries` — every call would fail
  // (either no matching row, or a column-does-not-exist error). `status`/
  // `paid_at`/`payment_method` are payments columns; the intended target
  // was always this row itself. Fixed in place rather than left broken
  // since it's the "Mark Paid" action the Invoice system (spec section 11)
  // depends on.
  const { data, error } = await supabase
    .from('payments')
    .update({
      status: 'paid',
      paid_at: new Date().toISOString(),
      ...(options?.payment_method ? { payment_method: options.payment_method } : {}),
      ...(options?.utr_number ? { utr_number: options.utr_number } : {}),
    })
    .eq('id', paymentId)
    .select()
    .single();
  if (error) throw error;
  const updated = await refreshJourneyStage(data.enquiry_id);
  await logActivity(data.enquiry_id, 'Invoice marked paid', `${data.payment_type} · ${formatPrice(data.amount)}${data.invoice_number ? ` · ${data.invoice_number}` : ''}`);
  // The money for a pending invoice actually lands here, not at creation
  // time — see autoSendBookingEmail in shared.ts.
  await autoSendBookingEmail(updated, await getPaymentsForEnquiry(data.enquiry_id));
  return data;
}
