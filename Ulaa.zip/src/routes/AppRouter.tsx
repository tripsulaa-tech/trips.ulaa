import { lazy, Suspense, useLayoutEffect, useRef } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider } from '../context/AuthContext';
import { useAuth } from '../context/useAuth';
import { motion } from 'framer-motion';
import InstallAppBanner from '../components/ui/InstallAppBanner';
import BottomNav from '../components/layout/BottomNav';
import { scrollToInstant } from '../utils/scroll';
import BrandingFavicon from '../components/layout/BrandingFavicon';

// The browser's own back/forward scroll restoration tries to remember and
// replay scroll positions per history entry, which fights with our own
// per-route logic below (ScrollToTop / useScrollRestoration) — the two
// would both try to move the page, sometimes to different places, producing
// a visible double-jump. Taking manual control here means our logic is the
// only thing that ever moves the scroll position on navigation.
if (typeof window !== 'undefined' && 'scrollRestoration' in window.history) {
  window.history.scrollRestoration = 'manual';
}

// Scrolls the window to the top whenever the route changes, so navigating
// (e.g. via the footer's Upcoming Trips / Completed Trips / About / Contact
// links) always lands the user at the top of the destination page. Also
// moves keyboard/screen-reader focus to the new page, since client-side
// routing never does what a full page load does for free (reset focus to
// the top of the document).
function ScrollToTop() {
  const { pathname } = useLocation();
  // True only for the very first render of the whole app (a hard page
  // load) — focus is deliberately left alone there, since the browser's
  // own default (the document) is what's expected on first load, not an
  // immediate jump into the content. Every render after that is a
  // client-side navigation, where moving focus is the part a full page
  // load would otherwise have done for free.
  const isInitialLoad = useRef(true);

  // Layout effect (runs synchronously before paint) + an instant jump
  // instead of an animated one: the position is already correct in the
  // first frame the user sees, rather than visibly sliding into place
  // after the new page has appeared. Layout's own fade-in is the motion
  // that's actually meant to be seen.
  useLayoutEffect(() => {
    // Some pages (e.g. the completed-trips albums grid) ask to restore the
    // scroll position the user was at instead of jumping to the top — for
    // example when they follow an album's "All Albums" link back to the
    // grid they were browsing. When that flag is set for this pathname,
    // skip the reset and let the destination page's own restoration
    // handle it (see hooks/useScrollRestoration.ts).
    if (!sessionStorage.getItem(`ulaa:restoreScroll:${pathname}`)) {
      scrollToInstant(0);
    }

    if (isInitialLoad.current) {
      isInitialLoad.current = false;
      return;
    }

    // Admin routes don't render Layout's #main-content landmark (see
    // components/layout/Layout.tsx), so this simply finds nothing there
    // and no-ops. Public routes are lazy-loaded, so the destination page
    // can still be mid-Suspense (its chunk not yet fetched) at this exact
    // instant — retry across a few animation frames rather than giving up
    // immediately, the same bounded-retry shape
    // hooks/useScrollRestoration.ts uses for the same "content isn't
    // mounted yet" race. `preventScroll` avoids a second, redundant jump —
    // the scroll position was already set above.
    let cancelled = false;
    let rafId = 0;
    const deadline = performance.now() + 1000;
    const tryFocus = () => {
      if (cancelled) return;
      const main = document.getElementById('main-content');
      if (main) {
        main.focus({ preventScroll: true });
        return;
      }
      if (performance.now() < deadline) {
        rafId = requestAnimationFrame(tryFocus);
      }
    };
    rafId = requestAnimationFrame(tryFocus);

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafId);
    };
  }, [pathname]);

  return null;
}

// main.tsx swaps the manifest/icon links once, on the initial hard page
// load. That covers a visitor who types /admin directly, but not one who
// lands on "/" and then clicks through to /admin (or back) via client-side
// routing — the manifest link never got re-pointed for that navigation, so
// installing from the "wrong" route re-served the previous route's
// manifest. Re-run the same swap on every route change so it stays correct
// no matter how the visitor got there.
// Rendered once here, outside <Routes>, instead of inside each page's
// <Layout>. Layout used to render its own BottomNav, so navigating between
// pages unmounted and remounted it every time — replaying its entrance
// animation (so it never read as "sticky") and resetting the active-tab
// indicator's layoutId tracking (so it jumped instead of sliding). Keeping
// a single persistent instance here fixes both: it only mounts/unmounts
// when crossing the public/admin boundary, which is the one case where a
// fresh entrance is actually correct.
function PersistentBottomNav() {
  const { pathname } = useLocation();
  if (pathname.startsWith('/admin')) return null;
  return <BottomNav />;
}


// Public Pages
const HomePage = lazy(() => import('../pages/HomePage'));
const UpcomingTripsPage = lazy(() => import('../pages/UpcomingTripsPage'));
const TripDetailPage = lazy(() => import('../pages/TripDetailPage'));
const CompletedTripsPage = lazy(() => import('../pages/CompletedTripsPage'));
const AlbumPage = lazy(() => import('../pages/AlbumPage'));
const AboutPage = lazy(() => import('../pages/AboutPage'));
const ContactPage = lazy(() => import('../pages/ContactPage'));
const GamesPage = lazy(() => import('../pages/GamesPage'));
const StowawayJoinPage = lazy(() => import('../pages/StowawayJoinPage'));
const FindMyTwinJoinPage = lazy(() => import('../pages/FindMyTwinJoinPage'));

// Admin Pages
const AdminLogin = lazy(() => import('../admin/AdminLogin'));
const AdminDashboard = lazy(() => import('../admin/AdminDashboard'));
const AdminTrips = lazy(() => import('../admin/AdminTrips'));
const AdminAlbums = lazy(() => import('../admin/AdminAlbums'));
const AdminTripFinance = lazy(() => import('../admin/AdminTripFinance'));
const AdminEnquiries = lazy(() => import('../admin/enquiries/AdminEnquiries'));
const AdminEnquiryDetail = lazy(() => import('../admin/enquiries/AdminEnquiryDetail'));
const AdminTravellers = lazy(() => import('../admin/travellers/AdminTravellers'));
const AdminWaitlist = lazy(() => import('../admin/AdminWaitlist'));
const AdminReports = lazy(() => import('../admin/AdminReports'));
const AdminAbout = lazy(() => import('../admin/AdminAbout'));
const AdminHomePage = lazy(() => import('../admin/AdminHomePage'));
const AdminTripLeaders = lazy(() => import('../admin/AdminTripLeaders'));
const AdminCreatorRateCalculator = lazy(() => import('../admin/AdminCreatorRateCalculator'));
const AdminInvoiceGenerator = lazy(() => import('../admin/AdminInvoiceGenerator'));
const AdminTravelCards = lazy(() => import('../admin/AdminTravelCards'));
const AdminLogoStudio = lazy(() => import('../admin/AdminLogoStudio'));
const AdminGames = lazy(() => import('../admin/AdminGames'));

const PageLoader = () => (
  <div className="fixed inset-0 bg-background flex items-center justify-center z-50">
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
      className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full"
    />
  </div>
);

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) return <Navigate to="/admin" replace />;
  return <>{children}</>;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (user) return <Navigate to="/admin/dashboard" replace />;
  return <>{children}</>;
}

export default function AppRouter() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ScrollToTop />
        <BrandingFavicon />
        <InstallAppBanner />
        <PersistentBottomNav />
        <Suspense fallback={<PageLoader />}>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<HomePage />} />
            <Route path="/trips" element={<UpcomingTripsPage />} />
            <Route path="/trips/:slug" element={<TripDetailPage />} />
            <Route path="/completed-trips" element={<CompletedTripsPage />} />
            <Route path="/completed-trips/:slug" element={<AlbumPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/games" element={<GamesPage />} />
            <Route path="/play/stowaway" element={<StowawayJoinPage />} />
            <Route path="/play/stowaway/:code" element={<StowawayJoinPage />} />
            <Route path="/play/twin" element={<FindMyTwinJoinPage />} />
            <Route path="/play/twin/:code" element={<FindMyTwinJoinPage />} />

            {/* Admin Routes */}
            <Route path="/admin" element={
              <AdminRoute><AdminLogin /></AdminRoute>
            } />
            <Route path="/admin/dashboard" element={
              <ProtectedRoute><AdminDashboard /></ProtectedRoute>
            } />
            <Route path="/admin/trips" element={
              <ProtectedRoute><AdminTrips /></ProtectedRoute>
            } />
            <Route path="/admin/trips/:id/preview" element={
              <ProtectedRoute><TripDetailPage /></ProtectedRoute>
            } />
            <Route path="/admin/albums" element={
              <ProtectedRoute><AdminAlbums /></ProtectedRoute>
            } />
            <Route path="/admin/trip-finance" element={
              <ProtectedRoute><AdminTripFinance /></ProtectedRoute>
            } />
            <Route path="/admin/enquiries" element={
              <ProtectedRoute><AdminEnquiries /></ProtectedRoute>
            } />
            <Route path="/admin/enquiries/:id" element={
              <ProtectedRoute><AdminEnquiryDetail /></ProtectedRoute>
            } />
            <Route path="/admin/waitlist" element={
              <ProtectedRoute><AdminWaitlist /></ProtectedRoute>
            } />
            <Route path="/admin/travellers" element={
              <ProtectedRoute><AdminTravellers /></ProtectedRoute>
            } />
            <Route path="/admin/reports" element={
              <ProtectedRoute><AdminReports /></ProtectedRoute>
            } />
            <Route path="/admin/about" element={
              <ProtectedRoute><AdminAbout /></ProtectedRoute>
            } />
            <Route path="/admin/home" element={
              <ProtectedRoute><AdminHomePage /></ProtectedRoute>
            } />
            <Route path="/admin/trip-leaders" element={
              <ProtectedRoute><AdminTripLeaders /></ProtectedRoute>
            } />
            <Route path="/admin/creator-rate-calculator" element={
              <ProtectedRoute><AdminCreatorRateCalculator /></ProtectedRoute>
            } />
            <Route path="/admin/invoice-generator" element={
              <ProtectedRoute><AdminInvoiceGenerator /></ProtectedRoute>
            } />
            <Route path="/admin/travel-cards" element={
              <ProtectedRoute><AdminTravelCards /></ProtectedRoute>
            } />
            <Route path="/admin/games" element={
              <ProtectedRoute><AdminGames /></ProtectedRoute>
            } />
            <Route path="/admin/branding" element={<Navigate to="/admin/logo-studio" replace />} />
            <Route path="/admin/logo-studio" element={
              <ProtectedRoute><AdminLogoStudio /></ProtectedRoute>
            } />

            {/* 404 */}
            <Route path="*" element={
              <div className="min-h-screen flex flex-col items-center justify-center bg-background text-center px-4">
                <h1 className="font-display text-8xl font-bold text-primary mb-4">404</h1>
                <p className="text-dark-muted text-xl mb-8">This page doesn't exist.</p>
                <a href="/" className="bg-primary text-white px-6 py-3 rounded-lg font-button font-semibold hover:bg-primary-dark transition-colors">
                  Go Home
                </a>
              </div>
            } />
          </Routes>
        </Suspense>
      </AuthProvider>
    </BrowserRouter>
  );
}
