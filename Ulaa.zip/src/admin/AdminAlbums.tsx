import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  PencilSimple as Edit2,
  Trash as Trash2,
  Eye,
  EyeSlash as EyeOff,
} from '@phosphor-icons/react';
import AdminLayout from './AdminLayout';
import Button from '../components/ui/Button';
import AddFab from '../components/ui/AddFab';
import Modal from '../components/ui/Modal';
import ImageUploadField from '../components/ui/ImageUploadField';
import MultiImageUploadField from '../components/ui/MultiImageUploadField';
import DatePicker from '../components/ui/DatePicker';
import { getAllCompletedTripsAdmin, createCompletedTrip, updateCompletedTrip, deleteCompletedTripCascade, getCompletedTripDeletionImpact, deleteImageByUrl, COVER_IMAGE_TARGET_SIZE_BYTES } from '../services/api';

import { useConfirm } from '../components/ui/useConfirm';
import type { CompletedTrip } from '../types/types-index';
import { formatDate, slugify, formatBatchLabel, formatBatchShortLabel } from '../utils/utils-index';
import { FORM_INPUT_CLASS as inputClass } from '../constants/formStyles';

interface AlbumForm {
  title: string;
  destination: string;
  map_url: string;
  trip_date: string;
  description: string;
  batch: string;
  participants: number;
  cover_image: string;
  gallery_images: string[];
  is_published: boolean;
}

type AlbumFormErrors = Partial<Record<'title' | 'destination' | 'trip_date' | 'description', string>>;

// Same title+batch duplicate check handleSave used to only run after the
// fact via alert() — pulled out so the modal can also compute it live, as
// the admin types, instead of only surfacing behind an alert() after
// clicking Save. All the data this needs (the full album list) is already
// on the page, so there's no reason it has to wait for a save attempt.
function findDuplicateAlbum(form: AlbumForm, albums: CompletedTrip[], editingId: string | undefined): CompletedTrip | null {
  const titleNorm = form.title.trim().toLowerCase();
  if (!titleNorm) return null;
  const batchNorm = form.batch.trim().toLowerCase();
  return albums.find(a =>
    a.id !== editingId &&
    a.title.trim().toLowerCase() === titleNorm &&
    (a.batch || '').trim().toLowerCase() === batchNorm
  ) || null;
}

export default function AdminAlbums() {
  const confirm = useConfirm();
  const [albums, setAlbums] = useState<CompletedTrip[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<CompletedTrip | null>(null);
  const [viewing, setViewing] = useState<CompletedTrip | null>(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<AlbumFormErrors>({});
  const [form, setForm] = useState<AlbumForm>({
    title: '', destination: '', map_url: '', trip_date: '', description: '', batch: '', participants: 10, cover_image: '', gallery_images: [], is_published: false,
  });

  const load = () => {
    getAllCompletedTripsAdmin().then(setAlbums).catch(console.error).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditing(null);
    setErrors({});
    const emptyAlbumForm: AlbumForm = { title: '', destination: '', map_url: '', trip_date: '', description: '', batch: '', participants: 10, cover_image: '', gallery_images: [], is_published: false };
    setForm(emptyAlbumForm);
    initialModalUrlsRef.current = collectAlbumFormUrls(emptyAlbumForm);
    setModalOpen(true);
  };

  const openEdit = (album: CompletedTrip) => {
    setEditing(album);
    setErrors({});
    const editForm: AlbumForm = { title: album.title, destination: album.destination, map_url: album.map_url || '', trip_date: album.trip_date, description: album.description, batch: album.batch || '', participants: album.participants, cover_image: album.cover_image || '', gallery_images: album.gallery_images || [], is_published: album.is_published };
    setForm(editForm);
    initialModalUrlsRef.current = collectAlbumFormUrls(editForm);
    setModalOpen(true);
  };

  const validate = (): AlbumFormErrors => {
    const next: AlbumFormErrors = {};
    if (!form.title.trim()) next.title = 'Album title is required.';
    if (!form.destination.trim()) next.destination = 'Destination is required.';
    if (!form.trip_date.trim()) next.trip_date = 'Trip date is required.';
    if (!form.description.trim()) next.description = 'Description is required.';
    return next;
  };

  const handleSave = async () => {
    const fieldErrors = validate();
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      return;
    }
    setErrors({});

    const batch = form.batch.trim() || undefined;
    const duplicate = findDuplicateAlbum(form, albums, editing?.id);
    if (duplicate) {
      alert('An album with this title already exists' + (batch ? ' for this batch' : '') + '. Use a different batch, or change the title.');
      return;
    }

    try {
      setSaving(true);
      // The slug is a storage-folder path (see the `albums/{slug}/...`
      // pathPrefixes used throughout this form), so it must stay stable
      // once an album exists -- recomputing it from the title/batch on
      // every save would silently point the album at a new, empty
      // folder while its photos stay behind in the old one. Only set it
      // on create; on edit, the existing slug column is left untouched.
      const slugSource = batch ? `${form.title} ${batch}` : form.title;
      const data = { ...form, batch, ...(editing ? {} : { slug: slugify(slugSource) }) };
      if (editing) await updateCompletedTrip(editing.id, data);
      else await createCompletedTrip(data);
      // All uploads committed to DB — nothing to clean up on close.
      initialModalUrlsRef.current = new Set();
      setModalOpen(false);
      load();
    } catch { alert('Failed to save. Please check your connection and try again.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (album: CompletedTrip) => {
    const impact = await getCompletedTripDeletionImpact(album.id).catch(() => null);
    const parts: string[] = [];
    if (impact) {
      if (impact.enquiries > 0) parts.push(`${impact.enquiries} ${impact.enquiries === 1 ? 'enquiry' : 'enquiries'}`);
      if (impact.waitlist > 0) parts.push(`${impact.waitlist} waitlist ${impact.waitlist === 1 ? 'entry' : 'entries'}`);
      if (impact.photos > 0) parts.push(`${impact.photos} ${impact.photos === 1 ? 'photo' : 'photos'}`);
    }
    const message = parts.length
      ? `Deleting "${album.title}" also permanently removes ${parts.join(', ')} linked to it. This cannot be undone.`
      : `This will permanently delete "${album.title}". This cannot be undone.`;
    if (!(await confirm({ title: 'Delete this album?', message, confirmLabel: 'Delete everything' }))) return;
    await deleteCompletedTripCascade(album);
    load();
  };

  const togglePublish = async (album: CompletedTrip) => {
    await updateCompletedTrip(album.id, { is_published: !album.is_published });
    load();
  };

  // Tracks the set of image URLs that were already in the form when the
  // modal opened. Any storage URL present at close-time that was NOT in this
  // snapshot was uploaded during the session but never saved — delete it
  // best-effort so it doesn't sit around as an orphan in the bucket.
  const initialModalUrlsRef = useRef<Set<string>>(new Set());

  const collectAlbumFormUrls = (f: AlbumForm): Set<string> => {
    const urls = new Set<string>();
    const add = (u?: string) => { if (u) urls.add(u); };
    add(f.cover_image);
    f.gallery_images?.forEach(u => add(u));
    return urls;
  };

  const STORAGE_BUCKET = 'ulaa';
  const isStorageUrl = (url: string) => url.includes(`/object/public/${STORAGE_BUCKET}/`);

  const closeModal = () => {
    const currentUrls = collectAlbumFormUrls(form);
    const initial = initialModalUrlsRef.current;
    for (const url of currentUrls) {
      if (!initial.has(url) && isStorageUrl(url)) {
        deleteImageByUrl(STORAGE_BUCKET, url).catch(() => {});
      }
    }
    initialModalUrlsRef.current = new Set();
    setModalOpen(false);
  };

  // Live, as the admin types — recomputed on every render so a
  // title+batch clash shows up immediately instead of only behind an
  // alert() after Save.
  const duplicateAlbum = findDuplicateAlbum(form, albums, editing?.id);

  return (
    <AdminLayout title="Completed Trips" scrollRestorationReady={!loading}>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <p className="text-dark-muted">{albums.length} albums</p>
          <div className="hidden sm:block">
            <Button variant="primary" size="sm" onClick={openCreate}><Plus size={16} aria-hidden="true" /> Add Album</Button>
          </div>
        </div>
        <AddFab onClick={openCreate} label="Add album" />

        {loading ? (
          <div role="status" className="text-center py-16 text-dark-muted">Loading...</div>
        ) : (
          <>
            {/* Mobile (below sm): a card per album — the desktop table's
                hidden md/lg columns (destination, date, participants,
                photos) meant a phone was left with only a cramped
                title/status/actions row, so this gives every field room to
                breathe instead. Same pattern as AdminTripLeaders. */}
            <div className="sm:hidden space-y-3">
              {albums.map(album => (
                <motion.div
                  key={album.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white rounded-lg shadow-card p-4 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      {album.cover_image ? (
                        <img src={album.cover_image} alt={album.title} className="w-12 h-12 rounded-md object-cover flex-shrink-0" loading="lazy" decoding="async" />
                      ) : (
                        <div className="w-12 h-12 rounded-md bg-background-warm flex-shrink-0" />
                      )}
                      <div className="min-w-0">
                        <button
                          onClick={() => setViewing(album)}
                          className="text-sm font-medium text-dark truncate text-left hover:text-primary hover:underline underline-offset-2 block"
                          aria-label={`View details for ${album.title}`}
                        >
                          {album.title}
                        </button>
                        <p className="text-xs text-dark-muted truncate">{album.destination}</p>
                      </div>
                    </div>
                    <span className={`shrink-0 text-[10px] font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${album.is_published ? 'bg-green-100 text-green-700' : 'bg-background-warm text-dark-muted'}`}>
                      {album.is_published ? 'Published' : 'Draft'}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {album.batch && (
                      <span className="text-xs font-button font-medium text-primary bg-background-warm px-2 py-0.5 rounded-full whitespace-nowrap">
                        {formatBatchLabel(album.batch)}
                      </span>
                    )}
                    <span className="text-xs text-dark-muted whitespace-nowrap">{formatDate(album.trip_date, { month: 'long', year: 'numeric' })}</span>
                    <span className="text-xs text-dark-muted whitespace-nowrap">{album.participants} participants</span>
                    <span className="text-xs text-dark-muted whitespace-nowrap">{album.gallery_images?.length || 0} photos</span>
                  </div>

                  <div className="flex items-center justify-end gap-1 pt-1 border-t border-background-warm">
                    <button
                      onClick={() => togglePublish(album)}
                      aria-pressed={album.is_published}
                      aria-label={album.is_published ? `Unpublish ${album.title}` : `Publish ${album.title}`}
                      className="p-2 rounded hover:bg-background text-dark-muted hover:text-primary transition-colors"
                    >
                      {album.is_published ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}
                    </button>
                    <button onClick={() => openEdit(album)} aria-label={`Edit ${album.title}`} className="p-2 rounded hover:bg-background text-dark-muted hover:text-primary transition-colors"><Edit2 size={16} aria-hidden="true" /></button>
                    <button onClick={() => handleDelete(album)} aria-label={`Delete ${album.title}`} className="p-2 rounded hover:bg-primary/5 text-dark-muted hover:text-primary transition-colors"><Trash2 size={16} aria-hidden="true" /></button>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Desktop (sm and up): the full table. */}
            <div className="hidden sm:block bg-white rounded-lg shadow-card overflow-hidden">
              <div className="overflow-x-auto scrollbar-hide">
                <table className="w-full text-sm">
                  <thead className="bg-background-warm text-dark font-medium">
                    <tr>
                      <th className="px-4 py-4 text-left">Album</th>
                      <th className="px-4 py-4 text-left hidden md:table-cell">Destination</th>
                      <th className="px-4 py-4 text-left hidden md:table-cell">Date</th>
                      <th className="px-4 py-4 text-left hidden lg:table-cell">Participants</th>
                      <th className="px-4 py-4 text-left hidden lg:table-cell">Photos</th>
                      <th className="px-2 py-4 text-center whitespace-nowrap">Status</th>
                      <th className="px-3 py-4 text-right whitespace-nowrap">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-background-warm">
                    {albums.map(album => (
                      <motion.tr key={album.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background/50">
                        <td className="px-4 py-4 font-medium text-dark max-w-[150px] sm:max-w-none">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <button
                              onClick={() => setViewing(album)}
                              className="truncate text-left hover:text-primary hover:underline underline-offset-2"
                              aria-label={`View details for ${album.title}`}
                            >
                              {album.title}
                            </button>
                            {album.batch && (
                              <span className="shrink-0 text-xs font-button font-medium text-primary bg-background-warm px-2 py-0.5 rounded-full whitespace-nowrap">
                                <span className="sm:hidden">{formatBatchShortLabel(album.batch)}</span>
                                <span className="hidden sm:inline">{formatBatchLabel(album.batch)}</span>
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-dark-muted hidden md:table-cell truncate">{album.destination}</td>
                        <td className="px-4 py-4 text-dark-muted hidden md:table-cell whitespace-nowrap">{formatDate(album.trip_date, { month: 'long', year: 'numeric' })}</td>
                        <td className="px-4 py-4 text-dark-muted hidden lg:table-cell">{album.participants}</td>
                        <td className="px-4 py-4 text-dark-muted hidden lg:table-cell">{album.gallery_images?.length || 0}</td>
                        <td className="px-2 py-4 text-center">
                          <span className={`text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${album.is_published ? 'bg-green-100 text-green-700' : 'bg-background-warm text-dark-muted'}`}>
                            {album.is_published ? 'Published' : 'Draft'}
                          </span>
                        </td>
                        <td className="pl-4 pr-3 py-4">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => togglePublish(album)}
                              aria-pressed={album.is_published}
                              aria-label={album.is_published ? `Unpublish ${album.title}` : `Publish ${album.title}`}
                              className="p-1.5 rounded hover:bg-background text-dark-muted hover:text-primary transition-colors"
                            >
                              {album.is_published ? <EyeOff size={15} aria-hidden="true" /> : <Eye size={15} aria-hidden="true" />}
                            </button>
                            <button onClick={() => openEdit(album)} aria-label={`Edit ${album.title}`} className="p-1.5 rounded hover:bg-background text-dark-muted hover:text-primary transition-colors"><Edit2 size={15} aria-hidden="true" /></button>
                            <button onClick={() => handleDelete(album)} aria-label={`Delete ${album.title}`} className="p-1.5 rounded hover:bg-primary/5 text-dark-muted hover:text-primary transition-colors"><Trash2 size={15} aria-hidden="true" /></button>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>

      <Modal isOpen={modalOpen} onClose={closeModal} title={editing ? 'Edit Album' : 'Add Album'} size="lg">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label htmlFor="album-title" className="block text-sm font-medium text-dark mb-1">Album Title *</label>
            <input
              id="album-title"
              value={form.title}
              onChange={e => { setForm(f => ({ ...f, title: e.target.value })); setErrors(err => ({ ...err, title: undefined })); }}
              className={`${inputClass} ${errors.title ? '!border-red-400' : ''}`}
              placeholder="e.g. Magical Meghalaya"
            />
            {errors.title && <p role="alert" className="text-xs text-red-500 mt-1">{errors.title}</p>}
          </div>
          <div>
            <label htmlFor="album-destination" className="block text-sm font-medium text-dark mb-1">Destination *</label>
            <div className="flex gap-2">
              <input
                id="album-destination"
                value={form.destination}
                onChange={e => { setForm(f => ({ ...f, destination: e.target.value })); setErrors(err => ({ ...err, destination: undefined })); }}
                className={`${inputClass} ${errors.destination ? '!border-red-400' : ''}`}
              />
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(form.destination)}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={e => { if (!form.destination.trim()) e.preventDefault(); }}
                className="shrink-0 flex items-center gap-1.5 px-3 rounded-md border-2 border-background-warm bg-background text-dark text-sm font-medium hover:border-primary hover:text-primary transition-colors whitespace-nowrap"
                title="Opens Google Maps in a new tab, already searching for this"
              >
                Find on Maps ↗
              </a>
            </div>
            {errors.destination && <p role="alert" className="text-xs text-red-500 mt-1">{errors.destination}</p>}
          </div>
          <div>
            <label htmlFor="album-map-url" className="block text-sm font-medium text-dark mb-1">Destination — Google Maps Link</label>
            <input
              id="album-map-url"
              value={form.map_url}
              onChange={e => setForm(f => ({ ...f, map_url: e.target.value }))}
              className={inputClass}
              placeholder="Paste the link here"
            />
            <p className="text-xs text-dark-muted mt-1.5">
              Optional. In the Maps tab: confirm the pin is right → <span className="font-medium text-dark">Share</span> → <span className="font-medium text-dark">Copy link</span> → paste here. Without this, the album page falls back to a text search for the destination.
              {form.map_url.trim() && (
                <>
                  {' '}
                  <a href={form.map_url} target="_blank" rel="noopener noreferrer" className="text-primary font-medium hover:underline">
                    Open this link ↗
                  </a>
                </>
              )}
            </p>
          </div>
          <div>
            <label htmlFor="album-batch" className="block text-sm font-medium text-dark mb-1">Batch (optional)</label>
            <input id="album-batch" value={form.batch} onChange={e => setForm(f => ({ ...f, batch: e.target.value }))} className={`${inputClass} ${duplicateAlbum ? '!border-red-400' : ''}`} placeholder="e.g. 1 (shows as 'Batch 1')" />
            {duplicateAlbum && (
              <p role="alert" className="text-xs text-red-500 mt-1">
                An album with this title already exists{form.batch.trim() ? ' for this batch' : ''}. Use a different batch, or change the title.
              </p>
            )}
          </div>
          <div>
            <label htmlFor="album-trip-date" className="block text-sm font-medium text-dark mb-1">Trip Date *</label>
            <DatePicker
              id="album-trip-date"
              value={form.trip_date}
              onChange={trip_date => { setForm(f => ({ ...f, trip_date })); setErrors(err => ({ ...err, trip_date: undefined })); }}
              className={errors.trip_date ? '!border-red-400' : ''}
            />
            {errors.trip_date && <p role="alert" className="text-xs text-red-500 mt-1">{errors.trip_date}</p>}
          </div>
          <div>
            <label htmlFor="album-participants" className="block text-sm font-medium text-dark mb-1">Participants</label>
            <input id="album-participants" type="number" value={form.participants} onChange={e => setForm(f => ({ ...f, participants: +e.target.value }))} className={inputClass} />
          </div>
          <div>
            <ImageUploadField
              label="Cover Image"
              value={form.cover_image}
              onChange={url => setForm(f => ({ ...f, cover_image: url }))}
              bucket="ulaa"
              pathPrefix="album-covers"
              fileNamePrefix={editing ? editing.slug : (slugify(form.title) || undefined)}
              maxSizeBytes={COVER_IMAGE_TARGET_SIZE_BYTES}
              hint="Wide landscape, at least 1600×1200px — shown full-bleed as the album's hero banner."
            />
          </div>
          <div className="md:col-span-2">
            <MultiImageUploadField
              label="Album Photos"
              value={form.gallery_images}
              onChange={urls => setForm(f => ({ ...f, gallery_images: urls }))}
              bucket="ulaa"
              // Folder name is the album's slug (e.g. "attapadi") rather than
              // its UUID, so storage stays human-readable. For an existing
              // album we use its saved slug; for a brand-new one (not saved
              // yet, so no slug exists) we derive one live from the title
              // being typed, falling back to "new" only if the title is
              // still empty.
              pathPrefix={`albums/${editing ? editing.slug : (slugify(form.title) || 'new')}`}
              hint="Shown uncropped in a masonry grid, so any aspect works — just keep each photo at least 800px on its shortest side."
            />
          </div>
          <div className="md:col-span-2">
            <label htmlFor="album-description" className="block text-sm font-medium text-dark mb-1">Description *</label>
            <textarea
              id="album-description"
              value={form.description}
              onChange={e => { setForm(f => ({ ...f, description: e.target.value })); setErrors(err => ({ ...err, description: undefined })); }}
              rows={3}
              className={`${inputClass} resize-none ${errors.description ? '!border-red-400' : ''}`}
            />
            {errors.description && <p role="alert" className="text-xs text-red-500 mt-1">{errors.description}</p>}
          </div>
          <div className="md:col-span-2 flex items-center gap-3">
            <input type="checkbox" id="pub" checked={form.is_published} onChange={e => setForm(f => ({ ...f, is_published: e.target.checked }))} className="w-4 h-4 accent-primary" />
            <label htmlFor="pub" className="text-sm font-medium text-dark">Publish immediately</label>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <Button variant="outline" size="md" className="flex-1 max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]" onClick={closeModal}>Cancel</Button>
          <Button
            variant="primary"
            size="md"
            className="flex-1 max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]"
            onClick={handleSave}
            loading={saving}
            disabled={!!duplicateAlbum}
            title={duplicateAlbum ? 'Fix the highlighted fields before saving' : undefined}
          >
            {editing ? 'Save Changes' : 'Create Album'}
          </Button>
        </div>
      </Modal>

      {/* View-only details popup — no editable fields, just a clean read-out */}
      <Modal isOpen={!!viewing} onClose={() => setViewing(null)} title={viewing?.title || 'Album Details'} size="lg">
        {viewing && (
          <div className="space-y-5">
            {viewing.cover_image && (
              <img src={viewing.cover_image} alt={viewing.title} className="w-full h-48 object-cover rounded-md" loading="lazy" decoding="async" />
            )}

            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${viewing.is_published ? 'bg-green-100 text-green-700' : 'bg-background-warm text-dark-muted'}`}>
                {viewing.is_published ? 'Published' : 'Draft'}
              </span>
              {viewing.batch && (
                <span className="text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap bg-background-warm text-dark-muted">
                  {formatBatchLabel(viewing.batch)}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs font-medium text-dark-muted mb-0.5">Destination</p>
                <p className="text-dark">{viewing.destination}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-dark-muted mb-0.5">Trip Date</p>
                <p className="text-dark">{formatDate(viewing.trip_date, { month: 'long', year: 'numeric' })}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-dark-muted mb-0.5">Participants</p>
                <p className="text-dark">{viewing.participants}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-dark-muted mb-0.5">Photos</p>
                <p className="text-dark">{viewing.gallery_images?.length || 0}</p>
              </div>
            </div>

            {viewing.description && (
              <div>
                <p className="text-xs font-medium text-dark-muted mb-1">Description</p>
                <p className="text-sm text-dark whitespace-pre-line">{viewing.description}</p>
              </div>
            )}

            {viewing.gallery_images?.length > 0 && (
              <div>
                <p className="text-xs font-medium text-dark-muted mb-1">Gallery ({viewing.gallery_images.length})</p>
                <div className="grid grid-cols-4 gap-2">
                  {viewing.gallery_images.slice(0, 8).map((url, i) => (
                    <img key={i} src={url} alt="" className="w-full h-16 object-cover rounded" loading="lazy" decoding="async" />
                  ))}
                </div>
              </div>
            )}

            {(viewing.original_itinerary?.length || viewing.original_highlight_cards?.length || viewing.original_highlights?.length
              || viewing.original_included_items?.length || viewing.original_included?.length || viewing.original_not_included?.length) ? (
              <details className="group">
                <summary className="text-xs font-medium text-dark-muted mb-1 cursor-pointer select-none list-none flex items-center gap-1">
                  <span className="transition-transform group-open:rotate-90">▶</span> Original Trip Plan
                  <span className="text-dark-muted/70 font-normal">(from Upcoming Trips — admin reference only, not shown publicly)</span>
                </summary>
                <div className="mt-2 bg-background rounded-md p-3 max-h-80 overflow-y-auto app-scroll space-y-4">
                  {viewing.original_highlight_cards?.length ? (
                    <div>
                      <p className="text-xs font-medium text-dark-muted mb-1">Highlights</p>
                      <div className="flex flex-wrap gap-1.5">
                        {viewing.original_highlight_cards.map((h, i) => (
                          <span key={i} className="text-xs bg-white text-dark px-2 py-1 rounded-full">{h.icon ? `${h.icon} ` : ''}{h.heading}</span>
                        ))}
                      </div>
                    </div>
                  ) : viewing.original_highlights?.length ? (
                    <div>
                      <p className="text-xs font-medium text-dark-muted mb-1">Highlights</p>
                      <div className="flex flex-wrap gap-1.5">
                        {viewing.original_highlights.map((h, i) => (
                          <span key={i} className="text-xs bg-white text-dark px-2 py-1 rounded-full">{h}</span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                  {viewing.original_itinerary?.length ? (
                    <div>
                      <p className="text-xs font-medium text-dark-muted mb-1">Itinerary</p>
                      <div className="space-y-2">
                        {viewing.original_itinerary.map((d, i) => (
                          <div key={i} className="text-sm">
                            <p className="font-medium text-dark">Day {d.day || i + 1}: {d.title}</p>
                            {d.description && <p className="text-dark-muted text-xs mt-0.5">{d.description}</p>}
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : null}
                  {(viewing.original_included_items?.length || viewing.original_included?.length || viewing.original_not_included?.length) ? (
                    <div className="grid grid-cols-2 gap-4">
                      {viewing.original_included_items?.length ? (
                        <div>
                          <p className="text-xs font-medium text-dark-muted mb-1">What's Included</p>
                          <ul className="text-sm text-dark list-disc list-inside space-y-0.5">
                            {viewing.original_included_items.map((item, i) => <li key={i}>{item.icon ? `${item.icon} ` : ''}{item.description}</li>)}
                          </ul>
                        </div>
                      ) : viewing.original_included?.length ? (
                        <div>
                          <p className="text-xs font-medium text-dark-muted mb-1">What's Included</p>
                          <ul className="text-sm text-dark list-disc list-inside space-y-0.5">
                            {viewing.original_included.map((item, i) => <li key={i}>{item}</li>)}
                          </ul>
                        </div>
                      ) : null}
                      {viewing.original_not_included?.length ? (
                        <div>
                          <p className="text-xs font-medium text-dark-muted mb-1">Not Included</p>
                          <ul className="text-sm text-dark list-disc list-inside space-y-0.5">
                            {viewing.original_not_included.map((item, i) => <li key={i}>{item}</li>)}
                          </ul>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              </details>
            ) : null}

            <div className="flex gap-3 pt-2 border-t border-background-warm">
              <Button
                variant="primary"
                size="md"
                className="flex-1 max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]"
                onClick={() => { const a = viewing; setViewing(null); openEdit(a); }}
              >
                Edit Album
              </Button>
              <Button variant="outline" size="md" className="flex-1 max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]" onClick={() => setViewing(null)}>Close</Button>
            </div>
          </div>
        )}
      </Modal>
    </AdminLayout>
  );
}
