import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, Trash2, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import AdminLayout from './AdminLayout';
import Button from '../components/ui/Button';
import { getGalleryImages, addGalleryImage, deleteGalleryImage, updateGalleryFeatured, updateGalleryOrder, uploadImage, deleteImage, getStoragePathFromUrl } from '../services/api';
import { useConfirm } from '../components/ui/useConfirm';
import type { GalleryImage } from '../types/types-index';

export default function AdminGallery() {
  const confirm = useConfirm();
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = () => {
    getGalleryImages().then(setImages).catch(console.error).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    try {
      setUploading(true);
      let nextOrder = images.length;
      for (const file of files) {
        const path = `gallery/${Date.now()}-${file.name}`;
        const url = await uploadImage('ulaa', file, path);
        await addGalleryImage(url, nextOrder);
        nextOrder++;
      }
      load();
    } catch {
      alert('Failed to upload. Make sure the Supabase storage bucket "ulaa" exists and is public.');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const handleDelete = async (img: GalleryImage) => {
    if (!(await confirm({ message: 'Delete this image?', confirmLabel: 'Delete' }))) return;
    const path = getStoragePathFromUrl('ulaa', img.image_url);
    if (path) {
      await deleteImage('ulaa', path).catch(() => {});
    }
    await deleteGalleryImage(img.id);
    load();
  };

  const toggleFeatured = async (img: GalleryImage) => {
    await updateGalleryFeatured(img.id, !img.is_featured);
    load();
  };

  const move = async (index: number, dir: -1 | 1) => {
    const target = index + dir;
    if (target < 0 || target >= images.length) return;
    const a = images[index];
    const b = images[target];
    await Promise.all([
      updateGalleryOrder(a.id, b.sort_order),
      updateGalleryOrder(b.id, a.sort_order),
    ]);
    load();
  };

  return (
    <AdminLayout title="Instagram Moments" subtitle="Photos shown in the 'Instagram Moments' section on the homepage.">
      <div className="space-y-6">
        {/* Upload */}
        <div className="bg-white rounded-lg shadow-card p-6 border-2 border-dashed border-background-warm hover:border-primary transition-colors">
          <div className="text-center">
            <Upload size={32} className="mx-auto text-primary mb-3" aria-hidden="true" />
            <p className="font-display text-lg font-bold text-dark mb-1">Upload Images</p>
            <p className="text-dark-muted text-sm mb-4">PNG, JPG, WEBP up to 10MB each. Select multiple files at once. Square photos work best (e.g. 800×800px) — shown in a cropped grid.</p>
            <input ref={fileRef} type="file" multiple accept="image/*" onChange={handleUpload} className="hidden" id="gallery-upload" />
            <Button
              type="button"
              variant="primary"
              size="md"
              loading={uploading}
              className="cursor-pointer max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]"
              onClick={() => fileRef.current?.click()}
            >
              <Upload size={16} aria-hidden="true" />
              {uploading ? 'Uploading...' : 'Choose Files'}
            </Button>
          </div>
        </div>

        {/* Images Grid */}
        {loading ? (
          <div className="text-center py-16 text-dark-muted">Loading gallery...</div>
        ) : images.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-lg shadow-card">
            <p className="font-display text-xl text-dark-muted">No images yet. Upload your first!</p>
          </div>
        ) : (
          <>
            <p className="text-dark-muted text-sm">{images.length} images</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {images.map((img, index) => (
                <motion.div
                  key={img.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="relative group rounded-lg overflow-hidden aspect-square"
                >
                  <img src={img.image_url} alt={`Gallery photo ${index + 1}`} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-dark/50 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button
                      onClick={() => move(index, -1)}
                      disabled={index === 0}
                      aria-label={`Move photo ${index + 1} earlier`}
                      className="p-2 rounded bg-white/20 text-white hover:bg-white/40 transition-colors disabled:opacity-30 disabled:pointer-events-none"
                      title="Move earlier"
                    >
                      <ChevronLeft size={16} aria-hidden="true" />
                    </button>
                    <button
                      onClick={() => toggleFeatured(img)}
                      aria-pressed={img.is_featured}
                      aria-label={img.is_featured ? `Unfeature photo ${index + 1}` : `Feature photo ${index + 1}`}
                      className={`p-2 rounded transition-colors ${img.is_featured ? 'bg-secondary text-white' : 'bg-white/20 text-white hover:bg-secondary'}`}
                      title="Toggle featured"
                    >
                      <Star size={16} className={img.is_featured ? 'fill-white' : ''} aria-hidden="true" />
                    </button>
                    <button
                      onClick={() => handleDelete(img)}
                      aria-label={`Delete photo ${index + 1}`}
                      className="p-2 rounded bg-primary text-white hover:bg-primary-dark transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={16} aria-hidden="true" />
                    </button>
                    <button
                      onClick={() => move(index, 1)}
                      disabled={index === images.length - 1}
                      aria-label={`Move photo ${index + 1} later`}
                      className="p-2 rounded bg-white/20 text-white hover:bg-white/40 transition-colors disabled:opacity-30 disabled:pointer-events-none"
                      title="Move later"
                    >
                      <ChevronRight size={16} aria-hidden="true" />
                    </button>
                  </div>
                  {img.is_featured && (
                    <div className="absolute top-2 left-2 bg-secondary text-white text-xs px-2 py-0.5 rounded-md font-button font-semibold">
                      Featured
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </>
        )}
      </div>
    </AdminLayout>
  );
}
