import { useEffect, useMemo, useRef, useState } from 'react';
import {
  createUpcomingTrip, updateUpcomingTrip, getAllTripLeadersAdmin, deleteImageByUrl,
} from '../../services/api';
import { useAlert } from '../../components/ui/useAlert';
import { useToast } from '../../components/ui/useToast';
import type { UpcomingTrip, TripLeader } from '../../types/types-index';
import { slugify } from '../../utils/utils-index';
import { DEFAULT_TERMS_AND_CONDITIONS } from '../../constants/terms';
import { DEFAULT_CANCELLATION_POLICY } from '../../constants/cancellationPolicy';
import { emptyTripFinance, foldLegacyCosts } from '../../utils/tripFinance';
import { emptyTripOptions, cleanTripOptions } from '../../utils/tripOptions';
import { emptyEndBanner, emptyForm, computeDuration, type TripForm } from './tripFormTypes';
import { handleExportTemplate, parseImportedTripForm } from './tripTemplateIO';
import { scrollToTextMatch } from '../../utils/scroll';
import {
  useDraftKeeper, modalDraftBase, resolveModalDraft, settleDraft, discardDraft, type ModalDraftValue,
} from '../../hooks/useSessionDraft';
import { STORAGE_BUCKET } from '../../constants/storage';

export { FORM_INPUT_CLASS as inputClass } from '../../constants/formStyles';

// Where the half-edited trip is parked while the admin hops over to
// Admin → Trip Leaders to fix a leader's details (see stashDraftForLeaderDetour).
// sessionStorage, so it survives the route change (and a refresh) but is gone
// when the tab closes.
const LEADER_DETOUR_DRAFT_KEY = 'ulaa_trip_draft_leader_detour';

interface LeaderDetourDraft {
  tripId: string | null;
  form: TripForm;
  initialUrls: string[];
}

/** The form as built from a saved trip — what "Edit trip" opens with, and what a kept draft of that
 *  trip is measured against. */
function tripToForm(trip: UpcomingTrip): TripForm {
  return {
    title: trip.title, destination: trip.destination,
    start_date: trip.start_date, end_date: trip.end_date,
    duration: computeDuration(trip.start_date, trip.end_date) || trip.duration, description: trip.description,
    itinerary: trip.itinerary || [],
    not_included: trip.not_included || [],
    meeting_point: trip.meeting_point || '',
    meeting_point_map_url: trip.meeting_point_map_url || '',
    meeting_time: trip.meeting_time || '', meeting_terminal: trip.meeting_terminal || '',
    meeting_details: trip.meeting_details || '',
    faqs: trip.faqs || [], total_seats: trip.total_seats, seats_booked: trip.seats_booked || 0,
    min_age: trip.min_age ?? '', max_age: trip.max_age ?? '',
    price: trip.price ?? '', early_bird_price: trip.early_bird_price ?? '',
    early_bird_deadline: trip.early_bird_deadline || '',
    early_bird_seats: trip.early_bird_seats ?? '',
    strike_through_price: trip.strike_through_price ?? '',
    advance_amount: trip.advance_amount ?? '',
    special_offer_name: trip.special_offer_name || '',
    special_offer_price: trip.special_offer_price ?? '',
    special_offer_date: trip.special_offer_date || '',
    special_offer_end_date: trip.special_offer_end_date || '',
    card_feature_tags: trip.card_feature_tags || [],
    trip_type: trip.trip_type || '',
    cover_image: trip.cover_image || '',
    cover_image_crop: trip.cover_image_crop || null,
    hero_mobile_image: trip.hero_mobile_image || '',
    status: trip.status,
    terms_and_conditions: trip.terms_and_conditions || DEFAULT_TERMS_AND_CONDITIONS,
    cancellation_policy: trip.cancellation_policy || DEFAULT_CANCELLATION_POLICY,
    // Extended
    highlight_cards: trip.highlight_cards || [],
    accommodation_description: trip.accommodation_description || '',
    accommodation_photos: trip.accommodation_photos || [],
    included_groups: trip.included_groups || [],
    gallery_items: trip.gallery_items || [],
    gallery_description: trip.gallery_description || '',
    fashion_photos: trip.fashion_photos || [],
    fashion_description: trip.fashion_description || '',
    things_to_carry_items: trip.things_to_carry_items || [],
    trip_leader_id: trip.trip_leader_id || '',
    confidence_items: trip.confidence_items || [],
    confidence_description: trip.confidence_description || '',
    meeting_address: trip.meeting_address || '',
    end_banner: trip.end_banner || emptyEndBanner,
    trip_finance: foldLegacyCosts(trip.trip_finance || emptyTripFinance),
    trip_options: trip.trip_options || emptyTripOptions,
  };
}

const TRIP_DRAFT_KEY = 'trip-form';

/** Owns the Add/Edit Trip modal end-to-end: the TripForm state itself,
 *  opening it (blank or pre-filled from a trip), the in-modal field
 *  search, saving, closing (with orphaned-upload cleanup), and the
 *  Export/Import Template flow. `load` is called after any save so the
 *  Trips table (owned by useTripsData) reflects the change. */
export function useTripFormModal(load: () => void) {
  const alert = useAlert();
  const toast = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [modalSearch, setModalSearch] = useState('');
  const [modalSearchNoMatch, setModalSearchNoMatch] = useState(false);
  // The modal's own scrollable body — passed to Modal as `bodyRef` and to
  // Tabs as `scrollContainerRef` so both the scroll-spy and any
  // programmatic jump (tab click, field search) scope their scrolling to
  // this container instead of walking up to <body>/<html>.
  const modalBodyRef = useRef<HTMLDivElement>(null);
  const [editingTrip, setEditingTrip] = useState<UpcomingTrip | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<TripForm>(emptyForm);
  // The form as it was when the pop-up opened (blank, or built from the saved trip): what the
  // kept draft is measured against.
  const [baseline, setBaseline] = useState<TripForm | null>(null);
  // A kept draft whose trip changed after the draft was started: held until the admin chooses.
  const [heldDraft, setHeldDraft] = useState<{ recordId: string | null; form: TripForm; baseline: TripForm } | null>(null);
  const importInputRef = useRef<HTMLInputElement>(null);

  // The Trip Leaders directory (Admin → Trip Leaders), loaded once so the
  // Add/Edit Trip modal's Trip Leader tab can offer an "assign from directory"
  // picker and preview the assigned leader's details live.
  const [tripLeaders, setTripLeaders] = useState<TripLeader[]>([]);
  useEffect(() => {
    getAllTripLeadersAdmin().then(setTripLeaders).catch(() => setTripLeaders([]));
  }, []);

  // Tracks the set of image URLs that were already in the form when the
  // modal opened. Any storage URL in the form at close-time that is NOT in
  // this set was uploaded during the current session but never saved to the
  // DB — it's an orphan. We delete those on cancel/close so they don't
  // silently accumulate in the bucket.
  const initialModalUrlsRef = useRef<Set<string>>(new Set());

  // Collects every image URL currently in a TripForm into a flat Set.
  const collectTripFormUrls = (f: TripForm): Set<string> => {
    const urls = new Set<string>();
    const add = (u?: string) => { if (u) urls.add(u); };
    add(f.cover_image);
    add(f.hero_mobile_image);
    add(f.end_banner?.image);
    f.accommodation_photos?.forEach(u => add(u));
    f.fashion_photos?.forEach(u => add(u));
    f.gallery_items?.forEach(item => add(item.photo));
    f.itinerary?.forEach(day => day.images?.forEach(u => add(u)));
    return urls;
  };

  const isStorageUrl = (url: string) => url.includes(`/object/public/${STORAGE_BUCKET}/`);

  // Closes the edit/create modal. Any image URLs that were uploaded during
  // this session but aren't in the initial snapshot are orphans (the admin
  // navigated away without saving) — delete them best-effort before closing.
  const closeModal = () => {
    const currentUrls = collectTripFormUrls(form);
    const initial = initialModalUrlsRef.current;
    for (const url of currentUrls) {
      if (!initial.has(url) && isStorageUrl(url)) {
        deleteImageByUrl(STORAGE_BUCKET, url).catch(() => {});
      }
    }
    initialModalUrlsRef.current = new Set();
    setModalOpen(false);
    discardDraft(TRIP_DRAFT_KEY);
  };

  // Keep the pop-up's unsaved edits while they differ from where it started, so leaving the
  // page (or refreshing) and coming back finds the pop-up as it was left.
  const draftValue = useMemo<ModalDraftValue<TripForm>>(() => ({ recordId: editingTrip?.id ?? null, form }), [editingTrip, form]);
  useDraftKeeper({
    key: TRIP_DRAFT_KEY,
    value: draftValue,
    base: modalOpen && baseline ? modalDraftBase(editingTrip?.id ?? null, baseline) : null,
  });

  const openFromDraft = (trips: UpcomingTrip[], recordId: string | null, draftForm: TripForm, draftBaseline: TripForm) => {
    setEditingTrip(recordId ? trips.find(t => t.id === recordId) ?? null : null);
    setForm({ ...emptyForm, ...draftForm });
    setBaseline(draftBaseline);
    initialModalUrlsRef.current = collectTripFormUrls(draftBaseline);
    setModalSearch('');
    setModalSearchNoMatch(false);
    setModalOpen(true);
  };

  /** Reopens the pop-up as it was left, if an unsaved draft is kept for this tab. Returns true
   *  when it reopened (or put a draft on hold because the trip changed meanwhile). */
  const resumeKeptDraft = (trips: UpcomingTrip[]): boolean => {
    const result = resolveModalDraft<TripForm>(TRIP_DRAFT_KEY, id => {
      if (id === null) return emptyForm;
      const trip = trips.find(t => t.id === id);
      return trip ? tripToForm(trip) : null;
    });
    if (result.status === 'none') return false;
    if (result.status === 'stale') {
      setHeldDraft({ recordId: result.recordId, form: result.form, baseline: result.baseline });
      return true;
    }
    openFromDraft(trips, result.recordId, result.form, result.baseline);
    return true;
  };

  const restoreHeldDraft = (trips: UpcomingTrip[]) => {
    if (!heldDraft) return;
    openFromDraft(trips, heldDraft.recordId, heldDraft.form, heldDraft.baseline);
    setHeldDraft(null);
  };
  const discardHeldDraft = () => {
    discardDraft(TRIP_DRAFT_KEY);
    setHeldDraft(null);
  };

  // Scans every field label / section heading currently rendered inside the
  // Add/Edit Trip modal (Tabs renders every section in one continuous flow,
  // so everything is always in the DOM) and scrolls the first text match
  // into view with a brief highlight flash — a quick way to jump straight
  // to a field (e.g. "meeting point", "pricing") without hunting through
  // tabs. `modalBodyRef` is the modal's own scrollable body (see Modal's
  // `bodyRef`); see scrollToTextMatch (shared with useSectionTabChrome's
  // own handlePageSearch) for why scrolling is scoped to it directly rather
  // than calling the match's own scrollIntoView(). The sticky bar it's kept
  // clear of here is Tabs' own `data-sticky-toolbar` marker.
  const handleModalSearch = () => {
    const query = modalSearch.trim();
    const container = modalBodyRef.current;
    if (!query || !container) {
      setModalSearchNoMatch(false);
      return;
    }
    const found = scrollToTextMatch(container, query, 'label, h4', {
      getStickyOffset: c => c.querySelector<HTMLElement>('[data-sticky-toolbar]')?.getBoundingClientRect().height ?? 0,
    });
    setModalSearchNoMatch(!found);
  };

  // Runs the field search automatically as the admin types, so there's no
  // separate "Search" button to click — a short debounce avoids jumping/
  // scrolling on every single keystroke. Clearing the box resolves via the
  // same debounced call (handleModalSearch resets the no-match flag itself
  // when the query is empty), so nothing needs to run synchronously here.
  useEffect(() => {
    if (!modalOpen) return;
    const timeout = setTimeout(() => handleModalSearch(), modalSearch.trim() ? 350 : 0);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalSearch, modalOpen]);

  // ---- Trip Leader detour -------------------------------------------------
  // The Trip Leader tab can send the admin to Admin → Trip Leaders to edit
  // (or add) a leader. That's a different route, so this page unmounts and the
  // open modal would lose everything typed so far. Before leaving, the whole
  // form is parked in sessionStorage; on return, resumeLeaderDraft() puts the
  // modal back exactly as it was (and scrolls to the Trip Leader section).
  // Returns false if it couldn't be saved, so the caller can stay put instead
  // of silently losing work.
  const stashDraftForLeaderDetour = (): boolean => {
    try {
      const draft: LeaderDetourDraft = {
        tripId: editingTrip?.id ?? null,
        form,
        initialUrls: Array.from(initialModalUrlsRef.current),
      };
      sessionStorage.setItem(LEADER_DETOUR_DRAFT_KEY, JSON.stringify(draft));
      return true;
    } catch {
      return false;
    }
  };

  const pendingLeaderScrollRef = useRef(false);

  // Re-opens the modal from the parked draft. `trips` is the loaded trips
  // list (to find the trip being edited); `assignLeaderId`, when given (a
  // leader just created), is selected on the restored form.
  const resumeLeaderDraft = (trips: UpcomingTrip[], assignLeaderId?: string): boolean => {
    let draft: LeaderDetourDraft | null = null;
    try {
      const raw = sessionStorage.getItem(LEADER_DETOUR_DRAFT_KEY);
      draft = raw ? (JSON.parse(raw) as LeaderDetourDraft) : null;
      sessionStorage.removeItem(LEADER_DETOUR_DRAFT_KEY);
    } catch {
      draft = null;
    }
    if (!draft) return false;
    const trip = draft.tripId ? trips.find(t => t.id === draft!.tripId) : null;
    if (draft.tripId && !trip) return false; // the trip was deleted meanwhile
    setEditingTrip(trip ?? null);
    setForm(assignLeaderId ? { ...draft.form, trip_leader_id: assignLeaderId } : draft.form);
    setBaseline(trip ? tripToForm(trip) : emptyForm);
    initialModalUrlsRef.current = new Set(draft.initialUrls);
    setModalSearch('');
    setModalSearchNoMatch(false);
    pendingLeaderScrollRef.current = true;
    setModalOpen(true);
    return true;
  };

  // After a resume, bring the Trip Leader section into view once the modal
  // has rendered.
  useEffect(() => {
    if (!modalOpen || !pendingLeaderScrollRef.current) return;
    pendingLeaderScrollRef.current = false;
    const timeout = setTimeout(() => {
      scrollToTextMatch(modalBodyRef.current, 'Assign Trip Leader', 'label', {
        getStickyOffset: c => c.querySelector<HTMLElement>('[data-sticky-toolbar]')?.getBoundingClientRect().height ?? 0,
      });
    }, 450);
    return () => clearTimeout(timeout);
  }, [modalOpen]);

  const openCreate = () => {
    setEditingTrip(null);
    setModalSearch('');
    setModalSearchNoMatch(false);
    const initialForm = emptyForm;
    setForm(initialForm);
    setBaseline(initialForm);
    initialModalUrlsRef.current = collectTripFormUrls(initialForm);
    setModalOpen(true);
  };

  const openEdit = (trip: UpcomingTrip) => {
    setEditingTrip(trip);
    const editForm = tripToForm(trip);
    setForm(editForm);
    setBaseline(editForm);
    initialModalUrlsRef.current = collectTripFormUrls(editForm);
    setModalSearch('');
    setModalSearchNoMatch(false);
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title.trim() || !form.destination.trim() || !form.start_date || !form.end_date) {
      await alert({
        title: 'Missing required fields',
        message: 'Title, Destination, Start Date, and End Date are all required before saving this trip.',
      });
      return;
    }
    if (form.price === '' || Number(form.price) <= 0) {
      await alert({
        title: 'Regular price required',
        message: 'Please enter a Regular Price per person before saving this trip.',
      });
      return;
    }
    if (form.min_age !== '' && form.max_age !== '' && Number(form.min_age) > Number(form.max_age)) {
      await alert({
        title: 'Invalid age range',
        message: 'Min Age cannot be greater than Max Age.',
      });
      return;
    }
    if (form.special_offer_date && form.special_offer_end_date && form.special_offer_end_date < form.special_offer_date) {
      await alert({
        title: 'Invalid offer date range',
        message: 'Offer End Date cannot be before Offer Start Date.',
      });
      return;
    }
    try {
      setSaving(true);
      const data = {
        ...form,
        // The slug is a public URL and a storage-folder path (see the
        // `trips/{slug}/...` pathPrefixes throughout this form), so it must
        // stay stable once a trip exists — recomputing it from the title on
        // every save would silently split an edited trip's images across
        // two folders (old-slug and new-slug) and break any previously
        // shared/bookmarked trip link. Only set it on create; on edit, the
        // existing slug column is left untouched (own it via a dedicated
        // rename flow if it ever needs to change deliberately).
        ...(editingTrip ? {} : { slug: slugify(form.title) }),
        price: form.price,
        early_bird_price: form.early_bird_price === '' ? null : form.early_bird_price,
        early_bird_deadline: form.early_bird_deadline || null,
        early_bird_seats: form.early_bird_seats === '' || form.early_bird_seats <= 0 ? null : Math.floor(form.early_bird_seats),
        strike_through_price: form.strike_through_price === '' ? null : form.strike_through_price,
        advance_amount: form.advance_amount === '' ? null : form.advance_amount,
        special_offer_name: form.special_offer_name === '' ? null : form.special_offer_name,
        special_offer_price: form.special_offer_price === '' ? null : form.special_offer_price,
        special_offer_date: form.special_offer_date || null,
        special_offer_end_date: form.special_offer_end_date || null,
        trip_type: form.trip_type === '' ? null : form.trip_type,
        min_age: form.min_age === '' ? null : form.min_age,
        max_age: form.max_age === '' ? null : form.max_age,
        trip_leader_id: form.trip_leader_id === '' ? null : form.trip_leader_id,
        seats_booked: Math.max(0, Math.min(form.seats_booked, form.total_seats)),
        // Blank/unnamed rows and dangling option references are dropped;
        // nothing left = stored as null (a plain single-price trip).
        trip_options: cleanTripOptions(form.trip_options),
      };
      if (editingTrip) {
        await updateUpcomingTrip(editingTrip.id, data);
      } else {
        await createUpcomingTrip(data);
      }
      // All uploads are now committed to the DB — nothing to clean up on close.
      initialModalUrlsRef.current = new Set();
      setModalOpen(false);
      // Photos that were uploaded and then replaced before saving are deleted now.
      settleDraft(TRIP_DRAFT_KEY, collectTripFormUrls(form));
      load();
    } catch {
      toast.error("Couldn't save the trip.", { action: { label: 'Try again', onClick: () => { void handleSave(); } } });
    } finally {
      setSaving(false);
    }
  };

  // Commits whatever's typed/pasted in a group's bullet-draft textarea as one
  // or more bullets, then clears the box. Handles the case where a paste
  // didn't contain multiple lines (so wasn't auto-split) and needs Enter/blur
  // to be added as a single bullet.
  const commitGroupBulletDraft = (gi: number, el: HTMLTextAreaElement) => {
    const lines = el.value.split(/\r?\n\s*\n|\r?\n/).map(l => l.trim()).filter(Boolean);
    if (lines.length === 0) return;
    setForm(f => ({ ...f, included_groups: f.included_groups.map((g, idx) => idx === gi ? { ...g, bullets: [...g.bullets, ...lines] } : g) }));
    el.value = '';
  };

  // Reads a filled-in export template (produced by handleExportTemplate,
  // optionally filled in) and populates the Add Trip form so the admin only
  // has to review/adjust and upload photos before saving.
  const handleImportFile = async (file: File) => {
    try {
      const raw = JSON.parse(await file.text());
      const imported = parseImportedTripForm(raw);
      setEditingTrip(null);
      setForm(imported);
      // Measured against the blank form: an imported template is unsaved work worth keeping.
      setBaseline(emptyForm);
      initialModalUrlsRef.current = collectTripFormUrls(imported);
      setModalOpen(true);
    } catch {
      await alert({
        title: 'Import failed',
        message: 'That file could not be read as a valid trip template. Make sure it is the JSON file produced by Export Template (optionally filled in) and try again.',
      });
    }
  };

  const handleImportInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImportFile(file);
    e.target.value = '';
  };

  return {
    modalOpen, closeModal, openCreate, openEdit,
    modalSearch, setModalSearch, modalSearchNoMatch, modalBodyRef,
    editingTrip, form, setForm, saving, handleSave,
    commitGroupBulletDraft,
    importInputRef, handleImportInputChange,
    handleExportTemplate,
    tripLeaders,
    stashDraftForLeaderDetour, resumeLeaderDraft,
    resumeKeptDraft, heldDraft, restoreHeldDraft, discardHeldDraft,
  };
}
