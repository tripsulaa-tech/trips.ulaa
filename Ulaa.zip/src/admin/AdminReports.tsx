// Reports page (CRM spec section 16).
//
// Deliberately reads the same data AdminEnquiries/AdminDashboard already
// fetch (getEnquiries / getAllUpcomingTripsAdmin / getAllCompletedTripsAdmin)
// and reuses their existing derivation helpers (isBooked, isCancelled,
// closedReasonBreakdown, JOURNEY_STAGE_CONFIG, ...) rather than introducing
// a parallel set of status checks — so a report can never silently drift
// out of sync with what the Enquiries table itself considers "booked" or
// "cancelled". Nothing here writes anything; this is a read-only rollup.
//
// The one thing genuinely new here vs. the existing per-trip KPI strip in
// AdminEnquiries.tsx is scope: that strip is always scoped to "whichever
// trip is selected right now". This page is business-wide and adds the one
// axis nothing else exposes — a time period — so "how are we trending this
// month" is answerable without exporting to a spreadsheet.
import { useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { loadPersisted, savePersisted } from '../utils/sessionState';
import {
  Users,
  UserPlus,
  Phone,
  XCircle,
  TrendUp as TrendingUp,
  Clock,
  CurrencyInr as IndianRupee,
  Wallet,
  ArrowUUpLeft as Undo2,
  Ticket,
  ChartLineUp,
  PiggyBank,
  Receipt,
  Coins,
  Bank,
  Percent,
  UsersThree,
  CheckCircle,
  SealCheck as BadgeCheck,
  Confetti as PartyPopper,
  CalendarX as CalendarX2,
  MapPin,
  ForkKnife as UtensilsCrossed,
  UserMinus as UserX,
  ChartPie as PieChart,
  DownloadSimple as Download,
  ChartBar as BarChart3,
  CreditCard,
  Compass,
  UserCircle,
} from '@phosphor-icons/react';
import AdminLayout from './AdminLayout';
import Select from '../components/ui/Select';
import { getEnquiries, getAllUpcomingTripsAdmin, getAllCompletedTripsAdmin, getAllPayments } from '../services/api';
import type { Enquiry, UpcomingTrip, CompletedTrip, Payment, TripFinance } from '../types/types-index';
import { isBooked, isCancelled } from './enquiries/AdminEnquiriesShared';
import { closedReasonBreakdown, isNotInterested } from './enquiries/AdminEnquiryCommon';
import { formatPrice } from '../utils/utils-index';
import { computeTripFinanceSummary } from '../utils/tripFinance';
import { downloadTripExcelReport, downloadAllTripsExcelReport } from '../utils/tripExcelReport';

// Real, human-readable label for every value enquiries.source can actually
// hold. Deliberately not reusing enquiries/AdminEnquiriesShared's
// SOURCE_OPTIONS here — that list is scoped to the manual-entry form's
// dropdown and excludes 'website' on purpose (see enquiryGrouping.ts), but
// real enquiry rows very much do carry source: 'website', and a lead-source
// report that silently dropped the public booking form would be useless.
const SOURCE_LABELS: Record<Enquiry['source'], string> = {
  website: 'Website',
  whatsapp: 'WhatsApp',
  phone: 'Phone Call',
  instagram: 'Instagram',
  walk_in: 'Walk-in',
  other: 'Other',
};

type Period = 'all' | 'month' | '30d';

// Persisted the same way as the Enquiries page's filters (see
// useEnquiryFilters.ts and utils/sessionState.ts) so switching admin tabs
// and coming back to Reports keeps the same period/trip filters instead of
// resetting to "All Time" / "All Trips".
const PERIOD_STORAGE_KEY = 'ulaa:admin-reports:filters';
type PersistedReportsFilters = { period: Period; tripId: string };

// Sentinel value for the Trip dropdown's "no trip selected" state — kept
// out of the real trip id space (trip ids are UUIDs) so it can never
// collide with an actual trip.
const ALL_TRIPS = 'all';

const PERIOD_OPTIONS: { value: Period; label: string; shortLabel: string }[] = [
  { value: 'all', label: 'All Time', shortLabel: 'All' },
  { value: 'month', label: 'This Month', shortLabel: 'Month' },
  { value: '30d', label: 'Last 30 Days', shortLabel: '30D' },
];

function withinPeriod(dateStr: string, period: Period): boolean {
  if (period === 'all') return true;
  const d = new Date(dateStr);
  const now = new Date();
  if (period === 'month') {
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }
  // 30d
  const cutoff = now.getTime() - 30 * 24 * 60 * 60 * 1000;
  return d.getTime() >= cutoff;
}

function pct(n: number, total: number): number {
  return total ? Math.round((n / total) * 100) : 0;
}

// Buckets paid ledger rows into a revenue-over-time series. Granularity
// follows the period toggle: daily buckets for the two short windows (30
// days / a month is few enough days to read as a bar each), monthly
// buckets for "All Time" (could span years — daily bars would be unreadable
// and mostly empty). Always returns buckets in chronological order, oldest
// first, including zero-revenue days/months in between so gaps in the
// timeline are visible rather than silently compressed out.
function buildRevenueTrend(paidRows: Payment[], period: Period): { label: string; amount: number }[] {
  if (paidRows.length === 0) return [];
  const daily = period !== 'all';
  const keyOf = (d: Date) => daily
    ? `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
    : `${d.getFullYear()}-${d.getMonth()}`;
  const labelOf = (d: Date) => daily
    ? d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
    : d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });

  const sums = new Map<string, number>();
  paidRows.forEach(p => {
    const d = new Date(p.paid_at);
    const key = keyOf(d);
    sums.set(key, (sums.get(key) || 0) + p.amount);
  });

  // Walk every day/month between the earliest and latest payment so gaps
  // show as zero bars instead of disappearing.
  const dates = paidRows.map(p => new Date(p.paid_at));
  const earliest = new Date(Math.min(...dates.map(d => d.getTime())));
  const latest = new Date(Math.max(...dates.map(d => d.getTime())));
  const buckets: { key: string; date: Date }[] = [];
  const cursor = new Date(earliest);
  if (daily) cursor.setHours(0, 0, 0, 0); else cursor.setDate(1);
  while (cursor <= latest) {
    buckets.push({ key: keyOf(cursor), date: new Date(cursor) });
    if (daily) cursor.setDate(cursor.getDate() + 1); else cursor.setMonth(cursor.getMonth() + 1);
  }
  // Cap at 31 bars even for "All Time" spanning many years — collapse to
  // the most recent 31 buckets rather than rendering an unreadable strip.
  const capped = buckets.slice(-31);
  return capped.map(b => ({ label: labelOf(b.date), amount: sums.get(b.key) || 0 }));
}

// Average time between an enquiry landing and an admin actually recording a
// contact outcome against it — the "Average Response Time" lead report.
// Only meaningful for rows that have been through the Record Contact
// Outcome popup at least once (last_contact_at set); a lead nobody has
// called yet isn't a response-time data point, it's a queue depth.
function averageResponseTime(list: Enquiry[]): string {
  const withResponse = list.filter(e => e.last_contact_at);
  if (withResponse.length === 0) return '—';
  const totalMs = withResponse.reduce((sum, e) => {
    return sum + (new Date(e.last_contact_at as string).getTime() - new Date(e.created_at).getTime());
  }, 0);
  const avgMs = totalMs / withResponse.length;
  const avgHours = avgMs / (1000 * 60 * 60);
  if (avgHours < 1) return `${Math.max(1, Math.round(avgMs / (1000 * 60)))} min`;
  if (avgHours < 48) return `${avgHours.toFixed(1)} hrs`;
  return `${(avgHours / 24).toFixed(1)} days`;
}

// Shared color for stat card icon badges and section glyphs. green/red are
// kept as universal profit-vs-loss / success-vs-failure signals on
// financial and operational figures. For everything else, badge color was
// previously varied (secondary vs. primary) to signal "view" vs "create"
// tiles, but the brand palette is tightly clustered — at badge size every
// non-green/red tone rendered as the same pale peach, so that distinction
// wasn't actually visible. Simplified to a single primary-tinted badge for
// all non-financial tiles; matches the Dashboard page.
type Tone = 'primary' | 'green' | 'red';
const TONE_STYLES: Record<Tone, { bg: string; text: string }> = {
  primary: { bg: 'bg-primary/10', text: 'text-primary' },
  green: { bg: 'bg-green-100', text: 'text-green-700' },
  red: { bg: 'bg-red-100', text: 'text-red-600' },
};

const cardVariants = {
  hidden: { opacity: 0, y: 8 },
  show: { opacity: 1, y: 0 },
};

function StatCard({
  label, value, sub, icon: Icon, tone = 'primary',
}: { label: string; value: string | number; sub?: string; icon: typeof Users; tone?: Tone }) {
  const t = TONE_STYLES[tone];
  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="show"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.25 }}
      className="bg-white rounded-lg p-4 shadow-card hover:shadow-card-hover transition-shadow min-w-0"
    >
      <div className="flex items-center gap-2.5">
        <span className={`inline-flex items-center justify-center w-9 h-9 rounded-md shrink-0 ${t.bg}`}>
          <Icon size={18} className={t.text} aria-hidden="true" />
        </span>
        <p className="font-display text-xl sm:text-2xl font-bold text-dark leading-tight truncate">{value}</p>
      </div>
      <p className="text-dark-muted text-xs font-medium truncate mt-2">{label}</p>
      {sub && <p className="text-dark-muted/70 text-[11px] mt-0.5 truncate">{sub}</p>}
    </motion.div>
  );
}

function ReportSection({
  title, subtitle, icon: Icon, tone = 'primary', children,
}: { title: string; subtitle?: string; icon?: typeof Users; tone?: Tone; children: ReactNode }) {
  const t = TONE_STYLES[tone];
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.35 }}
    >
      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-1 sm:gap-3 mb-3">
        <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
          {Icon && (
            <span className={`inline-flex items-center justify-center w-6 h-6 rounded-md shrink-0 ${t.bg}`}>
              <Icon size={13} className={t.text} aria-hidden="true" />
            </span>
          )}
          {title}
        </h3>
        {subtitle && <p className="text-dark-muted text-xs">{subtitle}</p>}
      </div>
      <div className="space-y-3">
        {children}
      </div>
    </motion.div>
  );
}

// Lightweight bar chart, no charting dependency — the app doesn't already
// pull one in, and this is the only place that needs one so far. Renders
// as plain divs (not SVG/canvas) so bar heights, hover tooltips, and text
// stay simple, accessible, and easy to restyle alongside the rest of the
// admin's Tailwind-based UI. Bars animate in from zero height, staggered
// slightly so a full redraw (e.g. switching the period toggle) reads as a
// deliberate transition rather than a jump-cut.
function RevenueTrendChart({ data }: { data: { label: string; amount: number }[] }) {
  // :hover has no equivalent on touch — a phone tapping a bar needs the
  // amount to actually show, not just flash on the release-tap that also
  // fires the browser's synthetic hover. Tracked explicitly and toggled
  // via onClick so it works the same on mobile as the group-hover does on
  // desktop.
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  if (data.length === 0) {
    return <p className="text-dark-muted text-sm text-center py-8">No collected payments in this range yet.</p>;
  }
  const max = Math.max(...data.map(d => d.amount), 1);
  // Skip every other label once there are enough bars that every label
  // would overlap its neighbors.
  const labelEvery = data.length > 15 ? Math.ceil(data.length / 15) : 1;
  // Cap the per-bar stagger so a 31-bar "All Time" view doesn't take
  // visibly longer to finish drawing than a 7-bar "This Month" one.
  const staggerStep = Math.min(0.02, 0.4 / data.length);
  return (
    <div className="flex items-end gap-1 h-40 pt-6 border-b border-background-warm">
      {data.map((d, i) => (
        <div
          key={`${d.label}-${i}`}
          className="flex-1 min-w-0 h-full flex flex-col items-center justify-end gap-1 group relative"
          onClick={() => setActiveIndex(cur => (cur === i ? null : i))}
          onMouseLeave={() => setActiveIndex(cur => (cur === i ? null : cur))}
        >
          <div className={`absolute -top-7 left-1/2 -translate-x-1/2 bg-dark text-white text-[10px] font-semibold px-1.5 py-0.5 rounded whitespace-nowrap transition-opacity pointer-events-none z-10 ${
            activeIndex === i ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}>
            {formatPrice(d.amount)}
            <span className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-dark" />
          </div>
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: `${Math.max(2, (d.amount / max) * 100)}%` }}
            transition={{ duration: 0.5, delay: i * staggerStep, ease: 'easeOut' }}
            className={`w-full bg-gradient-to-t from-primary rounded-t-sm min-h-[2px] cursor-pointer ${activeIndex === i ? 'to-primary' : 'to-primary/60 group-hover:to-primary'}`}
          />
          <span className="text-[9px] text-dark-muted truncate w-full text-center">
            {i % labelEvery === 0 ? d.label : ''}
          </span>
        </div>
      ))}
    </div>
  );
}

// Placeholder shapes matching the real layout (stat card grid + section
// header), shown while data loads instead of a bare "Loading…" line — so
// the page's structure is legible immediately and nothing visually jumps
// once the real numbers arrive.
function SkeletonBlock({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse bg-background-warm rounded ${className}`} />;
}
function ReportsSkeleton() {
  return (
    <div className="space-y-8" role="status" aria-label="Loading reports">
      {[0, 1].map(section => (
        <div key={section} className="space-y-3">
          <SkeletonBlock className="h-5 w-40" />
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {[0, 1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-lg p-4 shadow-card space-y-3">
                <SkeletonBlock className="w-9 h-9 rounded-md" />
                <SkeletonBlock className="h-6 w-16" />
                <SkeletonBlock className="h-3 w-20" />
              </div>
            ))}
          </div>
          <SkeletonBlock className="h-32 w-full rounded-lg" />
        </div>
      ))}
    </div>
  );
}

export default function AdminReports() {
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [upcomingTrips, setUpcomingTrips] = useState<UpcomingTrip[]>([]);
  const [completedTrips, setCompletedTrips] = useState<CompletedTrip[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<Period>(() => loadPersisted<PersistedReportsFilters>(PERIOD_STORAGE_KEY).period ?? 'all');
  const [tripId, setTripId] = useState<string>(() => loadPersisted<PersistedReportsFilters>(PERIOD_STORAGE_KEY).tripId ?? ALL_TRIPS);

  // Persist the period toggle and trip dropdown whenever either changes.
  useEffect(() => {
    savePersisted<PersistedReportsFilters>(PERIOD_STORAGE_KEY, { period, tripId });
  }, [period, tripId]);

  useEffect(() => {
    Promise.all([getEnquiries(), getAllUpcomingTripsAdmin(), getAllCompletedTripsAdmin(), getAllPayments()])
      .then(([allEnquiries, upcoming, completed, allPayments]) => {
        setEnquiries(allEnquiries);
        setUpcomingTrips(upcoming);
        setCompletedTrips(completed);
        setPayments(allPayments);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  // Trip dropdown options — every upcoming + completed trip, deduped by id
  // (a trip that's since completed would otherwise appear once from each
  // table) and sorted alphabetically so a long trip list stays scannable.
  const tripOptions = useMemo(() => {
    const byId = new Map<string, string>();
    upcomingTrips.forEach(t => byId.set(t.id, t.title));
    completedTrips.forEach(t => { if (!byId.has(t.id)) byId.set(t.id, t.title); });
    const sorted = Array.from(byId.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
    return [{ value: ALL_TRIPS, label: 'All Trips' }, ...sorted];
  }, [upcomingTrips, completedTrips]);

  // trip_id set for every not-yet-completed trip — used by Occupancy
  // further down.
  const upcomingTripIds = useMemo(() => new Set(upcomingTrips.map(t => t.id)), [upcomingTrips]);

  // Every metric below is derived from this one scoped list, so switching
  // either filter re-derives the whole page consistently instead of some
  // cards silently staying business-wide. The time window and the trip
  // dropdown stack (AND together) rather than being mutually exclusive —
  // e.g. "This Month" + a specific trip shows that trip's leads from this
  // month only.
  const scoped = useMemo(
    () => enquiries.filter(e => withinPeriod(e.created_at, period) && (tripId === ALL_TRIPS || e.trip_id === tripId)),
    [enquiries, period, tripId]
  );

  // trip_id -> destination, merged from both trip tables, so bookings on
  // completed trips (which no longer have an upcoming_trips row) still
  // resolve to a real place name instead of falling through to "Unknown".
  const destinationById = useMemo(() => {
    const map = new Map<string, string>();
    upcomingTrips.forEach(t => map.set(t.id, t.destination));
    completedTrips.forEach(t => map.set(t.id, t.destination));
    return map;
  }, [upcomingTrips, completedTrips]);

  const lead = useMemo(() => {
    const total = scoped.length;
    const newCount = scoped.filter(e => e.status === 'new').length;
    const contactedCount = scoped.filter(e => e.status === 'contacted').length;
    const closedCount = scoped.filter(isNotInterested).length;
    const bookedCount = scoped.filter(isBooked).length;
    return {
      total, newCount, contactedCount, closedCount, bookedCount,
      conversionPct: pct(bookedCount, total),
      closedBreakdown: closedReasonBreakdown(scoped),
      avgResponseTime: averageResponseTime(scoped),
    };
  }, [scoped]);

  const booking = useMemo(() => ({
    confirmed: scoped.filter(e => e.journey_stage === 'confirmed').length,
    completed: scoped.filter(e => e.journey_stage === 'completed').length,
    cancelled: scoped.filter(isCancelled).length,
  }), [scoped]);

  const financial = useMemo(() => {
    const revenue = scoped.reduce(
      (sum, e) => sum + (e.amount_paid || 0) - (e.refund_amount || 0),
      0
    );
    const refundAmount = scoped.reduce((sum, e) => sum + (e.refund_amount || 0), 0);
    const outstandingBalance = scoped
      .filter(e => isBooked(e) && e.total_amount)
      .reduce((sum, e) => {
        return sum + (e.total_amount ? Math.max(0, (e.total_amount || 0) - (e.amount_paid || 0)) : 0);
      }, 0);
    const bookedWithPrice = scoped.filter(e => isBooked(e) && e.total_amount);
    const avgBookingValue = bookedWithPrice.length
      ? bookedWithPrice.reduce((sum, e) => sum + (e.total_amount || 0), 0) / bookedWithPrice.length
      : 0;
    return { revenue, refundAmount, outstandingBalance, avgBookingValue };
  }, [scoped]);

  const operational = useMemo(() => {
    const bookedList = scoped.filter(isBooked);
    const vegAdults = bookedList.filter(e => e.food_preference === 'veg').length;
    const nonVegAdults = bookedList.filter(e => e.food_preference === 'non_veg').length;
    const notSetAdults = bookedList.length - vegAdults - nonVegAdults;

    const veg = vegAdults;
    const nonVeg = nonVegAdults;
    const notSet = notSetAdults;

    // "Ever became a booking" (booking_id assigned) is the denominator for
    // Cancellation % — a lead that never paid anything was never at risk of
    // being cancelled, so including it would understate the real rate.
    const everBooked = scoped.filter(e => !!e.booking_id);
    const cancelledOfBooked = everBooked.filter(isCancelled).length;

    // No-show only has a meaningful denominator among travellers whose trip
    // actually reached the point attendance gets recorded (checked in, or
    // marked no-show) — everyone still earlier in the journey isn't a
    // no-show data point yet.
    const attendanceRecorded = scoped.filter(e => e.is_no_show || e.checked_in_at);
    const noShowCount = scoped.filter(e => e.is_no_show).length;

    // Occupancy is deliberately NOT read from trip.seats_booked — that
    // field is meant to stay DB-trigger-synced from real bookings, but
    // AdminTripFormModal also exposes it as a plain editable number an
    // admin can retype by hand, so it can drift from what was actually
    // paid and booked. Recomputing straight from isBooked enquiries (the
    // same real amount_paid/cancelled_at fields already trusted everywhere
    // else on this page) means Occupancy can't silently disagree with
    // Cancellation Rate or Revenue just because someone edited a trip.
    // Deliberately NOT scoped to the period toggle — like the trip's real
    // seat count, this is "how full are trips right now", not "how many
    // people booked in the selected window". It IS scoped to the Trip
    // dropdown though — with a specific trip picked, every card on this
    // page (including this one) should reflect just that trip.
    const relevantUpcomingTrips = tripId === ALL_TRIPS ? upcomingTrips : upcomingTrips.filter(t => t.id === tripId);
    const totalSeats = relevantUpcomingTrips.reduce((sum, t) => sum + (t.total_seats || 0), 0);
    const seatsBooked = enquiries.filter(e =>
      isBooked(e) && e.trip_id && upcomingTripIds.has(e.trip_id) && (tripId === ALL_TRIPS || e.trip_id === tripId)
    ).length;

    const destCounts = new Map<string, number>();
    bookedList.forEach(e => {
      const dest = (e.trip_id && destinationById.get(e.trip_id)) || e.trip_title || 'Unknown';
      destCounts.set(dest, (destCounts.get(dest) || 0) + 1);
    });
    const topDestinations = Array.from(destCounts.entries())
      .map(([label, count]) => ({ label, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      veg, nonVeg, notSet,
      cancellationPct: pct(cancelledOfBooked, everBooked.length),
      cancelledOfBooked, everBookedCount: everBooked.length,
      noShowPct: pct(noShowCount, attendanceRecorded.length),
      noShowCount, attendanceRecordedCount: attendanceRecorded.length,
      occupancyPct: pct(seatsBooked, totalSeats),
      totalSeats, seatsBooked,
      topDestinations,
    };
  }, [scoped, enquiries, upcomingTrips, upcomingTripIds, tripId, destinationById]);

  // Paid ledger rows within the selected period — the source for both the
  // trend chart and the payment-method breakdown below. Filtered on
  // paid_at (when money actually moved), not the enquiry's created_at,
  // restricted to status === 'paid' so pending/uncollected invoice rows
  // (see the Payment interface's status field) don't get counted as
  // revenue before they've actually been collected — and, when the Trip
  // dropdown has a specific trip selected, further narrowed to payments
  // belonging to that trip's enquiries. Payments don't carry trip_id
  // directly, so that last check goes through the enquiry they belong to.
  const enquiryTripId = useMemo(() => new Map(enquiries.map(e => [e.id, e.trip_id])), [enquiries]);
  const paidInPeriod = useMemo(
    () => payments.filter(p =>
      p.status === 'paid'
      && withinPeriod(p.paid_at, period)
      && (tripId === ALL_TRIPS || enquiryTripId.get(p.enquiry_id) === tripId)
    ),
    [payments, period, tripId, enquiryTripId]
  );

  const revenueTrend = useMemo(() => buildRevenueTrend(paidInPeriod, period), [paidInPeriod, period]);

  const sourceBreakdown = useMemo(() => {
    const map = new Map<string, { total: number; booked: number }>();
    scoped.forEach(e => {
      const entry = map.get(e.source) || { total: 0, booked: 0 };
      entry.total += 1;
      if (isBooked(e)) entry.booked += 1;
      map.set(e.source, entry);
    });
    return Array.from(map.entries())
      .map(([source, v]) => ({
        source,
        label: SOURCE_LABELS[source as Enquiry['source']] || source,
        total: v.total,
        booked: v.booked,
        conversionPct: pct(v.booked, v.total),
      }))
      .sort((a, b) => b.total - a.total);
  }, [scoped]);

  const paymentMethodBreakdown = useMemo(() => {
    const map = new Map<string, { amount: number; count: number }>();
    paidInPeriod.forEach(p => {
      const key = p.payment_method || 'Not specified';
      const entry = map.get(key) || { amount: 0, count: 0 };
      entry.amount += p.amount;
      entry.count += 1;
      map.set(key, entry);
    });
    const totalAmount = paidInPeriod.reduce((sum, p) => sum + p.amount, 0);
    return Array.from(map.entries())
      .map(([method, v]) => ({ method, amount: v.amount, count: v.count, sharePct: pct(v.amount, totalAmount) }))
      .sort((a, b) => b.amount - a.amount);
  }, [paidInPeriod]);

  // Per-trip rollup — same real-booking derivation as Occupancy above
  // (isBooked, not trip.seats_booked), so this table and the top-level
  // Occupancy card can never disagree about how full a given trip is.
  // Deliberately business-wide re: the period toggle (all enquiries, not
  // `scoped`) — a trip's collected/pending/occupancy is its current
  // standing regardless of when each individual booking came in, same
  // reasoning as Occupancy itself. It IS scoped to the Trip dropdown,
  // though — down to a single row when a specific trip is selected.
  const tripBreakdown = useMemo(() => {
    const relevantTrips = tripId === ALL_TRIPS ? upcomingTrips : upcomingTrips.filter(t => t.id === tripId);
    return relevantTrips
      .map(t => {
        const tripEnquiries = enquiries.filter(e => e.trip_id === t.id && isBooked(e));
        const collected = tripEnquiries.reduce((sum, e) => sum + (e.amount_paid || 0), 0);
        const pendingAmt = tripEnquiries
          .filter(e => e.total_amount)
          .reduce((sum, e) => sum + Math.max(0, (e.total_amount || 0) - (e.amount_paid || 0)), 0);
        return {
          id: t.id,
          title: t.title || t.destination,
          startDate: t.start_date,
          seatsBooked: tripEnquiries.length,
          totalSeats: t.total_seats || 0,
          occupancyPct: pct(tripEnquiries.length, t.total_seats || 0),
          collected,
          pending: pendingAmt,
        };
      })
      .sort((a, b) => (a.startDate || '').localeCompare(b.startDate || ''));
  }, [upcomingTrips, enquiries, tripId]);

  // Internal cost/profit rollup — pulls the "Finances & Profit" tab data
  // entered on each trip (Add/Edit Trip, see utils/tripFinance.ts) and
  // rolls it up against real bookings, the same way AdminTripViewModal's
  // read-only summary does for a single trip. Business-wide re: the period
  // toggle (all enquiries, not `scoped`) for the same reason
  // tripBreakdown/Occupancy are: a trip's cost structure and current fill
  // are its current standing, not something that resets with the period
  // toggle. Scoped to the Trip dropdown, same as tripBreakdown above. Only
  // trips where an admin has actually filled in the Finances tab are
  // included — a trip with no finance data entered has nothing real to
  // roll up (emptyTripFinance would just report 100% margin, which is
  // wrong, not "no data").
  const financeByTrip = useMemo(() => {
    const relevantTrips = tripId === ALL_TRIPS ? upcomingTrips : upcomingTrips.filter(t => t.id === tripId);
    return relevantTrips
      .filter(t => !!t.trip_finance)
      .map(t => {
        // Real revenue for this trip: sum of what each booked enquiry was
        // actually invoiced for (total_amount), not bookedCount x listed
        // price — bookings routinely differ from the regular price
        // (early-bird, group/manual discounts, one-off deals), so a flat
        // per-head multiply would silently misstate revenue. Enquiries
        // that are booked but have no total_amount set yet (price not
        // finalized) contribute 0 to revenue, same as everywhere else on
        // this page treats an unset total_amount.
        const tripBookings = enquiries.filter(e => e.trip_id === t.id && isBooked(e));
        const totalRevenue = tripBookings.reduce((sum, e) => sum + (e.total_amount || 0), 0);
        const childFareCount = tripBookings.filter(e => e.has_child_addon).length;
        const summary = computeTripFinanceSummary(t.trip_finance, tripBookings.length, totalRevenue, childFareCount);
        return {
          id: t.id,
          title: t.title || t.destination,
          startDate: t.start_date,
          // Raw Finances-tab record, kept alongside the rolled-up summary
          // fields so the Excel export can itemize ulaaCosts/organiserCosts
          // (ad spend, agency payment, organiser's own entry ticket, etc.)
          // instead of only showing the two totals. Non-null: this map only
          // runs over trips the `.filter(t => !!t.trip_finance)` above
          // already kept.
          finance: t.trip_finance as TripFinance,
          ...summary,
        };
      })
      .sort((a, b) => (a.startDate || '').localeCompare(b.startDate || ''));
  }, [upcomingTrips, enquiries, tripId]);

  const financeTotals = useMemo(() => {
    return financeByTrip.reduce(
      (acc, t) => ({
        totalRevenue: acc.totalRevenue + t.totalRevenue,
        totalCosts: acc.totalCosts + t.totalCosts,
        netProfit: acc.netProfit + t.netProfit,
      }),
      { totalRevenue: 0, totalCosts: 0, netProfit: 0 }
    );
  }, [financeByTrip]);

  const financeMarginPct = pct(Math.max(0, financeTotals.netProfit), financeTotals.totalRevenue);

  // Same isBooked + total scoping as the Outstanding Balance card itself,
  // so the two can never disagree — this is that number broken out
  // person-by-person instead of just the business-wide total.
  const outstandingByPerson = useMemo(() => {
    return scoped
      .filter(e => isBooked(e) && e.total_amount)
      .map(e => {
        const balance = e.total_amount ? Math.max(0, (e.total_amount || 0) - (e.amount_paid || 0)) : 0;
        return {
          name: e.full_name,
          trip: (e.trip_id && destinationById.get(e.trip_id)) || e.trip_title || 'Unknown',
          total: e.total_amount || 0,
          paid: e.amount_paid || 0,
          balance,
        };
      })
      .filter(row => row.balance > 0)
      .sort((a, b) => b.balance - a.balance);
  }, [scoped, destinationById]);

  // Assembles one trip's row for the styled Excel export (tripExcelReport.ts)
  // out of financeByTrip's already-computed cost/profit summary plus three
  // things that summary doesn't carry on its own: a food-preference split,
  // a per-person outstanding-balance list, and the itemized line items
  // behind the ulaaCosts/organiserCosts totals (read from the trip's raw
  // `finance` record — see the TripFinance import above — since
  // computeTripFinanceSummary only returns already-summed totals for most
  // of these). Both the food/balance figures are deliberately read straight
  // from `enquiries` (not `scoped`) and scoped only by trip id — same
  // "current standing, not period-windowed" reasoning financeByTrip and
  // Occupancy already use elsewhere on this page, so the Excel export can't
  // show a different profit/outstanding picture for a trip than the rest of
  // the page depending on which period happens to be selected when it's
  // clicked.
  const buildExcelRowForTrip = (t: (typeof financeByTrip)[number]) => {
    const tripBookings = enquiries.filter(e => e.trip_id === t.id && isBooked(e));
    const vegCount = tripBookings.filter(e => e.food_preference === 'veg').length;
    const nonVegCount = tripBookings.filter(e => e.food_preference === 'non_veg').length;
    const outstanding = tripBookings
      .filter(e => e.total_amount)
      .map(e => ({
        name: e.full_name,
        total: e.total_amount || 0,
        paid: e.amount_paid || 0,
        balance: Math.max(0, (e.total_amount || 0) - (e.amount_paid || 0)),
      }))
      .filter(row => row.balance > 0)
      .sort((a, b) => b.balance - a.balance);

    const f = t.finance;

    // ULAA Costs breakdown — mirrors computeTripFinanceSummary's own
    // ulaaCosts formula (ad spend + per-traveler costs + agency + child
    // fare costs) line by line, using the already-computed per-traveler
    // and agency figures from `t` (entryTicketCosts, kitCosts, agencyCost,
    // ...) plus the one raw field that summary doesn't expose on its own:
    // ad_spend. Child Fare lines are only included when this trip actually
    // has Child Fare bookings — otherwise they're three zero rows that add
    // nothing.
    const ulaaCostBreakdown: { label: string; amount: number }[] = [
      { label: 'Ad Spend', amount: f.ad_spend || 0 },
      { label: 'Entry Ticket Costs (Adults)', amount: t.entryTicketCosts },
      { label: 'Kit Costs (Adults)', amount: t.kitCosts },
      {
        label: f.agency_name
          ? `Agency Payment — ${f.agency_name}${f.agency_amount_type === 'per_traveler' ? ' (per traveler)' : ''}`
          : `Agency Payment${f.agency_amount_type === 'per_traveler' ? ' (per traveler)' : ''}`,
        amount: t.agencyCost,
      },
    ];
    if (t.childFareCount > 0) {
      ulaaCostBreakdown.push(
        { label: `Child Fare — Vendor Cost (×${t.childFareCount})`, amount: t.childFareVendorCost },
        { label: `Child Fare — Entry Ticket (×${t.childFareCount})`, amount: t.childFareEntryTicketCost },
        { label: `Child Fare — Kit Cost (×${t.childFareCount})`, amount: t.childFareKitCost },
      );
    }

    // Organiser Costs breakdown — these four raw fields are simply summed
    // into organiserCosts (no per-traveler math involved), so they're read
    // straight off the trip's finance record.
    const organiserCostBreakdown: { label: string; amount: number }[] = [
      { label: f.organiser_name ? `Organiser Travel Cost — ${f.organiser_name}` : 'Organiser Travel Cost', amount: f.organiser_travel_cost || 0 },
      { label: 'Organiser Agency Payment', amount: f.organiser_agency_payment || 0 },
      { label: 'Organiser Misc Expense', amount: f.organiser_misc_expense || 0 },
      { label: "Organiser's Own Entry Ticket", amount: f.organiser_own_entry_ticket || 0 },
    ];

    return {
      tripTitle: t.title,
      travelerCount: t.travelerCount,
      vegCount,
      nonVegCount,
      revenue: t.totalRevenue,
      ulaaCosts: t.ulaaCosts,
      organiserCosts: t.organiserCosts,
      totalCosts: t.totalCosts,
      netProfit: t.netProfit,
      profitPerPerson: t.profitPerPerson,
      outstandingByPerson: outstanding,
      ulaaCostBreakdown,
      organiserCostBreakdown,
    };
  };

  // Only trips with a Finances tab filled in have anything to put in the
  // cost/profit half of the sheet (see financeByTrip above), so this export
  // is scoped to those same trips — same reasoning, not a separate rule.
  // A specific trip picked in the Trip dropdown exports as one sheet; "All
  // Trips" exports one sheet per trip so nothing gets flattened away.
  const handleExportExcel = async () => {
    if (financeByTrip.length === 0) return;
    const rows = financeByTrip.map(buildExcelRowForTrip);
    if (tripId === ALL_TRIPS) {
      await downloadAllTripsExcelReport(rows);
    } else {
      await downloadTripExcelReport(rows[0]);
    }
  };

  return (
    <AdminLayout title="Reports" scrollRestorationReady={!loading}>
      <div className="space-y-6 sm:space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <p className="text-dark-muted text-sm">
            Business-wide rollups across Lead, Booking, Financial and Operational activity.
          </p>
          <div className="flex flex-wrap gap-2 shrink-0 items-center">
            <div className="relative flex gap-1 shrink-0 items-center bg-white rounded-full p-1 shadow-card">
              {PERIOD_OPTIONS.map(opt => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setPeriod(opt.value)}
                  aria-pressed={period === opt.value}
                  className={`relative px-2.5 sm:px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors ${
                    period === opt.value ? 'text-white' : 'text-dark-muted hover:text-dark'
                  }`}
                >
                  {period === opt.value && (
                    <motion.span
                      layoutId="reports-period-pill"
                      className="absolute inset-0 bg-primary rounded-full"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
                    />
                  )}
                  <span className="relative">
                    <span className="sm:hidden">{opt.shortLabel}</span>
                    <span className="hidden sm:inline">{opt.label}</span>
                  </span>
                </button>
              ))}
            </div>
            <div className="w-36 sm:w-48 shrink-0">
              <label htmlFor="reports-trip-filter" className="sr-only">Filter by trip</label>
              <Select
                inputId="reports-trip-filter"
                value={tripId}
                onChange={setTripId}
                options={tripOptions}
                size="sm"
                variant="pill"
              />
            </div>
            {!loading && financeByTrip.length > 0 && (
              <motion.button
                type="button"
                onClick={handleExportExcel}
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.96 }}
                title="Download a formatted per-trip Excel report (finance summary + outstanding balances)"
                className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap bg-white text-dark-muted shadow-card hover:text-dark hover:shadow-card-hover transition-colors"
              >
                <Download size={14} aria-hidden="true" />
                <span className="sm:hidden">Excel</span>
                <span className="hidden sm:inline">Export Excel</span>
              </motion.button>
            )}
          </div>
        </div>

        {loading ? (
          <ReportsSkeleton />
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }} className="space-y-6 sm:space-y-8">
            {/* ---- Lead Reports ---- */}
            <ReportSection title="Lead Reports" subtitle={`${lead.total} lead${lead.total === 1 ? '' : 's'} in this view`} icon={Users} tone="primary">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <StatCard label="Conversion Rate" value={`${lead.conversionPct}%`} sub={`${lead.bookedCount} of ${lead.total} booked`} icon={TrendingUp} tone="green" />
                <StatCard label="New" value={lead.newCount} icon={UserPlus} tone="primary" />
                <StatCard label="Contacted" value={lead.contactedCount} icon={Phone} tone="primary" />
                <StatCard label="Avg. Response Time" value={lead.avgResponseTime} sub="Enquiry → first contact" icon={Clock} tone="primary" />
              </div>

              {lead.closedBreakdown.length > 0 && (
                <div className="bg-white border border-background-warm rounded-lg px-4 py-3">
                  <p className="text-[11px] font-button font-bold text-dark-muted uppercase tracking-wide mb-2">
                    Closed Reasons ({lead.closedCount} closed)
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {lead.closedBreakdown.map(r => (
                      <span key={r.label} className="inline-flex items-center gap-1.5 text-xs font-button font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-dark-muted">
                        {r.label} <span className="text-dark">{r.count}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {sourceBreakdown.length > 0 && (
                <div className="bg-white rounded-lg shadow-card p-4">
                  <p className="text-[11px] font-button font-bold text-dark-muted uppercase tracking-wide mb-3">
                    Lead Source Breakdown
                  </p>
                  <div className="space-y-2.5">
                    {sourceBreakdown.map(s => {
                      const max = sourceBreakdown[0].total || 1;
                      return (
                        <div key={s.source} className="flex items-center gap-3">
                          <span className="text-sm text-dark font-medium truncate flex-1 min-w-0">{s.label}</span>
                          <div className="hidden sm:block w-28 h-1.5 rounded-full bg-background-warm overflow-hidden shrink-0">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${Math.max(6, (s.total / max) * 100)}%` }}
                              transition={{ duration: 0.5, ease: 'easeOut' }}
                              className="h-full bg-primary rounded-full"
                            />
                          </div>
                          <span className="text-sm font-semibold text-dark w-6 text-right shrink-0">{s.total}</span>
                          <span className="text-xs text-dark-muted w-28 text-right shrink-0">{s.booked} booked ({s.conversionPct}%)</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </ReportSection>

            {/* ---- Booking Reports ---- */}
            <ReportSection title="Booking Reports" icon={BadgeCheck} tone="primary">
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                <StatCard label="Confirmed" value={booking.confirmed} sub="Currently at this stage" icon={CheckCircle} tone="primary" />
                <StatCard label="Completed" value={booking.completed} icon={PartyPopper} tone="green" />
                <StatCard label="Cancelled" value={booking.cancelled} icon={CalendarX2} tone="red" />
              </div>
            </ReportSection>

            {/* ---- Financial Reports ---- */}
            <ReportSection title="Financial Reports" subtitle="Net of refunds" icon={IndianRupee} tone="primary">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <StatCard label="Revenue" value={formatPrice(financial.revenue)} icon={Coins} tone="green" />
                <StatCard label="Refund Amount" value={formatPrice(financial.refundAmount)} icon={Undo2} tone="red" />
                <StatCard label="Outstanding Balance" value={formatPrice(financial.outstandingBalance)} sub="Active bookings" icon={Wallet} tone="primary" />
                <StatCard label="Avg. Booking Value" value={formatPrice(Math.round(financial.avgBookingValue))} icon={Ticket} tone="primary" />
              </div>

              <div className="bg-white rounded-lg shadow-card p-4">
                <p className="text-[11px] font-button font-bold text-dark-muted uppercase tracking-wide mb-1 flex items-center gap-1.5">
                  <BarChart3 size={13} aria-hidden="true" /> Collected Over Time
                </p>
                <RevenueTrendChart data={revenueTrend} />
              </div>

              {paymentMethodBreakdown.length > 0 && (
                <div className="bg-white rounded-lg shadow-card p-4">
                  <p className="text-[11px] font-button font-bold text-dark-muted uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <CreditCard size={13} aria-hidden="true" /> Collection by Payment Method
                  </p>
                  <div className="space-y-2.5">
                    {paymentMethodBreakdown.map(m => {
                      const max = paymentMethodBreakdown[0].amount || 1;
                      return (
                        <div key={m.method} className="flex items-center gap-3">
                          <span className="text-sm text-dark font-medium truncate flex-1 min-w-0 capitalize">{m.method}</span>
                          <div className="hidden sm:block w-28 h-1.5 rounded-full bg-background-warm overflow-hidden shrink-0">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${Math.max(6, (m.amount / max) * 100)}%` }}
                              transition={{ duration: 0.5, ease: 'easeOut' }}
                              className="h-full bg-primary rounded-full"
                            />
                          </div>
                          <span className="text-xs text-dark-muted w-10 text-right shrink-0">{m.count}×</span>
                          <span className="text-sm font-semibold text-dark w-24 text-right shrink-0">{formatPrice(m.amount)}</span>
                          <span className="text-xs text-dark-muted w-10 text-right shrink-0">{m.sharePct}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {outstandingByPerson.length > 0 && (
                <div className="bg-white rounded-lg shadow-card overflow-hidden overflow-x-auto">
                  <p className="text-[11px] font-button font-bold text-dark-muted uppercase tracking-wide flex items-center gap-1.5 px-4 pt-4">
                    <UserCircle size={13} aria-hidden="true" /> Outstanding Balances by Person ({outstandingByPerson.length})
                  </p>
                  <table className="w-full text-sm min-w-[520px] mt-2">
                    <thead>
                      <tr className="border-b border-background-warm text-left">
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">Traveler</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">Trip</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Total</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Paid</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {outstandingByPerson.map((p, i) => (
                        <motion.tr key={`${p.name}-${i}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border-b border-background-warm last:border-0 hover:bg-background-warm/30">
                          <td className="px-4 py-2.5 text-dark font-medium truncate max-w-[180px]">{p.name}</td>
                          <td className="px-4 py-2.5 text-dark-muted truncate max-w-[180px]">{p.trip}</td>
                          <td className="px-4 py-2.5 text-dark-muted text-right whitespace-nowrap">{formatPrice(p.total)}</td>
                          <td className="px-4 py-2.5 text-green-700 text-right whitespace-nowrap">{formatPrice(p.paid)}</td>
                          <td className="px-4 py-2.5 text-primary font-semibold text-right whitespace-nowrap">{formatPrice(p.balance)}</td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </ReportSection>

            {/* ---- Trip Finance & Profitability ---- */}
            {financeByTrip.length > 0 && (
              <ReportSection
                title="Trip Finance & Profitability"
                subtitle="Trips with the Finances tab filled in · all-time"
                icon={ChartLineUp}
                tone="primary"
              >
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                  <StatCard label="Total Revenue" value={formatPrice(financeTotals.totalRevenue)} icon={Bank} tone="green" />
                  <StatCard label="Total Costs" value={formatPrice(financeTotals.totalCosts)} icon={Receipt} tone="primary" />
                  <StatCard
                    label="Net Profit"
                    value={formatPrice(financeTotals.netProfit)}
                    sub={financeTotals.netProfit < 0 ? 'Currently a loss' : undefined}
                    icon={PiggyBank}
                    tone={financeTotals.netProfit < 0 ? 'red' : 'green'}
                  />
                  <StatCard label="Profit Margin" value={`${financeMarginPct}%`} icon={Percent} tone="primary" />
                </div>

                <div className="bg-white rounded-lg shadow-card overflow-hidden overflow-x-auto">
                  <table className="w-full text-sm min-w-[680px]">
                    <thead>
                      <tr className="border-b border-background-warm text-left">
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">
                          <span className="inline-flex items-center gap-1.5"><Compass size={13} aria-hidden="true" /> Trip</span>
                        </th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Travelers</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Revenue</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Total Costs</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Net Profit</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Profit/Person</th>
                      </tr>
                    </thead>
                    <tbody>
                      {financeByTrip.map(t => (
                        <motion.tr key={t.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border-b border-background-warm last:border-0 hover:bg-background-warm/30">
                          <td className="px-4 py-2.5 text-dark font-medium truncate max-w-[220px]">{t.title}</td>
                          <td className="px-4 py-2.5 text-dark-muted text-right">{t.travelerCount}</td>
                          <td className="px-4 py-2.5 text-dark font-semibold text-right whitespace-nowrap">{formatPrice(t.totalRevenue)}</td>
                          <td className="px-4 py-2.5 text-primary font-semibold text-right whitespace-nowrap">{formatPrice(t.totalCosts)}</td>
                          <td className={`px-4 py-2.5 font-semibold text-right whitespace-nowrap ${t.netProfit < 0 ? 'text-red-600' : 'text-green-700'}`}>
                            {formatPrice(t.netProfit)}
                          </td>
                          <td className="px-4 py-2.5 text-dark-muted text-right whitespace-nowrap">{formatPrice(Math.round(t.profitPerPerson))}</td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </ReportSection>
            )}

            {/* ---- Operational Reports ---- */}
            <ReportSection title="Operational Reports" icon={PieChart} tone="primary">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <StatCard label="Occupancy" value={`${operational.occupancyPct}%`} sub={`${operational.seatsBooked} of ${operational.totalSeats} seats · upcoming trips`} icon={UsersThree} tone="primary" />
                <StatCard label="Cancellation Rate" value={`${operational.cancellationPct}%`} sub={`${operational.cancelledOfBooked} of ${operational.everBookedCount} bookings`} icon={XCircle} tone="red" />
                <StatCard label="No-Show Rate" value={`${operational.noShowPct}%`} sub={`${operational.noShowCount} of ${operational.attendanceRecordedCount} arrivals tracked`} icon={UserX} tone="primary" />
                <StatCard label="Food Preference" value={`${operational.veg}V / ${operational.nonVeg}NV`} sub={operational.notSet ? `${operational.notSet} not set` : 'Travellers'} icon={UtensilsCrossed} tone="primary" />
              </div>

              {operational.topDestinations.length > 0 && (
                <div className="bg-white rounded-lg shadow-card p-4">
                  <p className="text-[11px] font-button font-bold text-dark-muted uppercase tracking-wide mb-3">
                    Top Destinations
                  </p>
                  <div className="space-y-2.5">
                    {operational.topDestinations.map((d, i) => {
                      const max = operational.topDestinations[0].count || 1;
                      return (
                        <div key={d.label} className="flex items-center gap-3">
                          <span className="text-xs font-semibold text-dark-muted w-4 shrink-0">{i + 1}</span>
                          <MapPin size={14} className="text-primary shrink-0" aria-hidden="true" />
                          <span className="text-sm text-dark font-medium truncate flex-1 min-w-0">{d.label}</span>
                          <div className="hidden sm:block w-28 h-1.5 rounded-full bg-background-warm overflow-hidden shrink-0">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${Math.max(6, (d.count / max) * 100)}%` }}
                              transition={{ duration: 0.5, ease: 'easeOut' }}
                              className="h-full bg-primary rounded-full"
                            />
                          </div>
                          <span className="text-sm font-semibold text-dark w-6 text-right shrink-0">{d.count}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </ReportSection>

            {/* ---- Per-Trip Breakdown ---- */}
            {tripBreakdown.length > 0 && (
              <ReportSection title="Per-Trip Breakdown" subtitle="Upcoming trips · current standing" icon={Compass} tone="primary">
                <div className="bg-white rounded-lg shadow-card overflow-hidden overflow-x-auto">
                  <table className="w-full text-sm min-w-[560px]">
                    <thead>
                      <tr className="border-b border-background-warm text-left">
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">
                          <span className="inline-flex items-center gap-1.5"><Compass size={13} aria-hidden="true" /> Trip</span>
                        </th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Seats</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Occupancy</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Collected</th>
                        <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Pending</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tripBreakdown.map(t => (
                        <motion.tr key={t.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border-b border-background-warm last:border-0 hover:bg-background-warm/30">
                          <td className="px-4 py-2.5 text-dark font-medium truncate max-w-[220px]">{t.title}</td>
                          <td className="px-4 py-2.5 text-dark-muted text-right whitespace-nowrap">{t.seatsBooked}/{t.totalSeats}</td>
                          <td className="px-4 py-2.5 text-dark font-semibold text-right">{t.occupancyPct}%</td>
                          <td className="px-4 py-2.5 text-green-700 font-semibold text-right whitespace-nowrap">{formatPrice(t.collected)}</td>
                          <td className="px-4 py-2.5 text-primary font-semibold text-right whitespace-nowrap">{formatPrice(t.pending)}</td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </ReportSection>
            )}
          </motion.div>
        )}
      </div>
    </AdminLayout>
  );
}
