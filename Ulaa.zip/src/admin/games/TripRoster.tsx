import { Users, CheckCircle, Circle } from '@phosphor-icons/react';
import Select from '../../components/ui/Select';
import { formatDateRange } from '../../utils/utils-index';
import { isInProgress } from './hostShared';
import type { TripRoster } from './useTripRoster';

export default function TripRosterPanel({ roster }: { roster: TripRoster }) {
  const { trips, tripsError, tripId, trip, today, loadingPeople, bookedError, people, anyCheckedIn, presentIds, present } = roster;
  const options = (trips ?? []).map(t => ({
    value: t.id,
    label: `${t.title} · ${formatDateRange(t.start_date, t.end_date)}${isInProgress(t, today) ? ' · In progress' : ''}`,
  }));

  return (
    <div className="bg-white rounded-lg shadow-card p-3 sm:p-4 space-y-3">
      {tripsError ? (
        <p role="alert" className="text-sm text-dark">Couldn't load the trips. Please refresh the page.</p>
      ) : trips === null ? (
        <p role="status" className="text-sm text-dark-muted">Loading trips…</p>
      ) : trips.length === 0 ? (
        <p className="text-sm text-dark-muted">There are no upcoming or in-progress trips right now.</p>
      ) : (
        <div className="max-w-xl">
          <label htmlFor="games-trip" className="block text-xs font-medium text-dark-muted mb-1">Trip <span className="font-normal">· upcoming and in-progress only</span></label>
          <Select inputId="games-trip" size="sm" value={tripId} onChange={roster.pickTrip} options={options} placeholder="Select a trip…" />
        </div>
      )}

      {tripId && (
        <>
          <hr className="border-background-warm" />
          {loadingPeople ? (
            <p role="status" className="text-sm text-dark-muted">Loading booked travellers…</p>
          ) : bookedError ? (
            <p role="alert" className="text-sm text-dark">Couldn't load the booked travellers. Pick the trip again to retry.</p>
          ) : people.length === 0 ? (
            <p className="text-sm text-dark-muted">No one is booked on {trip?.title ?? 'this trip'} yet, so there is nobody to play with.</p>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <p className="inline-flex items-center gap-1.5 text-sm font-semibold text-dark" role="status">
                  <Users size={16} weight="duotone" aria-hidden="true" />
                  {present.length} of {people.length} present
                </p>
                <p className="text-xs text-dark-muted hidden sm:block">
                  {anyCheckedIn ? 'Checked-in travellers are ticked.' : 'Nobody is checked in yet, so everyone is ticked.'} Tap a name to change.
                </p>
                <span className="ml-auto inline-flex items-center gap-3 text-xs font-button font-semibold">
                  <button type="button" onClick={() => roster.setAll(true)} className="text-primary hover:underline min-h-[32px]">All</button>
                  <button type="button" onClick={() => roster.setAll(false)} className="text-primary hover:underline min-h-[32px]">None</button>
                </span>
              </div>
              <ul className="flex flex-wrap gap-1.5" aria-label="Travellers present">
                {people.map(p => {
                  const on = presentIds.has(p.id);
                  return (
                    <li key={p.id}>
                      <label className={`inline-flex items-center gap-1.5 h-9 sm:h-8 pl-2 pr-3 rounded-full border text-[13px] cursor-pointer select-none transition-colors focus-within:ring-2 focus-within:ring-primary/40 ${on ? 'bg-primary/10 border-primary/40 text-dark font-medium' : 'bg-white border-background-warm text-dark-muted hover:border-primary/30'}`}>
                        <input type="checkbox" checked={on} onChange={() => roster.toggle(p.id)} className="sr-only" />
                        {on ? <CheckCircle size={16} weight="fill" className="text-primary shrink-0" aria-hidden="true" /> : <Circle size={16} className="shrink-0 opacity-50" aria-hidden="true" />}
                        <span className="truncate max-w-[12rem]">{p.full_name}</span>
                        {p.checked_in_at && <span className="text-[10px] font-semibold text-green-700 bg-green-50 rounded px-1 leading-4" title="Checked in">In</span>}
                      </label>
                    </li>
                  );
                })}
              </ul>
            </>
          )}
        </>
      )}
    </div>
  );
}
