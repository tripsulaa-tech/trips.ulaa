import type { ReactNode } from 'react';
import { ShareNetwork, Copy, WhatsappLogo } from '@phosphor-icons/react';
import { useToast } from '../../components/ui/useToast';

// One game under Admin -> Games -> Play: a slim tile (tap to play here) with
// the share buttons right under it. Kept short so four games fit on a phone.
interface GameCardProps {
  /** The game's tile (use its `row` look), or a short message when it can't start yet. */
  game: ReactNode;
  /** The link to share. Omit while there is none yet. */
  url?: string;
  shareText?: string;
  shareTitle: string;
  /** Shown in the button row before the link exists (e.g. "Make share link"). */
  action?: ReactNode;
  /** One small line under the buttons. */
  note?: ReactNode;
  /** Under the note (e.g. "Update link"). */
  footer?: ReactNode;
}

export const smallBtn = 'inline-flex items-center gap-1.5 text-xs font-button font-semibold px-3 h-9 rounded-lg border-2 border-background-warm text-dark hover:border-primary/40 transition-colors disabled:opacity-50';
export const primaryBtn = 'inline-flex items-center gap-1.5 text-xs font-button font-semibold px-3 h-9 rounded-lg bg-primary text-white hover:opacity-90 transition-opacity disabled:opacity-50';

export default function GameCard({ game, url, shareText = '', shareTitle, action, note, footer }: GameCardProps) {
  const toast = useToast();
  const copyLink = async () => {
    if (!url) return;
    try { await navigator.clipboard.writeText(url); toast.success('Link copied.'); }
    catch { toast.error("Couldn't copy the link. Please try again."); }
  };
  const shareNative = async () => {
    if (!url) return;
    try { await navigator.share({ title: shareTitle, text: shareText, url }); }
    catch { /* cancelled */ }
  };

  return (
    <div className="bg-white rounded-lg shadow-card p-3 space-y-2.5">
      {game}
      {(action || url) && (
        <div className="flex flex-wrap items-center gap-2">
          {action}
          {url && (
            <>
              <button type="button" onClick={() => void copyLink()} className={smallBtn}><Copy size={14} aria-hidden="true" /> Copy link</button>
              <a href={`https://wa.me/?text=${encodeURIComponent(shareText)}`} target="_blank" rel="noopener noreferrer" className={primaryBtn}><WhatsappLogo size={14} weight="fill" aria-hidden="true" /> WhatsApp</a>
              {typeof navigator.share === 'function' && (
                <button type="button" onClick={() => void shareNative()} className={smallBtn} aria-label="More sharing options"><ShareNetwork size={14} aria-hidden="true" /></button>
              )}
            </>
          )}
        </div>
      )}
      {note && <p className="text-xs text-dark-muted">{note}</p>}
      {footer}
    </div>
  );
}
