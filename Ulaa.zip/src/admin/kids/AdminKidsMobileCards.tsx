import { motion } from 'framer-motion';
import {
  Envelope as Mail,
  Phone,
  UserMinus,
  ArrowsClockwise as RefreshCw,
  CalendarDot as CalendarClock,
  CalendarBlank as CalendarDays,
  User,
} from '@phosphor-icons/react';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/ui/Button';
import FoodMark from '../../components/ui/FoodMark';
import ActionsMenu from '../../components/ui/ActionsMenu';
import { TablePagination, ContactQuickLinks } from '../../components/ui/DataTableChrome';
import { formatDate, formatPrice } from '../../utils/utils-index';
import type { ClosedReason, KidStatus } from '../../types/types-index';
import {
  KID_STATUS_CONFIG, KID_NO_SHOW_BADGE, kidFollowUpStatus, canMarkKidNotInterested, canReopenKid,
  kidPaymentBadge, kidFoodBadge, buildKidActions, type KidRow,
} from './kidsShared';

interface AdminKidsMobileCardsProps {
  paginatedKids: KidRow[];
  kidsSafePage: number;
  kidsTotalPages: number;
  kidsRangeStart: number;
  kidsRangeEnd: number;
  totalFiltered: number;
  onPageChange: (page: number) => void;
  busy: string | null;
  onViewDetails: (kid: KidRow) => void;
  onManagePayment: (kid: KidRow) => void;
  onStatusChange: (kid: KidRow, status: KidStatus, reason?: ClosedReason) => void;
  onNotInterested: (kid: KidRow) => void;
  onNoShowToggle: (kid: KidRow, isNoShow: boolean) => void;
  onDelete: (kid: KidRow) => void;
}

/** The mobile card layout for the Kids list — below sm. Purely
 *  presentational; all state, filtering/sorting, and row actions live in
 *  the page's hooks. Mirrors AdminWaitlistMobileCards' shape/spacing
 *  conventions, columns swapped for the kid-specific fields. */
export default function AdminKidsMobileCards({
  paginatedKids, kidsSafePage, kidsTotalPages, kidsRangeStart, kidsRangeEnd, totalFiltered, onPageChange,
  busy, onViewDetails, onManagePayment, onStatusChange, onNotInterested, onNoShowToggle, onDelete,
}: AdminKidsMobileCardsProps) {
  const navigate = useNavigate();

  return (
    <>
      <div className="sm:hidden space-y-3">
        {paginatedKids.map(kid => {
          const cfg = KID_STATUS_CONFIG[kid.status];
          const followUp = kidFollowUpStatus(kid);
          const payBadge = kidPaymentBadge(kid);
          const foodBadge = kidFoodBadge(kid);
          return (
            <motion.div
              key={kid.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white rounded-lg shadow-card p-4 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <button type="button" onClick={() => onViewDetails(kid)} className="min-w-0 text-left">
                  <p className="text-sm font-medium text-dark truncate flex items-center gap-1.5">
                    {kid.label}
                    {(kid.food_preference === 'veg' || kid.food_preference === 'non_veg') && (
                      <FoodMark type={kid.food_preference} size={11} className={kid.food_preference === 'veg' ? 'text-green-700 shrink-0' : 'text-red-700 shrink-0'} />
                    )}
                  </p>
                  <p className="text-dark-muted text-xs truncate">{kid.parentName} · {kid.tripTitle || 'Untitled trip'}</p>
                </button>
                <span className={`shrink-0 inline-flex items-center gap-1 text-[11px] font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${cfg.color}`}>
                  <cfg.icon size={11} className="shrink-0" aria-hidden="true" />
                  {cfg.label}
                </span>
              </div>

              <div className="text-xs text-dark-muted space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="flex items-center gap-1.5 min-w-0">
                    <span className="w-5 h-5 rounded-full bg-amber-50 text-amber-700 inline-flex items-center justify-center shrink-0">
                      <Mail size={10} aria-hidden="true" />
                    </span>
                    <span className="truncate">{kid.email}</span>
                  </p>
                  <ContactQuickLinks phone={kid.phone} email={kid.email} name={kid.parentName} tripTitle={kid.tripTitle} />
                </div>
                <p className="flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-50 text-amber-700 inline-flex items-center justify-center shrink-0">
                    <Phone size={10} aria-hidden="true" />
                  </span>
                  {kid.phone}
                </p>
                <div className="border-b border-background-warm !mt-2.5 !mb-2.5" />
                <p className="flex items-center flex-wrap gap-x-2 gap-y-1.5">
                  {kid.age != null && (
                    <>
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-amber-50 text-amber-700 inline-flex items-center justify-center shrink-0">
                          <User size={10} aria-hidden="true" />
                        </span>
                        {kid.age} yrs
                      </span>
                      <span className="w-px h-3.5 bg-background-warm shrink-0" />
                    </>
                  )}
                  <span className={`inline-flex items-center gap-1 ${foodBadge.key === 'veg' ? 'text-green-700' : foodBadge.key === 'non_veg' ? 'text-red-700' : 'text-dark-muted'}`}>
                    <FoodMark type={foodBadge.key} size={11} /> {foodBadge.label}
                  </span>
                  <span className="w-px h-3.5 bg-background-warm shrink-0" />
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-50 text-amber-700 inline-flex items-center justify-center shrink-0">
                      <CalendarDays size={10} aria-hidden="true" />
                    </span>
                    {formatDate(kid.created_at, { day: 'numeric', month: 'short', year: 'numeric' })}
                  </span>
                </p>
                <button
                  type="button"
                  onClick={() => onManagePayment(kid)}
                  className={`inline-flex items-center gap-1.5 mt-1 font-button font-medium ${payBadge.color} px-2 py-1 rounded-md`}
                >
                  <payBadge.icon size={11} aria-hidden="true" />
                  {kid.amount ? `${formatPrice(kid.amount_paid || 0)} / ${formatPrice(kid.amount)}` : payBadge.label}
                </button>
                {kid.is_no_show && (
                  <span className={`inline-block ml-2 text-[11px] font-button font-semibold px-2 py-0.5 rounded-md whitespace-nowrap ${KID_NO_SHOW_BADGE.color}`}>
                    {KID_NO_SHOW_BADGE.label}
                  </span>
                )}
                {followUp && kid.status === 'pending' && (
                  <p className={`flex items-center gap-1.5 mt-1.5 ${followUp.isOverdue ? 'text-red-700' : followUp.isDue ? 'text-amber-700' : 'text-dark-muted'}`}>
                    <CalendarClock size={12} className="shrink-0" aria-hidden="true" /> {followUp.label}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <div className="flex-1 flex flex-wrap items-center gap-1.5">
                  {canMarkKidNotInterested(kid) && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onNotInterested(kid)}
                      disabled={busy === kid.id}
                      className="!px-2 !py-1 !gap-1 text-[11px] whitespace-nowrap shrink-0"
                    >
                      <UserMinus size={12} aria-hidden="true" /> Not Interested
                    </Button>
                  )}
                  {canReopenKid(kid) && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onStatusChange(kid, 'pending')}
                      disabled={busy === kid.id}
                      className="!px-2 !py-1 !gap-1 text-[11px] whitespace-nowrap shrink-0"
                    >
                      <RefreshCw size={12} aria-hidden="true" /> Reopen
                    </Button>
                  )}
                  {kid.bookingId && (
                    <button
                      type="button"
                      onClick={() => navigate(`/admin/enquiries?enquiry=${kid.enquiry_id}`)}
                      className="text-[11px] font-button font-medium text-primary hover:underline whitespace-nowrap"
                    >
                      View booking
                    </button>
                  )}
                </div>
                <ActionsMenu
                  items={buildKidActions(kid, {
                    onViewDetails: () => onViewDetails(kid),
                    onManagePayment: () => onManagePayment(kid),
                    onStatusChange: status => onStatusChange(kid, status),
                    onNotInterested: () => onNotInterested(kid),
                    onNoShowToggle: isNoShow => onNoShowToggle(kid, isNoShow),
                    onDelete: () => onDelete(kid),
                  })}
                  disabled={busy === kid.id}
                  label={`${kid.label} actions`}
                />
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Mobile: same "Showing X–Y of N" + Prev/Next pagination the
          desktop table gets. */}
      <div className="sm:hidden bg-white rounded-lg shadow-card overflow-hidden">
        <p className="text-dark-muted text-xs text-center px-4 pt-3">
          {totalFiltered === 0 ? 'No kids found' : `Showing ${kidsRangeStart}\u2013${kidsRangeEnd} of ${totalFiltered} kids`}
        </p>
        <TablePagination
          currentPage={kidsSafePage}
          totalPages={kidsTotalPages}
          onPageChange={onPageChange}
        />
      </div>
    </>
  );
}
