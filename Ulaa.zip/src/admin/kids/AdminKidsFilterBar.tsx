import {
  CaretDown as ChevronDown,
  SlidersHorizontal,
  ArrowsClockwise as RefreshCw,
  MagnifyingGlass as Search,
  X,
} from '@phosphor-icons/react';
import FilterDropdown from '../enquiries/AdminFilterDropdown';
import type { KidStatus } from '../../types/types-index';
import { KID_STATUS_CONFIG, KID_PAYMENT_STATUS_CONFIG, type KidPaymentStatusKey } from './kidsShared';
import { FOOD_PREFERENCE_BADGE } from '../../constants/foodPreference';

interface TripOption { value: string; label: string; isCompleted: boolean }

interface AdminKidsFilterBarProps {
  trips: TripOption[];
  statusFilter: 'all' | KidStatus;
  setStatusFilter: (v: 'all' | KidStatus) => void;
  foodFilter: 'all' | 'veg' | 'non_veg' | 'not_set';
  setFoodFilter: (v: 'all' | 'veg' | 'non_veg' | 'not_set') => void;
  paymentFilter: 'all' | KidPaymentStatusKey;
  setPaymentFilter: (v: 'all' | KidPaymentStatusKey) => void;
  tripFilter: string;
  setTripFilter: (v: string) => void;
  searchQuery: string;
  setSearchQuery: (v: string) => void;
  openFilterPanel: 'status' | 'food' | 'payment' | 'trip' | null;
  setOpenFilterPanel: (v: 'status' | 'food' | 'payment' | 'trip' | null) => void;
  mobileFiltersOpen: boolean;
  setMobileFiltersOpen: (fn: (o: boolean) => boolean) => void;
  counts: Record<'all' | KidStatus, number>;
  foodCounts: Record<'all' | 'veg' | 'non_veg' | 'not_set', number>;
  paymentCounts: Record<'all' | KidPaymentStatusKey, number>;
  tripCounts: Record<string, number>;
  activeFilterCount: number;
  clearAllFilters: () => void;
}

/** The mobile search bar plus the Status/Food/Payment/Trip filter row and
 *  its "N active" / "Clear All" chrome — same single-row layout as the
 *  Waitlist/Enquiries pages' filter bars, just with two extra filters
 *  (Food, Payment) since a standalone kid list needs to slice on those the
 *  way neither the Enquiries list nor the per-booking Kids card ever had
 *  to (see kidPaymentStatusKey/kidFoodBadge in kidsShared.ts). */
export default function AdminKidsFilterBar({
  trips, statusFilter, setStatusFilter, foodFilter, setFoodFilter, paymentFilter, setPaymentFilter,
  tripFilter, setTripFilter, searchQuery, setSearchQuery, openFilterPanel, setOpenFilterPanel,
  mobileFiltersOpen, setMobileFiltersOpen, counts, foodCounts, paymentCounts, tripCounts,
  activeFilterCount, clearAllFilters,
}: AdminKidsFilterBarProps) {
  return (
    <>
      {/* Mobile-only search bar — same reachable-without-the-filter-panel
          convention as the Waitlist page's own mobile search. Bound to the
          same searchQuery state the desktop TableHeaderBar search uses. */}
      <div className="relative sm:hidden">
        <label htmlFor="kids-mobile-search" className="sr-only">Search kid, parent, trip, or contact</label>
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-dark-muted pointer-events-none" aria-hidden="true" />
        <input
          id="kids-mobile-search"
          type="text"
          value={searchQuery}
          onChange={ev => setSearchQuery(ev.target.value)}
          placeholder="Search kid, parent, trip..."
          className="w-full pl-10 pr-10 py-3 rounded-lg border-2 border-background-warm bg-white font-body text-dark text-sm focus:border-primary outline-none transition-colors shadow-card"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-dark-muted hover:text-dark p-1"
            aria-label="Clear search"
          >
            <X size={16} aria-hidden="true" />
          </button>
        )}
      </div>

      {/* Filters — one single row: Search | Filters | Clear All, same
          layout as the Waitlist/Enquiries pages' filter bars. */}
      {openFilterPanel && (
        <div className="fixed inset-0 z-20" onClick={() => setOpenFilterPanel(null)} />
      )}
      <div className="bg-white rounded-lg shadow-card p-4">
        <button
          type="button"
          onClick={() => setMobileFiltersOpen(o => !o)}
          aria-expanded={mobileFiltersOpen}
          aria-controls="kids-mobile-filters-panel"
          className="w-full flex items-center gap-2 sm:pointer-events-none sm:cursor-default"
        >
          <SlidersHorizontal size={16} className="text-dark shrink-0" aria-hidden="true" />
          <span className="font-button font-bold text-dark text-[15px] whitespace-nowrap flex-1 text-left">Filters</span>
          {activeFilterCount > 0 && (
            <span className="shrink-0 inline-flex items-center justify-center px-2 h-[22px] rounded-md bg-primary/10 text-primary text-[11px] font-button font-semibold">
              {activeFilterCount} active
            </span>
          )}
          <ChevronDown size={18} className={`sm:hidden shrink-0 text-dark-muted transition-transform ${mobileFiltersOpen ? 'rotate-180' : ''}`} aria-hidden="true" />
        </button>

        <div id="kids-mobile-filters-panel" className={`${mobileFiltersOpen ? 'flex' : 'hidden'} sm:flex flex-col sm:flex-row sm:items-end gap-3 mt-4`}>
          {/* Filters + Clear All — sit together in one row at the bottom
              of the panel. */}
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-end gap-2 flex-1 min-w-0">
            {/* Status */}
            <div className="relative w-full sm:w-auto sm:min-w-[140px]">
              <label htmlFor="kids-filter-status" className="block text-[10px] font-button font-bold text-dark-muted uppercase tracking-wide mb-1">Status</label>
              <button
                id="kids-filter-status"
                aria-haspopup="listbox"
                aria-expanded={openFilterPanel === 'status'}
                onClick={() => setOpenFilterPanel(openFilterPanel === 'status' ? null : 'status')}
                className={`w-full flex items-center justify-between gap-2 rounded-md border-2 px-3 py-2 bg-white transition-colors ${
                  openFilterPanel === 'status' ? 'border-primary/50' : 'border-background-warm hover:border-primary/30'
                }`}
              >
                <span className="text-sm font-button font-medium text-primary truncate">{statusFilter === 'all' ? 'All' : KID_STATUS_CONFIG[statusFilter].label}</span>
                <ChevronDown size={14} className={`text-dark-muted shrink-0 transition-transform ${openFilterPanel === 'status' ? 'rotate-180' : ''}`} aria-hidden="true" />
              </button>
              {openFilterPanel === 'status' && (
                <FilterDropdown
                  value={statusFilter}
                  onSelect={key => { setStatusFilter(key as 'all' | KidStatus); setOpenFilterPanel(null); }}
                  options={(['all', 'pending', 'confirmed', 'checked_in', 'completed', 'cancelled', 'not_interested'] as const).map(key => ({
                    key, label: key === 'all' ? 'All' : KID_STATUS_CONFIG[key].label, count: counts[key],
                  }))}
                />
              )}
            </div>

            {/* Food */}
            <div className="relative w-full sm:w-auto sm:min-w-[130px]">
              <label htmlFor="kids-filter-food" className="block text-[10px] font-button font-bold text-dark-muted uppercase tracking-wide mb-1">Food</label>
              <button
                id="kids-filter-food"
                aria-haspopup="listbox"
                aria-expanded={openFilterPanel === 'food'}
                onClick={() => setOpenFilterPanel(openFilterPanel === 'food' ? null : 'food')}
                className={`w-full flex items-center justify-between gap-2 rounded-md border-2 px-3 py-2 bg-white transition-colors ${
                  openFilterPanel === 'food' ? 'border-primary/50' : 'border-background-warm hover:border-primary/30'
                }`}
              >
                <span className="text-sm font-button font-medium text-primary truncate">{foodFilter === 'all' ? 'All' : FOOD_PREFERENCE_BADGE[foodFilter].label}</span>
                <ChevronDown size={14} className={`text-dark-muted shrink-0 transition-transform ${openFilterPanel === 'food' ? 'rotate-180' : ''}`} aria-hidden="true" />
              </button>
              {openFilterPanel === 'food' && (
                <FilterDropdown
                  value={foodFilter}
                  onSelect={key => { setFoodFilter(key as 'all' | 'veg' | 'non_veg' | 'not_set'); setOpenFilterPanel(null); }}
                  options={(['all', 'veg', 'non_veg', 'not_set'] as const).map(key => ({
                    key, label: key === 'all' ? 'All' : FOOD_PREFERENCE_BADGE[key].label, count: foodCounts[key],
                  }))}
                />
              )}
            </div>

            {/* Payment */}
            <div className="relative w-full sm:w-auto sm:min-w-[150px]">
              <label htmlFor="kids-filter-payment" className="block text-[10px] font-button font-bold text-dark-muted uppercase tracking-wide mb-1">Payment</label>
              <button
                id="kids-filter-payment"
                aria-haspopup="listbox"
                aria-expanded={openFilterPanel === 'payment'}
                onClick={() => setOpenFilterPanel(openFilterPanel === 'payment' ? null : 'payment')}
                className={`w-full flex items-center justify-between gap-2 rounded-md border-2 px-3 py-2 bg-white transition-colors ${
                  openFilterPanel === 'payment' ? 'border-primary/50' : 'border-background-warm hover:border-primary/30'
                }`}
              >
                <span className="text-sm font-button font-medium text-primary truncate">{paymentFilter === 'all' ? 'All' : KID_PAYMENT_STATUS_CONFIG[paymentFilter].label}</span>
                <ChevronDown size={14} className={`text-dark-muted shrink-0 transition-transform ${openFilterPanel === 'payment' ? 'rotate-180' : ''}`} aria-hidden="true" />
              </button>
              {openFilterPanel === 'payment' && (
                <FilterDropdown
                  value={paymentFilter}
                  onSelect={key => { setPaymentFilter(key as 'all' | KidPaymentStatusKey); setOpenFilterPanel(null); }}
                  options={(['all', 'not_set', 'pending', 'partial', 'paid'] as const).map(key => ({
                    key, label: key === 'all' ? 'All' : KID_PAYMENT_STATUS_CONFIG[key].label, count: paymentCounts[key],
                  }))}
                />
              )}
            </div>

            {/* Trip */}
            {trips.length > 0 && (
              <div className="relative w-full sm:w-auto sm:min-w-[160px]">
                <label htmlFor="kids-filter-trip" className="block text-[10px] font-button font-bold text-dark-muted uppercase tracking-wide mb-1">Trip</label>
                <button
                  id="kids-filter-trip"
                  aria-haspopup="listbox"
                  aria-expanded={openFilterPanel === 'trip'}
                  onClick={() => setOpenFilterPanel(openFilterPanel === 'trip' ? null : 'trip')}
                  className={`w-full flex items-center justify-between gap-2 rounded-md border-2 px-3 py-2 bg-white transition-colors ${
                    openFilterPanel === 'trip' ? 'border-primary/50' : 'border-background-warm hover:border-primary/30'
                  }`}
                >
                  <span className="text-sm font-button font-medium text-primary truncate">
                    {tripFilter === 'all' ? 'All' : trips.find(t => t.value === tripFilter)?.label || 'All'}
                  </span>
                  <ChevronDown size={14} className={`text-dark-muted shrink-0 transition-transform ${openFilterPanel === 'trip' ? 'rotate-180' : ''}`} aria-hidden="true" />
                </button>
                {openFilterPanel === 'trip' && (
                  <FilterDropdown
                    value={tripFilter}
                    onSelect={key => { setTripFilter(key); setOpenFilterPanel(null); }}
                    options={[
                      { key: 'all', label: 'All trips', count: tripCounts.all },
                      ...trips.map(t => ({ key: t.value, label: t.label, count: tripCounts[t.value] || 0, section: t.isCompleted ? 'Completed' : undefined })),
                    ]}
                  />
                )}
              </div>
            )}
          </div>

          {/* Clear All — sits at the end of the row; disabled (and
              dimmed) whenever no filter or search term is active. */}
          <button
            onClick={clearAllFilters}
            disabled={activeFilterCount === 0}
            className={`w-full sm:w-auto shrink-0 inline-flex items-center justify-center gap-1.5 text-xs font-button font-semibold rounded-md border-2 px-3 py-2 transition-colors whitespace-nowrap ${
              activeFilterCount === 0
                ? 'border-background-warm text-dark-muted/40 cursor-default'
                : 'border-background-warm text-dark hover:border-primary/30'
            }`}
          >
            <RefreshCw size={13} aria-hidden="true" /> Clear All
          </button>
        </div>
      </div>
    </>
  );
}
