import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Baby,
  Clock,
  CheckCircle as CheckCircle2,
  SignIn as LogIn,
  Confetti as PartyPopper,
  UserMinus,
} from '@phosphor-icons/react';
import AdminLayout from '../AdminLayout';
import { KpiCards, KpiCarousel } from '../../components/ui/KpiCards';
import { useDragScroll } from '../../components/ui/dataTableUtils';
import { useKidsData } from './useKidsData';
import { useKidsFilters } from './useKidsFilters';
import { useKidsActions } from './useKidsActions';
import AdminKidsFilterBar from './AdminKidsFilterBar';
import AdminKidsDesktopTable from './AdminKidsDesktopTable';
import AdminKidsMobileCards from './AdminKidsMobileCards';
import AdminKidPaymentModal from '../enquiries/AdminKidPaymentModal';
import AdminKidNotInterestedModal from '../enquiries/AdminKidNotInterestedModal';
import type { ClosedReason } from '../../types/types-index';
import type { KidRow } from './kidsShared';

/** The standalone Kids admin page — every kid across every booking,
 *  business-wide, at /admin/kids. Mirrors /admin/enquiries and
 *  /admin/waitlist's shape: this component is deliberately just an
 *  orchestrator, with data loading in useKidsData, filter/sort/pagination/
 *  export in useKidsFilters, and row actions (status change, payment,
 *  follow-up, no-show, edit, delete) in useKidsActions — see ./kids/ for
 *  those, plus the desktop table, mobile cards, and filter bar this file
 *  composes.
 *
 *  The "Kids" concept already existed fully (its own status lifecycle,
 *  per-kid payments, follow-ups, not-interested reasons, no-show
 *  tracking) but only ever surfaced nested inside a booking — as sub-rows
 *  on AdminEnquiries.tsx or a card on the enquiry detail page
 *  (AdminEnquiryKidsCard.tsx). This page is the first place every kid
 *  across every booking can be seen, filtered, and worked from at once.
 *  "View Details" navigates to that kid's own full routed page
 *  (/admin/kids/:id — see AdminKidDetail.tsx) rather than opening a local
 *  modal, so a kid's detail view is the same bookmarkable/shareable page
 *  no matter which list it was opened from. Every other kid mutation
 *  (payment, not-interested, status/no-show/follow-up quick actions) is
 *  reused unchanged from the enquiry-detail Kids card — see kidsShared.ts,
 *  useKidPayment.ts, AdminKidPaymentModal/AdminKidNotInterestedModal — so
 *  this page can never drift from what the per-booking Kids card or the
 *  kid detail page already show for the same kid. */
export default function AdminKids() {
  const navigate = useNavigate();
  const { kidRows, completedTrips, getTripChildPrice, loading, load } = useKidsData();
  const filters = useKidsFilters(kidRows, completedTrips);
  const {
    busy,
    handleUpdateStatus, handleToggleNoShow, handleDelete,
    kidPaymentTarget, kidPaymentForm, setKidPaymentForm, kidPaymentChildPrice, savingKidPayment,
    kidPaymentHistory, kidPaymentHistoryLoading, openKidPayment, handleSaveKidPayment, setKidPaymentTarget,
  } = useKidsActions(kidRows, load, getTripChildPrice);

  const { ref: tableScrollRef, isDragging, handlers: dragHandlers } = useDragScroll<HTMLDivElement>();

  // Not Interested reason picker — same shape as
  // AdminEnquiryKidsCard's own kidNotInterestedTarget/kidClosedReason
  // state, just scoped to this page.
  const [kidNotInterestedTarget, setKidNotInterestedTarget] = useState<KidRow | null>(null);
  const [kidClosedReason, setKidClosedReason] = useState<ClosedReason>('no_response');
  const openKidNotInterestedModal = (kid: KidRow) => {
    setKidClosedReason('no_response');
    setKidNotInterestedTarget(kid);
  };
  const handleConfirmKidNotInterested = async () => {
    if (!kidNotInterestedTarget) return;
    await handleUpdateStatus(kidNotInterestedTarget, 'not_interested', kidClosedReason);
    setKidNotInterestedTarget(null);
  };

  // KPI summary cards — same visual style as the Enquiries/Waitlist pages,
  // adapted to kid statuses: Total Kids, Pending, Confirmed, Checked In,
  // Completed, Not Interested/Cancelled.
  const kpiPct = (n: number) => (filters.counts.all ? Math.round((n / filters.counts.all) * 100) : 0);
  const KPI_CARDS = [
    { label: 'Total Kids', value: filters.counts.all, sub: 'All time', icon: Baby },
    { label: 'Pending', value: filters.counts.pending, sub: `${kpiPct(filters.counts.pending)}% of total`, icon: Clock },
    { label: 'Confirmed', value: filters.counts.confirmed, sub: `${kpiPct(filters.counts.confirmed)}% of total`, icon: CheckCircle2 },
    { label: 'Checked In', value: filters.counts.checked_in, sub: `${kpiPct(filters.counts.checked_in)}% of total`, icon: LogIn },
    { label: 'Completed', value: filters.counts.completed, sub: `${kpiPct(filters.counts.completed)}% of total`, icon: PartyPopper },
    { label: 'Not Interested', value: filters.counts.not_interested, sub: `${kpiPct(filters.counts.not_interested)}% of total`, icon: UserMinus },
  ] as const;

  return (
    <AdminLayout title="Kids" subtitle="Every kid across every booking, in one place.">
      <div className="space-y-6">
        {/* KPI summary — desktop grid + mobile carousel, same style as the
            Enquiries/Waitlist pages. */}
        <KpiCards cards={KPI_CARDS} />
        <KpiCarousel cards={KPI_CARDS} />

        <AdminKidsFilterBar
          trips={filters.trips}
          statusFilter={filters.statusFilter}
          setStatusFilter={filters.setStatusFilter}
          foodFilter={filters.foodFilter}
          setFoodFilter={filters.setFoodFilter}
          paymentFilter={filters.paymentFilter}
          setPaymentFilter={filters.setPaymentFilter}
          tripFilter={filters.tripFilter}
          setTripFilter={filters.setTripFilter}
          searchQuery={filters.searchQuery}
          setSearchQuery={filters.setSearchQuery}
          openFilterPanel={filters.openFilterPanel}
          setOpenFilterPanel={filters.setOpenFilterPanel}
          mobileFiltersOpen={filters.mobileFiltersOpen}
          setMobileFiltersOpen={filters.setMobileFiltersOpen}
          counts={filters.counts}
          foodCounts={filters.foodCounts}
          paymentCounts={filters.paymentCounts}
          tripCounts={filters.tripCounts}
          activeFilterCount={filters.activeFilterCount}
          clearAllFilters={filters.clearAllFilters}
        />

        {loading ? (
          <div className="text-center py-16">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : filters.filtered.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-lg shadow-card">
            <p className="font-display text-xl text-dark-muted">No kids found.</p>
          </div>
        ) : (
          <>
            <AdminKidsDesktopTable
              paginatedKids={filters.paginatedKids}
              kidsSafePage={filters.kidsSafePage}
              kidsTotalPages={filters.kidsTotalPages}
              kidsRangeStart={filters.kidsRangeStart}
              kidsRangeEnd={filters.kidsRangeEnd}
              totalFiltered={filters.filtered.length}
              sortKey={filters.sortKey}
              sortDir={filters.sortDir}
              onSort={filters.handleSort}
              searchQuery={filters.searchQuery}
              setSearchQuery={filters.setSearchQuery}
              onExport={filters.handleExportCsv}
              onPageChange={filters.setCurrentPage}
              tableScrollRef={tableScrollRef}
              isDragging={isDragging}
              dragHandlers={dragHandlers}
              busy={busy}
              onViewDetails={kid => navigate(`/admin/kids/${kid.id}`)}
              onManagePayment={kid => openKidPayment(kid, kid.tripId)}
              onStatusChange={(kid, status, reason) => handleUpdateStatus(kid, status, reason)}
              onNotInterested={openKidNotInterestedModal}
              onNoShowToggle={(kid, isNoShow) => handleToggleNoShow(kid, isNoShow)}
              onDelete={handleDelete}
            />

            <AdminKidsMobileCards
              paginatedKids={filters.paginatedKids}
              kidsSafePage={filters.kidsSafePage}
              kidsTotalPages={filters.kidsTotalPages}
              kidsRangeStart={filters.kidsRangeStart}
              kidsRangeEnd={filters.kidsRangeEnd}
              totalFiltered={filters.filtered.length}
              onPageChange={filters.setCurrentPage}
              busy={busy}
              onViewDetails={kid => navigate(`/admin/kids/${kid.id}`)}
              onManagePayment={kid => openKidPayment(kid, kid.tripId)}
              onStatusChange={(kid, status, reason) => handleUpdateStatus(kid, status, reason)}
              onNotInterested={openKidNotInterestedModal}
              onNoShowToggle={(kid, isNoShow) => handleToggleNoShow(kid, isNoShow)}
              onDelete={handleDelete}
            />
          </>
        )}
      </div>

      <AdminKidPaymentModal
        kidPaymentTarget={kidPaymentTarget}
        fallbackLabel={kidPaymentTarget ? (kidRows.find(k => k.id === kidPaymentTarget.id)?.label ?? '') : ''}
        onClose={() => setKidPaymentTarget(null)}
        kidPaymentForm={kidPaymentForm}
        setKidPaymentForm={setKidPaymentForm}
        kidPaymentChildPrice={kidPaymentChildPrice}
        kidPaymentHistory={kidPaymentHistory}
        kidPaymentHistoryLoading={kidPaymentHistoryLoading}
        savingKidPayment={savingKidPayment}
        onSave={handleSaveKidPayment}
      />

      <AdminKidNotInterestedModal
        kidNotInterestedTarget={kidNotInterestedTarget}
        targetLabel={kidNotInterestedTarget?.label ?? ''}
        onClose={() => setKidNotInterestedTarget(null)}
        closedReason={kidClosedReason}
        setClosedReason={setKidClosedReason}
        onConfirm={handleConfirmKidNotInterested}
        updating={kidNotInterestedTarget && busy === kidNotInterestedTarget.id ? kidNotInterestedTarget.id : null}
      />
    </AdminLayout>
  );
}
