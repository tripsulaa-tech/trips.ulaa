import type { RefObject } from 'react';
import { motion } from 'framer-motion';
import {
  Envelope as Mail,
  Phone,
  UserMinus,
  ArrowsClockwise as RefreshCw,
  CalendarDot as CalendarClock,
} from '@phosphor-icons/react';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/ui/Button';
import FoodMark from '../../components/ui/FoodMark';
import ActionsMenu from '../../components/ui/ActionsMenu';
import { TableHeaderBar, TablePagination, SortableTh, ContactQuickLinks } from '../../components/ui/DataTableChrome';
import { formatDate, formatPrice } from '../../utils/utils-index';
import type { ClosedReason, KidStatus } from '../../types/types-index';
import type { KidsSortKey } from './useKidsFilters';
import {
  KID_STATUS_CONFIG, KID_NO_SHOW_BADGE, kidFollowUpStatus, canMarkKidNotInterested, canReopenKid,
  kidPaymentBadge, kidFoodBadge, buildKidActions, type KidRow,
} from './kidsShared';

interface AdminKidsDesktopTableProps {
  paginatedKids: KidRow[];
  kidsSafePage: number;
  kidsTotalPages: number;
  kidsRangeStart: number;
  kidsRangeEnd: number;
  totalFiltered: number;
  sortKey: KidsSortKey | null;
  sortDir: 'asc' | 'desc';
  onSort: (key: KidsSortKey) => void;
  searchQuery: string;
  setSearchQuery: (v: string) => void;
  onExport: () => void;
  onPageChange: (page: number) => void;
  tableScrollRef: RefObject<HTMLDivElement | null>;
  isDragging: boolean;
  dragHandlers: Record<string, (e: React.MouseEvent) => void>;
  busy: string | null;
  onViewDetails: (kid: KidRow) => void;
  onManagePayment: (kid: KidRow) => void;
  onStatusChange: (kid: KidRow, status: KidStatus, reason?: ClosedReason) => void;
  onNotInterested: (kid: KidRow) => void;
  onNoShowToggle: (kid: KidRow, isNoShow: boolean) => void;
  onDelete: (kid: KidRow) => void;
}

/** The desktop/tablet Kids table — sm and up. Purely presentational; all
 *  state, filtering/sorting, and row actions live in the page's hooks
 *  (useKidsFilters / useKidsActions). Same shape as AdminWaitlistDesktopTable,
 *  columns swapped for the kid-specific fields (Parent, Food, Payment)
 *  this standalone list needs that the per-booking Kids card never showed
 *  side-by-side across bookings. */
export default function AdminKidsDesktopTable({
  paginatedKids, kidsSafePage, kidsTotalPages, kidsRangeStart, kidsRangeEnd, totalFiltered,
  sortKey, sortDir, onSort, searchQuery, setSearchQuery, onExport, onPageChange,
  tableScrollRef, isDragging, dragHandlers, busy,
  onViewDetails, onManagePayment, onStatusChange, onNotInterested, onNoShowToggle, onDelete,
}: AdminKidsDesktopTableProps) {
  const navigate = useNavigate();

  return (
    <div className="hidden sm:block bg-white rounded-lg shadow-card overflow-hidden">
      <TableHeaderBar
        title="Kids details"
        rangeStart={kidsRangeStart}
        rangeEnd={kidsRangeEnd}
        total={totalFiltered}
        itemLabel="kids"
        searchValue={searchQuery}
        onSearchChange={setSearchQuery}
        searchPlaceholder="Search kid, parent, trip..."
        onExport={onExport}
        exportLabel="Export CSV"
      />
      <div
        ref={tableScrollRef}
        {...dragHandlers}
        className={`overflow-x-auto overflow-y-auto scrollbar-hide mx-4 sm:mx-5 mb-4 sm:mb-5 max-h-[620px] rounded-md border border-background-warm ${isDragging ? 'cursor-grabbing select-none' : 'cursor-grab'}`}
      >
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10 bg-background-warm text-dark font-medium">
            <tr>
              <SortableTh label="Kid" sortKey="name" activeKey={sortKey} direction={sortDir} onSort={onSort} className="px-4 py-4 text-left" />
              <SortableTh label="Parent" sortKey="parent" activeKey={sortKey} direction={sortDir} onSort={onSort} className="px-4 py-4 text-left hidden md:table-cell" />
              <SortableTh label="Trip" sortKey="trip" activeKey={sortKey} direction={sortDir} onSort={onSort} className="px-4 py-4 text-left hidden lg:table-cell" />
              <SortableTh label="Food" sortKey="food" activeKey={sortKey} direction={sortDir} onSort={onSort} className="px-2 py-4 text-left whitespace-nowrap" />
              <SortableTh label="Payment" sortKey="payment" activeKey={sortKey} direction={sortDir} onSort={onSort} className="px-2 py-4 text-left whitespace-nowrap" />
              <SortableTh label="Status" sortKey="status" activeKey={sortKey} direction={sortDir} onSort={onSort} className="px-2 py-4 text-right whitespace-nowrap" />
              <th className="px-2 py-4 text-right whitespace-nowrap"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-background-warm">
            {paginatedKids.map(kid => {
              const cfg = KID_STATUS_CONFIG[kid.status];
              const followUp = kidFollowUpStatus(kid);
              const payBadge = kidPaymentBadge(kid);
              const foodBadge = kidFoodBadge(kid);
              return (
                <motion.tr key={kid.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background/50">
                  <td className="px-4 py-4 max-w-[160px] sm:max-w-none">
                    <button type="button" onClick={() => onViewDetails(kid)} className="text-left">
                      <p className="font-medium text-dark truncate flex items-center gap-1.5">
                        {kid.label}
                        {(kid.food_preference === 'veg' || kid.food_preference === 'non_veg') && (
                          <FoodMark type={kid.food_preference} size={11} className={kid.food_preference === 'veg' ? 'text-green-700 shrink-0' : 'text-red-700 shrink-0'} />
                        )}
                      </p>
                      {kid.age != null && <p className="text-dark-muted text-xs mt-0.5">{kid.age} yrs</p>}
                      {followUp && kid.status === 'pending' && (
                        <p className={`text-xs mt-1 flex items-center gap-1 ${followUp.isOverdue ? 'text-red-700' : followUp.isDue ? 'text-amber-700' : 'text-dark-muted'}`}>
                          <CalendarClock size={11} className="shrink-0" aria-hidden="true" /> {followUp.label}
                        </p>
                      )}
                    </button>
                  </td>
                  <td className="px-4 py-4 text-dark-muted hidden md:table-cell max-w-[180px]">
                    <p className="truncate font-medium text-dark">{kid.parentName}</p>
                    <p className="flex items-center gap-1 text-xs mt-0.5"><Mail size={11} className="shrink-0" aria-hidden="true" /> {kid.email}</p>
                    <p className="flex items-center gap-1 text-xs mt-0.5"><Phone size={11} className="shrink-0" aria-hidden="true" /> {kid.phone}</p>
                    <div className="mt-1.5">
                      <ContactQuickLinks phone={kid.phone} email={kid.email} name={kid.parentName} tripTitle={kid.tripTitle} />
                    </div>
                  </td>
                  <td className="px-4 py-4 text-dark-muted hidden lg:table-cell max-w-[180px]">
                    <p className="truncate">{kid.tripTitle || '—'}</p>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center gap-1 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${foodBadge.color}`}>
                      <FoodMark type={foodBadge.key} size={12} />
                      {foodBadge.label}
                    </span>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="flex flex-col items-start gap-1">
                      <span className={`inline-flex items-center gap-1 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${payBadge.color}`}>
                        <payBadge.icon size={12} className="shrink-0" aria-hidden="true" /> {payBadge.label}
                      </span>
                      {kid.amount ? (
                        <span className="text-dark-muted text-[11px]">{formatPrice(kid.amount_paid || 0)} / {formatPrice(kid.amount)}</span>
                      ) : null}
                    </div>
                  </td>
                  <td className="px-2 py-4 text-right">
                    <div className="flex flex-col items-end gap-1">
                      <span className={`inline-flex items-center gap-1 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${cfg.color}`}>
                        <cfg.icon size={12} className="shrink-0" aria-hidden="true" /> {cfg.label}
                      </span>
                      {kid.is_no_show && (
                        <span className={`text-[11px] font-button font-semibold px-2 py-0.5 rounded-md whitespace-nowrap ${KID_NO_SHOW_BADGE.color}`}>
                          {KID_NO_SHOW_BADGE.label}
                        </span>
                      )}
                      <span className="text-dark-muted text-[11px] whitespace-nowrap">{formatDate(kid.created_at, { day: 'numeric', month: 'short' })}</span>
                    </div>
                  </td>
                  <td className="px-2 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {canMarkKidNotInterested(kid) && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onNotInterested(kid)}
                          disabled={busy === kid.id}
                          className="!px-2 !py-1 !gap-1 text-[11px] whitespace-nowrap shrink-0"
                        >
                          <UserMinus size={12} aria-hidden="true" /> Not Interested
                        </Button>
                      )}
                      {canReopenKid(kid) && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onStatusChange(kid, 'pending')}
                          disabled={busy === kid.id}
                          className="!px-2 !py-1 !gap-1 text-[11px] whitespace-nowrap shrink-0"
                        >
                          <RefreshCw size={12} aria-hidden="true" /> Reopen
                        </Button>
                      )}
                      {kid.bookingId && (
                        <button
                          type="button"
                          onClick={() => navigate(`/admin/enquiries?enquiry=${kid.enquiry_id}`)}
                          title="View parent booking"
                          className="shrink-0 text-[11px] font-button font-medium text-primary hover:underline whitespace-nowrap"
                        >
                          View booking
                        </button>
                      )}
                      <ActionsMenu
                        items={buildKidActions(kid, {
                          onViewDetails: () => onViewDetails(kid),
                          onManagePayment: () => onManagePayment(kid),
                          onStatusChange: status => onStatusChange(kid, status),
                          onNotInterested: () => onNotInterested(kid),
                          onNoShowToggle: isNoShow => onNoShowToggle(kid, isNoShow),
                          onDelete: () => onDelete(kid),
                        })}
                        disabled={busy === kid.id}
                        label={`${kid.label} actions`}
                      />
                    </div>
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <TablePagination
        currentPage={kidsSafePage}
        totalPages={kidsTotalPages}
        onPageChange={onPageChange}
      />
    </div>
  );
}
