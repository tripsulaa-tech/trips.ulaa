import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import type { SortDirection } from '../../components/ui/dataTableUtils';
import { paginate } from '../../components/ui/dataTableUtils';
import { formatDate, formatPrice, downloadCsv } from '../../utils/utils-index';
import type { KidStatus } from '../../types/types-index';
import type { CompletedTrip } from '../../types/types-index';
import { KID_STATUS_CONFIG, kidPaymentStatusKey, kidFoodBadge, type KidRow, type KidPaymentStatusKey } from './kidsShared';

export type KidsSortKey = 'name' | 'parent' | 'trip' | 'status' | 'food' | 'payment' | 'joined';

// Table pagination — 10 rows per page, same as the Waitlist page.
const KIDS_PAGE_SIZE = 10;

/** Owns every filter/search/sort/pagination knob for the Kids list —
 *  Status, Food, Payment, Trip, search text, column sort, and current
 *  page — plus the derived filtered/sorted/paginated rows, counts, and
 *  CSV export.
 *
 *  Takes `kidRows` from useKidsData and `completedTrips` for the same
 *  "flag a trip that already graduated into an album" labeling
 *  useWaitlistFilters does. Mirrors that hook's shape closely — see it for
 *  the fuller rationale behind the page-reset-on-filter-change pattern. */
export function useKidsFilters(kidRows: KidRow[], completedTrips: CompletedTrip[]) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [statusFilter, setStatusFilter] = useState<'all' | KidStatus>('all');
  const [foodFilter, setFoodFilter] = useState<'all' | 'veg' | 'non_veg' | 'not_set'>('all');
  const [paymentFilter, setPaymentFilter] = useState<'all' | KidPaymentStatusKey>('all');
  const [tripFilter, setTripFilter] = useState<string>(searchParams.get('trip') || 'all');
  const [searchQuery, setSearchQuery] = useState('');
  const [openFilterPanel, setOpenFilterPanel] = useState<'status' | 'food' | 'payment' | 'trip' | null>(null);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortKey, setSortKey] = useState<KidsSortKey | null>(null);
  const [sortDir, setSortDir] = useState<SortDirection>('asc');
  const handleSort = (key: KidsSortKey) => {
    if (sortKey === key) {
      setSortDir(d => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  // Clear the ?trip= param from the URL once picked up — same as
  // useWaitlistFilters, so a link in from a trip page doesn't stick around
  // after the admin changes the filter manually.
  useEffect(() => {
    if (searchParams.get('trip')) {
      setSearchParams(params => { params.delete('trip'); return params; }, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const trips = useMemo(() => {
    const completedIds = new Set(completedTrips.map(t => t.id));
    const map = new Map<string, string>();
    kidRows.forEach(k => { if (k.tripId && !map.has(k.tripId)) map.set(k.tripId, k.tripTitle || 'Untitled trip'); });
    return Array.from(map.entries())
      .map(([id, title]) => ({ value: id, label: title, isCompleted: completedIds.has(id) }))
      .sort((a, b) => Number(a.isCompleted) - Number(b.isCompleted));
  }, [kidRows, completedTrips]);

  const trimmedSearch = searchQuery.trim().toLowerCase();
  const filtered = kidRows
    .filter(k => statusFilter === 'all' || k.status === statusFilter)
    .filter(k => foodFilter === 'all' || kidFoodBadge(k).key === foodFilter)
    .filter(k => paymentFilter === 'all' || kidPaymentStatusKey(k) === paymentFilter)
    .filter(k => tripFilter === 'all' || k.tripId === tripFilter)
    .filter(k => !trimmedSearch
      || k.label.toLowerCase().includes(trimmedSearch)
      || k.parentName?.toLowerCase().includes(trimmedSearch)
      || k.phone?.toLowerCase().includes(trimmedSearch)
      || k.email?.toLowerCase().includes(trimmedSearch)
      || k.tripTitle?.toLowerCase().includes(trimmedSearch));

  const sortedFiltered = sortKey ? [...filtered].sort((a, b) => {
    const dir = sortDir === 'asc' ? 1 : -1;
    switch (sortKey) {
      case 'name': return dir * a.label.localeCompare(b.label);
      case 'parent': return dir * (a.parentName || '').localeCompare(b.parentName || '');
      case 'trip': return dir * (a.tripTitle || '').localeCompare(b.tripTitle || '');
      case 'status': return dir * a.status.localeCompare(b.status);
      case 'food': return dir * kidFoodBadge(a).key.localeCompare(kidFoodBadge(b).key);
      case 'payment': return dir * kidPaymentStatusKey(a).localeCompare(kidPaymentStatusKey(b));
      case 'joined': return dir * (a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0);
      default: return 0;
    }
  }) : filtered;

  const {
    pageItems: paginatedKids,
    totalPages: kidsTotalPages,
    safePage: kidsSafePage,
    rangeStart: kidsRangeStart,
    rangeEnd: kidsRangeEnd,
  } = paginate(sortedFiltered, currentPage, KIDS_PAGE_SIZE);

  // Land back on page 1 whenever the filters or search term change — same
  // during-render adjustment useWaitlistFilters uses, for the same reason
  // (see https://react.dev/learn/you-might-not-need-an-effect#adjusting-some-state-when-a-prop-changes).
  const filterSignature = `${statusFilter}|${foodFilter}|${paymentFilter}|${tripFilter}|${trimmedSearch}`;
  const [prevFilterSignature, setPrevFilterSignature] = useState(filterSignature);
  if (filterSignature !== prevFilterSignature) {
    setPrevFilterSignature(filterSignature);
    setCurrentPage(1);
  }

  const counts: Record<'all' | KidStatus, number> = {
    all: kidRows.length,
    pending: kidRows.filter(k => k.status === 'pending').length,
    confirmed: kidRows.filter(k => k.status === 'confirmed').length,
    checked_in: kidRows.filter(k => k.status === 'checked_in').length,
    completed: kidRows.filter(k => k.status === 'completed').length,
    cancelled: kidRows.filter(k => k.status === 'cancelled').length,
    not_interested: kidRows.filter(k => k.status === 'not_interested').length,
  };

  const foodCounts: Record<'all' | 'veg' | 'non_veg' | 'not_set', number> = {
    all: kidRows.length,
    veg: kidRows.filter(k => kidFoodBadge(k).key === 'veg').length,
    non_veg: kidRows.filter(k => kidFoodBadge(k).key === 'non_veg').length,
    not_set: kidRows.filter(k => kidFoodBadge(k).key === 'not_set').length,
  };

  const paymentCounts: Record<'all' | KidPaymentStatusKey, number> = {
    all: kidRows.length,
    not_set: kidRows.filter(k => kidPaymentStatusKey(k) === 'not_set').length,
    pending: kidRows.filter(k => kidPaymentStatusKey(k) === 'pending').length,
    partial: kidRows.filter(k => kidPaymentStatusKey(k) === 'partial').length,
    paid: kidRows.filter(k => kidPaymentStatusKey(k) === 'paid').length,
  };

  const tripCounts: Record<string, number> = { all: kidRows.length };
  trips.forEach(t => { tripCounts[t.value] = kidRows.filter(k => k.tripId === t.value).length; });

  const activeFilterCount = (statusFilter !== 'all' ? 1 : 0) + (foodFilter !== 'all' ? 1 : 0)
    + (paymentFilter !== 'all' ? 1 : 0) + (tripFilter !== 'all' ? 1 : 0) + (trimmedSearch ? 1 : 0);
  const clearAllFilters = () => {
    setStatusFilter('all');
    setFoodFilter('all');
    setPaymentFilter('all');
    setTripFilter('all');
    setSearchQuery('');
    setOpenFilterPanel(null);
  };

  // Exports exactly what's currently filtered/sorted — same "scope to one
  // trip via the filter, get a per-trip export for free" idea as
  // useWaitlistFilters' handleExportCsv.
  const handleExportCsv = () => {
    const headers = [
      'Kid', 'Parent/Guardian', 'Phone', 'Email', 'Age', 'Trip', 'Food',
      'Status', 'No Show', 'Amount', 'Amount Paid', 'Payment Status', 'Added At',
    ];
    const rows = sortedFiltered.map(k => [
      k.label,
      k.parentName,
      k.phone,
      k.email,
      k.age ?? '',
      k.tripTitle ?? '',
      kidFoodBadge(k).label,
      KID_STATUS_CONFIG[k.status]?.label ?? k.status,
      k.is_no_show ? 'Yes' : 'No',
      formatPrice(k.amount || 0),
      formatPrice(k.amount_paid || 0),
      KID_STATUS_CONFIG[k.status] ? kidPaymentStatusKey(k) : kidPaymentStatusKey(k),
      formatDate(k.created_at),
    ]);
    const tripName = tripFilter !== 'all' ? trips.find(t => t.value === tripFilter)?.label : undefined;
    const scopeSuffix = tripName ? `-${tripName.replace(/\s+/g, '_')}` : '';
    downloadCsv(`kids${scopeSuffix}-${new Date().toISOString().slice(0, 10)}`, headers, rows);
  };

  return {
    trips,
    statusFilter, setStatusFilter,
    foodFilter, setFoodFilter,
    paymentFilter, setPaymentFilter,
    tripFilter, setTripFilter,
    searchQuery, setSearchQuery, trimmedSearch,
    openFilterPanel, setOpenFilterPanel,
    mobileFiltersOpen, setMobileFiltersOpen,
    currentPage, setCurrentPage,
    sortKey, sortDir, handleSort,
    filtered, sortedFiltered,
    paginatedKids,
    kidsTotalPages, kidsSafePage, kidsRangeStart, kidsRangeEnd,
    counts, foodCounts, paymentCounts, tripCounts,
    activeFilterCount, clearAllFilters,
    handleExportCsv,
  };
}
