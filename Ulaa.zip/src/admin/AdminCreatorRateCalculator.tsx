// Creator Commercial Rate Calculator — admin tool for working out what to
// pay/quote an Instagram creator for a collaboration, ported 1:1 from the
// "Creator_Rate_Calculator_final.xlsx" spreadsheet (Rate Calculator +
// Model Settings tabs). All formulas below mirror that workbook's cells
// exactly (see comments citing the original cell refs) so the numbers this
// page produces match the spreadsheet for the same inputs.
//
// Unlike the spreadsheet, every calculation run here can be saved
// (creator_rate_calculations table — see
// supabase/migration/add_creator_rate_calculations.sql) so past quotes are
// a real, searchable record rather than disappearing the moment the page
// is closed. Both the raw inputs and every derived output are stored
// together, so a saved row stays an accurate record of what was actually
// quoted even if the niche benchmarks or multiplier tiers are tuned later.
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calculator,
  Users,
  Eye,
  ChartLineUp,
  Target,
  ArrowsClockwise as RotateCcw,
  Info,
  FloppyDisk as Save,
  ClockCounterClockwise as History,
  Trash as Trash2,
  CaretDown as ChevronDown,
  CaretUp as ChevronUp,
  InstagramLogo as Instagram,
  Phone,
  ClipboardText,
  Copy,
  WhatsappLogo,
  Check,
  NotePencil as TemplateIcon,
  PencilSimple as EditIcon,
  Plus,
  Star,
  X,
  TextB as BoldIcon,
  TextItalic as ItalicIcon,
  TextStrikethrough as StrikethroughIcon,
  Code as MonospaceIcon,
} from '@phosphor-icons/react';
import AdminLayout from './AdminLayout';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import { useAlert } from '../components/ui/useAlert';
import { useConfirm } from '../components/ui/useConfirm';
import { formatPrice, formatDate, getWhatsAppLink } from '../utils/utils-index';
import { FORM_INPUT_CLASS as inputClass } from '../constants/formStyles';
import { getCreatorRateCalculations, saveCreatorRateCalculation, deleteCreatorRateCalculation, getSiteContent, upsertSiteContent } from '../services/api';
import type { CreatorRateCalculation, CreatorRateAsset } from '../types/types-index';

// ---- Model Settings tab, columns A:B (Niche → CPV Benchmark) ----
const NICHE_CPV_BENCHMARKS: { niche: string; cpv: number }[] = [
  { niche: 'Finance / Fintech', cpv: 0.75 },
  { niche: 'Tech', cpv: 0.65 },
  { niche: 'Business / Entrepreneurship', cpv: 0.65 },
  { niche: 'Beauty / Fashion', cpv: 0.475 },
  { niche: 'Travel & Lifestyle', cpv: 0.5 },
  { niche: 'Food', cpv: 0.375 },
  { niche: 'Comedy / Entertainment', cpv: 0.25 },
  { niche: 'Gaming', cpv: 0.25 },
  { niche: 'Education', cpv: 0.5 },
  { niche: 'Health / Wellness', cpv: 0.45 },
];

const NICHE_OPTIONS = NICHE_CPV_BENCHMARKS.map(n => ({ value: n.niche, label: n.niche }));

const REEL_COUNT = 10;

// Height of AdminLayout's sticky top bar (76px mobile / 92px desktop, plus
// a little breathing room) — used whenever a collapsible section on this
// page is expanded and scrolled into view, since scrolling its header to
// the very top of the page would otherwise tuck it directly underneath
// that sticky bar instead of leaving it visible below it.
const STICKY_HEADER_SCROLL_OFFSET = 100;

// Saved Calculations card/row expand state — kept in sessionStorage (not
// localStorage) so leaving this page for another admin screen and coming
// back mid-visit doesn't lose your place, but the card still honours its
// "collapsed by default" design on a fresh tab/next day rather than
// permanently remembering whatever was left open.
const HISTORY_EXPANDED_KEY = 'cr_history_expanded';
const HISTORY_EXPANDED_ID_KEY = 'cr_history_expanded_id';
const TEMPLATE_EXPANDED_KEY = 'cr_template_expanded';

function readSessionFlag(key: string): boolean {
  try {
    return sessionStorage.getItem(key) === '1';
  } catch {
    return false;
  }
}

function readSessionString(key: string): string | null {
  try {
    return sessionStorage.getItem(key);
  } catch {
    return null;
  }
}

// Scrolls `el` (offset for the sticky top bar) into place, then keeps
// re-checking its position for a short window instead of trusting a single
// snapshot-in-time scroll. Right after a click, this page's layout can
// still be settling — web fonts swapping in, an in-flight fetch resolving
// — any of which nudges content up/down a beat after we've already
// scrolled, leaving the target back off-screen even though the scroll
// "worked". Re-asserts the corrected position on every frame for ~800ms,
// stopping early the moment the admin scrolls by hand.
function scrollElementIntoView(el: HTMLElement, offset: number) {
  let cancelled = false;
  const deadline = performance.now() + 800;
  let firstJump = true;

  const step = () => {
    if (cancelled) return;
    const target = el.getBoundingClientRect().top + window.scrollY - offset;
    if (Math.abs(window.scrollY - target) > 2) {
      // The first jump animates (smooth) so opening the panel reads as one
      // motion; any later correction (layout having shifted since) snaps
      // instantly — a second smooth call would just restart the easing
      // and fight itself into visible jitter instead of settling.
      window.scrollTo({ top: target, behavior: firstJump ? 'smooth' : 'auto' });
      firstJump = false;
    }
    if (performance.now() < deadline) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);

  const stop = () => { cancelled = true; };
  window.addEventListener('wheel', stop, { passive: true, once: true });
  window.addEventListener('touchmove', stop, { passive: true, once: true });

  return () => {
    cancelled = true;
    window.removeEventListener('wheel', stop);
    window.removeEventListener('touchmove', stop);
  };
}

// Default identity fields, so the common case (quoting the same test/house
// creator) doesn't need retyping every time — still fully editable, and
// Reset restores these rather than blanking them out.
const DEFAULT_CREATOR_NAME = 'Jini';
const DEFAULT_INSTAGRAM_HANDLE = '@justjini_';
const DEFAULT_PHONE = '6383336772';

// Pulls every view-count-looking token out of pasted text, so a Reel field
// can accept a whole column copied from Instagram Insights or a
// spreadsheet (one value per line, comma/tab separated, etc.) instead of
// forcing the admin to enter all 10 values one at a time. Handles thousand
// separators ("12,345") and shorthand suffixes ("12.3k", "1.1M").
function extractViewNumbers(text: string): number[] {
  const matches = text.match(/-?\d[\d,]*(?:\.\d+)?\s*[kKmM]?/g) || [];
  return matches
    .map(raw => {
      const cleaned = raw.replace(/,/g, '').trim();
      const m = cleaned.match(/^(-?\d+(?:\.\d+)?)\s*([kKmM])?$/);
      if (!m) return null;
      let value = parseFloat(m[1]);
      if (Number.isNaN(value)) return null;
      const suffix = m[2]?.toLowerCase();
      if (suffix === 'k') value *= 1_000;
      if (suffix === 'm') value *= 1_000_000;
      return Math.round(value);
    })
    .filter((n): n is number => n !== null);
}

// Rate Calculator!H8 — tiered View/Follower Ratio → Quality Multiplier,
// straight from the nested IF in that cell (equivalent to the lookup table
// on Model Settings!D:E).
function viewQualityMultiplier(ratio: number): number {
  if (ratio < 0.2) return 0.25;
  if (ratio < 0.4) return 0.4;
  if (ratio < 0.6) return 0.6;
  if (ratio < 0.8) return 0.8;
  if (ratio < 1) return 0.9;
  if (ratio < 1.25) return 0.92;
  if (ratio < 1.5) return 0.96;
  return 1;
}

// Excel FLOOR(x, 50) / CEILING(x, 50) — round down/up to the nearest ₹50,
// used throughout the "Final Commercials" section of the sheet.
function floorTo50(x: number): number {
  return Math.floor(x / 50) * 50;
}
function ceilTo50(x: number): number {
  return Math.ceil(x / 50) * 50;
}

// Turns a saved calculation into a ready-to-send message — this is the
// piece the admin actually hands to the creator (via Copy or WhatsApp
// Share on each saved row), so it stays plain text/emoji only, no app
// jargon like "CPV" or "quality multiplier".
//
// The wording itself comes from one or more named variants stored in the
// site_content table (key RATE_MESSAGE_TEMPLATE_KEY — same generic
// key/value store the rest of the site's editable copy uses, see
// supabase/schema.sql), edited directly in the "Message Template" box
// above the saved-calculations list rather than per saved calculation.
// Saving it there updates that row, so every admin sees the same variants
// for every calculation (new or old), on any device. Copy/Share on a saved
// row use whichever variant is marked default unless the admin picks a
// different one for that send from the row's own variant picker.
const RATE_MESSAGE_TEMPLATE_KEY = 'creator_rate_message_template';

interface MessageTemplateVariant {
  id: string;
  name: string;
  template: string;
}

interface CreatorRateMessageTemplateContent {
  variants: MessageTemplateVariant[];
  defaultVariantId: string;
  /** @deprecated pre-variants shape, read for backward compatibility only */
  template?: string;
}

const DEFAULT_MESSAGE_TEMPLATE = [
  "{{greeting}} Here's the commercial rate card for your {{niche}} content ({{followers}} followers):",
  '',
  '{{items}}',
  '',
  'These are our suggested ranges — happy to discuss and finalise. Let us know your thoughts!',
  '— Team ULAA',
].join('\n');

const DEFAULT_VARIANT_ID = 'default';

const DEFAULT_MESSAGE_TEMPLATE_VARIANTS: MessageTemplateVariant[] = [
  { id: DEFAULT_VARIANT_ID, name: 'Default', template: DEFAULT_MESSAGE_TEMPLATE },
];

// Fills a template's {{greeting}} / {{niche}} / {{followers}} / {{items}}
// tokens in with one calculation's actual values. Only needs this sliver of
// CreatorRateCalculation, so the live "Preview Template" popup below can
// feed it the in-progress form state without a full saved-row shape.
type MessageTemplateSource = Pick<CreatorRateCalculation, 'creator_name' | 'niche' | 'follower_count' | 'final_commercials'>;

// The "Final Commercials" asset names carry a leading count for the admin
// table above (e.g. "1 Non-Collab Reel", so a future "2 Story" scales
// cleanly) — but reads oddly in the message sent to the creator, so it's
// stripped here for the {{items}} output only. The table itself keeps
// the count untouched.
function stripLeadingCount(assetName: string): string {
  return assetName.replace(/^1\s+/, '');
}

// A real HTML table can't be sent as a WhatsApp message, but padding each
// row's asset name out to the same width — inside a monospace block, where
// every character is the same width — lines the Max column up into
// something that reads as a table once WhatsApp renders the monospace
// formatting. Used whenever {{items}} sits directly inside a ```…``` block
// (the "Monospace" toolbar button wraps the current selection in exactly
// that), so wrapping {{items}} in Monospace is what turns it into a table.
function formatItemsAsTable(assets: CreatorRateAsset[]): string {
  const names = assets.map(row => stripLeadingCount(row.asset));
  const nameWidth = Math.max(...names.map(name => name.length));
  return assets
    .map((row, i) => `${names[i].padEnd(nameWidth)}  ${formatPrice(row.max)}`)
    .join('\n');
}

function renderMessageTemplate(template: string, h: MessageTemplateSource): string {
  const greeting = h.creator_name ? `Hi ${h.creator_name.trim().split(/\s+/)[0]}!` : 'Hi!';
  const itemsToken = '{{items}}';
  const tokenIndex = template.indexOf(itemsToken);
  const isTableWrapped =
    tokenIndex !== -1 &&
    template.slice(Math.max(0, tokenIndex - 3), tokenIndex) === '```' &&
    template.slice(tokenIndex + itemsToken.length, tokenIndex + itemsToken.length + 3) === '```';
  const items = isTableWrapped
    ? formatItemsAsTable(h.final_commercials)
    : h.final_commercials.map(row => `- ${stripLeadingCount(row.asset)}: *${formatPrice(row.max)}*`).join('\n');
  return template
    .replace('{{greeting}}', greeting)
    .replace('{{niche}}', h.niche)
    .replace('{{followers}}', h.follower_count.toLocaleString('en-IN'))
    .replace(itemsToken, items);
}

// Renders WhatsApp's own lightweight markup (*bold*, _italic_,
// ~strikethrough~, ```monospace```) as actual formatting for the Preview
// popup, so the admin can see how the message will really look once
// WhatsApp applies that markup on send — the raw asterisks/underscores
// stay in the underlying template text (and in what Copy puts on the
// clipboard); this only affects what's displayed inside the popup itself.
function renderFormattedPreview(text: string): (string | ReactNode)[] {
  const parts = text.split(/(\*[^*\n]+\*|_[^_\n]+_|~[^~\n]+~|```[^`]+```)/g);
  return parts.map((part, i) => {
    if (/^\*[^*\n]+\*$/.test(part)) return <strong key={i}>{part.slice(1, -1)}</strong>;
    if (/^_[^_\n]+_$/.test(part)) return <em key={i}>{part.slice(1, -1)}</em>;
    if (/^~[^~\n]+~$/.test(part)) return <span key={i} className="line-through">{part.slice(1, -1)}</span>;
    if (/^```[^`]+```$/.test(part)) return <code key={i} className="font-mono text-[0.85em] bg-background-warm px-1 py-0.5 rounded">{part.slice(3, -3)}</code>;
    return part;
  });
}

// Sample "Final Commercials" used to fill the {{items}} token in the
// template preview when the calculator above doesn't have a real
// calculation to preview with yet (no follower count / Reel views entered)
// — so Preview always has something concrete to show rather than blank
// placeholders.
const PREVIEW_SAMPLE_ASSETS: CreatorRateAsset[] = [
  { asset: '1 Non-Collab Reel', min: 5050, max: 5050, pricing_logic: 'Base Reel Rate' },
  { asset: '1 Collab Tag Reel', min: 5550, max: 6050, pricing_logic: '1.1–1.2× Non-Collab Reel' },
  { asset: '1 Feed Post', min: 1500, max: 2000, pricing_logic: '0.3–0.5× Reel' },
  { asset: '1 Story', min: 1000, max: 2000, pricing_logic: '0.2–0.4× Reel' },
  { asset: '1 Month Ad Rights', min: 1500, max: 1500, pricing_logic: '0.3× Reel' },
];

export default function AdminCreatorRateCalculator() {
  const alert = useAlert();
  const confirm = useConfirm();

  // ---- Identity (saved alongside the calculation, optional) ----
  const [creatorName, setCreatorName] = useState(DEFAULT_CREATOR_NAME);
  const [instagramHandle, setInstagramHandle] = useState(DEFAULT_INSTAGRAM_HANDLE);
  const [phone, setPhone] = useState(DEFAULT_PHONE);
  const [notes, setNotes] = useState('');

  // ---- Calculator inputs ----
  const [followerCount, setFollowerCount] = useState<string>('');
  const [reelViews, setReelViews] = useState<string[]>(Array(REEL_COUNT).fill(''));
  const [niche, setNiche] = useState<string>(NICHE_OPTIONS[0].value);
  const reelInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const followers = Number(followerCount) || 0;
  const views = reelViews.map(v => Number(v) || 0);
  const reelsEntered = views.filter(v => v > 0).length;

  const result = useMemo(() => {
    // Rate Calculator!H5 — AVERAGE(B6:B15)
    const avgViews = views.length ? views.reduce((s, v) => s + v, 0) / views.length : 0;
    // Rate Calculator!H6 — IFERROR(H5/B5, 0)
    const viewFollowerRatio = followers > 0 ? avgViews / followers : 0;
    // Rate Calculator!H7 — VLOOKUP(niche, Model Settings!I2:J11, 2, FALSE)
    const nicheCpv = NICHE_CPV_BENCHMARKS.find(n => n.niche === niche)?.cpv ?? 0;
    // Rate Calculator!H8
    const qualityMultiplier = viewQualityMultiplier(viewFollowerRatio);
    // Rate Calculator!H9 — B5*H7
    const baseRate = followers * nicheCpv;
    // Rate Calculator!H10 — MIN(B5, H9*H8)
    const minReelRate = Math.min(followers, baseRate * qualityMultiplier);
    // Rate Calculator!H11 — MIN(B5, H9)
    const maxReelRate = Math.min(followers, baseRate);

    // Rate Calculator!A22:D26 — Final Commercials table
    const assets: CreatorRateAsset[] = [
      { asset: '1 Non-Collab Reel', min: floorTo50(minReelRate), max: ceilTo50(maxReelRate), pricing_logic: 'Base Reel Rate' },
      { asset: '1 Collab Tag Reel', min: floorTo50(maxReelRate), max: ceilTo50(1.2 * maxReelRate), pricing_logic: '1.1–1.2× Non-Collab Reel' },
      { asset: '1 Feed Post', min: floorTo50(0.3 * minReelRate), max: ceilTo50(0.4 * maxReelRate), pricing_logic: '0.3–0.5× Reel' },
      { asset: '1 Story', min: floorTo50(0.2 * minReelRate), max: ceilTo50(0.4 * maxReelRate), pricing_logic: '0.2–0.4× Reel' },
      { asset: '1 Month Ad Rights', min: floorTo50(0.3 * minReelRate), max: ceilTo50(0.3 * maxReelRate), pricing_logic: '0.3× Reel' },
    ];

    return { avgViews, viewFollowerRatio, nicheCpv, qualityMultiplier, baseRate, minReelRate, maxReelRate, assets };
  }, [followers, views, niche]);

  const hasInputs = followers > 0 && reelsEntered > 0;

  const handleReset = () => {
    setCreatorName(DEFAULT_CREATOR_NAME);
    setInstagramHandle(DEFAULT_INSTAGRAM_HANDLE);
    setPhone(DEFAULT_PHONE);
    setNotes('');
    setFollowerCount('');
    setReelViews(Array(REEL_COUNT).fill(''));
    setNiche(NICHE_OPTIONS[0].value);
  };

  // ---- Reel views entry helpers ----
  // Filling in 10 values one field at a time is tedious, so a paste into
  // any Reel field that contains more than one number (a column copied
  // from Instagram Insights, Notes, or a spreadsheet) fans out across the
  // remaining fields starting at that box, instead of dumping everything
  // into one input.
  const fillReelViewsFrom = (startIndex: number, parsed: number[]) => {
    if (parsed.length === 0) return;
    setReelViews(prev => {
      const next = [...prev];
      parsed.forEach((val, offset) => {
        const target = startIndex + offset;
        if (target < REEL_COUNT) next[target] = String(val);
      });
      return next;
    });
    const focusIndex = Math.min(startIndex + parsed.length, REEL_COUNT - 1);
    requestAnimationFrame(() => reelInputRefs.current[focusIndex]?.focus());
  };

  const handleReelPaste = (e: React.ClipboardEvent<HTMLInputElement>, index: number) => {
    const parsed = extractViewNumbers(e.clipboardData.getData('text'));
    if (parsed.length === 0) return; // let the browser handle a plain/empty paste as usual
    e.preventDefault();
    fillReelViewsFrom(index, parsed);
  };

  // Spreadsheet-style keyboard navigation between the 10 boxes: Enter (or
  // the mobile keyboard's "Next"/"Go" action) moves to the next Reel,
  // Up/Down jumps a row (5 columns on desktop) so the whole set can be
  // filled without reaching for the mouse.
  const handleReelKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (index + 1 < REEL_COUNT) reelInputRefs.current[index + 1]?.focus();
      else e.currentTarget.blur();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      reelInputRefs.current[Math.min(index + 5, REEL_COUNT - 1)]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      reelInputRefs.current[Math.max(index - 5, 0)]?.focus();
    }
  };

  // One-tap fill for the whole set: read the clipboard directly (no click
  // into a specific box needed) and distribute every number found, in
  // order, into Reels 1–10.
  const handlePasteAllViews = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const parsed = extractViewNumbers(text);
      if (parsed.length === 0) {
        await alert("Couldn't find any numbers on your clipboard. Copy the 10 view counts first, then try again.");
        return;
      }
      fillReelViewsFrom(0, parsed);
    } catch (err) {
      console.error(err);
      await alert("Couldn't read your clipboard — paste directly into a Reel field instead.");
    }
  };

  // ---- Save ----
  const [saving, setSaving] = useState(false);
  const handleSave = async () => {
    if (!hasInputs) return;
    setSaving(true);
    try {
      const saved = await saveCreatorRateCalculation({
        creator_name: creatorName.trim() || null,
        instagram_handle: instagramHandle.trim() || null,
        phone: phone.trim() || null,
        follower_count: followers,
        reel_views: views,
        niche,
        avg_views: result.avgViews,
        view_follower_ratio: result.viewFollowerRatio,
        niche_cpv: result.nicheCpv,
        quality_multiplier: result.qualityMultiplier,
        base_rate: result.baseRate,
        min_reel_rate: result.minReelRate,
        max_reel_rate: result.maxReelRate,
        final_commercials: result.assets,
        notes: notes.trim() || null,
      });
      setHistory(prev => [saved, ...prev]);
      await alert({ message: 'Calculation saved.', variant: 'success' });
    } catch (err) {
      console.error(err);
      await alert("Couldn't save this calculation. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  // ---- History ----
  const [history, setHistory] = useState<CreatorRateCalculation[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(() => readSessionString(HISTORY_EXPANDED_ID_KEY));
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  // Row header buttons, keyed by calculation id — so that opening a card
  // (see effect below) can scroll its header up into view. Without this,
  // expanding a row near the bottom of a long history list just grows the
  // page below the fold and the admin has to go hunting for what they just
  // opened.
  const historyRowRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const cleanupScrollRef = useRef<(() => void) | null>(null);
  // Set true only inside an actual row-toggle click/keydown, and consumed
  // (reset to false) the moment the scroll-into-view effect below acts on
  // it. This is what stops that effect from also firing when expandedId is
  // restored from sessionStorage on mount (see HISTORY_EXPANDED_ID_KEY) —
  // a restore isn't a fresh click, and the page's own scroll-position
  // restoration (useScrollRestoration, wired up via AdminLayout above)
  // already puts the admin back exactly where they left off, using the
  // real saved scrollY rather than a recomputed element position. Letting
  // both systems try to move the scroll on the same mount raced against
  // each other and could visibly override one with the other.
  const rowUserToggledRef = useRef(false);
  // Whole-section collapse — same pattern as the Message Template card
  // below (collapsed by default, click the header to expand) instead of
  // this list always taking up space on the page.
  const [historyExpanded, setHistoryExpanded] = useState(() => readSessionFlag(HISTORY_EXPANDED_KEY));
  const historyHeaderRef = useRef<HTMLDivElement | null>(null);
  const historySectionScrollCleanupRef = useRef<(() => void) | null>(null);
  // Same purpose as rowUserToggledRef above, for the card's own header.
  const historyUserToggledRef = useRef(false);

  // Whenever a saved calculation is expanded, bring its header up so the
  // newly-revealed details are actually visible instead of the row sitting
  // wherever it happened to be in a long list. The button being scrolled
  // sits above its own expanding body, so its on-screen position doesn't
  // shift as that body grows — meaning we don't need to wait for the
  // 0.2s expand animation to finish, just for this render's DOM update to
  // land (one rAF). That lets the scroll and the expand happen together
  // as one smooth motion instead of expand-then-jump.
  useEffect(() => {
    if (!expandedId) return;
    if (!rowUserToggledRef.current) return;
    rowUserToggledRef.current = false;
    const frame = requestAnimationFrame(() => {
      const el = historyRowRefs.current[expandedId];
      if (!el) return;
      cleanupScrollRef.current = scrollElementIntoView(el, STICKY_HEADER_SCROLL_OFFSET);
    });
    return () => {
      cancelAnimationFrame(frame);
      cleanupScrollRef.current?.();
    };
  }, [expandedId]);

  // Persist which row (if any) is expanded, so navigating to another admin
  // page and back mid-visit restores it — see HISTORY_EXPANDED_ID_KEY above.
  useEffect(() => {
    try {
      if (expandedId) sessionStorage.setItem(HISTORY_EXPANDED_ID_KEY, expandedId);
      else sessionStorage.removeItem(HISTORY_EXPANDED_ID_KEY);
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — fine to skip.
    }
  }, [expandedId]);

  useEffect(() => {
    (async () => {
      try {
        const rows = await getCreatorRateCalculations();
        setHistory(rows);
      } catch (err) {
        console.error(err);
      } finally {
        setHistoryLoading(false);
      }
    })();
  }, []);

  // Same as Message Template below: the header sits above its own
  // expanding body so its position doesn't shift as that body grows —
  // scroll and expand can run together as one smooth motion.
  useEffect(() => {
    if (!historyExpanded) return;
    if (!historyUserToggledRef.current) return;
    historyUserToggledRef.current = false;
    const frame = requestAnimationFrame(() => {
      const el = historyHeaderRef.current;
      if (!el) return;
      historySectionScrollCleanupRef.current = scrollElementIntoView(el, STICKY_HEADER_SCROLL_OFFSET);
    });
    return () => {
      cancelAnimationFrame(frame);
      historySectionScrollCleanupRef.current?.();
    };
  }, [historyExpanded]);

  // Persist the Saved Calculations card's own open/closed state the same
  // way as the row above.
  useEffect(() => {
    try {
      if (historyExpanded) sessionStorage.setItem(HISTORY_EXPANDED_KEY, '1');
      else sessionStorage.removeItem(HISTORY_EXPANDED_KEY);
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — fine to skip.
    }
  }, [historyExpanded]);

  // ---- Message template variants (site_content row, shared across every
  // admin — see RATE_MESSAGE_TEMPLATE_KEY above). Starts at the factory
  // default variant and is swapped for whatever's saved in the DB as soon
  // as that loads, so the very first render (before the fetch resolves)
  // still has a sensible default to work from. Edited directly in the
  // "Message Template" box above the saved-calculations list — Copy/Share
  // on each saved row render from whichever variant is marked default,
  // unless overridden per row. ----
  const [templateVariants, setTemplateVariants] = useState<MessageTemplateVariant[]>(DEFAULT_MESSAGE_TEMPLATE_VARIANTS);
  const [defaultVariantId, setDefaultVariantId] = useState<string>(DEFAULT_VARIANT_ID);
  const [templateExpanded, setTemplateExpanded] = useState(() => readSessionFlag(TEMPLATE_EXPANDED_KEY));
  const [templateEditing, setTemplateEditing] = useState(false);
  const [templateSaving, setTemplateSaving] = useState(false);
  const [templateSaved, setTemplateSaved] = useState(false);
  const templateTextareaRefs = useRef<Record<string, HTMLTextAreaElement | null>>({});
  const templateHeaderRef = useRef<HTMLDivElement | null>(null);
  const templateScrollCleanupRef = useRef<(() => void) | null>(null);
  // Same purpose as rowUserToggledRef/historyUserToggledRef above — only
  // scroll-into-view on an actual click, not when templateExpanded is
  // restored from sessionStorage on mount (the page's own scrollY
  // restoration already handles that case).
  const templateUserToggledRef = useRef(false);

  // Same as the Saved Calculations rows above: the header sits above its
  // own expanding body so its position doesn't shift as that body grows —
  // scroll and expand can run together as one smooth motion instead of
  // waiting for the animation to finish first.
  useEffect(() => {
    if (!templateExpanded) return;
    if (!templateUserToggledRef.current) return;
    templateUserToggledRef.current = false;
    const frame = requestAnimationFrame(() => {
      const el = templateHeaderRef.current;
      if (!el) return;
      templateScrollCleanupRef.current = scrollElementIntoView(el, STICKY_HEADER_SCROLL_OFFSET);
    });
    return () => {
      cancelAnimationFrame(frame);
      templateScrollCleanupRef.current?.();
    };
  }, [templateExpanded]);

  // Persist the Message Template card's open/closed state — same as Saved
  // Calculations above: restored mid-visit when navigating back to this
  // page, but not remembered permanently (sessionStorage, not localStorage)
  // so it still starts collapsed on a fresh tab/next day.
  useEffect(() => {
    try {
      if (templateExpanded) sessionStorage.setItem(TEMPLATE_EXPANDED_KEY, '1');
      else sessionStorage.removeItem(TEMPLATE_EXPANDED_KEY);
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — fine to skip.
    }
  }, [templateExpanded]);

  // ---- Formatting toolbar (Bold / Italic / Strikethrough / Monospace) ----
  // The template ends up as a plain-text WhatsApp message (via Copy or
  // Share) — there's no rich-text renderer on the receiving end, so real
  // bold/italic/colour/table formatting can't actually be sent. WhatsApp
  // does understand its own lightweight markup though (*bold*, _italic_,
  // ~strikethrough~, and ```monospace```), and does render it, so these
  // buttons wrap the current selection in that markup instead. Clicking
  // again on an already-wrapped selection unwraps it (toggle).
  const applyTemplateFormat = (variantId: string, marker: string) => {
    const el = templateTextareaRefs.current[variantId];
    if (!el) return;
    const { selectionStart, selectionEnd, value } = el;
    const selected = value.slice(selectionStart, selectionEnd);
    const before = value.slice(0, selectionStart);
    const after = value.slice(selectionEnd);
    const alreadyWrapped = before.endsWith(marker) && after.startsWith(marker);

    let next: string;
    let newStart: number;
    let newEnd: number;
    if (alreadyWrapped) {
      next = before.slice(0, -marker.length) + selected + after.slice(marker.length);
      newStart = selectionStart - marker.length;
      newEnd = selectionEnd - marker.length;
    } else {
      const content = selected || 'text';
      next = `${before}${marker}${content}${marker}${after}`;
      newStart = selectionStart + marker.length;
      newEnd = newStart + content.length;
    }

    updateVariant(variantId, { template: next });
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(newStart, newEnd);
    });
  };

  // ---- Variant list helpers (add / remove / reorder / rename / edit —
  // same shape as CancellationPolicyEditor's refund tiers). At least one
  // variant must always remain, since Copy/Share need something to fall
  // back to. ----
  const updateVariant = (variantId: string, patch: Partial<MessageTemplateVariant>) => {
    setTemplateVariants(prev => prev.map(v => (v.id === variantId ? { ...v, ...patch } : v)));
  };

  const addVariant = () => {
    const id = crypto.randomUUID();
    setTemplateVariants(prev => [...prev, { id, name: `Variant ${prev.length + 1}`, template: DEFAULT_MESSAGE_TEMPLATE }]);
  };

  const removeVariant = (variantId: string) => {
    setTemplateVariants(prev => {
      if (prev.length <= 1) return prev;
      const next = prev.filter(v => v.id !== variantId);
      if (defaultVariantId === variantId) setDefaultVariantId(next[0].id);
      return next;
    });
  };

  const moveVariant = (index: number, dir: -1 | 1) => {
    setTemplateVariants(prev => {
      const target = index + dir;
      if (target < 0 || target >= prev.length) return prev;
      const copy = [...prev];
      [copy[index], copy[target]] = [copy[target], copy[index]];
      return copy;
    });
  };

  useEffect(() => {
    (async () => {
      try {
        const content = await getSiteContent<CreatorRateMessageTemplateContent>(RATE_MESSAGE_TEMPLATE_KEY);
        if (content?.variants?.length) {
          setTemplateVariants(content.variants);
          setDefaultVariantId(content.variants.some(v => v.id === content.defaultVariantId) ? content.defaultVariantId : content.variants[0].id);
        } else if (content?.template) {
          // Pre-variants shape — migrate the single saved template into one "Default" variant.
          setTemplateVariants([{ id: DEFAULT_VARIANT_ID, name: 'Default', template: content.template }]);
          setDefaultVariantId(DEFAULT_VARIANT_ID);
        }
      } catch (err) {
        console.error(err);
      }
    })();
  }, []);

  // ---- Preview: shows a variant fully filled in, in a popup, so an admin
  // can check the wording actually reads right before saving it. Uses
  // whatever's currently entered in the calculator above (creator name,
  // niche, follower count, computed Final Commercials) when there's enough
  // to work with, otherwise falls back to sample figures so the popup never
  // shows blank tokens. ----
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewVariantId, setPreviewVariantId] = useState<string | null>(null);
  const previewMessage = useMemo(() => {
    const template = templateVariants.find(v => v.id === previewVariantId)?.template ?? templateVariants[0]?.template ?? '';
    const source: MessageTemplateSource = hasInputs
      ? { creator_name: creatorName.trim() || null, niche, follower_count: followers, final_commercials: result.assets }
      : { creator_name: creatorName.trim() || DEFAULT_CREATOR_NAME, niche, follower_count: 10100, final_commercials: PREVIEW_SAMPLE_ASSETS };
    return renderMessageTemplate(template, source);
  }, [templateVariants, previewVariantId, hasInputs, creatorName, niche, followers, result.assets]);

  const handleSaveMessageTemplate = async () => {
    setTemplateSaving(true);
    try {
      await upsertSiteContent(RATE_MESSAGE_TEMPLATE_KEY, { variants: templateVariants, defaultVariantId } satisfies CreatorRateMessageTemplateContent);
      setTemplateSaved(true);
      setTemplateEditing(false);
      window.setTimeout(() => setTemplateSaved(false), 2000);
    } catch (err) {
      console.error(err);
      await alert("Couldn't save the message template. Please try again.");
    } finally {
      setTemplateSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    const ok = await confirm({ message: 'Delete this saved calculation? This cannot be undone.', variant: 'danger' });
    if (!ok) return;
    setDeletingId(id);
    try {
      await deleteCreatorRateCalculation(id);
      setHistory(prev => prev.filter(h => h.id !== id));
      if (expandedId === id) setExpandedId(null);
    } catch (err) {
      console.error(err);
      await alert("Couldn't delete this calculation. Please try again.");
    } finally {
      setDeletingId(null);
    }
  };

  // ---- Per-row variant override: which variant Copy/Share use for a given
  // saved row, if the admin picked one from that row's variant picker
  // instead of leaving it on the default. Only shown when there's more
  // than one variant to choose from. ----
  const [rowVariantId, setRowVariantId] = useState<Record<string, string>>({});
  const variantForRow = (h: CreatorRateCalculation): MessageTemplateVariant =>
    templateVariants.find(v => v.id === (rowVariantId[h.id] ?? defaultVariantId)) ?? templateVariants[0];

  // ---- Send to creator: Copy (works with any app) + Share (opens
  // WhatsApp pre-filled to the creator's saved number, since that's how
  // these quotes are actually sent out). Both render from this row's
  // chosen variant (default unless overridden above), filled in with this
  // row's own values. ----
  const handleCopyCalculation = async (h: CreatorRateCalculation) => {
    try {
      await navigator.clipboard.writeText(renderMessageTemplate(variantForRow(h).template, h));
      setCopiedId(h.id);
      window.setTimeout(() => setCopiedId(prev => (prev === h.id ? null : prev)), 2000);
    } catch (err) {
      console.error(err);
      await alert("Couldn't copy to clipboard. Please try again.");
    }
  };

  const handleShareCalculation = async (h: CreatorRateCalculation) => {
    const message = renderMessageTemplate(variantForRow(h).template, h);
    if (h.phone) {
      window.open(getWhatsAppLink(h.phone, message), '_blank', 'noopener,noreferrer');
      return;
    }
    if (navigator.share) {
      try {
        await navigator.share({ text: message });
      } catch {
        // user cancelled the share sheet — nothing to do
      }
      return;
    }
    // No saved phone and no native share sheet — fall back to copying.
    await handleCopyCalculation(h);
    await alert('No phone number saved for this creator, so the message was copied instead — paste it into WhatsApp, Instagram DM, or email.');
  };

  return (
    <AdminLayout title="Creator Rate Calculator" subtitle="Work out a fair commercial rate from a creator's followers, average views, and niche" scrollRestorationReady={!historyLoading}>
      <div className="space-y-6 max-w-5xl">
        {/* ---- Inputs ---- */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
          <div className="flex items-center justify-between gap-3 mb-4">
            <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                <Users size={15} className="text-primary" aria-hidden="true" />
              </span>
              Inputs
            </h3>
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-dark-muted hover:text-primary transition-colors"
            >
              <RotateCcw size={13} aria-hidden="true" /> Reset
            </button>
          </div>

          <p className="text-xs text-dark-muted mb-4 inline-flex items-start gap-1.5">
            <Info size={14} className="text-primary shrink-0 mt-0.5" aria-hidden="true" />
            Enter the creator's follower count, average views for their last 10 Reels, and select their niche.
          </p>

          {/* Optional identity — not part of the original spreadsheet, but
              needed to make a saved row identifiable later. */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4 mb-5 pb-5 border-b border-background-warm">
            <div>
              <label htmlFor="cr-name" className="block text-sm font-medium text-dark mb-1">Creator Name</label>
              <input
                id="cr-name"
                type="text"
                value={creatorName}
                onChange={e => setCreatorName(e.target.value)}
                className={inputClass}
                placeholder="e.g. Priya Sharma"
              />
            </div>
            <div>
              <label htmlFor="cr-handle" className="block text-sm font-medium text-dark mb-1">Instagram Handle</label>
              <input
                id="cr-handle"
                type="text"
                value={instagramHandle}
                onChange={e => setInstagramHandle(e.target.value)}
                className={inputClass}
                placeholder="e.g. @priya.travels"
              />
            </div>
            <div>
              <label htmlFor="cr-phone" className="block text-sm font-medium text-dark mb-1">Phone</label>
              <input
                id="cr-phone"
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className={inputClass}
                placeholder="e.g. 98765 43210"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-5">
            <div>
              <label htmlFor="cr-followers" className="block text-sm font-medium text-dark mb-1">Follower Count *</label>
              <input
                id="cr-followers"
                type="number"
                min={0}
                inputMode="numeric"
                value={followerCount}
                onChange={e => setFollowerCount(e.target.value)}
                className={inputClass}
                placeholder="e.g. 15000"
              />
            </div>
            <div>
              <label htmlFor="cr-niche" className="block text-sm font-medium text-dark mb-1">Niche *</label>
              <Select
                inputId="cr-niche"
                value={niche}
                onChange={setNiche}
                options={NICHE_OPTIONS}
                placeholder="Select niche..."
              />
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 mb-2">
            <p className="text-sm font-medium text-dark">Average Views — Last 10 Reels *</p>
            <button
              type="button"
              onClick={handlePasteAllViews}
              className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-primary hover:text-primary-dark transition-colors shrink-0"
            >
              <ClipboardText size={14} aria-hidden="true" /> Paste all 10
            </button>
          </div>
          <p className="text-2xs text-dark-muted mb-2">
            Tip: copy the 10 view counts (one per line, from Insights or a spreadsheet) and hit "Paste all 10", or paste into any box below and press Enter to move to the next.
          </p>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mb-5">
            {reelViews.map((val, i) => (
              <div key={i}>
                <label htmlFor={`cr-reel-${i}`} className="block text-2xs text-dark-muted mb-1">Reel {i + 1}</label>
                <input
                  id={`cr-reel-${i}`}
                  ref={el => { reelInputRefs.current[i] = el; }}
                  type="number"
                  min={0}
                  inputMode="numeric"
                  enterKeyHint={i + 1 < REEL_COUNT ? 'next' : 'done'}
                  value={val}
                  onChange={e => {
                    const next = [...reelViews];
                    next[i] = e.target.value;
                    setReelViews(next);
                  }}
                  onPaste={e => handleReelPaste(e, i)}
                  onKeyDown={e => handleReelKeyDown(e, i)}
                  className={inputClass}
                  placeholder="0"
                />
              </div>
            ))}
          </div>

          <div>
            <label htmlFor="cr-notes" className="block text-sm font-medium text-dark mb-1">Notes</label>
            <textarea
              id="cr-notes"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className={inputClass}
              rows={2}
              placeholder="Optional — context for this quote, negotiation notes, etc."
            />
          </div>
        </motion.div>

        {!hasInputs ? (
          <div className="bg-white rounded-lg shadow-card p-8 text-center text-dark-muted text-sm">
            Enter a follower count and at least one Reel's average views to see the calculated rate.
          </div>
        ) : (
          <>
            {/* ---- Calculation ---- */}
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
              <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2 mb-3">
                <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                  <ChartLineUp size={15} className="text-primary" aria-hidden="true" />
                </span>
                Calculation
              </h3>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <CalcCard label="Average Views (10 Reels)" value={Math.round(result.avgViews).toLocaleString('en-IN')} icon={Eye} />
                <CalcCard label="View / Follower Ratio" value={`${Math.round(result.viewFollowerRatio * 100)}%`} icon={ChartLineUp} />
                <CalcCard label="Niche CPV Benchmark" value={formatPrice(result.nicheCpv)} icon={Target} />
                <CalcCard label="View Quality Multiplier" value={`${result.qualityMultiplier}x`} icon={Calculator} />
              </div>
            </motion.div>

            {/* ---- Suggested range ---- */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-primary/5 border-2 border-primary/20 rounded-lg p-5 sm:p-6 text-center"
            >
              <p className="text-2xs font-button font-bold text-primary uppercase tracking-wide mb-1.5">
                Suggested 1-Reel Commercial Range
              </p>
              <p className="font-display text-2xl sm:text-3xl font-bold text-dark">
                {formatPrice(Math.round(result.minReelRate))} – {formatPrice(Math.round(result.maxReelRate))}
              </p>
              <p className="text-xs text-dark-muted mt-2">
                Calculated base rate: {formatPrice(Math.round(result.baseRate))} (Follower Count × Niche CPV Benchmark)
              </p>
            </motion.div>

            {/* ---- Final commercials table ---- */}
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
              <div className="flex items-center justify-between gap-3 mb-3">
                <h3 className="font-display text-base sm:text-lg font-bold text-dark">Final Commercials</h3>
                <Button variant="primary" size="sm" onClick={handleSave} loading={saving}>
                  <Save size={15} aria-hidden="true" /> Save Calculation
                </Button>
              </div>
              <div className="bg-white rounded-lg shadow-card overflow-hidden overflow-x-auto">
                <table className="w-full text-sm min-w-[520px]">
                  <thead>
                    <tr className="border-b border-background-warm text-left">
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">Asset</th>
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Minimum</th>
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Maximum</th>
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">Pricing Logic</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.assets.map(row => (
                      <tr key={row.asset} className="border-b border-background-warm last:border-0 hover:bg-background-warm/30">
                        <td className="px-4 py-2.5 text-dark font-medium">{row.asset}</td>
                        <td className="px-4 py-2.5 text-dark-muted text-right whitespace-nowrap">{formatPrice(row.min)}</td>
                        <td className="px-4 py-2.5 text-dark font-semibold text-right whitespace-nowrap">{formatPrice(row.max)}</td>
                        <td className="px-4 py-2.5 text-dark-muted text-xs">{row.pricing_logic}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-dark-muted mt-3 italic">
                💡 Negotiation Tip: these prices are suggested benchmark rates. Quote higher than these to leave room for negotiation and arrive at your desired final commercial.
              </p>
            </motion.div>
          </>
        )}

        {/* ---- Message template — edited here, not per saved calculation.
              Copy/Share on every row below (new or old) always sends
              whatever's currently saved here. Collapsed by default (same
              pattern as the Saved Calculations rows below) since this is a
              tweak-it-occasionally tool, not something needed on every
              visit to the page. ---- */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
          <div
            ref={templateHeaderRef}
            role="button"
            tabIndex={0}
            onClick={() => {
              templateUserToggledRef.current = true;
              setTemplateExpanded(v => {
                if (v) setTemplateEditing(false);
                return !v;
              });
            }}
            onKeyDown={e => {
              if (e.key !== 'Enter' && e.key !== ' ') return;
              e.preventDefault();
              templateUserToggledRef.current = true;
              setTemplateExpanded(v => {
                if (v) setTemplateEditing(false);
                return !v;
              });
            }}
            aria-expanded={templateExpanded}
            className="w-full flex items-center justify-between gap-3 text-left cursor-pointer select-none"
          >
            <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                <TemplateIcon size={15} className="text-primary" aria-hidden="true" />
              </span>
              Message Template
            </h3>
            <div className="flex items-center gap-1 shrink-0">
              {templateExpanded && (
                <button
                  type="button"
                  onClick={e => { e.stopPropagation(); setTemplateEditing(v => !v); }}
                  aria-pressed={templateEditing}
                  title={templateEditing ? 'Done editing' : 'Edit variants'}
                  aria-label={templateEditing ? 'Done editing' : 'Edit variants'}
                  className={`inline-flex items-center justify-center w-8 h-8 rounded-md border transition-colors ${
                    templateEditing
                      ? 'bg-primary/10 border-primary/30 text-primary'
                      : 'border-transparent text-dark-muted hover:text-primary hover:bg-primary/5'
                  }`}
                >
                  <EditIcon size={15} aria-hidden="true" />
                </button>
              )}
              {templateExpanded ? <ChevronUp size={18} className="text-dark-muted shrink-0" aria-hidden="true" /> : <ChevronDown size={18} className="text-dark-muted shrink-0" aria-hidden="true" />}
            </div>
          </div>

          <AnimatePresence initial={false}>
            {templateExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="pt-3">
                  <div className="flex items-center justify-between mb-2 gap-3">
                    <span className="text-xs font-button font-bold text-dark-muted">Variants</span>
                    {templateEditing && (
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => {
                            setTemplateVariants(DEFAULT_MESSAGE_TEMPLATE_VARIANTS);
                            setDefaultVariantId(DEFAULT_VARIANT_ID);
                          }}
                          className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-dark-muted hover:text-primary transition-colors"
                        >
                          <RotateCcw size={13} aria-hidden="true" /> Reset to original wording
                        </button>
                        <button
                          type="button"
                          onClick={addVariant}
                          className="inline-flex items-center gap-1 text-xs font-button font-semibold text-primary hover:text-primary/80 transition-colors"
                        >
                          <Plus size={14} aria-hidden="true" /> Add Variant
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 mb-3">
                    {templateVariants.map((variant, index) => (
                      <div key={variant.id} className="bg-background-warm rounded-lg p-3 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            {variant.id === defaultVariantId ? (
                              <span
                                title="Default variant — used for Copy/Share unless overridden per row"
                                aria-label="Default variant"
                                className="inline-flex items-center justify-center text-primary shrink-0"
                              >
                                <Star size={13} weight="fill" aria-hidden="true" />
                              </span>
                            ) : templateEditing ? (
                              <button
                                type="button"
                                onClick={() => setDefaultVariantId(variant.id)}
                                title="Set as default"
                                aria-label={`Set "${variant.name}" as the default variant`}
                                className="inline-flex items-center justify-center text-dark-muted hover:text-primary transition-colors shrink-0"
                              >
                                <Star size={13} aria-hidden="true" />
                              </button>
                            ) : null}
                            <label htmlFor={`cr-template-name-${variant.id}`} className="sr-only">Variant name</label>
                            <input
                              id={`cr-template-name-${variant.id}`}
                              value={variant.name}
                              onChange={e => updateVariant(variant.id, { name: e.target.value })}
                              readOnly={!templateEditing}
                              className={`flex-1 min-w-0 bg-transparent text-xs font-button font-bold text-dark border-0 focus:outline-none focus:ring-0 px-0 ${!templateEditing ? 'cursor-default' : ''}`}
                            />
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => { setPreviewVariantId(variant.id); setPreviewOpen(true); }}
                              title="Preview"
                              aria-label={`Preview "${variant.name}"`}
                              className="p-1 rounded-md hover:bg-white text-dark-muted hover:text-primary transition-colors"
                            >
                              <Eye size={14} aria-hidden="true" />
                            </button>
                            {templateEditing && (
                              <>
                                <button type="button" onClick={() => moveVariant(index, -1)} disabled={index === 0} className="p-1 rounded-md hover:bg-white disabled:opacity-30 text-dark-muted transition-colors" title="Move up" aria-label={`Move "${variant.name}" up`}>
                                  <ChevronUp size={14} aria-hidden="true" />
                                </button>
                                <button type="button" onClick={() => moveVariant(index, 1)} disabled={index === templateVariants.length - 1} className="p-1 rounded-md hover:bg-white disabled:opacity-30 text-dark-muted transition-colors" title="Move down" aria-label={`Move "${variant.name}" down`}>
                                  <ChevronDown size={14} aria-hidden="true" />
                                </button>
                                <button type="button" onClick={() => removeVariant(variant.id)} disabled={templateVariants.length <= 1} className="p-1 rounded-md hover:bg-red-50 disabled:opacity-30 disabled:hover:bg-transparent text-dark-muted hover:text-red-600 transition-colors" title="Remove variant" aria-label={`Remove "${variant.name}"`}>
                                  <X size={14} aria-hidden="true" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                        {templateEditing && (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '*')}
                              title="Bold"
                              aria-label="Bold"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <BoldIcon size={15} weight="bold" aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '_')}
                              title="Italic"
                              aria-label="Italic"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <ItalicIcon size={15} aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '~')}
                              title="Strikethrough"
                              aria-label="Strikethrough"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <StrikethroughIcon size={15} aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '```')}
                              title="Monospace"
                              aria-label="Monospace"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <MonospaceIcon size={15} aria-hidden="true" />
                            </button>
                          </div>
                        )}
                        <label htmlFor={`cr-template-body-${variant.id}`} className="sr-only">{`Message body for "${variant.name}"`}</label>
                        <textarea
                          id={`cr-template-body-${variant.id}`}
                          ref={el => { templateTextareaRefs.current[variant.id] = el; }}
                          value={variant.template}
                          onChange={e => updateVariant(variant.id, { template: e.target.value })}
                          readOnly={!templateEditing}
                          rows={8}
                          className={`${inputClass} font-mono text-xs resize-y ${!templateEditing ? 'bg-white/60 cursor-default' : 'bg-white'}`}
                          placeholder="Message template..."
                        />
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3">
                    <Button variant="outline" size="sm" fullWidth onClick={() => { setPreviewVariantId(defaultVariantId); setPreviewOpen(true); }}>
                      <Eye size={15} aria-hidden="true" /> Preview
                    </Button>
                    <Button variant="primary" size="sm" fullWidth onClick={handleSaveMessageTemplate} loading={templateSaving}>
                      {templateSaved ? <Check size={15} weight="bold" aria-hidden="true" /> : <Save size={15} aria-hidden="true" />}
                      {templateSaved ? 'Saved' : 'Save'}
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* ---- Template preview popup — read-only, shows exactly what
              Copy/Share would send right now, filled in with either the
              live calculator inputs above or sample figures. ---- */}
        <Modal
          isOpen={previewOpen}
          onClose={() => setPreviewOpen(false)}
          title={(() => {
            const name = templateVariants.find(v => v.id === previewVariantId)?.name;
            return name ? `Preview — ${name}` : 'Template Preview';
          })()}
          size="sm"
          footer={
            <div className="flex justify-end">
              <Button variant="primary" size="sm" onClick={() => setPreviewOpen(false)}>
                Close
              </Button>
            </div>
          }
        >
          <p className="text-xs text-dark-muted mb-3">
            {hasInputs
              ? 'This is how the message looks with the details currently entered above.'
              : `Enter a follower count and Reel views above to preview with a real calculation — showing sample figures for now.`}
          </p>
          <div className="bg-background-warm/40 border border-background-warm rounded-md p-4 whitespace-pre-wrap text-sm text-dark font-sans">
            {renderFormattedPreview(previewMessage)}
          </div>
        </Modal>

        {/* ---- Saved history — collapsed by default, same card/header
              pattern as Message Template above (click to expand, edit-style
              affordances live inside once open, header scrolls into view). ---- */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
          <div
            ref={historyHeaderRef}
            role="button"
            tabIndex={0}
            onClick={() => { historyUserToggledRef.current = true; setHistoryExpanded(v => !v); }}
            onKeyDown={e => {
              if (e.key !== 'Enter' && e.key !== ' ') return;
              e.preventDefault();
              historyUserToggledRef.current = true;
              setHistoryExpanded(v => !v);
            }}
            aria-expanded={historyExpanded}
            className="w-full flex items-center justify-between gap-3 text-left cursor-pointer select-none"
          >
            <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                <History size={15} className="text-primary" aria-hidden="true" />
              </span>
              Saved Calculations
              {!historyLoading && history.length > 0 && (
                <span className="text-dark-muted font-normal text-sm">({history.length})</span>
              )}
            </h3>
            <div className="flex items-center gap-1 shrink-0">
              {historyExpanded ? <ChevronUp size={18} className="text-dark-muted shrink-0" aria-hidden="true" /> : <ChevronDown size={18} className="text-dark-muted shrink-0" aria-hidden="true" />}
            </div>
          </div>

          <AnimatePresence initial={false}>
            {historyExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="pt-3">
                  {historyLoading ? (
                    <div className="text-center text-dark-muted text-sm py-6">Loading…</div>
                  ) : history.length === 0 ? (
                    <div className="text-center text-dark-muted text-sm py-6">
                      No saved calculations yet — save one above to build a history you can look back on.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {history.map(h => {
                const isOpen = expandedId === h.id;
                return (
                  <div key={h.id} className="bg-background-warm rounded-lg overflow-hidden">
                    <button
                      type="button"
                      ref={el => { historyRowRefs.current[h.id] = el; }}
                      onClick={() => { rowUserToggledRef.current = true; setExpandedId(isOpen ? null : h.id); }}
                      aria-expanded={isOpen}
                      className="w-full flex items-center justify-between gap-3 p-4 text-left hover:bg-white/60 transition-colors"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-dark truncate">
                          {h.creator_name || h.instagram_handle || 'Unnamed creator'}
                          <span className="text-dark-muted font-normal"> &middot; {h.niche}</span>
                        </p>
                        <p className="text-xs text-dark-muted mt-0.5">
                          {h.follower_count.toLocaleString('en-IN')} followers &middot; {formatDate(h.created_at)}
                        </p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-sm font-semibold text-primary whitespace-nowrap">
                          {formatPrice(Math.round(h.min_reel_rate))} – {formatPrice(Math.round(h.max_reel_rate))}
                        </span>
                        {isOpen ? <ChevronUp size={16} className="text-dark-muted" aria-hidden="true" /> : <ChevronDown size={16} className="text-dark-muted" aria-hidden="true" />}
                      </div>
                    </button>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="mx-3 mb-3 p-3 rounded-md bg-white space-y-3">
                            {(h.instagram_handle || h.phone) && (
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-dark-muted">
                                {h.instagram_handle && (
                                  <span className="inline-flex items-center gap-1"><Instagram size={13} aria-hidden="true" /> {h.instagram_handle}</span>
                                )}
                                {h.phone && (
                                  <span className="inline-flex items-center gap-1"><Phone size={13} aria-hidden="true" /> {h.phone}</span>
                                )}
                              </div>
                            )}

                            <div className="overflow-x-auto">
                              <table className="w-full text-xs min-w-[480px]">
                                <thead>
                                  <tr className="border-b border-background-warm text-left">
                                    <th className="px-3 py-2 font-button font-bold text-dark-muted uppercase tracking-wide">Asset</th>
                                    <th className="px-3 py-2 font-button font-bold text-dark-muted uppercase tracking-wide text-right">Min</th>
                                    <th className="px-3 py-2 font-button font-bold text-dark-muted uppercase tracking-wide text-right">Max</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {h.final_commercials.map(row => (
                                    <tr key={row.asset} className="border-b border-background-warm last:border-0">
                                      <td className="px-3 py-1.5 text-dark">{row.asset}</td>
                                      <td className="px-3 py-1.5 text-dark-muted text-right whitespace-nowrap">{formatPrice(row.min)}</td>
                                      <td className="px-3 py-1.5 text-dark font-semibold text-right whitespace-nowrap">{formatPrice(row.max)}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>

                            {h.notes && <p className="text-xs text-dark-muted italic">"{h.notes}"</p>}

                            <div className="flex items-center justify-between gap-3 flex-wrap pt-3 mt-1 border-t border-background-warm">
                              <div className="flex items-center gap-2 flex-wrap">
                                {templateVariants.length > 1 && (
                                  <Select
                                    inputId={`cr-row-variant-${h.id}`}
                                    size="sm"
                                    value={rowVariantId[h.id] ?? defaultVariantId}
                                    onChange={val => setRowVariantId(prev => ({ ...prev, [h.id]: val }))}
                                    options={templateVariants.map(v => ({ value: v.id, label: v.name }))}
                                    className="w-36"
                                  />
                                )}
                                <button
                                  type="button"
                                  onClick={() => handleCopyCalculation(h)}
                                  className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-button font-semibold transition-colors ${
                                    copiedId === h.id
                                      ? 'bg-primary/20 border-primary/40 text-primary-dark'
                                      : 'bg-primary/10 border-primary/20 text-primary hover:bg-primary/20'
                                  }`}
                                >
                                  {copiedId === h.id ? (
                                    <Check size={14} weight="bold" aria-hidden="true" />
                                  ) : (
                                    <Copy size={14} weight="bold" aria-hidden="true" />
                                  )}
                                  {copiedId === h.id ? 'Copied' : 'Copy'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleShareCalculation(h)}
                                  className="inline-flex items-center gap-1.5 rounded-full border bg-secondary/10 border-secondary/25 text-secondary hover:bg-secondary/20 hover:border-secondary/40 px-3 py-1.5 text-xs font-button font-semibold transition-colors"
                                  title={h.phone ? `Share via WhatsApp to ${h.phone}` : 'Share'}
                                >
                                  <WhatsappLogo size={14} weight="fill" aria-hidden="true" /> Share
                                </button>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleDelete(h.id)}
                                disabled={deletingId === h.id}
                                className="inline-flex items-center gap-1.5 rounded-full border border-transparent hover:border-red-200 hover:bg-red-50 px-3 py-1.5 text-xs font-button font-semibold text-dark-muted hover:text-red-600 transition-colors disabled:opacity-50"
                              >
                                <Trash2 size={14} aria-hidden="true" /> Delete
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
                      })}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </AdminLayout>
  );
}

function CalcCard({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Eye }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow-card min-w-0">
      <div className="flex items-center gap-2.5">
        <span className="inline-flex items-center justify-center w-9 h-9 rounded-md bg-primary/10 shrink-0">
          <Icon size={18} className="text-primary" aria-hidden="true" />
        </span>
        <p className="font-display text-lg sm:text-xl font-bold text-dark leading-tight truncate">{value}</p>
      </div>
      <p className="text-dark-muted text-xs font-medium truncate mt-2">{label}</p>
    </div>
  );
}
