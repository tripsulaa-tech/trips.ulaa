import { useRef, useState } from 'react';
import {
  Plus,
  Trash as Trash2,
  ImageSquare as ImagePlus,
  CircleNotch as Loader2,
  CaretUp as ChevronUp,
  CaretDown as ChevronDown,
  Eye,
  EyeSlash as EyeOff,
  Images,
  DeviceMobile,
} from '@phosphor-icons/react';
import ImageUploadField from '../../components/ui/ImageUploadField';
import { uploadImage, deleteImageByUrl } from '../../services/api';
import { DEFAULT_HOME_HERO } from '../../constants/home-hero';
import type { HomeHeroContent, HomeHeroSlide } from '../../types/types-index';
import { FORM_INPUT_CLASS as inputClass } from '../../constants/formStyles';

const STORAGE_BUCKET = 'ulaa';

export default function HeroBannerSection({
  content,
  setContent,
  sectionRef,
}: {
  content: HomeHeroContent;
  setContent: React.Dispatch<React.SetStateAction<HomeHeroContent>>;
  sectionRef: (el: HTMLDivElement | null) => void;
}) {
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleAddPhotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    try {
      setUploading(true);
      const template = content.slides[content.slides.length - 1] ?? DEFAULT_HOME_HERO;
      const newSlides: HomeHeroSlide[] = [];
      for (const file of files) {
        const path = `home-hero/${Date.now()}-${file.name}`;
        const url = await uploadImage(STORAGE_BUCKET, file, path);
        newSlides.push({
          id: crypto.randomUUID(),
          image: url,
          mobile_image: '',
          active: true,
          heading_line1: template.heading_line1,
          heading_highlight: template.heading_highlight,
          heading_line2: template.heading_line2,
          subheading: template.subheading,
        });
      }
      setContent(c => ({ ...c, slides: [...c.slides, ...newSlides] }));
    } catch {
      alert('Failed to upload one or more photos. Please try again.');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const updateSlide = (id: string, patch: Partial<HomeHeroSlide>) => {
    setContent(c => ({ ...c, slides: c.slides.map(s => (s.id === id ? { ...s, ...patch } : s)) }));
  };

  const removeSlide = async (id: string) => {
    const slide = content.slides.find(s => s.id === id);
    setContent(c => ({ ...c, slides: c.slides.filter(s => s.id !== id) }));
    if (slide?.image.includes(`/${STORAGE_BUCKET}/`)) {
      deleteImageByUrl(STORAGE_BUCKET, slide.image).catch(() => {});
    }
  };

  const moveSlide = (id: string, direction: -1 | 1) => {
    setContent(c => {
      const arr = [...c.slides];
      const from = arr.findIndex(s => s.id === id);
      const to = from + direction;
      if (from === -1 || to < 0 || to >= arr.length) return c;
      [arr[from], arr[to]] = [arr[to], arr[from]];
      return { ...c, slides: arr };
    });
  };

  return (
    <div ref={sectionRef} data-section={1} className="scroll-mt-4 space-y-8">
      <div className="space-y-4">
        <h2 className="font-display text-lg font-bold text-dark pb-3 border-b border-background-warm">
          Carousel Settings
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label className="flex items-center gap-2 text-sm font-medium text-dark">
            <input
              type="checkbox"
              checked={content.autoplay}
              onChange={e => setContent(c => ({ ...c, autoplay: e.target.checked }))}
              className="w-4 h-4 accent-primary"
            />
            Auto-rotate slides
          </label>
          <div>
            <label htmlFor="home-hero-interval" className="block text-sm font-medium text-dark mb-1">Seconds between slides</label>
            <input
              id="home-hero-interval"
              type="number"
              min={2}
              max={30}
              value={content.interval_seconds}
              onChange={e => setContent(c => ({ ...c, interval_seconds: Math.max(2, Number(e.target.value) || 6) }))}
              disabled={!content.autoplay}
              className={`${inputClass} disabled:opacity-50`}
            />
          </div>
        </div>
        {content.slides.length === 0 && (
          <p className="text-xs text-dark-muted flex items-center gap-1.5 bg-background-warm/60 rounded-md px-3 py-2">
            <Images size={14} className="flex-shrink-0" aria-hidden="true" />
            No photos yet — the homepage will keep showing its original default hero image until you add some below.
          </p>
        )}
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-background-warm flex-wrap">
          <h2 className="font-display text-lg font-bold text-dark">
            Photos ({content.slides.length})
          </h2>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-1 text-xs font-medium text-primary border border-primary rounded-md px-2.5 py-1.5 hover:bg-primary/5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading ? <Loader2 size={13} className="animate-spin" aria-hidden="true" /> : <ImagePlus size={13} aria-hidden="true" />}
            {uploading ? 'Uploading...' : 'Add Photos'}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleAddPhotos}
            className="hidden"
          />
        </div>
        <p className="text-xs text-dark-muted -mt-2">
          Wide landscape, at least 1920×1080px. Slides play in the order below — use the arrows to reorder, and the eye icon to temporarily hide a photo without deleting it.
        </p>

        {content.slides.length === 0 ? (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="w-full flex flex-col items-center justify-center gap-2 py-12 rounded-lg border-2 border-dashed border-background-warm text-dark-muted hover:border-primary hover:text-primary transition-colors"
          >
            <Plus size={22} aria-hidden="true" />
            <span className="text-sm font-medium">Add your first banner photo</span>
          </button>
        ) : (
          <div className="space-y-4">
            {content.slides.map((slide, i) => (
              <div
                key={slide.id}
                className={`rounded-xl border-2 overflow-hidden transition-colors ${
                  slide.active ? 'border-background-warm bg-white' : 'border-background-warm bg-background-warm/50 opacity-70'
                }`}
              >
                {/* Header bar: number + status on the left, reorder/visibility/delete actions on the right.
                    Kept on its own full-width row (not squeezed next to the thumbnail) so it never wraps
                    awkwardly on narrow phone screens. */}
                <div className="flex items-center justify-between gap-2 px-3 py-2 bg-background-warm/40 border-b border-background-warm">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary text-white text-2xs font-bold flex-shrink-0">
                      {i + 1}
                    </span>
                    <span className="text-sm font-semibold text-dark whitespace-nowrap">Slide {i + 1}</span>
                    {!slide.active && (
                      <span className="text-2xs font-medium text-dark-muted bg-background-warm rounded-full px-2 py-0.5 whitespace-nowrap">
                        Hidden
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-0.5 rounded-full bg-white border border-background-warm p-0.5 flex-shrink-0">
                    <button
                      type="button"
                      onClick={() => moveSlide(slide.id, -1)}
                      disabled={i === 0}
                      title="Move up"
                      aria-label={`Move slide ${i + 1} up`}
                      className="p-1.5 rounded-full text-dark-muted hover:text-dark hover:bg-background-warm transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <ChevronUp size={15} aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveSlide(slide.id, 1)}
                      disabled={i === content.slides.length - 1}
                      title="Move down"
                      aria-label={`Move slide ${i + 1} down`}
                      className="p-1.5 rounded-full text-dark-muted hover:text-dark hover:bg-background-warm transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <ChevronDown size={15} aria-hidden="true" />
                    </button>
                    <span className="w-px h-4 bg-background-warm" aria-hidden="true" />
                    <button
                      type="button"
                      onClick={() => updateSlide(slide.id, { active: !slide.active })}
                      title={slide.active ? 'Hide from homepage' : 'Show on homepage'}
                      aria-label={slide.active ? `Hide slide ${i + 1} from homepage` : `Show slide ${i + 1} on homepage`}
                      aria-pressed={slide.active}
                      className="p-1.5 rounded-full text-dark-muted hover:text-dark hover:bg-background-warm transition-colors"
                    >
                      {slide.active ? <Eye size={15} aria-hidden="true" /> : <EyeOff size={15} aria-hidden="true" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => removeSlide(slide.id)}
                      title="Remove"
                      aria-label={`Remove slide ${i + 1}`}
                      className="p-1.5 rounded-full text-primary/70 hover:text-primary hover:bg-primary/5 transition-colors"
                    >
                      <Trash2 size={15} aria-hidden="true" />
                    </button>
                  </div>
                </div>

                {/* Body: image stacks above the fields on phones, and sits beside them from sm
                    upward — avoids the cramped side-by-side squeeze on small screens. */}
                <div className="p-3 sm:p-4 flex flex-col sm:flex-row gap-4">
                  <div className="sm:w-40 flex-shrink-0">
                    <ImageUploadField
                      label=""
                      value={slide.image}
                      onChange={url => updateSlide(slide.id, { image: url })}
                      bucket={STORAGE_BUCKET}
                      pathPrefix="home-hero"
                      aspectRatio="3/2"
                    />
                  </div>
                  <div className="flex-1 min-w-0 space-y-3">
                    <details className="group text-xs">
                      <summary className="flex items-center gap-1.5 cursor-pointer text-dark-muted hover:text-dark select-none list-none">
                        <span className="transition-transform group-open:rotate-90">▶</span>
                        <DeviceMobile size={13} className="flex-shrink-0" aria-hidden="true" />
                        Optional: different photo for phone screens
                      </summary>
                      <div className="mt-2 pl-4">
                        <ImageUploadField
                          label="Mobile Image"
                          value={slide.mobile_image}
                          onChange={url => updateSlide(slide.id, { mobile_image: url })}
                          bucket={STORAGE_BUCKET}
                          pathPrefix="home-hero-mobile"
                          hint="Tall portrait, at least 1080×1350px. Falls back to the main photo if left empty."
                        />
                      </div>
                    </details>

                    <details className="group text-xs" open>
                      <summary className="flex items-center gap-1.5 cursor-pointer text-dark-muted hover:text-dark select-none font-medium list-none">
                        <span className="transition-transform group-open:rotate-90">▶</span>
                        Headline text for this slide
                      </summary>
                      <div className="mt-2 pl-4 space-y-2">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <div>
                            <label htmlFor={`home-hero-heading-1-${slide.id}`} className="block text-2xs font-medium text-dark mb-1">Line 1</label>
                            <input
                              id={`home-hero-heading-1-${slide.id}`}
                              type="text"
                              value={slide.heading_line1}
                              onChange={e => updateSlide(slide.id, { heading_line1: e.target.value })}
                              className="w-full px-2.5 py-1.5 rounded-md border-2 border-background-warm bg-background font-body text-dark text-xs focus:border-primary outline-none transition-colors"
                            />
                          </div>
                          <div>
                            <label htmlFor={`home-hero-heading-highlight-${slide.id}`} className="block text-2xs font-medium text-dark mb-1">Highlighted word</label>
                            <input
                              id={`home-hero-heading-highlight-${slide.id}`}
                              type="text"
                              value={slide.heading_highlight}
                              onChange={e => updateSlide(slide.id, { heading_highlight: e.target.value })}
                              className="w-full px-2.5 py-1.5 rounded-md border-2 border-background-warm bg-background font-body text-dark text-xs focus:border-primary outline-none transition-colors"
                            />
                          </div>
                          <div>
                            <label htmlFor={`home-hero-heading-2-${slide.id}`} className="block text-2xs font-medium text-dark mb-1">Line 1 continued</label>
                            <input
                              id={`home-hero-heading-2-${slide.id}`}
                              type="text"
                              value={slide.heading_line2}
                              onChange={e => updateSlide(slide.id, { heading_line2: e.target.value })}
                              className="w-full px-2.5 py-1.5 rounded-md border-2 border-background-warm bg-background font-body text-dark text-xs focus:border-primary outline-none transition-colors"
                            />
                          </div>
                        </div>
                        <div>
                          <label htmlFor={`home-hero-subheading-${slide.id}`} className="block text-2xs font-medium text-dark mb-1">Supporting Text</label>
                          <p className="text-2xs text-dark-muted leading-snug mb-1">Paragraph shown below the heading.</p>
                          <textarea
                            id={`home-hero-subheading-${slide.id}`}
                            rows={2}
                            value={slide.subheading}
                            onChange={e => updateSlide(slide.id, { subheading: e.target.value })}
                            className="w-full px-2.5 py-1.5 rounded-md border-2 border-background-warm bg-background font-body text-dark text-xs focus:border-primary outline-none transition-colors resize-none"
                          />
                        </div>
                        <div>
                          <p className="text-2xs font-medium text-dark-muted uppercase tracking-wide mb-1.5">Live preview</p>
                          <div className="rounded-lg bg-dark px-4 py-4">
                            <p className="font-display text-base sm:text-lg font-bold leading-[1.15] text-white mb-1.5">
                              {slide.heading_line1}
                              <br />
                              <span className="text-secondary italic">{slide.heading_highlight}</span> {slide.heading_line2}
                            </p>
                            <p className="text-2xs text-white/85">{slide.subheading}</p>
                          </div>
                        </div>
                      </div>
                    </details>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
