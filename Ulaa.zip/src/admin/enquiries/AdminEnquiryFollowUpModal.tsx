// Both follow-up modals live in this one file, split out of
// AdminEnquiryDetail.tsx originally. Two different reminders, two
// different shapes, kept together because they're always touched
// together and it's one place to change either.
//
// AdminEnquiryFollowUpModal (default export) — the "Set Follow-up
// Reminder" date/time picker for a still-warm lead. Shared by both the
// Enquiries list (AdminEnquiries.tsx, where a row's target comes and
// goes as `followUpTarget`) and the enquiry's own CRM page
// (AdminEnquiryDetail.tsx, which already has `enquiry` in scope and
// just gates it behind its own `followUpOpen` boolean — same
// `target={someOpenFlag ? enquiry : null}` idiom that page already
// uses for the shared ContactOutcomeModal).
//
// BookingFollowUpModal (named export) — the post-booking counterpart
// (CRM spec section 8B) for reminders like a balance payment or
// passport chase that come with their own type and notes rather than
// a bare date. Same "discard unsaved changes?" protection as every
// other business-data modal (spec's Unsaved Changes Protection
// section) — nothing saves until Save is explicitly pressed.
import { useEffect, useMemo, useState } from 'react';
import Modal from '../../components/ui/Modal';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import DatePicker from '../../components/ui/DatePicker';
import TimePicker from '../../components/ui/TimePicker';
import { useConfirm } from '../../components/ui/useConfirm';
import { BOOKING_FOLLOW_UP_TYPE_CONFIG, availableBookingFollowUpTypes } from './AdminEnquiryCommon';
import type { BookingFollowUpType, Enquiry } from '../../types/types-index';
import { inputClass } from './AdminEnquiriesShared';

interface AdminEnquiryFollowUpModalProps {
  target: Enquiry | null;
  onClose: () => void;
  followUpDate: string;
  setFollowUpDate: (date: string) => void;
  followUpTime: string;
  setFollowUpTime: (time: string) => void;
  saving: boolean;
  onSave: () => void;
}

export default function AdminEnquiryFollowUpModal({
  target, onClose, followUpDate, setFollowUpDate, followUpTime, setFollowUpTime, saving, onSave,
}: AdminEnquiryFollowUpModalProps) {
  return (
    <Modal isOpen={!!target} onClose={onClose} title="Set Follow-up Reminder" size="sm">
      <div className="space-y-4">
        <p className="text-sm text-dark-muted">
          {target?.follow_up_at
            ? 'Update the date to check back in.'
            : "Lead is warm but not ready to close. Pick a date to check back. It shows as due that day and clears once the lead moves past Contacted."}
        </p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="ed-followup-date" className="block text-sm font-medium text-dark mb-1">Follow-up Date</label>
            <DatePicker id="ed-followup-date" value={followUpDate} onChange={setFollowUpDate} />
          </div>
          <div>
            <label htmlFor="ed-followup-time" className="block text-sm font-medium text-dark mb-1">Follow-up Time</label>
            <TimePicker id="ed-followup-time" value={followUpTime} onChange={setFollowUpTime} />
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <Button variant="outline" size="md" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button variant="primary" size="md" className="flex-1" onClick={onSave} disabled={!followUpDate || !followUpTime} loading={saving}>Save</Button>
        </div>
      </div>
    </Modal>
  );
}

export interface BookingFollowUpResult {
  at: string;
  time: string;
  type: BookingFollowUpType;
  notes: string;
}

export function BookingFollowUpModal({
  target,
  onClose,
  onSave,
  saving,
}: {
  target: Enquiry | null;
  onClose: () => void;
  onSave: (result: BookingFollowUpResult) => void | Promise<void>;
  saving: boolean;
}) {
  const confirm = useConfirm();
  const [type, setType] = useState<BookingFollowUpType>('other');
  const [at, setAt] = useState('');
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');

  // Which reminder types make sense for THIS booking right now — e.g.
  // Balance Payment Reminder drops off once the balance's cleared. If the
  // booking already has a reminder saved of a type that's since fallen out
  // of that set (set back when there was still a balance due, booking's
  // since gone fully_paid), keep showing it here so the dropdown reflects
  // what's actually saved rather than silently swapping it out from under
  // the admin — it just won't be offered for a fresh pick.
  const typeOptions = useMemo(() => {
    if (!target) return [];
    const available = availableBookingFollowUpTypes(target);
    const types = target.booking_follow_up_type && !available.includes(target.booking_follow_up_type)
      ? [target.booking_follow_up_type, ...available]
      : available;
    return types.map(value => ({ value, label: BOOKING_FOLLOW_UP_TYPE_CONFIG[value].label }));
  }, [target]);

  // Pre-fill from any existing reminder when reopening this booking, blank
  // slate otherwise — never carry over a previous target's half-filled form.
  useEffect(() => {
    if (!target) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- resetting local form state to match a newly-opened target, not syncing an external system
    setType(target.booking_follow_up_type || availableBookingFollowUpTypes(target)[0] || 'other');
    setAt(target.booking_follow_up_at || '');
    setTime(target.booking_follow_up_time || '');
    setNotes(target.booking_follow_up_notes || '');
  }, [target?.id, target?.booking_follow_up_type, target?.booking_follow_up_at, target?.booking_follow_up_time, target?.booking_follow_up_notes]); // eslint-disable-line react-hooks/exhaustive-deps -- target's identity changes every render (parent re-derives it); depending on the fields actually read avoids refiring on unrelated re-renders

  const isDirty = at !== (target?.booking_follow_up_at || '')
    || time !== (target?.booking_follow_up_time || '')
    || type !== (target?.booking_follow_up_type || (target ? availableBookingFollowUpTypes(target)[0] : undefined) || 'other')
    || notes !== (target?.booking_follow_up_notes || '');

  const requestClose = async () => {
    if (isDirty) {
      const ok = await confirm({
        title: 'Discard unsaved changes?',
        message: "You've entered a follow-up reminder that hasn't been saved yet.",
        confirmLabel: 'Discard',
        cancelLabel: 'Continue Editing',
        variant: 'danger',
      });
      if (!ok) return;
    }
    onClose();
  };

  return (
    <Modal isOpen={!!target} onClose={requestClose} title="Booking Follow-up" size="sm">
      {target && (
        <div className="space-y-4">
          <div className="bg-background-warm rounded-md px-4 py-3">
            <p className="font-medium text-dark">{target.full_name}</p>
            <p className="text-dark-muted text-xs">{target.trip_title || 'No trip linked'}</p>
          </div>

          <div>
            <label htmlFor="bfu-type" className="block text-sm font-medium text-dark mb-1">Reminder Type</label>
            <Select inputId="bfu-type" value={type} onChange={val => setType(val as BookingFollowUpType)} options={typeOptions} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="bfu-date" className="block text-sm font-medium text-dark mb-1">Follow-up Date</label>
              <DatePicker id="bfu-date" value={at} onChange={setAt} />
            </div>
            <div>
              <label htmlFor="bfu-time" className="block text-sm font-medium text-dark mb-1">Follow-up Time</label>
              <TimePicker id="bfu-time" value={time} onChange={setTime} />
            </div>
          </div>

          <div>
            <label htmlFor="bfu-notes" className="block text-sm font-medium text-dark mb-1">Notes</label>
            <textarea
              id="bfu-notes"
              value={notes}
              onChange={ev => setNotes(ev.target.value)}
              className={inputClass}
              rows={3}
              placeholder="e.g. which document is still pending — optional"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="outline" size="md" className="flex-1" onClick={requestClose}>Cancel</Button>
            <Button
              variant="primary"
              size="md"
              className="flex-1"
              disabled={!at}
              loading={saving}
              onClick={() => onSave({ at, time, type, notes })}
            >
              Save
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
