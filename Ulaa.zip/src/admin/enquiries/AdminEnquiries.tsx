import { useState, useEffect, useRef } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  UsersThree,
  CheckCircle as CheckCircle2,
  Trash as Trash2,
  Users,
  Pencil,
  X,
  MagnifyingGlass as Search,
  CalendarBlank as CalendarDays,
} from '@phosphor-icons/react';
import AdminLayout from '../AdminLayout';
import Button from '../../components/ui/Button';
import FoodMark from '../../components/ui/FoodMark';
import { paginate, useDragScroll } from '../../components/ui/dataTableUtils';
import type { CompletedTrip, Enquiry, UpcomingTrip, WaitlistEntry } from '../../types/types-index';
import { formatDateRange, formatPrice, seatsLeft, buildGroupLetterMap, formatBatchLabel, formatDate } from '../../utils/utils-index';
import type { GroupUnit } from '../../utils/utils-index';
import {
  foodPreferenceKey, SOURCE_CONFIG, JOURNEY_STAGE_CONFIG,
  closedReasonBreakdown, followUpStatus, validatePaymentForm,
  getTripPrice as getTripPriceCommon, getTripChildFareAmount as getTripChildFareAmountCommon,
} from './AdminEnquiryCommon';
import { JourneyLifecycleLegend } from './AdminEnquiryLifecycle';
import { useMarkInvoicePaid } from './useMarkInvoicePaid';
import { useEnquiryData } from './useEnquiryData';
import { useEnquiryFilters, ENQUIRIES_PAGE_SIZE } from './useEnquiryFilters';
import { useEnquirySelection } from './useEnquirySelection';
import { useEnquiryLifecycle } from './useEnquiryLifecycle';
import { useAddEnquiry } from './useAddEnquiry';
import { useBulkEnquiry } from './useBulkEnquiry';
import { useEnquiryPayment } from './useEnquiryPayment';
import { useEnquiryDetailsModal } from './useEnquiryDetailsModal';
import { useEnquiryStatusActions } from './useEnquiryStatusActions';
import { useBulkEdit } from './useBulkEdit';
import { useRowActions } from './useRowActions';
import {
  isGeneralContactMessage, groupLabelFor, groupColorFor, buildGroupColorMap,
  paymentTotals, foodTotals, buildKpiCards, describeWaiting, fetchWaitlistCounts,
} from './enquiryGrouping';

import {
  paymentFilterKey, isBooked, isCancelled,
  isGroupEntry, STATUS_CONFIG, PAY_FILTER_LABELS, FOOD_FILTER_LABELS,
  BOOKING_FILTER_LABELS, GROUP_FILTER_LABELS, PACKAGE_FILTER_LABELS, packageFilterKey,
} from './AdminEnquiriesShared';
import AdminEnquiryFilterPanel from './AdminEnquiryFilterPanel';
import { KpiCards, KpiCarousel } from '../../components/ui/KpiCards';
import AddEnquiryModal from './AdminAddEnquiryModal';
import BulkEnquiryModal from './AdminBulkEnquiryModal';
import DetailsModal from './AdminDetailsModal';
import MarkPaidModal from './AdminMarkPaidModal';
import NotInterestedModal from './AdminNotInterestedModal';
import FollowUpModal, { BookingFollowUpModal } from './AdminEnquiryFollowUpModal';
import ContactOutcomeModal from './AdminContactOutcomeModal';
import CancelModal from './AdminCancelModal';
import BulkEditModal from './AdminBulkEditModal';
import AdminEnquiriesDesktopTable from './AdminEnquiriesDesktopTable';
import AdminEnquiriesMobileCards from './AdminEnquiriesMobileCards';
import AdminEnquiriesFab from './AdminEnquiriesFab';
import AdminEnquiryPaymentModal from './AdminEnquiryPaymentModal';

export default function AdminEnquiries() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { enquiries, trips, completedTrips, loading, load, setTrips } = useEnquiryData();
  // Scroll restoration for this page (restoring where the admin was after
  // e.g. expanding a card, tapping "View Full CRM", then coming back) is
  // now centralized in AdminLayout — see the scrollRestorationReady={!loading}
  // prop passed to it below.
  const {
    filter, setFilter,
    journeyFilter, setJourneyFilter,
    payFilter, setPayFilter,
    bookedFilter, setBookedFilter,
    groupFilter, setGroupFilter,
    foodFilter, setFoodFilter,
    packageFilter, setPackageFilter,
    sourceFilter, setSourceFilter,
    followUpDueOnly, setFollowUpDueOnly,
    searchQuery, setSearchQuery, trimmedSearch,
    selectedTripKey, setSelectedTripKey,
    currentPage, setCurrentPage,
    sortKey, sortDir, handleSort,
    activeFilterCount,
    clearAllFilters,
    handleExportCsv,
  } = useEnquiryFilters();
  const { ref: tableScrollRef, isDragging, handlers: dragHandlers } = useDragScroll<HTMLDivElement>();
  const [updating, setUpdating] = useState<string | null>(null);
  // Owns the desktop "View Details" popup — target/invoices state plus the
  // download/share invoice actions.
  const {
    detailsTarget, setDetailsTarget,
    detailsInvoices, setDetailsInvoices,
    detailsInvoicesLoading,
    invoiceBusy,
    handleDownloadInvoice,
    handleShareInvoice,
    handleSendBookingEmail,
  } = useEnquiryDetailsModal();
  // Which mobile card is expanded — restored from sessionStorage on mount so
  // that expanding a card, tapping "View Full CRM" to drill into the detail
  // page, then coming back (browser back / in-app back) lands the admin
  // exactly where they left off: same card still expanded, same scroll
  // position (scroll restoration itself now lives in AdminLayout — see the
  // scrollRestorationReady prop passed to it below). Previously this was
  // plain local state, so navigating away and back always collapsed
  // everything and reset the scroll to the top.
  const [expandedId, setExpandedId] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('ulaa:admin-enquiries:expandedId');
    } catch {
      return null;
    }
  });
  // Tracks whether the expandedId above came from a restore (vs. a fresh
  // tap) so the scroll-into-view effect further down can skip its
  // scroll/animate step just once — AdminLayout's scroll restoration
  // already puts the page at the exact saved scrollY, and re-running
  // scrollIntoView on top of that would fight it and produce a visible jump.
  const restoredExpandedIdRef = useRef(expandedId !== null);
  // Separate from expandedId: expandedId also drives the mobile
  // expand/collapse toggle and should stay set. highlightId is purely a
  // "you arrived here via a link" visual cue for the desktop table (which
  // has no expand/collapse concept) and fades out on its own.
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const cardRefs = useRef<Record<string, HTMLElement | null>>({});
  // Looks up what a trip actually charges for a given package (early-bird or
  // normal). Returns undefined if the trip or that price isn't set.
  const getTripPrice = (tripId: string | undefined, packageType: Enquiry['package_type']): number | undefined =>
    getTripPriceCommon(trips, tripId, packageType);
  // This trip's configured Child Fare Amount (Add/Edit Trip → Finances &
  // Profit), used to auto-fill and lock the Add-on Amount field once the
  // Child Fare chip is picked in PaymentFormFields — see that component
  // for why it's a hard lock with no per-child override.
  const getTripChildFareAmount = (tripId: string | undefined): number | undefined =>
    getTripChildFareAmountCommon(trips, tripId);
  // Payment modal — a click on the Payment cell/"Record Payment"/"Add
  // Payment" opens this right here on the list (same modal
  // AdminEnquiryDetail.tsx uses), instead of navigating away to the full
  // CRM page first. paymentTarget/paymentForm stay owned by
  // useEnquiryPayment (not local state) since useEnquiryLifecycle's
  // handleToggleNoShow also needs to keep them in sync from elsewhere in
  // the table.
  const {
    paymentTarget, setPaymentTarget,
    paymentForm, setPaymentForm,
    savingPayment,
    paymentHistory, paymentHistoryLoading,
    openPayment,
    handleSavePayment,
  } = useEnquiryPayment({ setTrips, load, getTripPrice });
  // Live, field-level errors for the modal — same shared validator the
  // detail page's own Track Payment modal uses.
  const paymentErrors = paymentTarget ? validatePaymentForm(paymentForm, paymentTarget.amount_paid || 0) : {};
  const hasPaymentErrors = Object.keys(paymentErrors).length > 0;
  const {
    cancelTarget, setCancelTarget,
    cancelCharges, setCancelCharges,
    cancelIsNoShow, setCancelIsNoShow,
    cancelReason, setCancelReason,
    cancelNotes, setCancelNotes,
    cancelling, completingId,
    togglingNoShow,
    handleCancelToggle, handleConfirmCancel,
    handleToggleNoShow, handleDelete, handleMarkCompleted,
    handleCheckIn, handleUndoCheckIn,
  } = useEnquiryLifecycle({ load, setTrips, setUpdating, setPaymentTarget, setPaymentForm, setDetailsTarget });
  // Edit Details used to be owned here (target/form/touched state, opening
  // with the enquiry's current values prefilled, and saving) but that flow
  // now lives solely on the "View Full CRM" detail page — see
  // AdminEnquiryDetail.tsx's own useEditEnquiry() call — so there's one
  // place to fix a wrong name/contact/trip instead of two.
  // How many waitlist signups — and how many actual people, since a group
  // signup (group_size > 1) is one signup but several people — are
  // waiting (status 'waiting') for each trip. Used to warn admins before
  // they free up a seat that someone's already in line for — see the
  // Cancel modal and the per-trip banner below.
  const [waitlistWaitingCounts, setWaitlistWaitingCounts] = useState<Record<string, { entries: number; people: number }>>({});
  // Raw waitlist entries — kept only so group waitlist signups (group_size
  // > 1) can be folded into the same trip-scoped Group A/B/C sequence as
  // group bookings in the table below (see groupLetterMap).
  const [waitlistEntriesForGroups, setWaitlistEntriesForGroups] = useState<WaitlistEntry[]>([]);

  // Bulk operations: select, edit, save, delete across multiple enquiries
  // at once.
  const {
    selectedIds, setSelectedIds,
    bulkEditAllowed, selectedTripName,
    toggleSelectOne, toggleSelectAllFiltered,
  } = useEnquirySelection(enquiries, selectedTripKey);
  // Lightweight, self-dismissing confirmation for things that succeeded but
  // don't need to block the admin with an "OK" click — unlike the shared
  // AlertDialog (used inside the hooks above, e.g. useAddEnquiry/
  // useBulkEdit), which is reserved for errors/validation that the admin
  // actually needs to acknowledge.
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (message: string) => setToast(message);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(t);
  }, [toast]);

  const markPaid = useMarkInvoicePaid(updatedPayment => {
    setDetailsInvoices(prev => prev.map(p => (p.id === updatedPayment.id ? updatedPayment : p)));
    setDetailsTarget(prev => {
      if (!prev) return prev;
      const isRefund = updatedPayment.payment_type === 'refund';
      return { ...prev, amount_paid: (prev.amount_paid || 0) + (isRefund ? 0 : updatedPayment.amount) };
    });
    load();
  });

  const loadWaitlistCounts = () => fetchWaitlistCounts(setWaitlistEntriesForGroups, setWaitlistWaitingCounts);

  useEffect(() => {
    loadWaitlistCounts();
  }, []);

  // Syncs local state FROM the URL's ?trip=/?enquiry= params (external
  // system) rather than deriving state from a prop, so this genuinely
  // belongs in an effect rather than the render-time-adjustment pattern
  // used above — it also needs to call setSearchParams to clear the params
  // once consumed, which can only happen after commit.
  useEffect(() => {
    if (enquiries.length === 0) return;
    const tripParam = searchParams.get('trip');
    const enquiryParam = searchParams.get('enquiry');
    if (tripParam) setSelectedTripKey(tripParam);
    if (enquiryParam) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- syncing local state from the ?enquiry= URL param (external system), same rationale as setSelectedTripKey above
      setExpandedId(enquiryParam);
      setHighlightId(enquiryParam);
      // "View booking" links (e.g. from the Waitlist page) only pass
      // ?enquiry=, not ?trip= — without also selecting that enquiry's trip
      // group here, activeGroup stays null, the trip-scoped table never
      // renders, and there's nothing on screen for expandedId to expand.
      if (!tripParam) {
        const target = enquiries.find(e => e.id === enquiryParam);
        if (target) setSelectedTripKey(target.trip_id || 'unlinked');
      }
    }
    if (tripParam || enquiryParam) setSearchParams({}, { replace: true });
  }, [enquiries, searchParams, setSearchParams, setSelectedTripKey]);

  // Owns the "Log an Enquiry" modal: form state, the waitlist-conversion
  // handoff (solo and multi-seat "group" flows), possible-duplicate
  // detection, and the suggested-amount prefill.
  const {
    modalOpen,
    form, setForm,
    saving,
    convertingWaitlist,
    waitlistPeople,
    possibleDuplicates,
    openAdd, closeAddModal, updateWaitlistPerson,
    applySuggestedAmount,
    applyDuplicate,
    handleSave,
  } = useAddEnquiry({ trips, enquiries, setTrips, load, loadWaitlistCounts, showToast, getTripPrice });

  // Owns the "Bulk Enquiry" modal — batch-logging a list of manually-sourced
  // leads (WhatsApp/Instagram/walk-in names) against one trip/source at once.
  const {
    modalOpen: bulkEnquiryModalOpen,
    form: bulkEnquiryForm, setForm: setBulkEnquiryForm,
    saving: bulkEnquirySaving,
    activeTrips: bulkEnquiryActiveTrips,
    pastTrips: bulkEnquiryPastTrips,
    entries: bulkEnquiryEntries,
    openBulkAdd: openBulkEnquiry,
    closeBulkModal: closeBulkEnquiryModal,
    handleBulkSave: handleBulkEnquirySave,
  } = useBulkEnquiry({ trips, completedTrips, setTrips, load, showToast });

  // Keep sessionStorage in sync so a later mount (e.g. coming back from the
  // full CRM detail page) can restore this exact card as expanded.
  useEffect(() => {
    try {
      if (expandedId) sessionStorage.setItem('ulaa:admin-enquiries:expandedId', expandedId);
      else sessionStorage.removeItem('ulaa:admin-enquiries:expandedId');
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — expand state
      // just won't survive a navigation; not worth failing anything over.
    }
  }, [expandedId]);

  useEffect(() => {
    if (!expandedId) return;
    if (restoredExpandedIdRef.current) {
      // This run is the restored card, not a fresh tap — skip the
      // scroll-into-view animation once so it doesn't fight the scrollY
      // restoration below, then behave normally for every expand after.
      restoredExpandedIdRef.current = false;
      return;
    }
    const el = cardRefs.current[expandedId];
    if (!el) return;
    // Wait a beat for the expand animation/layout to settle, then decide
    // whether the page needs to move at all.
    const t = setTimeout(() => {
      const rect = el.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const fitsAlready = rect.top >= 0 && rect.bottom <= viewportHeight;

      // Plenty of room below (or above) already — expanding in place is all
      // that's needed, so don't move the page and cause an unnecessary jump.
      if (fitsAlready) return;

      // Not enough room below: bring the card fully into view. If the whole
      // expanded card is taller than the viewport itself, prioritize showing
      // its header/top details ('start'); otherwise align its bottom edge to
      // the viewport bottom ('end'), which is what makes the card appear to
      // slide up just enough to reveal the newly expanded content.
      const cardTallerThanViewport = rect.height > viewportHeight;
      el.scrollIntoView({ behavior: 'smooth', block: cardTallerThanViewport ? 'start' : 'end' });
    }, 80);
    return () => clearTimeout(t);
  }, [expandedId]);

  // Fades the "you arrived here" highlight after a couple seconds so it
  // reads as a pointer, not a permanent state.
  useEffect(() => {
    if (!highlightId) return;
    const t = setTimeout(() => setHighlightId(null), 2500);
    return () => clearTimeout(t);
  }, [highlightId]);

  // Owns the small "row status transition" handlers: recording a contact
  // outcome, the single-button "Advance" dispatcher, Not Interested +
  // Reopen, the lead follow-up reminder, and the post-booking follow-up
  // reminder.
  const {
    contactOutcomeTarget, setContactOutcomeTarget,
    savingContactOutcome,
    handleSaveContactOutcome,
    handleAdvance,
    notInterestedTarget, setNotInterestedTarget,
    closedReason, setClosedReason,
    handleMarkNotInterested,
    handleConfirmNotInterested,
    followUpTarget, setFollowUpTarget,
    followUpDate, setFollowUpDate,
    followUpTime, setFollowUpTime,
    openFollowUpModal,
    handleSaveFollowUp,
    handleClearFollowUp,
    bookingFollowUpTarget, setBookingFollowUpTarget,
    handleSaveBookingFollowUp,
    handleClearBookingFollowUp,
    handleReopenEnquiry,
  } = useEnquiryStatusActions({ load, setUpdating, openPayment, handleCheckIn, handleMarkCompleted });

  // Builds the per-row kebab menu (Mark/Undo No Show, invoice
  // download/share, Cancel/Reactivate, Delete, etc.) by
  // wiring together handlers owned by the hooks above — see
  // useRowActions.ts for what's included/excluded and why.
  const { buildRowActions } = useRowActions({
    invoiceBusy, handleDownloadInvoice, handleShareInvoice, handleSendBookingEmail,
    handleToggleNoShow, handleUndoCheckIn, handleClearFollowUp, handleClearBookingFollowUp,
    handleReopenEnquiry, handleMarkNotInterested, handleCancelToggle, handleDelete,
  });

  // Owns bulk operations across the current selection: the Bulk Edit
  // modal's target/form state, saving, and deleting every selected
  // enquiry.
  const {
    bulkEditOpen, setBulkEditOpen,
    bulkForm, setBulkForm,
    bulkSaving,
    bulkDeleting,
    openBulkEdit,
    handleBulkSave,
    handleBulkDelete,
  } = useBulkEdit({ enquiries, selectedIds, setSelectedIds, setTrips, load, showToast });

  // Group enquiries by trip so the admin can see, per trip, how many people
  // enquired/contacted/closed and how much has been collected vs is pending —
  // instead of one long undifferentiated list.
  type TripGroup = {
    key: string;
    title: string;
    trip?: UpcomingTrip;
    enquiries: Enquiry[];
    // True when this group's enquiries reference a trip_id that no longer
    // exists in the current `trips` list — i.e. the trip was deleted after
    // people enquired for it. The group still has to show up (deleting a
    // trip doesn't delete its enquiries/payment history), but it's flagged
    // so the admin isn't confused about why a "gone" trip still appears.
    isDeletedTrip: boolean;
    // True when the trip finished and graduated into a completed album
    // (sync_started_trip_albums, same id). Distinct from isDeletedTrip —
    // this is the normal, expected lifecycle for every trip, not a loss of
    // data — but it's still flagged and labeled so an admin scanning the
    // Trip filter can tell "this already happened" apart from "this is
    // still bookable" at a glance, the same way a CRM tags a closed deal
    // or a support desk tags a resolved ticket instead of leaving it
    // looking identical to an open one in the same list.
    isCompletedTrip: boolean;
  };

  // 'unlinked' bucket = every enquiry with trip_id null — both genuine
  // "Contact Us" messages (submitContactEnquiry, always source: 'website')
  // and any manual admin entry logged without picking a trip. Labeled and
  // sorted distinctly (3.8) so it doesn't just blend into the trip list:
  // pinned to the front regardless of count, since a handful of "just say
  // hi" messages could otherwise sink to the bottom of a long, busy-season
  // trip list and never get noticed.
  const UNLINKED_GROUP_KEY = 'unlinked';

  // The same trip can run more than once (e.g. same title as a Batch 1
  // and Batch 2 completed_trips row) — the Trip filter groups by trip_id
  // so they're already separate entries, but without this they'd carry
  // the exact same visible label and be indistinguishable in the list.
  // Append the batch when set; if it isn't (or two rows still share the
  // same title+batch), fall back to the trip date instead.
  const completedTripGroupTitle = (ct: CompletedTrip): string => {
    if (ct.batch?.trim()) return `${ct.title} \u2014 ${formatBatchLabel(ct.batch)}`;
    const sameTitle = completedTrips.filter(t => t.title === ct.title);
    if (sameTitle.length > 1) return `${ct.title} \u2014 ${formatDate(ct.trip_date, { month: 'short' })}`;
    return ct.title;
  };

  const tripGroups: TripGroup[] = (() => {
    const map = new Map<string, TripGroup>();
    enquiries.forEach(e => {
      const key = e.trip_id || UNLINKED_GROUP_KEY;
      if (!map.has(key)) {
        const linkedTrip = e.trip_id ? trips.find(t => t.id === e.trip_id) : undefined;
        // A trip_id can stop matching `trips` (upcoming) either because it
        // was genuinely deleted, or because the trip finished and
        // sync_started_trip_albums() turned it into a completed album with
        // the same id — that's a normal lifecycle move, not a deletion, so
        // it must not be flagged the same way.
        const linkedCompletedTrip = e.trip_id ? completedTrips.find(t => t.id === e.trip_id) : undefined;
        const isDeletedTrip = !!e.trip_id && !linkedTrip && !linkedCompletedTrip;
        const isCompletedTrip = !!linkedCompletedTrip;
        const title = linkedTrip?.title
          || (linkedCompletedTrip ? completedTripGroupTitle(linkedCompletedTrip) : undefined)
          || e.trip_title
          || 'General Enquiries (No Trip)';
        map.set(key, {
          key,
          title,
          trip: linkedTrip,
          enquiries: [],
          isDeletedTrip,
          isCompletedTrip,
        });
      }
      map.get(key)!.enquiries.push(e);
    });
    return Array.from(map.values()).sort((a, b) => {
      if (a.key === UNLINKED_GROUP_KEY) return -1;
      if (b.key === UNLINKED_GROUP_KEY) return 1;
      // Active trips first, then completed, then deleted — so the Trip
      // filter reads top-to-bottom as "what's live" → "what's finished" →
      // "what's gone" instead of interleaving all three by raw enquiry
      // count. Same idea as an inbox listing unread before archived.
      const tier = (g: TripGroup) => (g.isDeletedTrip ? 2 : g.isCompletedTrip ? 1 : 0);
      const tierDiff = tier(a) - tier(b);
      if (tierDiff !== 0) return tierDiff;
      return b.enquiries.length - a.enquiries.length;
    });
  })();


  const activeGroup = tripGroups.find(g => g.key === selectedTripKey) || null;
  const scopedEnquiries = activeGroup ? activeGroup.enquiries : enquiries;

  // Names every group booking "Group A", "Group B", "Group C"... scoped to
  // the trip it belongs to — the first group ever created for a given trip
  // is always Group A, regardless of which trip is currently being viewed,
  // what filters/sort/search are active, or how the list is paginated.
  // Group waitlist signups (someone joining the waitlist because their
  // group of N didn't fit) are folded into the very same per-trip sequence
  // — via the buildGroupLetterMap helper shared with the Waitlist page —
  // so a new group waitlist entry picks up the next letter after whatever
  // group bookings already exist for that trip, instead of starting over.
  // Built from the full, unscoped `enquiries`/waitlist lists (not
  // scopedEnquiries or any filtered/sorted derivative) so a group's letter
  // is stable and never reshuffles as the admin navigates around.
  const groupUnits: GroupUnit[] = [];
  {
    const seenGroupIds = new Set<string>();
    enquiries.forEach(e => {
      if (!e.group_id || seenGroupIds.has(e.group_id)) return;
      seenGroupIds.add(e.group_id);
      groupUnits.push({ key: e.group_id, tripId: e.trip_id || 'unlinked', createdAt: e.created_at });
    });
    waitlistEntriesForGroups.forEach(w => {
      if (!w.group_size || w.group_size <= 1) return;
      groupUnits.push({ key: `wl:${w.id}`, tripId: w.trip_id || 'unlinked', createdAt: w.created_at });
    });
  }
  const groupLetterMap = buildGroupLetterMap(groupUnits);
  const groupLabel = (e: Enquiry) => groupLabelFor(e, groupLetterMap);

  // Group-booking rows are inserted together in one batch, so their
  // created_at timestamps are effectively identical — ordering purely by
  // created_at (as the initial fetch does) then leaves them in whatever
  // arbitrary order the database happened to return, e.g. "Group 2/5, 1/5,
  // 3/5...". This re-sorts so every group's members sit together,
  // internally ordered 1/N, 2/N, 3/N..., while the groups (and any solo
  // bookings) themselves stay in the same overall newest-first order as
  // before — keyed off the *earliest* created_at seen in each group, since
  // that's the one moment a batch actually happened.
  const groupEarliestCreatedAt = new Map<string, string>();
  scopedEnquiries.forEach(e => {
    if (!e.group_id) return;
    const existing = groupEarliestCreatedAt.get(e.group_id);
    if (!existing || e.created_at < existing) groupEarliestCreatedAt.set(e.group_id, e.created_at);
  });
  const sortedScoped = [...scopedEnquiries].sort((a, b) => {
    const aKey = a.group_id ? groupEarliestCreatedAt.get(a.group_id)! : a.created_at;
    const bKey = b.group_id ? groupEarliestCreatedAt.get(b.group_id)! : b.created_at;
    if (aKey !== bKey) return aKey < bKey ? 1 : -1; // newest batch/entry first
    if (a.group_id && a.group_id === b.group_id) return (a.group_seq || 1) - (b.group_seq || 1);
    return 0;
  });

  // Assigns each group_id a color from the palette below, in the order
  // groups first appear top-to-bottom in the (now-clustered) list — see
  // buildGroupColorMap in enquiryGrouping.ts.
  const groupColorMap = buildGroupColorMap(sortedScoped);
  const groupColor = (e: Enquiry) => groupColorFor(e, groupColorMap);

  const filtered = sortedScoped
    .filter(e => filter === 'all' || e.status === filter)
    .filter(e => journeyFilter === 'all' || e.journey_stage === journeyFilter)
    .filter(e => payFilter === 'all' || paymentFilterKey(e) === payFilter)
    .filter(e => bookedFilter === 'all' || (
      bookedFilter === 'cancelled' ? isCancelled(e)
      : bookedFilter === 'booked' ? isBooked(e)
      : !isBooked(e) && !isCancelled(e)
    ))
    .filter(e => groupFilter === 'all' || (groupFilter === 'group' ? isGroupEntry(e) : !isGroupEntry(e)))
    .filter(e => foodFilter === 'all' || foodPreferenceKey(e) === foodFilter)
    .filter(e => packageFilter === 'all' || packageFilterKey(e) === packageFilter)
    .filter(e => sourceFilter === 'all' || e.source === sourceFilter)
    .filter(e => !followUpDueOnly || !!followUpStatus(e)?.isDue)
    .filter(e => !trimmedSearch
      || e.full_name?.toLowerCase().includes(trimmedSearch)
      || e.phone?.toLowerCase().includes(trimmedSearch)
      || e.email?.toLowerCase().includes(trimmedSearch)
      || e.trip_title?.toLowerCase().includes(trimmedSearch));

  const sortedFiltered = sortKey ? [...filtered].sort((a, b) => {
    const dir = sortDir === 'asc' ? 1 : -1;
    switch (sortKey) {
      case 'name': return dir * (a.full_name || '').localeCompare(b.full_name || '');
      case 'group': return dir * ((a.group_size || 1) - (b.group_size || 1));
      case 'food': return dir * foodPreferenceKey(a).localeCompare(foodPreferenceKey(b));
      case 'source': return dir * (a.source || '').localeCompare(b.source || '');
      case 'date': return dir * (a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0);
      case 'package': return dir * (a.package_type || 'normal').localeCompare(b.package_type || 'normal');
      case 'payment': return dir * ((a.amount_paid || 0) - (b.amount_paid || 0));
      case 'status': return dir * (a.status || '').localeCompare(b.status || '');
      // Nulls (no reminder set) always sort to the end regardless of
      // direction — an admin sorting this column wants due/upcoming dates
      // grouped together, not chasing them past a block of blanks.
      case 'follow_up': {
        if (!a.follow_up_at && !b.follow_up_at) return 0;
        if (!a.follow_up_at) return 1;
        if (!b.follow_up_at) return -1;
        return dir * (a.follow_up_at < b.follow_up_at ? -1 : a.follow_up_at > b.follow_up_at ? 1 : 0);
      }
      default: return 0;
    }
  }) : filtered;

  const {
    pageItems: paginatedEnquiries,
    totalPages: enquiriesTotalPages,
    safePage: enquiriesSafePage,
    rangeStart: enquiriesRangeStart,
    rangeEnd: enquiriesRangeEnd,
  } = paginate(sortedFiltered, currentPage, ENQUIRIES_PAGE_SIZE);

  const counts = {
    all: scopedEnquiries.length,
    new: scopedEnquiries.filter(e => e.status === 'new').length,
    contacted: scopedEnquiries.filter(e => e.status === 'contacted').length,
    closed: scopedEnquiries.filter(e => e.status === 'closed').length,
  };
  const journeyCounts = {
    all: scopedEnquiries.length,
    new_enquiry: scopedEnquiries.filter(e => e.journey_stage === 'new_enquiry').length,
    contacted: scopedEnquiries.filter(e => e.journey_stage === 'contacted').length,
    advance_pending: scopedEnquiries.filter(e => e.journey_stage === 'advance_pending').length,
    advance_paid: scopedEnquiries.filter(e => e.journey_stage === 'advance_paid').length,
    confirmed: scopedEnquiries.filter(e => e.journey_stage === 'confirmed').length,
    balance_pending: scopedEnquiries.filter(e => e.journey_stage === 'balance_pending').length,
    fully_paid: scopedEnquiries.filter(e => e.journey_stage === 'fully_paid').length,
    checked_in: scopedEnquiries.filter(e => e.journey_stage === 'checked_in').length,
    completed: scopedEnquiries.filter(e => e.journey_stage === 'completed').length,
    not_interested: scopedEnquiries.filter(e => e.journey_stage === 'not_interested').length,
  };
  const payCounts = {
    all: scopedEnquiries.length,
    paid: scopedEnquiries.filter(e => paymentFilterKey(e) === 'paid').length,
    partial: scopedEnquiries.filter(e => paymentFilterKey(e) === 'partial').length,
    unpaid: scopedEnquiries.filter(e => paymentFilterKey(e) === 'unpaid').length,
    not_set: scopedEnquiries.filter(e => paymentFilterKey(e) === 'not_set').length,
  };
  const bookedCounts = {
    all: scopedEnquiries.length,
    booked: scopedEnquiries.filter(isBooked).length,
    not_booked: scopedEnquiries.filter(e => !isBooked(e) && !isCancelled(e)).length,
    cancelled: scopedEnquiries.filter(isCancelled).length,
  };
  const groupCounts = {
    all: scopedEnquiries.length,
    group: scopedEnquiries.filter(isGroupEntry).length,
    solo: scopedEnquiries.filter(e => !isGroupEntry(e)).length,
  };
  const foodCounts = {
    all: scopedEnquiries.length,
    veg: scopedEnquiries.filter(e => foodPreferenceKey(e) === 'veg').length,
    non_veg: scopedEnquiries.filter(e => foodPreferenceKey(e) === 'non_veg').length,
    not_set: scopedEnquiries.filter(e => foodPreferenceKey(e) === 'not_set').length,
  };
  const packageCounts = {
    all: scopedEnquiries.length,
    early_bird: scopedEnquiries.filter(e => packageFilterKey(e) === 'early_bird').length,
    normal: scopedEnquiries.filter(e => packageFilterKey(e) === 'normal').length,
  };
  const sourceCounts = Object.keys(SOURCE_CONFIG).reduce((acc, key) => {
    acc[key] = scopedEnquiries.filter(e => e.source === key).length;
    return acc;
  }, { all: scopedEnquiries.length } as Record<string, number>);
  const followUpDueCount = scopedEnquiries.filter(e => !!followUpStatus(e)?.isDue).length;

  return (
    <AdminLayout title="Enquiries" scrollRestorationReady={!loading}>
      <div className="space-y-4 sm:space-y-6">
        <JourneyLifecycleLegend />

        {/* Reporting breakdown — only meaningful once the admin is actually
            looking at closed leads; scoped to whatever trip/search filters
            are already active so it matches what's in the table below. */}
        {filter === 'closed' && closedReasonBreakdown(scopedEnquiries).length > 0 && (
          <div className="bg-white border border-background-warm rounded-lg px-4 py-3">
            <p className="text-2xs font-button font-bold text-dark-muted uppercase tracking-wide mb-2">
              Why these didn't convert
            </p>
            <div className="flex flex-wrap gap-2">
              {closedReasonBreakdown(scopedEnquiries).map(r => (
                <span key={r.label} className="inline-flex items-center gap-1.5 text-xs font-button font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-dark-muted">
                  {r.label} <span className="text-dark">{r.count}</span>
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-between items-center gap-3">
          <p className="text-dark-muted text-sm hidden sm:block">Log a WhatsApp, phone, or walk-in enquiry that didn't come through the website.</p>
          {/* Desktop/tablet keeps the inline button pair — plenty of room
              and it's the expected pattern there. Mobile gets a floating
              "+" action button instead (rendered further down, fixed to
              the viewport) so this row doesn't cost mobile a full width
              of vertical space above the fold. */}
          <div className="hidden sm:flex items-center gap-2 ml-auto">
            <Button variant="outline" size="sm" onClick={openBulkEnquiry}>
              <UsersThree size={16} aria-hidden="true" /> Bulk Enquiry
            </Button>
            <Button variant="primary" size="sm" onClick={openAdd}>
              <Plus size={16} aria-hidden="true" /> Add Enquiry
            </Button>
          </div>
        </div>

        <AdminEnquiriesFab onAddEnquiry={openAdd} onBulkEnquiry={openBulkEnquiry} />

        {/* KPI summary — desktop grid + mobile carousel, both scoped to
            whichever trip is selected in the Trip filter below (or
            business-wide when "All trips" is selected). */}
        <KpiCards cards={buildKpiCards(scopedEnquiries)} />
        <KpiCarousel cards={buildKpiCards(scopedEnquiries)} />

        {/* Mobile-only search bar — sits right under the KPI carousel so
            it's reachable with a thumb without hunting through the
            (collapsed-by-default) filter panel below. Bound to the same
            searchQuery state the desktop TableHeaderBar search uses. */}
        <div className="relative sm:hidden">
          <label htmlFor="enq-mobile-search" className="sr-only">Search name, phone, email, or trip</label>
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-dark-muted pointer-events-none" aria-hidden="true" />
          <input
            id="enq-mobile-search"
            type="text"
            value={searchQuery}
            onChange={ev => setSearchQuery(ev.target.value)}
            placeholder="Search name, phone, email, trip..."
            className="w-full pl-10 pr-10 py-3 rounded-lg border-2 border-background-warm bg-white font-body text-dark text-sm focus:border-primary outline-none transition-colors shadow-card"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-dark-muted hover:text-dark p-1"
              aria-label="Clear search"
            >
              <X size={16} aria-hidden="true" />
            </button>
          )}
        </div>

        {/* Trip summary card — shows "All Trips" totals when no Trip filter
            is selected below, or that trip's own name/seats/food/money
            once one is picked from the Trip filter. */}
        <div className="bg-white rounded-lg shadow-card overflow-hidden">
          <div className="flex flex-col md:flex-row">
            {/* Section 1 — trip photo + name / date / seats booked · food split */}
            <div className="flex items-center gap-3 p-4 pr-0 md:pr-4 flex-1 min-w-0 md:basis-1/3 border-b md:border-b-0 border-background-warm mx-4 md:mx-0 md:my-4 md:border-r">
              <div className="w-14 h-14 rounded-md overflow-hidden bg-background-warm shrink-0">
                {activeGroup?.trip?.cover_image && (
                  <img src={activeGroup.trip.cover_image} alt={activeGroup.title} className="w-full h-full object-cover" loading="lazy" decoding="async" />
                )}
              </div>
              <div className="min-w-0 flex-1 flex flex-col gap-1 py-0.5">
                <p className="font-display font-bold text-dark truncate flex items-center gap-2">
                  <span className="truncate">{activeGroup ? (activeGroup.title || activeGroup.trip?.title || 'Untitled Trip') : 'All Trips'}</span>
                  {activeGroup?.isCompletedTrip && (
                    <span className="shrink-0 text-2xs font-button font-bold uppercase tracking-wide px-1.5 py-0.5 rounded bg-background-warm text-dark-muted">Completed</span>
                  )}
                  {activeGroup?.isDeletedTrip && (
                    <span className="shrink-0 text-2xs font-button font-bold uppercase tracking-wide px-1.5 py-0.5 rounded bg-red-50 text-red-600">Deleted</span>
                  )}
                </p>
                {activeGroup?.trip?.start_date && activeGroup.trip.end_date && (
                  <p className="text-dark-muted text-xs flex items-center gap-1">
                    <CalendarDays size={11} className="shrink-0" aria-hidden="true" /> {formatDateRange(activeGroup.trip.start_date, activeGroup.trip.end_date)}
                  </p>
                )}
                {(() => {
                  // Only travellers who actually hold a booked seat count
                  // toward the meal split shown next to "X/Y seats booked"
                  // — otherwise this silently included every enquiry for
                  // the trip (new, contacted, cancelled, etc.), so the veg/
                  // non-veg numbers could add up to well more than the
                  // seats actually booked.
                  const food = foodTotals(scopedEnquiries.filter(isBooked));
                  return (
                    <p className="text-dark-muted text-[11px] md:text-xs flex items-center flex-wrap gap-x-1 md:gap-x-1.5 gap-y-0.5 [&>span]:whitespace-nowrap">
                      {activeGroup?.trip && <span>{activeGroup.trip.seats_booked}/{activeGroup.trip.total_seats} seats booked</span>}
                      {(food.veg > 0 || food.nonVeg > 0) && (
                        <>
                          {activeGroup?.trip && <span className="text-dark-muted/40" aria-hidden="true">|</span>}
                          <span className="inline-flex items-center gap-1 text-green-700"><FoodMark type="veg" size={9} /> {food.veg} Veg</span>
                          <span className="inline-flex items-center gap-1 text-red-700"><FoodMark type="non_veg" size={9} /> {food.nonVeg} Non-veg</span>
                        </>
                      )}
                    </p>
                  );
                })()}
              </div>
            </div>

            {/* Section 2 — seat utilization bar (only meaningful once a specific trip is picked) */}
            {activeGroup?.trip && (
              <div className="flex flex-col justify-center gap-1.5 p-4 flex-1 min-w-0 md:basis-1/3 border-b md:border-b-0 border-background-warm mx-4 md:mx-0 md:my-4 md:border-r">
                <p className="text-dark-muted text-xs font-medium">Seat Utilization</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 rounded-full bg-background-warm overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{ width: `${activeGroup.trip.total_seats ? Math.min(100, Math.round((activeGroup.trip.seats_booked / activeGroup.trip.total_seats) * 100)) : 0}%` }}
                    />
                  </div>
                  <span className="text-dark text-xs font-semibold shrink-0">
                    {activeGroup.trip.total_seats ? Math.min(100, Math.round((activeGroup.trip.seats_booked / activeGroup.trip.total_seats) * 100)) : 0}%
                  </span>
                </div>
                <p className="text-dark-muted text-xs">{activeGroup.trip.seats_booked} of {activeGroup.trip.total_seats} seats</p>
              </div>
            )}

            {/* Section 3 — payments collected/pending + link to the trip, button vertically centered against the full card height */}
            <div className="flex items-center gap-4 p-4 flex-1 min-w-0 md:basis-1/3">
              <div className="min-w-0 flex-1">
                <p className="text-dark-muted text-xs font-medium mb-1.5">Payments</p>
                <div className="flex items-center gap-6">
                  <div>
                    <p className="text-dark-muted text-xs">Collected</p>
                    <p className="text-green-700 font-semibold text-sm">{formatPrice(paymentTotals(scopedEnquiries.filter(isBooked)).collected)}</p>
                  </div>
                  <div>
                    <p className="text-dark-muted text-xs">Pending</p>
                    <p className="text-amber-600 font-semibold text-sm">{formatPrice(paymentTotals(scopedEnquiries.filter(isBooked)).pending)}</p>
                  </div>
                </div>
              </div>
              {activeGroup?.trip && (
                <Link
                  to="/admin/trips"
                  className="shrink-0 self-center text-xs font-button font-semibold px-4 py-2.5 rounded border border-primary/30 text-primary hover:bg-primary/5 transition-colors whitespace-nowrap"
                >
                  View Trip Details
                </Link>
              )}
            </div>
          </div>
        </div>

        {/* Someone's waiting for a seat on this trip and one's actually
            open right now — surface it here too, not just on the
            Waitlist page, since this is where an admin notices a seat
            freed up (e.g. right after cancelling someone) and might
            otherwise let it get booked by a new website visitor instead
            of the person who's been waiting longer. Only relevant once a
            specific trip is picked from the Trip filter. */}
        {activeGroup?.trip && waitlistWaitingCounts[activeGroup.key]?.entries > 0 && seatsLeft(activeGroup.trip.total_seats, activeGroup.trip.seats_booked) > 0 && (
          <div className="flex items-center gap-3 bg-orange-50 border border-orange-200 rounded-lg px-4 py-3">
            <Users size={18} className="text-orange-600 shrink-0" />
            <p className="text-sm text-orange-800 flex-1">
              <span className="font-semibold">
                {describeWaiting(waitlistWaitingCounts[activeGroup.key])} {waitlistWaitingCounts[activeGroup.key].entries === 1 ? 'is' : 'are'} waiting
              </span>{' '}
              for a seat on this trip, and one's open right now.
            </p>
            <Link
              to={`/admin/waitlist?trip=${activeGroup.key}`}
              className="shrink-0 text-xs font-button font-semibold px-3 py-1.5 rounded bg-orange-600 text-white hover:bg-orange-700 transition-colors whitespace-nowrap"
            >
              Go to Waitlist
            </Link>
          </div>
        )}

            {/* Filters — chip-based panel (one tap per filter, applied filters
                always visible, rare filters under "More filters"). See
                AdminEnquiryFilterPanel.tsx. */}
            <AdminEnquiryFilterPanel
              trip={{
                selectedKey: selectedTripKey,
                selectedLabel: activeGroup ? activeGroup.title : null,
                onSelect: setSelectedTripKey,
                options: [
                  { key: 'all', label: 'All trips', count: enquiries.length },
                  ...tripGroups.map(g => ({
                    key: g.key,
                    label: g.title,
                    count: g.enquiries.length,
                    section: g.key === UNLINKED_GROUP_KEY ? undefined : g.isDeletedTrip ? 'Deleted' : g.isCompletedTrip ? 'Completed' : undefined,
                  })),
                ],
                generalKey: UNLINKED_GROUP_KEY,
                generalCount: enquiries.filter(e => !e.trip_id).length,
              }}
              booking={{
                value: bookedFilter,
                onChange: v => setBookedFilter(v as typeof bookedFilter),
                options: (['all', 'booked', 'not_booked', 'cancelled'] as const).map(key => ({
                  key, label: BOOKING_FILTER_LABELS[key], count: bookedCounts[key],
                })),
              }}
              payment={{
                value: payFilter,
                onChange: v => setPayFilter(v as typeof payFilter),
                options: (['all', 'paid', 'partial', 'unpaid', 'not_set'] as const).map(key => ({
                  key, label: PAY_FILTER_LABELS[key], count: payCounts[key],
                })),
              }}
              followUp={{ active: followUpDueOnly, count: followUpDueCount, onToggle: () => setFollowUpDueOnly(v => !v) }}
              leadStatus={{
                value: filter,
                onChange: v => setFilter(v as typeof filter),
                options: (['all', 'new', 'contacted', 'closed'] as const).map(key => ({
                  key, label: key === 'all' ? 'All' : STATUS_CONFIG[key].label, count: counts[key],
                })),
              }}
              journey={{
                value: journeyFilter,
                onChange: v => setJourneyFilter(v as typeof journeyFilter),
                options: ([
                  'all', 'new_enquiry', 'contacted', 'advance_pending', 'advance_paid', 'confirmed',
                  'balance_pending', 'fully_paid', 'checked_in', 'completed', 'not_interested',
                ] as const).map(key => ({
                  key, label: key === 'all' ? 'All' : JOURNEY_STAGE_CONFIG[key].label, count: journeyCounts[key],
                })),
              }}
              group={{
                value: groupFilter,
                onChange: v => setGroupFilter(v as typeof groupFilter),
                options: (['all', 'group', 'solo'] as const).map(key => ({
                  key, label: GROUP_FILTER_LABELS[key], count: groupCounts[key],
                })),
              }}
              food={{
                value: foodFilter,
                onChange: v => setFoodFilter(v as typeof foodFilter),
                options: (['all', 'veg', 'non_veg', 'not_set'] as const).map(key => ({
                  key,
                  label: FOOD_FILTER_LABELS[key],
                  count: foodCounts[key],
                  icon: key === 'all' ? undefined : <FoodMark type={key} size={10} />,
                })),
              }}
              pkg={{
                value: packageFilter,
                onChange: v => setPackageFilter(v as typeof packageFilter),
                options: (['all', 'early_bird', 'normal'] as const).map(key => ({
                  key, label: PACKAGE_FILTER_LABELS[key], count: packageCounts[key],
                })),
              }}
              source={{
                value: sourceFilter,
                onChange: v => setSourceFilter(v as typeof sourceFilter),
                options: [
                  { key: 'all', label: 'All', count: sourceCounts.all },
                  ...(Object.keys(SOURCE_CONFIG) as (keyof typeof SOURCE_CONFIG)[]).map(key => ({
                    key: key as string, label: SOURCE_CONFIG[key].label, count: sourceCounts[key] || 0,
                  })),
                ],
              }}
              searchQuery={searchQuery}
              onClearSearch={() => setSearchQuery('')}
              activeCount={activeFilterCount}
              onClearAll={clearAllFilters}
              shownCount={sortedFiltered.length}
              totalCount={scopedEnquiries.length}
            />

        {loading ? (
          <div className="text-center py-16 text-dark-muted">Loading enquiries...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-lg shadow-card">
            <p className="font-display text-xl text-dark-muted">No enquiries found.</p>
          </div>
        ) : (
          <>
            {/* Bulk actions toolbar — appears once at least one enquiry is selected */}
            {selectedIds.size > 0 && (
              <div className="flex flex-wrap items-center gap-3 bg-white rounded-lg shadow-card px-4 py-3">
                <p className="text-sm font-medium text-dark" aria-live="polite">
                  {selectedIds.size} selected
                </p>
                <div className="flex items-center gap-2 ml-auto">
                  {bulkEditAllowed ? (
                    <button
                      onClick={openBulkEdit}
                      className="inline-flex items-center gap-1 text-xs font-button font-semibold px-3 py-2 rounded-md border border-background-warm text-dark hover:border-primary/30 transition-colors"
                    >
                      <Pencil size={14} aria-hidden="true" /> Bulk Edit
                    </button>
                  ) : (
                    <span title="Bulk Edit is disabled when the selection spans more than one trip — pricing fields aren't safe to apply across trips with different prices.">
                      <button
                        disabled
                        aria-label="Bulk Edit — disabled because the selection spans more than one trip"
                        className="inline-flex items-center gap-1 text-xs font-button font-semibold px-3 py-2 rounded-md border border-background-warm text-dark-muted/40 cursor-default"
                      >
                        <Pencil size={14} aria-hidden="true" /> Bulk Edit
                      </button>
                    </span>
                  )}
                  <button
                    onClick={handleBulkDelete}
                    disabled={bulkDeleting}
                    className="inline-flex items-center gap-1 text-xs font-button font-semibold px-3 py-2 rounded-md border border-primary/30 text-primary hover:bg-primary/5 transition-colors disabled:opacity-60"
                  >
                    <Trash2 size={14} aria-hidden="true" /> {bulkDeleting ? 'Deleting…' : 'Delete'}
                  </button>
                  <button
                    onClick={() => setSelectedIds(new Set())}
                    className="inline-flex items-center gap-1 text-xs font-button font-semibold px-3 py-2 rounded-md border border-background-warm text-dark-muted hover:bg-background/50 transition-colors"
                  >
                    <X size={14} aria-hidden="true" /> Clear
                  </button>
                </div>
              </div>
            )}

            <AdminEnquiriesDesktopTable
              paginatedEnquiries={paginatedEnquiries}
              enquiriesSafePage={enquiriesSafePage}
              pageSize={ENQUIRIES_PAGE_SIZE}
              enquiriesRangeStart={enquiriesRangeStart}
              enquiriesRangeEnd={enquiriesRangeEnd}
              enquiriesTotalPages={enquiriesTotalPages}
              totalFiltered={filtered.length}
              sortedFiltered={sortedFiltered}
              setCurrentPage={setCurrentPage}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onExportCsv={(rows, tripTitle, gl, trip) => handleExportCsv(rows, tripTitle, gl, trip, trips, enquiries)}
              activeGroupTitle={activeGroup?.title ?? null}
              sortKey={sortKey}
              sortDir={sortDir}
              handleSort={handleSort}
              selectedIds={selectedIds}
              toggleSelectOne={toggleSelectOne}
              toggleSelectAllFiltered={toggleSelectAllFiltered}
              activeGroup={activeGroup}
              highlightId={highlightId}
              groupColor={groupColor}
              groupLabel={groupLabel}
              cardRefs={cardRefs}
              tableScrollRef={tableScrollRef}
              dragHandlers={dragHandlers}
              isDragging={isDragging}
              updating={updating}
              completingId={completingId}
              openPayment={openPayment}
              openFollowUpModal={openFollowUpModal}
              setBookingFollowUpTarget={setBookingFollowUpTarget}
              handleAdvance={handleAdvance}
              buildRowActions={buildRowActions}
            />

            <AdminEnquiriesMobileCards
              paginatedEnquiries={paginatedEnquiries}
              enquiriesSafePage={enquiriesSafePage}
              enquiriesRangeStart={enquiriesRangeStart}
              enquiriesRangeEnd={enquiriesRangeEnd}
              enquiriesTotalPages={enquiriesTotalPages}
              totalFiltered={filtered.length}
              setCurrentPage={setCurrentPage}
              expandedId={expandedId}
              setExpandedId={setExpandedId}
              selectedIds={selectedIds}
              toggleSelectOne={toggleSelectOne}
              activeGroup={activeGroup}
              highlightId={highlightId}
              groupColor={groupColor}
              groupLabel={groupLabel}
              cardRefs={cardRefs}
              updating={updating}
              invoiceBusy={invoiceBusy}
              handleDownloadInvoice={handleDownloadInvoice}
              handleShareInvoice={handleShareInvoice}
              handleSendBookingEmail={handleSendBookingEmail}
              openPayment={openPayment}
              openFollowUpModal={openFollowUpModal}
              setBookingFollowUpTarget={setBookingFollowUpTarget}
              handleAdvance={handleAdvance}
              buildRowActions={buildRowActions}
            />
          </>
        )}
      </div>

      <AddEnquiryModal
        isOpen={modalOpen}
        onClose={closeAddModal}
        convertingWaitlist={convertingWaitlist}
        form={form}
        setForm={setForm}
        trips={trips}
        waitlistPeople={waitlistPeople}
        updateWaitlistPerson={updateWaitlistPerson}
        possibleDuplicates={possibleDuplicates}
        applySuggestedAmount={applySuggestedAmount}
        applyDuplicate={applyDuplicate}
        onSave={handleSave}
        saving={saving}
      />

      <BulkEnquiryModal
        isOpen={bulkEnquiryModalOpen}
        onClose={closeBulkEnquiryModal}
        form={bulkEnquiryForm}
        setForm={setBulkEnquiryForm}
        activeTrips={bulkEnquiryActiveTrips}
        pastTrips={bulkEnquiryPastTrips}
        entries={bulkEnquiryEntries}
        onSave={handleBulkEnquirySave}
        saving={bulkEnquirySaving}
      />

      <DetailsModal
        detailsTarget={detailsTarget}
        onClose={() => setDetailsTarget(null)}
        groupLabel={groupLabel}
        isGeneralContactMessage={isGeneralContactMessage}
        invoiceBusy={invoiceBusy}
        onDownloadInvoice={handleDownloadInvoice}
        onShareInvoice={handleShareInvoice}
        onSendBookingEmail={handleSendBookingEmail}
        completingId={completingId}
        onMarkCompleted={handleMarkCompleted}
        detailsInvoices={detailsInvoices}
        detailsInvoicesLoading={detailsInvoicesLoading}
        onOpenGenerateInvoice={openPayment}
        invoiceRowBusyId={markPaid.busyId}
        onMarkInvoicePaid={markPaid.open}
      />

      {paymentTarget && (
        <AdminEnquiryPaymentModal
          isOpen={!!paymentTarget}
          onClose={() => setPaymentTarget(null)}
          enquiry={paymentTarget}
          paymentForm={paymentForm}
          setPaymentForm={setPaymentForm}
          paymentErrors={paymentErrors}
          hasPaymentErrors={hasPaymentErrors}
          savingPayment={savingPayment}
          onSave={handleSavePayment}
          payments={paymentHistory}
          paymentsLoading={paymentHistoryLoading}
          togglingNoShow={togglingNoShow}
          onToggleNoShow={(isNoShow) => handleToggleNoShow(paymentTarget, isNoShow)}
          getTripPrice={getTripPrice}
          getTripChildFareAmount={getTripChildFareAmount}
        />
      )}

      <MarkPaidModal
        target={markPaid.target}
        onClose={markPaid.close}
        form={markPaid.form}
        setForm={markPaid.setForm}
        onConfirm={markPaid.confirm}
        saving={markPaid.saving}
      />

      <ContactOutcomeModal
        target={contactOutcomeTarget}
        onClose={() => setContactOutcomeTarget(null)}
        onSave={handleSaveContactOutcome}
        saving={savingContactOutcome}
      />

      <NotInterestedModal
        notInterestedTarget={notInterestedTarget}
        onClose={() => setNotInterestedTarget(null)}
        closedReason={closedReason}
        setClosedReason={setClosedReason}
        onConfirm={handleConfirmNotInterested}
        updating={updating}
      />

      <FollowUpModal
        target={followUpTarget}
        onClose={() => setFollowUpTarget(null)}
        followUpDate={followUpDate}
        setFollowUpDate={setFollowUpDate}
        followUpTime={followUpTime}
        setFollowUpTime={setFollowUpTime}
        onSave={handleSaveFollowUp}
        saving={!!followUpTarget && updating === followUpTarget.id}
      />

      <BookingFollowUpModal
        target={bookingFollowUpTarget}
        onClose={() => setBookingFollowUpTarget(null)}
        onSave={handleSaveBookingFollowUp}
        saving={!!bookingFollowUpTarget && updating === bookingFollowUpTarget.id}
      />

      <CancelModal
        cancelTarget={cancelTarget}
        onClose={() => setCancelTarget(null)}
        cancelCharges={cancelCharges}
        setCancelCharges={setCancelCharges}
        cancelIsNoShow={cancelIsNoShow}
        setCancelIsNoShow={setCancelIsNoShow}
        cancelReason={cancelReason}
        setCancelReason={setCancelReason}
        cancelNotes={cancelNotes}
        setCancelNotes={setCancelNotes}
        waitlistWaitingCounts={waitlistWaitingCounts}
        describeWaiting={describeWaiting}
        onConfirm={handleConfirmCancel}
        cancelling={cancelling}
      />

      {/* Lightweight success toast — bulk-save confirmation only, doesn't
          block the admin the way the AlertDialog (errors/validation) does */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[200] flex items-center gap-2 bg-dark text-white text-sm font-medium px-4 py-2.5 rounded-md shadow-warm-lg"
          >
            <CheckCircle2 size={16} className="text-green-400 shrink-0" />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>

      <BulkEditModal
        isOpen={bulkEditOpen}
        onClose={() => setBulkEditOpen(false)}
        selectedCount={selectedIds.size}
        selectedTripName={selectedTripName}
        targets={enquiries.filter(e => selectedIds.has(e.id))}
        bulkForm={bulkForm}
        setBulkForm={setBulkForm}
        activeGroupTripId={activeGroup?.trip?.id}
        getTripPrice={getTripPrice}
        onSave={handleBulkSave}
        bulkSaving={bulkSaving}
      />
    </AdminLayout>
  );
}
