import type { MutableRefObject } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  XCircle,
  ChatCircle as MessageCircle,
  CaretDown as ChevronDown,
  CurrencyInr as IndianRupee,
  Users,
  User,
  ForkKnife as Utensils,
  CalendarDot as CalendarClock,
  Briefcase,
  Buildings as Building2,
  Package,
  CalendarBlank as CalendarDays,
  Bird,
  Baby,
  FileText,
  ShareNetwork as Share2,
  Globe,
  ArrowRight,
  Phone as PhoneIcon,
  EnvelopeSimple,
} from '@phosphor-icons/react';
import Button from '../../components/ui/Button';
import FoodMark from '../../components/ui/FoodMark';
import { MobilePaginationFooter } from '../../components/ui/DataTableChrome';
import ActionsMenu from '../../components/ui/ActionsMenu';
import type { ActionMenuItem } from '../../components/ui/ActionsMenu';
import type { Enquiry, UpcomingTrip } from '../../types/types-index';
import { formatDate, formatTime, formatPrice, getWhatsAppLink } from '../../utils/utils-index';
import {
  PACKAGE_CONFIG,
  SOURCE_CONFIG,
  journeyBadge, nextManualAction,
  closedReasonLabel, canSetFollowUp, followUpStatus,
  canSetBookingFollowUp, bookingFollowUpStatus,
} from './AdminEnquiryCommon';
import type { InvoiceAction } from './AdminEnquiryCommon';
import { isGeneralContactMessage, groupColorFor } from './enquiryGrouping';
import { paymentStatus, paymentBalance, paymentFilterKey, refundStatus } from './AdminEnquiriesShared';

// Phosphor doesn't ship a real WhatsApp glyph (ChatCircle/ChatsCircle are
// generic speech-bubble icons, not the recognizable WhatsApp mark) — same
// path used elsewhere (DataTableChrome's ContactQuickLinks, the Activity
// Timeline, AdminEnquiryTravellerCard's own WhatsApp row) so this card's
// WhatsApp icon matches everywhere else it appears.
function WhatsAppGlyph({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size} aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  );
}

interface AdminEnquiriesMobileCardsProps {
  // Data for the current page
  paginatedEnquiries: Enquiry[];
  enquiriesSafePage: number;
  enquiriesRangeStart: number;
  enquiriesRangeEnd: number;
  enquiriesTotalPages: number;
  totalFiltered: number;
  setCurrentPage: (page: number) => void;

  // Expand/collapse
  expandedId: string | null;
  setExpandedId: (id: string | null) => void;

  // Selection
  selectedIds: Set<string>;
  toggleSelectOne: (id: string) => void;

  // Grouping / highlight
  activeGroup: { key: string; title: string; trip?: UpcomingTrip } | null;
  highlightId: string | null;
  groupColor: (e: Enquiry) => ReturnType<typeof groupColorFor>;
  groupLabel: (e: Enquiry) => string;
  cardRefs: MutableRefObject<Record<string, HTMLElement | null>>;

  // Row actions
  updating: string | null;
  invoiceBusy: { id: string; action: InvoiceAction } | null;
  handleDownloadInvoice: (e: Enquiry) => void;
  handleShareInvoice: (e: Enquiry) => void;
  handleSendBookingEmail: (e: Enquiry) => void;
  openPayment: (e: Enquiry) => void;
  openFollowUpModal: (e: Enquiry) => void;
  setBookingFollowUpTarget: (e: Enquiry) => void;
  handleAdvance: (e: Enquiry) => void;
  buildRowActions: (e: Enquiry) => ActionMenuItem[];
}

/** Mobile card-list view of the enquiries list (tap a card to expand full
 *  details), plus its own "Showing X–Y of N" + pagination footer —
 *  extracted from AdminEnquiries.tsx's JSX return (see that file's history
 *  for the original single-component version). Purely presentational, same
 *  as AdminEnquiriesDesktopTable: every piece of state and every handler is
 *  owned by AdminEnquiries (via its hooks) and passed in as props. */
export default function AdminEnquiriesMobileCards({
  paginatedEnquiries, enquiriesSafePage, enquiriesRangeStart, enquiriesRangeEnd,
  enquiriesTotalPages, totalFiltered, setCurrentPage,
  expandedId, setExpandedId,
  selectedIds, toggleSelectOne,
  activeGroup, highlightId, groupColor, groupLabel, cardRefs,
  updating, invoiceBusy, handleDownloadInvoice, handleShareInvoice, handleSendBookingEmail,
  openPayment, openFollowUpModal, setBookingFollowUpTarget, handleAdvance, buildRowActions,
}: AdminEnquiriesMobileCardsProps) {
  const navigate = useNavigate();

  return (
    <>
      {/* Mobile: tap a card to expand full details */}
      <div className="sm:hidden space-y-3">
        {paginatedEnquiries.map((e, idx) => {
          const jb = journeyBadge(e);
          const nma = nextManualAction(e);
          const srcCfg = SOURCE_CONFIG[e.source] || SOURCE_CONFIG.other;
          const isOpen = expandedId === e.id;
          const isHighlighted = highlightId === e.id;
          const clr = groupColor(e);
          return (
            <motion.div
              key={e.id}
              ref={(el) => { cardRefs.current[e.id] = el; }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className={`bg-white rounded-lg shadow-card overflow-hidden transition-shadow duration-1000 ${
                isHighlighted ? 'ring-2 ring-primary/40' : ''
              }`}
            >
              <div className={`w-full flex items-center gap-1.5 px-3 py-2.5 ${clr ? clr.row : ''}`}>
                <label className="shrink-0 flex items-center justify-center w-11 h-11 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedIds.has(e.id)}
                    onChange={() => toggleSelectOne(e.id)}
                    aria-label={`Select ${e.full_name}`}
                    className="w-5 h-5 rounded border-background-warm accent-primary cursor-pointer"
                  />
                </label>
              <button
                onClick={() => setExpandedId(isOpen ? null : e.id)}
                aria-expanded={isOpen}
                className="flex-1 min-w-0 flex flex-col text-left py-2.5 pr-1"
              >
                <div className="w-full flex items-start justify-between gap-3">
                  <p className="font-medium text-sm text-dark flex items-center gap-1.5 min-w-0">
                    <span className="text-dark-muted text-xs font-normal shrink-0">#{idx + 1}</span>
                    <span className="truncate min-w-0">{e.full_name}</span>
                    {e.package_type === 'early_bird' && (
                      <span
                        title="Early Bird"
                        className="inline-flex items-center gap-0.5 text-[9px] font-button font-semibold px-1.5 py-0.5 rounded-md bg-purple-100 text-purple-700 shrink-0"
                      >
                        <Bird size={11}  aria-hidden="true" />
                      </span>
                    )}
                    {e.cancelled_at && (
                      <span className={`inline-flex items-center gap-0.5 text-[9px] font-button font-semibold px-1.5 py-0.5 rounded-md shrink-0 ${e.is_no_show ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'}`}>
                        <XCircle size={9}  aria-hidden="true" /> {e.is_no_show ? 'No Show' : 'Cancelled'}
                      </span>
                    )}
                    {!e.trip_id && !activeGroup && (
                      <span
                        title={isGeneralContactMessage(e) ? 'A "Contact Us" message from the website — not linked to any trip' : 'Logged without picking a trip'}
                        className="inline-flex items-center gap-0.5 text-[9px] font-button font-semibold px-1.5 py-0.5 rounded-md bg-slate-100 text-dark-muted shrink-0"
                      >
                        <MessageCircle size={9}  aria-hidden="true" /> General
                      </span>
                    )}
                  </p>
                  <div className="flex items-center gap-2 shrink-0">
                    {followUpStatus(e)?.isDue && (
                      <span title={followUpStatus(e)!.label} className={`inline-flex items-center gap-1 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${followUpStatus(e)!.color}`}>
                        <CalendarClock size={12} className="shrink-0" aria-hidden="true" />
                      </span>
                    )}
                    {bookingFollowUpStatus(e)?.isDue && (
                      <span title={bookingFollowUpStatus(e)!.label} className={`inline-flex items-center gap-1 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${bookingFollowUpStatus(e)!.color}`}>
                        <CalendarClock size={12} className="shrink-0" aria-hidden="true" />
                      </span>
                    )}
                    <span title={closedReasonLabel(e) ? `Booking Journey: ${jb.label} — ${closedReasonLabel(e)}` : `Booking Journey: ${jb.label}`} className={`inline-flex items-center gap-1 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${jb.color}`}>
                      <jb.icon size={12} className="shrink-0" aria-hidden="true" />
                      {jb.label}
                    </span>
                    <ChevronDown size={16} className={`text-dark-muted transition-transform ${isOpen ? 'rotate-180' : ''}`} aria-hidden="true" />
                  </div>
                </div>
                <p className="text-dark-muted text-xs truncate mt-0.5">{e.phone}</p>
                <div className="w-full flex items-center flex-nowrap gap-1.5 mt-1.5 overflow-x-auto no-scrollbar">
                  {paymentFilterKey(e) === 'partial' && paymentBalance(e) != null && (
                    <span className="inline-flex items-center text-[10px] font-button font-semibold px-1.5 py-0.5 rounded-md whitespace-nowrap bg-green-100 text-green-700 shrink-0">
                      Due {formatPrice(paymentBalance(e)!)}
                    </span>
                  )}
                  {e.group_size && e.group_size > 1 ? (
                    <span
                      title={`${groupLabel(e)} — part of a group booking of ${e.group_size}`}
                      className={`inline-flex items-center gap-0.5 text-[10px] font-button font-semibold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap ${clr ? clr.badge : 'bg-slate-100 text-dark-muted'}`}
                    >
                      <Users size={9}  aria-hidden="true" /> {groupLabel(e).replace(/^Group /, '')} · {e.group_seq}/{e.group_size}
                    </span>
                  ) : (
                    <span
                      title="Booked individually, not part of a group"
                      className="inline-flex items-center gap-0.5 text-[10px] font-button font-semibold px-1.5 py-0.5 rounded-md shrink-0 whitespace-nowrap bg-slate-100 text-dark-muted"
                    >
                      <User size={9}  aria-hidden="true" /> Solo
                    </span>
                  )}
                  {e.has_child_addon && (
                    <span
                      title="A Child Fare add-on has been added to this booking"
                      className="inline-flex items-center gap-0.5 text-[10px] font-button font-semibold px-1.5 py-0.5 rounded-md whitespace-nowrap bg-amber-50 text-amber-700 shrink-0"
                    >
                      <Baby size={9} aria-hidden="true" /> Child
                    </span>
                  )}
                </div>
              </button>
              </div>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 border-t border-background-warm space-y-3">
                  <div className="grid grid-cols-2 gap-x-3 gap-y-3 pt-3 pb-3 border-b border-background-warm">
                    <div className="flex items-center gap-2.5 min-w-0">
                      {e.phone ? (
                        <a
                          href={`tel:${e.phone}`}
                          title={`Call ${e.full_name}`}
                          aria-label={`Call ${e.full_name}`}
                          className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0 hover:bg-primary hover:text-white transition-colors"
                          onClick={ev => ev.stopPropagation()}
                        >
                          <PhoneIcon size={15} aria-hidden="true" />
                        </a>
                      ) : (
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <PhoneIcon size={15} aria-hidden="true" />
                        </span>
                      )}
                      <div className="min-w-0">
                        <p className="text-dark-muted text-xs">Phone</p>
                        <p className="text-dark text-sm truncate">{e.phone}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5 min-w-0">
                      {e.email ? (
                        <a
                          href={`mailto:${e.email}`}
                          title={`Email ${e.full_name}`}
                          aria-label={`Email ${e.full_name}`}
                          className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0 hover:bg-primary hover:text-white transition-colors"
                          onClick={ev => ev.stopPropagation()}
                        >
                          <EnvelopeSimple size={15} aria-hidden="true" />
                        </a>
                      ) : (
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <EnvelopeSimple size={15} aria-hidden="true" />
                        </span>
                      )}
                      <div className="min-w-0">
                        <p className="text-dark-muted text-xs">Email</p>
                        <p className="text-dark text-sm truncate">{e.email}</p>
                      </div>
                    </div>
                  </div>

                  <div className="divide-y divide-background-warm">
                    {/* Trip (3.8) — spelled out explicitly, including
                        the no-trip case, instead of only being
                        inferable from which Trip filter group the
                        admin happens to be scoped to. */}
                    <div className="grid grid-cols-2 gap-x-3 gap-y-3 py-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <Briefcase size={15}  aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">Trip</p>
                          <p className="text-dark text-sm truncate">
                            {e.trip_id ? e.trip_title : (
                              <span className="text-dark-muted italic">
                                {isGeneralContactMessage(e) ? 'None — Contact Us message' : 'None — logged without a trip'}
                              </span>
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <User size={15}  aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">Age</p>
                          <p className="text-dark text-sm truncate">{e.age ?? '—'}</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-x-3 gap-y-3 py-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <Building2 size={15}  aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">City</p>
                          <p className="text-dark text-sm truncate">{e.city || '—'}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <Utensils size={15}  aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">Food Preference</p>
                          <p className={`text-sm truncate flex items-center gap-1 ${
                            e.food_preference === 'veg' ? 'text-green-700 font-medium' : e.food_preference === 'non_veg' ? 'text-red-700 font-medium' : 'text-dark'
                          }`}>
                            {(e.food_preference === 'veg' || e.food_preference === 'non_veg') && <FoodMark type={e.food_preference} size={11} />}
                            {e.food_preference === 'veg' ? 'Veg' : e.food_preference === 'non_veg' ? 'Non-veg' : '—'}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-x-3 gap-y-3 py-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <CalendarDays size={15}  aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">Date &amp; Time</p>
                          <p className="text-dark text-sm truncate">{formatDate(e.created_at, { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                          <p className="text-dark-muted text-xs truncate">{formatTime(e.created_at)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          <Globe size={15}  aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">Source</p>
                          <p className="text-dark text-sm truncate">{srcCfg.label}</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-x-3 gap-y-3 py-3 items-center">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0">
                          {e.package_type === 'early_bird' ? <Bird size={15}  aria-hidden="true" /> : <Package size={15}  aria-hidden="true" />}
                        </span>
                        <div className="min-w-0">
                          <p className="text-dark-muted text-xs">Package</p>
                          <p className="text-dark text-sm truncate">{PACKAGE_CONFIG[e.package_type || 'normal'].label}</p>
                        </div>
                      </div>
                      {e.phone && (
                        <div className="flex items-center gap-2.5 min-w-0">
                          <a
                            href={getWhatsAppLink(e.phone, `Hi ${e.full_name.trim().split(/\s+/)[0]}, following up on your ${e.trip_title ? `${e.trip_title} ` : ''}enquiry with ULAA — `)}
                            target="_blank"
                            rel="noopener noreferrer"
                            title={`Message ${e.full_name} on WhatsApp`}
                            aria-label={`Message ${e.full_name} on WhatsApp`}
                            className="w-9 h-9 rounded-full bg-primary/10 text-primary inline-flex items-center justify-center shrink-0 hover:bg-primary hover:text-white transition-colors"
                            onClick={ev => ev.stopPropagation()}
                          >
                            <WhatsAppGlyph size={15} />
                          </a>
                          <div className="min-w-0">
                            <p className="text-dark-muted text-xs">WhatsApp</p>
                            <p className="text-dark text-sm truncate">{e.phone}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Payment summary — desktop's table has a whole clickable
                      Payment column (amount paid / total + status label);
                      mobile only ever showed a "Due ₹X" chip for the partial
                      case specifically, so a fully paid, unpaid, or
                      not-yet-priced booking showed no payment info at all
                      here. This mirrors the desktop cell and opens the same
                      payment modal on tap — except on a brand-new,
                      uncontacted enquiry, where it mirrors the desktop
                      cell's other branch instead: no button, no click,
                      just a title nudging toward Mark Contacted, so this
                      tile can't silently bypass the Contact Outcome step
                      the kebab's "Add Payment" item already guards against
                      just below. */}
                  {e.journey_stage === 'new_enquiry' ? (
                    <div
                      title="Mark this enquiry Contacted first to record a payment"
                      className="w-full bg-background-warm/50 rounded-md px-3 py-2.5 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-dark-muted text-xs">Payment</p>
                        <p className="text-dark text-sm font-medium truncate">
                          {formatPrice(e.amount_paid || 0)}{e.total_amount ? ` / ${formatPrice(e.total_amount)}` : ''}
                        </p>
                      </div>
                      <span className={`shrink-0 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${paymentStatus(e).color}`}>
                        {paymentStatus(e).label}
                      </span>
                    </div>
                  ) : (
                    <button
                      onClick={() => openPayment(e)}
                      className="w-full text-left bg-background-warm/50 hover:bg-background-warm rounded-md px-3 py-2.5 transition-colors flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <p className="text-dark-muted text-xs">Payment</p>
                        <p className="text-dark text-sm font-medium truncate">
                          {formatPrice(e.amount_paid || 0)}{e.total_amount ? ` / ${formatPrice(e.total_amount)}` : ''}
                        </p>
                      </div>
                      <span className={`shrink-0 text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${paymentStatus(e).color}`}>
                        {paymentStatus(e).label}
                      </span>
                    </button>
                  )}

                  {e.message && (
                    <div>
                      <p className="text-dark-muted text-xs">Notes</p>
                      <p className="text-dark text-sm">{e.message}</p>
                    </div>
                  )}

                  {paymentFilterKey(e) === 'partial' && paymentBalance(e) != null && (
                    <div className="bg-amber-50 rounded-md px-3 py-2">
                      <p className="text-amber-700 text-xs font-medium">Balance due: {formatPrice(paymentBalance(e)!)}</p>
                    </div>
                  )}

                  {refundStatus(e) && (
                    <div className={`rounded-md px-3 py-2 ${refundStatus(e)!.color}`}>
                      <p className="text-xs font-medium">{refundStatus(e)!.label}</p>
                    </div>
                  )}

                  {e.booking_id && (
                    <div className="flex items-center justify-between bg-background-warm rounded-md px-3 py-2">
                      <div className="min-w-0">
                        <p className="text-dark-muted text-[10px]">Booking ID</p>
                        <p className="text-dark text-xs font-mono truncate">{e.booking_id}</p>
                      </div>
                      {/* Each button's disabled check is scoped to its own
                          action — downloading shouldn't grey out Share or
                          Email on the same row, since each does its own
                          independent payments-ledger fetch. */}
                      <div className="flex items-center gap-3 shrink-0">
                        <button
                          onClick={() => handleDownloadInvoice(e)}
                          disabled={invoiceBusy?.id === e.id && invoiceBusy.action === 'download'}
                          title="Download invoice"
                          aria-label="Download invoice"
                          className="p-2 -m-1 text-primary hover:text-primary-dark disabled:opacity-50"
                        >
                          <FileText size={16}  aria-hidden="true" />
                        </button>
                        <button
                          onClick={() => handleShareInvoice(e)}
                          disabled={invoiceBusy?.id === e.id && invoiceBusy.action === 'share'}
                          title="Share invoice"
                          aria-label="Share invoice"
                          className="p-2 -m-1 text-primary hover:text-primary-dark disabled:opacity-50"
                        >
                          <Share2 size={16}  aria-hidden="true" />
                        </button>
                        {e.email && (
                          <button
                            onClick={() => handleSendBookingEmail(e)}
                            disabled={invoiceBusy?.id === e.id && invoiceBusy.action === 'email'}
                            title="Email booking confirmation"
                            aria-label="Email booking confirmation"
                            className="p-2 -m-1 text-primary hover:text-primary-dark disabled:opacity-50"
                          >
                            <EnvelopeSimple size={16}  aria-hidden="true" />
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Action row — Follow-up chip (if applicable) +
                      Journey Advance (the one obvious next step for
                      this row, e.g. "Mark Contacted" on a fresh lead)
                      + the primary "View Full CRM" CTA + kebab. Journey
                      Advance used to only live inside the kebab, which
                      buried the single highest-leverage action for a
                      New Enquiry card behind Record Payment/Edit/View/
                      Not Interested/Delete — now it gets the same
                      visible-chip treatment as Set Follow-up, ahead of
                      View Full CRM (a navigation action, not a
                      forward-moving one). Record Payment, Edit Details,
                      View Details, Not Interested, and Delete remain in
                      the kebab so the row doesn't have to fit every
                      possible action inline. Themed to match the
                      "Payment" (outline) / "Add Invoice" (primary)
                      buttons on the enquiry detail page — same Button
                      component, same size, same variants — so the
                      list and detail views feel consistent. */}
                  {/* flex-wrap so a New Enquiry (Follow-up n/a) still
                      fits Mark Contacted + View Full CRM + kebab on one
                      line, while a Contacted lead with both a Follow-up
                      chip and Log Call Outcome showing at once wraps to
                      a second line instead of squeezing four controls
                      into an unreadable row. Kebab stays shrink-0 so it
                      never grows/shrinks with the wrap. */}
                  <div className="flex items-center gap-2 pt-3 flex-wrap">
                    {(followUpStatus(e) || canSetFollowUp(e) || bookingFollowUpStatus(e) || canSetBookingFollowUp(e)) && (
                      <Button
                        variant={
                          followUpStatus(e)?.isOverdue || bookingFollowUpStatus(e)?.isOverdue ? 'outlineDanger'
                          : followUpStatus(e) || bookingFollowUpStatus(e) ? 'secondary'
                          : 'primary'
                        }
                        size="sm"
                        onClick={() => (followUpStatus(e) || canSetFollowUp(e) ? openFollowUpModal(e) : setBookingFollowUpTarget(e))}
                        disabled={updating === e.id}
                        className="flex-1 min-w-[140px] text-xs !gap-1.5 whitespace-nowrap"
                      >
                        <CalendarClock size={14}  aria-hidden="true" />
                        {followUpStatus(e)?.label || bookingFollowUpStatus(e)?.label || 'Set Follow-up'}
                      </Button>
                    )}
                    {nma && (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleAdvance(e)}
                        disabled={updating === e.id}
                        className="flex-1 min-w-[140px] text-xs !gap-1.5 whitespace-nowrap"
                      >
                        <nma.icon size={14} aria-hidden="true" />
                        {nma.label}
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate(`/admin/enquiries/${e.id}`)}
                      className="flex-1 min-w-[140px] text-xs !gap-1.5 whitespace-nowrap"
                    >
                      View Full CRM <ArrowRight size={14}  aria-hidden="true" />
                    </Button>
                    <div className="shrink-0">
                      <ActionsMenu
                        disabled={updating === e.id}
                        items={[
                          // Hidden entirely on a fresh New Enquiry row —
                          // recording a payment here was a silent bypass
                          // around the Contact Outcome step (no notes, no
                          // "why they're interested" captured), even
                          // though the visible "Mark Contacted" chip
                          // already owns that leg. Once contacted (or
                          // later), the item comes back so an admin who
                          // already logged the outcome can still add a
                          // payment from the kebab instead of opening the
                          // full CRM page.
                          ...(e.journey_stage === 'new_enquiry' ? [] : [{
                            // Labelled the same as the equivalent button on
                            // the enquiry detail page (AdminEnquiryJourneyCard):
                            // 'Add Payment' implies a balance still owed,
                            // 'Add Charge' once the booking's Paid in full,
                            // where this same action only ever adds a fresh
                            // charge (a hotel upgrade, etc), never fills a
                            // balance.
                            label: paymentFilterKey(e) === 'paid' ? 'Add Charge' : 'Add Payment',
                            icon: IndianRupee,
                            onClick: () => openPayment(e),
                          }]),
                          ...buildRowActions(e),
                        ]}
                      />
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Mobile: same "Showing X–Y of N" + Prev/Next/page-number
          pagination the desktop table gets — previously mobile had
          no way to reach page 2+ at all. Wrapped in its own card so
          it reads as a distinct, easy-to-find control at the end of
          the list rather than bare text. */}
      <MobilePaginationFooter
        rangeStart={enquiriesRangeStart}
        rangeEnd={enquiriesRangeEnd}
        total={totalFiltered}
        itemLabel="enquiries"
        currentPage={enquiriesSafePage}
        totalPages={enquiriesTotalPages}
        onPageChange={setCurrentPage}
      />
    </>
  );
}
