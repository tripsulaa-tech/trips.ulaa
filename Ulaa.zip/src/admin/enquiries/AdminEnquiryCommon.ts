// Shared, purely presentational/data helpers used by both AdminEnquiries
// (the list/table view) and AdminEnquiryDetail (the single-enquiry CRM
// page) — kept in their own module (rather than exported from
// AdminEnquiries.tsx directly) so:
//   1. Fast Refresh keeps working on both admin pages (a component file
//      that also exports plain constants/functions breaks it).
//   2. AdminEnquiryDetail doesn't need to pull in the entire Enquiries
//      table component just to reuse a badge/label helper.
// Everything here is intentionally stateless — no hooks, no local state —
// so it's safe to call from anywhere. The two actual components that once
// lived alongside these helpers (BookingLifecycleStepper,
// JourneyLifecycleLegend) now live in ./AdminEnquiryLifecycle for the same
// Fast Refresh reason — a file can only be one or the other, not both.
import {
  Clock,
  ArrowsClockwise as RefreshCw,
  Hourglass,
  CurrencyInr as IndianRupee,
  CheckCircle as CheckCircle2,
  Warning as AlertTriangle,
  SealCheck as BadgeCheck,
  SignIn as LogIn,
  Confetti as PartyPopper,
  XCircle,
  Globe,
  ChatCircle as MessageCircle,
  Phone,
  Camera,
  MapPin,
  Question as HelpCircle,
  UserMinus,
  CalendarDot as CalendarClock,
} from '@phosphor-icons/react';
import type { BookingFollowUpType, CancellationReason, ClosedReason, ContactOutcome, Enquiry, Payment, UpcomingTrip } from '../../types/types-index';
import { formatDate } from '../../utils/utils-index';
import { FOOD_PREFERENCE_OPTIONS, foodPreferenceBadge } from '../../constants/foodPreference';

export { FOOD_PREFERENCE_OPTIONS };

// Parses a money-field <input type="number"> value into a non-negative
// number, or '' if the field is empty. The HTML `min={0}` attribute on
// these inputs is a visual hint only — some browsers still hand back a
// negative number from a programmatic read (e.g. typing "-5000" and
// tabbing away without the browser's spinner/blur clamp kicking in), so
// every money field routes through this instead of a bare `+e.target.value`.
export function parseNonNegative(raw: string): number | '' {
  if (raw === '') return '';
  const n = Number(raw);
  if (Number.isNaN(n)) return '';
  return Math.max(0, n);
}

// Placeholder for a payment/refund reference-number field: disabled with
// "N/A for cash" when the method is Cash, otherwise an example reference
// format. Shared so the Cash-check stays in one place across every
// payment/refund UTR field (Add Enquiry, Payment, Refund, Generate
// Invoice, Mark Paid modals).
export function refPlaceholder(method: string | undefined, example: string): string {
  return method === 'Cash' ? 'N/A for cash' : example;
}

export const PACKAGE_CONFIG = {
  early_bird: { label: 'Early Bird', color: 'bg-purple-100 text-purple-700' },
  normal: { label: 'Normal', color: 'bg-slate-100 text-slate-700' },
} as const;

export const PACKAGE_OPTIONS = [
  { value: 'normal', label: 'Normal Price' },
  { value: 'early_bird', label: 'Early Bird' },
];

// Display label for every invoice/payment-ledger type, including the ones
// only ever set server-side (booking_amount) — used wherever a raw
// payment_type value needs to read as a human label (Invoices list, Generate
// Invoice modal).
export const INVOICE_TYPE_LABEL: Record<Payment['payment_type'], string> = {
  booking_amount: 'Booking Amount',
  installment: 'Installment',
  balance: 'Balance',
  refund: 'Refund',
  full_payment: 'Full Payment',
  advance: 'Advance',
  addon: 'Add-on',
};

// Types the admin can pick in the Payment modal's Type dropdown. Refund
// isn't offered here — it already has its own dedicated flow in the Cancel
// Booking / Payment modal (recordRefund), which accounts for
// cancellation/no-show rules that a plain invoice type doesn't know about.
type GenerateInvoiceType = 'full_payment' | 'advance' | 'balance' | 'installment' | 'addon';

const GENERATE_INVOICE_TYPE_OPTIONS: { value: GenerateInvoiceType; label: string }[] = [
  { value: 'full_payment', label: 'Full Payment' },
  { value: 'advance', label: 'Advance' },
  { value: 'balance', label: 'Balance' },
  { value: 'installment', label: 'Installment' },
  { value: 'addon', label: 'Add-on' },
];

export const GENERATE_INVOICE_STATUS_OPTIONS: { value: 'paid' | 'pending'; label: string }[] = [
  { value: 'paid', label: 'Paid now — money already collected' },
  { value: 'pending', label: 'Pending — invoice only, collect later' },
];

// Which one of the three invoice buttons (Download / Share / Email) is
// currently in flight. Tracked per-action rather than as a single shared
// boolean/id so clicking one doesn't grey out the other two — each does
// its own independent payments-ledger fetch, so there's no reason a
// Download in progress should block Share or Email on the same row.
export type InvoiceAction = 'download' | 'share' | 'email';

export type PaymentForm = {
  package_type: Enquiry['package_type'];
  // Kept as the actual amount owed (list price - discount_amount, or the
  // free-typed value on a no-trip enquiry) — every existing consumer below
  // (outstandingBalance, availablePaymentTypeOptions, validatePaymentForm) reads
  // this unchanged. The modal computes it from discount_amount whenever the
  // enquiry has a trip; see computeDiscountedTotal.
  total_amount: number | '';
  // Flat ₹ off the trip's list price — what the admin now edits instead of
  // total_amount directly, when a trip (and so a list price) is linked.
  discount_amount: number | '';
  discount_reason: string;
  // This transaction's own amount — not a running total. Matches Generate
  // Invoice's "Amount" field: the admin enters what's coming in right now,
  // and picks payment_type directly below, the same way Generate Invoice's
  // Type dropdown works. recordPayment still does delta/running-total math
  // internally (every other caller of it needs that), but the UI here no
  // longer asks the admin to do that addition themselves.
  amount_paid: number | '';
  // Full Payment / Advance / Balance / Installment / Add-on — picked
  // manually here, same options and same meaning as Generate Invoice's Type
  // dropdown (see PAYMENT_TYPE_OPTIONS below, which is now literally
  // GENERATE_INVOICE_TYPE_OPTIONS — one shared list, no risk of the two
  // dropdowns drifting). 'addon' routes through addAddonCharge
  // instead of recordPayment's `type` override (which still only accepts
  // the original four) — see handleSavePayment for the branch.
  payment_type: GenerateInvoiceType;
  // Paid now vs pending — same meaning and same options
  // (GENERATE_INVOICE_STATUS_OPTIONS) as Generate Invoice's Status dropdown.
  // 'pending' raises an invoice without touching amount_paid (via
  // generatePendingInvoice, or addAddonCharge's collectedNow: false for the
  // addon type), for later settlement with the Mark Paid button in
  // the Invoices list — same as Generate Invoice, Track Payment just also
  // lets that pending invoice ride alongside a total/package/food edit.
  status: 'paid' | 'pending';
  // Payment Method / UTR — CRM spec sections 6/9/47: how this payment leg
  // (the amount_paid change above) was actually settled, and its bank/UPI
  // reference. Optional — only meaningful when status is 'paid' and
  // amount_paid actually changes; recordPayment/addAddonCharge silently
  // ignore them otherwise.
  payment_method: string;
  payment_utr: string;
  refund_amount: number | '';
  // Refund Method / Refund UTR / Refund Date / Notes — CRM spec section 7's
  // Refund Popup fields, only meaningful (and only shown) alongside
  // refund_amount on a cancelled booking. refund_date defaults to today
  // when the field is touched; left '' it falls back to recordRefund's own
  // now() default.
  refund_method: string;
  refund_utr: string;
  refund_date: string;
  refund_notes: string;
  food_preference: 'veg' | 'non_veg' | '';
  // Free-text note on this transaction — same field/meaning as Generate
  // Invoice's Notes, now folded into Track Payment now that it's the one
  // consolidated Payment flow. Also carries the "Child fare" preset (see
  // the Child Fare chip in PaymentFormFields) that flips has_child_addon.
  notes: string;
};

// Same types Generate Invoice offers, including Add-on and the
// paid/pending Status (refund is still excluded — it has its own dedicated,
// cancellation-aware flow here in Track Payment's cancelled-booking
// section). Literally the same array as GENERATE_INVOICE_TYPE_OPTIONS now —
// aliased under this name so Track Payment's imports/intent stay readable —
// so wording can never drift between the two dropdowns.
const PAYMENT_TYPE_OPTIONS: { value: PaymentForm['payment_type']; label: string }[] = GENERATE_INVOICE_TYPE_OPTIONS;

// Shared helpers for the Payment form (PaymentForm) below.
// List price minus a flat discount, floored at 0 so a discount bigger than
// the list price never produces a negative total. `listPrice` is undefined
// when the trip (or its price for this package) isn't set yet — callers
// fall back to whatever total_amount already holds in that case.
export function computeDiscountedTotal(listPrice: number | undefined, discountAmount: number | ''): number | undefined {
  if (listPrice == null) return undefined;
  const discount = discountAmount === '' ? 0 : Number(discountAmount);
  return Math.max(0, listPrice - discount);
}

// What's left owing on the booking's total, before this transaction — null
// when there's no total_amount set yet to owe anything against. Used both
// to decide whether 'Balance' should even be offered as a Payment Type
// (only makes sense once something is actually still owed), and to
// auto-fill Amount Being Paid Now the moment it's picked — see the Payment
// Type onChange in PaymentFormFields, which mirrors 'Full Payment's
// existing auto-fill the same way.
function outstandingBalance(totalAmount: number | '', alreadyPaid: number): number | null {
  if (totalAmount === '') return null;
  return Math.max(0, Number(totalAmount) - alreadyPaid);
}

// Same list as PAYMENT_TYPE_OPTIONS, minus:
//  - 'Full Payment' and 'Advance' once anything's already been paid — both
//    only make sense as the very first money in on a booking; once that's
//    happened, every further payment is an Installment (or a Balance, once
//    something's still owed), never another "first" payment.
//  - 'Balance', 'Installment', and 'Add-on' on that very first payment
//    (nothing paid yet) — the reverse of the rule above. 'Balance'/
//    'Installment' both imply money's already gone in toward the total,
//    and 'Add-on' implies a booking already exists to add a fresh charge
//    onto; none of that is true before the first rupee lands.
//  - 'Balance' specifically, whenever nothing is actually still owed on
//    the total — see outstandingBalance above. Once offered, picking it
//    auto-fills Amount Being Paid Now with that exact outstanding amount
//    (PaymentFormFields' onChange), so admins no longer need to already
//    know/type the figure for it to appear.
// Callers pair this with an effect that steers payment_type off whichever
// of these it no longer qualifies for (e.g. a second payment still has
// 'Advance' left over from the form's default, or the total/discount is
// edited after 'Balance' was picked), so the Select's current value always
// stays in this list.
export function availablePaymentTypeOptions(paymentForm: PaymentForm, alreadyPaid: number): { value: PaymentForm['payment_type']; label: string }[] {
  if (alreadyPaid <= 0) {
    return PAYMENT_TYPE_OPTIONS.filter(o => o.value === 'full_payment' || o.value === 'advance');
  }
  const options = PAYMENT_TYPE_OPTIONS.filter(o => o.value !== 'advance' && o.value !== 'full_payment');
  const owed = outstandingBalance(paymentForm.total_amount, alreadyPaid);
  if (owed != null && owed > 0) return options;
  if (owed === 0) {
    // Nothing left on the current total, so 'Installment' makes no more
    // sense than 'Balance' does — both imply paying toward an amount still
    // owed. Only 'Add-on' (which raises the total, creating a fresh
    // balance) still applies once the booking is fully paid.
    return options.filter(o => o.value !== 'balance' && o.value !== 'installment');
  }
  // owed === null: total_amount isn't filled in yet, so there's nothing to
  // judge Installment/Balance against — leave the full set on offer.
  return options.filter(o => o.value !== 'balance');
}

// Picks the label a payment SHOULD carry from what it actually does, so the
// admin never has to guess between Installment and Balance (or Advance and
// Full Payment):
//  - nothing paid yet: the whole total in one go = 'Full Payment', anything
//    less = 'Advance'.
//  - something already paid: exactly what's still owed = 'Balance' (the
//    payment that finishes the booking), anything less = 'Installment'.
// Add-on is never touched (it raises the total instead of paying toward it),
// and nothing changes while the amount is blank/zero, the total isn't known,
// or the payment would overshoot (validatePaymentForm reports that). Used
// live in PaymentFormFields as the admin types, and again at save time so
// every entry point lands on the same label.
export function reconcilePaymentType(
  type: PaymentForm['payment_type'],
  thisPayment: number,
  total: number | null,
  alreadyPaid: number
): PaymentForm['payment_type'] {
  if (type !== 'full_payment' && type !== 'advance' && type !== 'balance' && type !== 'installment') return type;
  if (!(thisPayment > 0) || total == null || !(total > 0)) return type;
  if (alreadyPaid <= 0) {
    if (thisPayment === total) return 'full_payment';
    return thisPayment < total ? 'advance' : type;
  }
  const owed = total - alreadyPaid;
  if (owed <= 0) return type;
  if (thisPayment === owed) return 'balance';
  return thisPayment < owed ? 'installment' : type;
}

// Field-level errors for the Track Payment form (formerly AdminPaymentModal,
// now retired — see AdminEnquiries.tsx), keyed by the field each message
// should render under. Shared by both handleSavePayment call sites
// (AdminEnquiries.tsx list view + AdminEnquiryDetail.tsx detail view) as
// the final save-time gate — one source of truth so the two screens can
// never drift on what counts as a valid payment.
type PaymentFormErrors = Partial<Record<
  'amount_paid' | 'payment_method' | 'payment_utr' | 'refund_amount' | 'refund_utr' | 'refund_method',
  string
>>;

export function validatePaymentForm(
  paymentForm: PaymentForm,
  alreadyPaid: number
): PaymentFormErrors {
  const errors: PaymentFormErrors = {};
  const totalAmount = paymentForm.total_amount === '' ? null : Number(paymentForm.total_amount);
  const thisPayment = paymentForm.amount_paid === '' ? 0 : Number(paymentForm.amount_paid);
  const isExtraCharge = paymentForm.payment_type === 'addon';
  const isPending = paymentForm.status === 'pending';
  const newRunningTotal = alreadyPaid + thisPayment;

  // Installment/Balance/Advance/Full Payment can never push the booking
  // past its total — Paid-now and Pending alike, since a Pending invoice is
  // still a claim against the same total, just settled later (see Mark
  // Paid). Add-on is the one exception: it raises the total itself, so
  // there's nothing to clear against yet.
  if (!isExtraCharge && totalAmount != null && thisPayment > 0 && newRunningTotal > totalAmount) {
    errors.amount_paid = 'This would take the amount paid past the total amount.';
  } else if ((isExtraCharge || isPending) && thisPayment <= 0) {
    errors.amount_paid = isExtraCharge
      ? 'Enter an extra charge amount greater than zero.'
      : 'Enter an amount greater than zero for the pending invoice.';
  }

  // Money is actually changing hands right now (not a pending invoice)
  // whenever thisPayment > 0 — whether that's a normal payment or an extra
  // charge collected immediately — so we need to know how.
  if (!isPending && thisPayment > 0 && !paymentForm.payment_method) {
    errors.payment_method = 'Select a payment method.';
  }
  if (!isPending && thisPayment > 0 && paymentForm.payment_method && paymentForm.payment_method !== 'Cash' && !paymentForm.payment_utr.trim()) {
    errors.payment_utr = 'Enter a UTR / reference number.';
  }

  const refundAmount = paymentForm.refund_amount === '' ? 0 : Number(paymentForm.refund_amount);
  if (refundAmount > 0 && !paymentForm.refund_method) {
    errors.refund_method = 'Select a refund method.';
  }
  if (refundAmount > 0 && paymentForm.refund_method && paymentForm.refund_method !== 'Cash' && !paymentForm.refund_utr.trim()) {
    errors.refund_utr = 'Enter a refund UTR / reference number.';
  }
  // Add-on collected now folds straight into amount_paid; Pending
  // never does, whatever the type — so the refund bound uses what
  // amount_paid will actually become, not the naive "already paid + this
  // payment" that only holds for a normal paid-now payment.
  const effectiveAmountPaid = isPending ? alreadyPaid : isExtraCharge ? alreadyPaid + thisPayment : newRunningTotal;
  if (refundAmount > effectiveAmountPaid) {
    errors.refund_amount = "Refund amount can't be more than what was actually paid.";
  }

  return errors;
}

// Same "which price applies" question, but pinned to whichever package the
// admin has explicitly set on the enquiry (Traveller & Trip → Package),
// rather than always following the trip's live early-bird window. This is
// what the "No Payment Yet" preview and the payment-modal suggestion should
// use once a package has been chosen for this enquiry — otherwise editing
// Package to Normal while the trip's early-bird window is still open would
// silently keep showing the early-bird price. Falls back to the trip's
// normal price if the requested package has no price set on the trip.
export function getTripPricingForPackage(
  trip: UpcomingTrip | undefined,
  packageType: Enquiry['package_type']
): { amount: number; isEarlyBird: boolean; deadline?: string | null } | null {
  if (!trip) return null;
  if (packageType === 'early_bird' && trip.early_bird_price != null) {
    return { amount: trip.early_bird_price, isEarlyBird: true, deadline: trip.early_bird_deadline };
  }
  if (trip.price != null) {
    return { amount: trip.price, isEarlyBird: false, deadline: trip.early_bird_deadline };
  }
  return null;
}

// Looks up what a trip actually charges for a given package (early-bird or
// normal). Returns undefined if the trip or that price isn't set. Shared by
// AdminEnquiries.tsx and AdminEnquiryDetail.tsx, which previously each had
// an identical copy of this closed over their own local `trips` state.
export function getTripPrice(
  trips: UpcomingTrip[],
  tripId: string | undefined,
  packageType: Enquiry['package_type']
): number | undefined {
  const trip = trips.find(t => t.id === tripId);
  if (!trip) return undefined;
  const price = packageType === 'early_bird' ? trip.early_bird_price : trip.price;
  return price ?? undefined;
}

// This trip's configured Child Fare Amount (Add/Edit Trip → Finances &
// Profit), used to auto-fill and lock the Add-on Amount field once the
// Child Fare chip is picked in PaymentFormFields — see that component
// for why it's a hard lock with no per-child override.
export function getTripChildFareAmount(trips: UpcomingTrip[], tripId: string | undefined): number | undefined {
  const trip = trips.find(t => t.id === tripId);
  return trip?.trip_finance?.child_fare_amount ?? undefined;
}

// Small inline badge shown next to each enquiry's name — lets an admin spot
// missing food preferences directly in the list, without opening the row.
export function foodBadge(e: Enquiry): { label: string; color: string } {
  return foodPreferenceBadge(e.food_preference);
}

export function foodPreferenceKey(e: Enquiry): 'veg' | 'non_veg' | 'not_set' {
  if (e.food_preference === 'veg') return 'veg';
  if (e.food_preference === 'non_veg') return 'non_veg';
  return 'not_set';
}

export const SOURCE_CONFIG = {
  website: { label: 'Website', icon: Globe },
  whatsapp: { label: 'WhatsApp', icon: MessageCircle },
  phone: { label: 'Phone Call', icon: Phone },
  instagram: { label: 'Instagram', icon: Camera },
  walk_in: { label: 'Walk-in', icon: MapPin },
  other: { label: 'Other', icon: HelpCircle },
} as const;

// Full source list including "Website" — unlike AdminEnquiriesShared's
// SOURCE_OPTIONS (which deliberately omits Website since that form is only
// for enquiries an admin is logging by hand), this is for editing an
// *existing* enquiry, which may already be a website submission.
export const SOURCE_OPTIONS_ALL = (Object.keys(SOURCE_CONFIG) as (keyof typeof SOURCE_CONFIG)[]).map(value => ({
  value,
  label: SOURCE_CONFIG[value].label,
}));

// Single "Booking Journey" badge shown in the table/detail page,
// superseding the old status/booking_status dropdown combination — see
// supabase/migration/add_booking_journey_stage.sql for how each stage is
// derived. journey_stage is guaranteed non-null by the DB once the
// migration has run; the 'new_enquiry' fallback here only guards against a
// stale row read before that migration is applied.
export const JOURNEY_STAGE_CONFIG: Record<Enquiry['journey_stage'], { label: string; color: string; icon: typeof Clock }> = {
  new_enquiry: { label: 'New Enquiry', color: 'bg-blue-100 text-blue-700', icon: Clock },
  contacted: { label: 'Contacted', color: 'bg-amber-100 text-amber-700', icon: RefreshCw },
  advance_pending: { label: 'Advance Pending', color: 'bg-amber-100 text-amber-700', icon: Hourglass },
  advance_paid: { label: 'Advance Paid', color: 'bg-purple-100 text-purple-700', icon: IndianRupee },
  confirmed: { label: 'Confirmed', color: 'bg-teal-100 text-teal-700', icon: CheckCircle2 },
  balance_pending: { label: 'Balance Pending', color: 'bg-orange-100 text-orange-700', icon: AlertTriangle },
  fully_paid: { label: 'Fully Paid', color: 'bg-green-100 text-green-700', icon: BadgeCheck },
  checked_in: { label: 'Checked In', color: 'bg-indigo-100 text-indigo-700', icon: LogIn },
  completed: { label: 'Completed', color: 'bg-green-100 text-green-700', icon: PartyPopper },
  cancelled: { label: 'Cancelled', color: 'bg-red-100 text-red-700', icon: XCircle },
  // A lead that was contacted and said no — closed out before any money
  // changed hands. Distinct from `cancelled` (which is always a booking
  // that had money on it at some point). See add_not_interested_journey_stage.sql.
  not_interested: { label: 'Not Interested', color: 'bg-slate-200 text-dark-muted', icon: UserMinus },
} as const;

export function journeyBadge(e: Enquiry) {
  return JOURNEY_STAGE_CONFIG[e.journey_stage] || JOURNEY_STAGE_CONFIG.new_enquiry;
}

// True when this enquiry was closed out before ever becoming a paying
// booking — i.e. an admin followed up and the person just wasn't
// interested, as opposed to `status: 'closed'` on a booking that actually
// went through (see the Enquiry.status doc comment in types-index.ts: a
// 'closed' lead can mean either "went nowhere" or "fully paid booking").
// Used to show a distinct "Not Interested" badge/action instead of the
// ambiguous generic 'closed' status. Checks journey_stage first (the
// source of truth going forward — see add_not_interested_journey_stage.sql)
// and falls back to the same derived check as before for any row whose
// journey_stage hasn't been refreshed since that migration landed.
export function isNotInterested(e: Enquiry): boolean {
  if (e.journey_stage === 'not_interested') return true;
  return e.status === 'closed' && !e.cancelled_at && (e.amount_paid || 0) <= 0 && !e.booking_id;
}

// Whether "Not Interested" is a valid action on this enquiry right now —
// only before any money's changed hands (once there's a booking_id or a
// payment on record, closing the lead out is a Cancel Booking decision
// instead — different consequences: refunds, seat release, etc) and only
// while it isn't already closed. Shared by the kebab-menu action and the
// inline quick-action button in both AdminEnquiries.tsx and
// AdminEnquiryDetail.tsx so the eligibility rule can't drift between them.
export function canMarkNotInterested(e: Enquiry): boolean {
  return !e.cancelled_at && !e.booking_id && (e.amount_paid || 0) <= 0 && !isNotInterested(e);
}

// Whether a follow-up reminder can be set on this enquiry right now — while
// it's still a live, pre-booked conversation (journey_stage 'contacted',
// 'advance_pending', or 'advance_paid' — the three stages status ===
// 'contacted' can derive to, see computeJourneyStage/computeAutoStatus in
// services/api.ts: status only flips off 'contacted' once amount_paid
// reaches total_amount). Not offered on a fresh lead nobody's spoken to yet
// (nothing to follow up on), nor once the booking's actually confirmed
// (booking_amount reached) or later — those move it past the window
// add_enquiry_follow_up.sql's check constraint allows follow_up_at to be
// set in, and refreshJourneyStage() clears any existing reminder the
// moment that happens.
export function canSetFollowUp(e: Enquiry): boolean {
  return e.journey_stage === 'contacted' || e.journey_stage === 'advance_pending' || e.journey_stage === 'advance_paid';
}

// Shared escalating-urgency computation behind both followUpStatus() and
// bookingFollowUpStatus() below: parses a `YYYY-MM-DD` date-only string
// (no time component) as a local date, compares it to today at midnight,
// and returns the overdue/due-today/upcoming color + isDue/isOverdue flags
// both chips render with. Callers layer their own label text (a bare date
// vs. a Booking Follow-up type + date) on top via `labels`. Pulled out so
// the two call sites can't drift on the color thresholds or day-diff math.
function computeDueStatus(
  dateStr: string,
  labels: { overdue: (dateLabel: string) => string; today: string; upcoming: (dateLabel: string) => string }
): { label: string; color: string; isDue: boolean; isOverdue: boolean } {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [y, m, d] = dateStr.split('-').map(Number);
  const target = new Date(y, (m || 1) - 1, d || 1);
  const diffDays = Math.round((target.getTime() - today.getTime()) / 86400000);
  const dateLabel = formatDate(dateStr, { day: 'numeric', month: 'short', year: undefined });
  if (diffDays < 0) return { label: labels.overdue(dateLabel), color: 'bg-red-100 text-red-700', isDue: true, isOverdue: true };
  if (diffDays === 0) return { label: labels.today, color: 'bg-amber-100 text-amber-700', isDue: true, isOverdue: false };
  return { label: labels.upcoming(dateLabel), color: 'bg-blue-50 text-blue-700', isDue: false, isOverdue: false };
}

// Follow-up reminder chip shown next to a Contacted lead — auto-escalates
// color/label as the date approaches so a due reminder actually reads as
// urgent instead of blending into the row like a plain date would. Compares
// on calendar day only (follow_up_at has no time component), so "today" is
// today regardless of what time the admin looks. Returns null when there's
// no reminder set, so callers can skip rendering the chip entirely.
export function followUpStatus(e: Enquiry): { label: string; color: string; icon: typeof CalendarClock; isDue: boolean; isOverdue: boolean } | null {
  if (!e.follow_up_at) return null;
  const status = computeDueStatus(e.follow_up_at, {
    overdue: (dateLabel) => `Overdue · ${dateLabel}`,
    today: 'Follow up today',
    upcoming: (dateLabel) => `Follow up ${dateLabel}`,
  });
  return { ...status, icon: CalendarClock };
}

// Whether a Booking Follow-up reminder can be set on this enquiry right
// now — CRM spec section 8B: only after the booking has started (past
// Advance Pending) and while it's still active. Mirrors
// canSetFollowUp() above on the opposite side of the same row's
// lifecycle — the two windows never overlap, enforced by the DB check
// constraints in add_booking_follow_up.sql and the clearing logic in
// refreshJourneyStage() (src/services/api.ts).
export function canSetBookingFollowUp(e: Enquiry): boolean {
  return e.booking_state === 'active' && (
    e.journey_stage === 'advance_pending' || e.journey_stage === 'advance_paid'
    || e.journey_stage === 'confirmed' || e.journey_stage === 'balance_pending'
    || e.journey_stage === 'fully_paid' || e.journey_stage === 'checked_in'
  );
}

// Whether "Cancel Booking" should be offered right now — CRM spec section
// 18's Cancellation Rules: only once a booking has actually started (past
// Advance Pending), and only until the traveller checks in or the trip
// completes. Previously the UI offered Cancel Booking on any non-completed,
// non-checked-in row — including a brand-new lead nobody's even contacted
// yet, which the spec explicitly calls out as not allowed ("Cannot cancel
// because customer has not agreed to book yet"). cancelEnquiry() in
// services/api.ts enforces the same rule server-side as a backstop. Does
// NOT cover the "already cancelled -> offer Reactivate instead" case —
// callers check e.cancelled_at separately for that, same as before.
export function canCancelBooking(e: Enquiry): boolean {
  if (e.cancelled_at || e.checked_in_at || e.journey_stage === 'completed') return false;
  return e.journey_stage !== 'new_enquiry' && e.journey_stage !== 'contacted' && e.journey_stage !== 'not_interested';
}

// Human-readable label for each Booking Follow-up type — see
// BookingFollowUpType in types-index.ts.
export const BOOKING_FOLLOW_UP_TYPE_CONFIG: Record<BookingFollowUpType, { label: string }> = {
  balance_payment: { label: 'Balance Payment Reminder' },
  document: { label: 'Document Reminder' },
  passport: { label: 'Passport Reminder' },
  medical_declaration: { label: 'Medical Declaration' },
  final_itinerary: { label: 'Final Itinerary Reminder' },
  other: { label: 'Other' },
};

// Which Booking Follow-up types make sense for THIS booking right now —
// not every type in BOOKING_FOLLOW_UP_TYPE_CONFIG applies at every
// journey_stage. Balance Payment Reminder only makes sense while there's
// still a balance to chase; once it's cleared (fully_paid/checked_in)
// offering it is misleading, same reasoning as the "Add Charge" vs "Add
// Payment" relabel on the detail page. The rest (document/passport/
// medical declaration/final itinerary/other) aren't tied to payment
// state, so they stay available for the whole active-booking window that
// canSetBookingFollowUp() already gates — no per-stage filtering needed
// there.
export function availableBookingFollowUpTypes(e: Enquiry): BookingFollowUpType[] {
  const balanceCleared = e.journey_stage === 'fully_paid' || e.journey_stage === 'checked_in';
  return (Object.keys(BOOKING_FOLLOW_UP_TYPE_CONFIG) as BookingFollowUpType[])
    .filter(t => t !== 'balance_payment' || !balanceCleared);
}

// Booking Follow-up reminder chip — same escalating urgency treatment as
// followUpStatus() above (overdue/today/upcoming), but labelled with what
// the reminder is actually about (e.g. "Balance Payment Reminder") instead
// of a bare date, since that's the whole point of carrying a type here.
// Returns null when no Booking Follow-up is set.
export function bookingFollowUpStatus(e: Enquiry): { label: string; color: string; icon: typeof CalendarClock; isDue: boolean; isOverdue: boolean } | null {
  if (!e.booking_follow_up_at) return null;
  const typeLabel = e.booking_follow_up_type ? BOOKING_FOLLOW_UP_TYPE_CONFIG[e.booking_follow_up_type].label : 'Booking Follow-up';
  const status = computeDueStatus(e.booking_follow_up_at, {
    overdue: (dateLabel) => `${typeLabel} · Overdue · ${dateLabel}`,
    today: `${typeLabel} · Today`,
    upcoming: (dateLabel) => `${typeLabel} · ${dateLabel}`,
  });
  return { ...status, icon: CalendarClock };
}

// Every reason an admin can pick when closing an enquiry out — see
// supabase/migration/add_closed_reason.sql. No plain "Not Interested" entry
// here: the closing action itself already carries that label everywhere
// else in the UI (journey_stage, badge, button), so a same-named reason
// would just restate it without adding information — "Other" is the
// catch-all instead. Order here is the order shown in the picker (most
// common first) and the order used for the reporting breakdown in
// AdminEnquiries.tsx.
const CLOSED_REASON_CONFIG: Record<ClosedReason, { label: string }> = {
  no_response: { label: 'No Response' },
  price_too_high: { label: 'Price Too High' },
  date_conflict: { label: "Date Doesn't Work" },
  destination_changed: { label: 'Destination Changed' },
  booked_elsewhere: { label: 'Booked Elsewhere' },
  // No 'will_join_later' here any more — that was really "still warm,
  // checking with family/friends", which isn't a closed reason at all (see
  // canSetFollowUp / followUpStatus below and add_enquiry_follow_up.sql).
  personal_reason: { label: 'Family / Personal Reason' },
  // Also reachable directly as a Contact Outcome (see CONTACT_OUTCOME_CONFIG
  // below) — kept here too since it's still a closed_reason value under the
  // hood, e.g. for the closed-reason breakdown in reporting.
  wrong_number: { label: 'Wrong Number' },
  other: { label: 'Other' },
};

const CLOSED_REASON_OPTIONS: { value: ClosedReason; label: string }[] =
  (Object.keys(CLOSED_REASON_CONFIG) as ClosedReason[]).map(value => ({
    value,
    label: CLOSED_REASON_CONFIG[value].label,
  }));

// Options offered in the Not Interested reason picker specifically —
// excludes 'wrong_number', which has its own dedicated Contact Outcome and
// would just duplicate it here.
export const NOT_INTERESTED_REASON_OPTIONS = CLOSED_REASON_OPTIONS.filter(
  o => o.value !== 'wrong_number'
);

// Every reason an admin can pick in the Cancel Booking popup — see
// CancellationReason in types-index.ts and add_cancellation_reason.sql.
// No 'no_show' entry: that's captured separately by the no-show checkbox in
// the same popup (attendance is independent of why a booking was
// cancelled — CRM spec section 4).
const CANCELLATION_REASON_CONFIG: Record<CancellationReason, { label: string }> = {
  medical: { label: 'Medical' },
  personal: { label: 'Personal' },
  emergency: { label: 'Emergency' },
  visa: { label: 'Visa' },
  price: { label: 'Price' },
  other: { label: 'Other' },
};

export const CANCELLATION_REASON_OPTIONS: { value: CancellationReason; label: string }[] =
  (Object.keys(CANCELLATION_REASON_CONFIG) as CancellationReason[]).map(value => ({
    value,
    label: CANCELLATION_REASON_CONFIG[value].label,
  }));

// Methods offered when recording any real money movement — a payment
// (Track Payment / Generate Invoice) or a refund (Refund popup). One
// canonical list (CRM spec sections 6/8) instead of two that could drift
// apart; payment_method stays a free-text column on `payments` (same as
// every other payment type), this is just a curated picker so admins
// record a consistent value instead of free-typing "upi"/"UPI"/"Upi"
// differently each time.
export const PAYMENT_METHOD_OPTIONS: { value: string; label: string }[] = [
  { value: 'UPI', label: 'UPI' },
  { value: 'Bank', label: 'Bank Transfer' },
  { value: 'Cash', label: 'Cash' },
  { value: 'Other', label: 'Other' },
];

// Refunds settle through the exact same methods as payments — reuse the
// same canonical list rather than a second, potentially-diverging one.
// (Copied rather than re-exported by reference so this is its own export
// binding, not a duplicate alias of PAYMENT_METHOD_OPTIONS.)
export const REFUND_METHOD_OPTIONS: { value: string; label: string }[] = [...PAYMENT_METHOD_OPTIONS];

// Outcomes offered in the "Record Contact Outcome" popup (see
// ContactOutcomeModal.tsx) — the single entry point for moving a lead from
// New to Contacted. Order here is the order shown in the popup.
export const CONTACT_OUTCOME_CONFIG: Record<ContactOutcome, {
  label: string;
  description: string;
  // What this outcome does to the lead once saved — drives
  // ContactOutcomeModal's conditional fields and recordContactOutcome()'s
  // branching. 'stays_contacted' outcomes always create a Lead Follow-up
  // (follow_up_at/time); 'closed' outcomes always end in status = 'closed'.
  effect: 'advance' | 'stays_contacted' | 'closed';
}> = {
  interested: {
    label: 'Interested',
    description: "Wants to book. Opens Payment to move to Advance Pending.",
    effect: 'advance',
  },
  needs_time: {
    label: 'Needs Time',
    description: 'Checking with family or friends. Stays Contacted with a follow-up reminder.',
    effect: 'stays_contacted',
  },
  call_later: {
    label: 'Call Later',
    description: "Asked for a call back. Stays Contacted with a follow-up reminder.",
    effect: 'stays_contacted',
  },
  payment_arrangement: {
    label: 'Payment Arrangement Needed',
    description: 'Needs time to arrange funds. Stays Contacted with a follow-up reminder.',
    effect: 'stays_contacted',
  },
  no_response: {
    label: 'No Response',
    description: "Didn't pick up. Stays Contacted with a retry reminder.",
    effect: 'stays_contacted',
  },
  not_interested: {
    label: 'Not Interested',
    description: 'Closes this lead. Pick a reason below.',
    effect: 'closed',
  },
  wrong_number: {
    label: 'Wrong Number',
    description: 'Closes this lead as an invalid contact.',
    effect: 'closed',
  },
};

export const CONTACT_OUTCOME_OPTIONS: { value: ContactOutcome; label: string }[] =
  (Object.keys(CONTACT_OUTCOME_CONFIG) as ContactOutcome[]).map(value => ({
    value,
    label: CONTACT_OUTCOME_CONFIG[value].label,
  }));

// Human label for why a closed enquiry didn't convert, or null when it
// either isn't closed or predates add_closed_reason.sql (closed with no
// reason on record). Used to enrich the "Not Interested" badge's tooltip
// without cluttering the badge itself.
export function closedReasonLabel(e: Enquiry): string | null {
  if (!isNotInterested(e) || !e.closed_reason) return null;
  return CLOSED_REASON_CONFIG[e.closed_reason]?.label ?? null;
}

// Counts closed-without-booking enquiries by reason, for the reporting
// strip in AdminEnquiries.tsx (mirrors the "35 closed before booking: 15 no
// response, 10 price..." breakdown). Rows closed before add_closed_reason.sql
// shipped (or bulk-closed without picking a reason) have no closed_reason —
// counted separately as "Unspecified" rather than silently dropped, so the
// breakdown total always matches the Closed tab's count. Zero-count reasons
// are omitted; the list is sorted highest-count first.
export function closedReasonBreakdown(
  enquiries: Enquiry[]
): { label: string; count: number }[] {
  const closed = enquiries.filter(isNotInterested);
  const counts = new Map<string, number>();
  for (const e of closed) {
    const label = e.closed_reason ? CLOSED_REASON_CONFIG[e.closed_reason]?.label : undefined;
    const key = label ?? 'Unspecified';
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return Array.from(counts.entries())
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count);
}

// The one, single manual action that moves a booking's journey forward a
// step — every other transition (Advance Pending -> Advance Paid ->
// Confirmed -> Balance Pending -> Fully Paid) happens automatically as a
// side effect of recording a payment, so there's nothing for a generic
// "next stage" button to do there; it's hidden for those stages instead of
// shown disabled, since the Payment modal is the actual next action.
//
// 'contacted' re-opens the same Record Contact Outcome popup used for the
// New -> Contacted transition — a lead that came back "Needs Time"/"Call
// Later"/"No Response" still needs a way to log what the *next* call
// actually resulted in (Interested, Not Interested, another retry, etc).
// Deliberately stops offering this once total_amount is set (journey_stage
// past 'contacted' — advance_pending/advance_paid/…): at that point Lead
// Management has handed off to Booking Journey (per the CRM spec, Lead
// Management "exists before a booking starts"), and Cancel Booking /
// Payment actions are the right tools instead.
export function nextManualAction(e: Enquiry): { label: string; icon: typeof Clock } | null {
  if (e.cancelled_at) return null;
  switch (e.journey_stage) {
    case 'new_enquiry':
      return { label: 'Mark Contacted', icon: RefreshCw };
    case 'contacted':
      return { label: 'Log Call Outcome', icon: RefreshCw };
    case 'fully_paid':
      return { label: 'Check In', icon: LogIn };
    case 'checked_in':
      return { label: 'Mark Completed', icon: PartyPopper };
    default:
      return null;
  }
}

// BookingLifecycleStepper and JourneyLifecycleLegend (the two actual React
// components that used to live here) now live in ./AdminEnquiryLifecycle —
// this file stays helpers/constants-only so Fast Refresh works on both
// modules (see the file header comment above).
