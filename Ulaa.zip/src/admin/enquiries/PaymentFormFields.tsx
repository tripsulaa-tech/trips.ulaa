// The actual Track Payment field set — split out of AdminEnquiryPaymentModal
// so the exact same fields/validation/behaviour can be rendered two ways:
// inside a Modal (once a booking already exists and the admin is adding a
// further payment) or directly inline on the page (the "No Payment Yet"
// state on AdminEnquiryDetail, before any booking exists — no popup needed
// for the very first payment). Neither caller owns any of this state; it's
// all still lifted to AdminEnquiryDetail, same as before the split.
import { useState } from 'react';
import { Baby, LockSimple, LockSimpleOpen } from '@phosphor-icons/react';
import Select from '../../components/ui/Select';
import type { Enquiry, Payment } from '../../types/types-index';
import { formatPrice } from '../../utils/utils-index';
import MethodReferenceFields from './MethodReferenceFields';
import {
  parseNonNegative, PACKAGE_OPTIONS, GENERATE_INVOICE_STATUS_OPTIONS,
  availablePaymentTypeOptions, computeDiscountedTotal, reconcilePaymentType,
  REFUND_METHOD_OPTIONS, PAYMENT_METHOD_OPTIONS,
} from './AdminEnquiryCommon';
import type { PaymentForm } from './AdminEnquiryCommon';
import PaymentHistoryList from './PaymentHistoryList';

// If a payment would leave no more than this many rupees still owed, the form
// asks the admin whether they meant to settle the whole balance.
const NEAR_BALANCE_THRESHOLD = 100;

export type PaymentErrors = Partial<Record<
  'amount_paid' | 'payment_method' | 'payment_utr' | 'refund_amount' | 'refund_method' | 'refund_utr' | 'notes',
  string
>>;

interface PaymentFormFieldsProps {
  enquiry: Enquiry;
  paymentForm: PaymentForm;
  setPaymentForm: React.Dispatch<React.SetStateAction<PaymentForm>>;
  paymentErrors: PaymentErrors;
  payments: Payment[];
  paymentsLoading: boolean;
  togglingNoShow: boolean;
  onToggleNoShow: (isNoShow: boolean) => void;
  getTripPrice: (tripId: string | undefined, packageType: Enquiry['package_type']) => number | undefined;
  // This trip's configured Child Fare Amount (Add/Edit Trip → Finances &
  // Profit) — drives the auto-fill/hard-lock below. Returns undefined for
  // a no-trip (general) enquiry or a trip with no Child Fare Amount set.
  getTripChildFareAmount: (tripId: string | undefined) => number | undefined;
  idPrefix?: string;
  // Pairs up fields that are otherwise single, full-width rows (Food
  // Preference/Package, Amount Being Paid Now/Payment Type) into a 2-col
  // grid on sm+ screens. Off by default so the narrow payment Modal keeps
  // its single-column layout; the wide inline "No Payment Yet" card on
  // AdminEnquiryJourneyCard turns it on since it has the room to spare.
  compact?: boolean;
}

export default function PaymentFormFields({
  enquiry, paymentForm, setPaymentForm, paymentErrors, payments, paymentsLoading,
  togglingNoShow, onToggleNoShow, getTripPrice, getTripChildFareAmount, idPrefix = 'ed-pay', compact = false,
}: PaymentFormFieldsProps) {
  const paymentErrorClass = 'text-red-500 text-xs mt-1';
  const fieldClass = 'w-full px-3 py-2 rounded-md border-2 border-background-warm bg-white text-sm focus:border-primary outline-none';
  // Only meaningful when a trip is linked — no-trip (general) enquiries
  // have no list price, so they keep the old free-typed Total Amount field.
  const listPrice = enquiry.trip_id ? getTripPrice(enquiry.trip_id, paymentForm.package_type) : undefined;
  // Once a trip is completed it drops out of the upcoming-trips list, so
  // getTripPrice() has no list price to discount from and used to return
  // undefined — the Discount field then saved discount_amount but left
  // total_amount untouched, so the balance never moved (and the "Trip
  // Amount" tile, which adds the discount back, over-reported). In that case
  // work back to the list price from what's already saved on the enquiry
  // (total + the discount it already had), so applying a discount still
  // lowers the total by the right amount.
  const savedListPrice = enquiry.trip_id && enquiry.total_amount != null
    ? enquiry.total_amount + (enquiry.discount_amount || 0)
    : undefined;
  // Child Fare is priced off this trip's configured rate, not a no-trip
  // (general) enquiry — see getTripChildFareAmount's doc comment.
  const tripChildFareAmount = enquiry.trip_id ? getTripChildFareAmount(enquiry.trip_id) : undefined;
  const isChildFare = paymentForm.payment_type === 'addon' && paymentForm.notes === 'Child fare';

  // Keeps Payment Type in step with the amount typed: exactly what's still
  // owed becomes 'Balance', less than that 'Installment' (and, on a first
  // payment, the full total becomes 'Full Payment', less 'Advance'). Runs
  // whenever the amount, total, discount or package changes. Picking a type
  // by hand still works — see the Payment Type Select below.
  const alreadyPaidNow = enquiry.amount_paid || 0;
  const [autoSwitch, setAutoSwitch] = useState<{ type: PaymentForm['payment_type']; text: string } | null>(null);
  const AUTO_SWITCH_TEXT: Partial<Record<PaymentForm['payment_type'], string>> = {
    balance: 'Switched to Balance — this payment clears the full amount owed.',
    installment: 'Switched to Installment — this is less than the balance owed.',
    full_payment: 'Switched to Full Payment — this payment covers the whole total.',
    advance: 'Switched to Advance — this is less than the full total.',
  };
  const updateForm = (patch: (f: PaymentForm) => PaymentForm) => {
    const edited = patch(paymentForm);
    const nextType = reconcilePaymentType(
      edited.payment_type,
      edited.amount_paid === '' ? 0 : Number(edited.amount_paid),
      edited.total_amount === '' ? null : Number(edited.total_amount),
      alreadyPaidNow,
    );
    if (nextType !== edited.payment_type) {
      setAutoSwitch({ type: nextType, text: AUTO_SWITCH_TEXT[nextType] ?? '' });
      setPaymentForm({ ...edited, payment_type: nextType });
    } else {
      setPaymentForm(edited);
    }
  };

  // Amount limit: a normal payment (anything but Add-on) can't be more than
  // what's still owed — the balance once something's been paid, otherwise the
  // whole total. Typing past it snaps back to that figure.
  const totalNum = paymentForm.total_amount === '' ? null : Number(paymentForm.total_amount);
  const remainingOwed = totalNum == null ? null : Math.max(0, totalNum - alreadyPaidNow);
  const capApplies = paymentForm.payment_type !== 'addon' && remainingOwed != null && remainingOwed > 0;
  const capLabel = alreadyPaidNow > 0 ? 'balance owed' : 'total amount';
  const [cappedAtRaw, setCappedAt] = useState<number | null>(null);
  // Only show the 'snapped back' note while it still matches the current limit.
  const cappedAt = cappedAtRaw != null && cappedAtRaw === remainingOwed ? cappedAtRaw : null;
  const amountNow = paymentForm.amount_paid === '' ? 0 : Number(paymentForm.amount_paid);
  // Left after this payment — small but not zero means it's probably a near miss.
  const leftAfter = capApplies ? (remainingOwed as number) - amountNow : null;
  const nearMiss = capApplies && amountNow > 0 && leftAfter != null && leftAfter > 0 && leftAfter <= NEAR_BALANCE_THRESHOLD;
  // space-y-4 in non-compact mode reproduces the original stacked spacing
  // for these two fields; grid+gap-4 in compact mode sits them side by side.
  const pairClass = compact ? 'grid grid-cols-1 sm:grid-cols-2 gap-4' : 'space-y-4';

  // Once money has actually been collected, Package/Discount silently
  // recalculating total_amount is dangerous — it rewrites the price basis
  // of a payment that's already been reconciled. Lock these fields behind
  // an explicit "I understand, let me edit" unlock once amount_paid > 0,
  // rather than letting them stay quietly editable forever.
  const hasPayment = (enquiry.amount_paid || 0) > 0;
  const [pricingUnlocked, setPricingUnlocked] = useState(false);
  const pricingLocked = hasPayment && !pricingUnlocked;

  return (
    <div className="space-y-4">
      {!compact && (
        <div>
          <div className="flex items-center justify-between mb-1">
            <label htmlFor={`${idPrefix}-package`} className="block text-sm font-medium text-dark">Package</label>
            {hasPayment && (
              <button
                type="button"
                onClick={() => setPricingUnlocked(u => !u)}
                className="inline-flex items-center gap-1 text-2xs font-medium text-primary hover:underline"
              >
                {pricingLocked ? <LockSimple size={12} /> : <LockSimpleOpen size={12} />}
                {pricingLocked ? 'Unlock to edit' : 'Lock'}
              </button>
            )}
          </div>
          <Select
            inputId={`${idPrefix}-package`}
            value={paymentForm.package_type}
            disabled={pricingLocked}
            onChange={val => {
              const packageType = val as Enquiry['package_type'];
              const suggested = getTripPrice(enquiry.trip_id, packageType);
              updateForm(f => ({
                ...f,
                package_type: packageType,
                total_amount: enquiry.trip_id
                  ? (computeDiscountedTotal(suggested, f.discount_amount) ?? f.total_amount)
                  : (suggested ?? f.total_amount),
              }));
            }}
            options={PACKAGE_OPTIONS}
          />
          {hasPayment && pricingLocked && (
            <p className="text-2xs text-dark-muted mt-1">
              Already paid {formatPrice(enquiry.amount_paid || 0)} Unlock to recalculate.
            </p>
          )}
        </div>
      )}
      {enquiry.trip_id ? (
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-dark mb-1">List Price (₹)</label>
            <div className={`${fieldClass} bg-background-warm text-dark-muted`}>
              {listPrice != null ? formatPrice(listPrice) : 'Not set'}
            </div>
            <p className="text-2xs text-dark-muted mt-1">Package price before discount.</p>
          </div>
          <div>
            <label htmlFor={`${idPrefix}-discount`} className="block text-sm font-medium text-dark mb-1">Discount (₹)</label>
            <input
              id={`${idPrefix}-discount`}
              type="number"
              min={0}
              value={paymentForm.payment_type === 'addon' ? '' : paymentForm.discount_amount}
              disabled={paymentForm.payment_type === 'addon' || pricingLocked}
              onChange={e => {
                const discount = parseNonNegative(e.target.value);
                updateForm(f => ({ ...f, discount_amount: discount, total_amount: computeDiscountedTotal(listPrice ?? savedListPrice, discount) ?? f.total_amount }));
              }}
              className={`${fieldClass} ${(paymentForm.payment_type === 'addon' || pricingLocked) ? 'opacity-60 cursor-not-allowed' : ''}`}
              placeholder={paymentForm.payment_type === 'addon' ? 'Updates automatically' : 'e.g. 1000'}
            />
          </div>
          <div className="col-span-2">
            <label htmlFor={`${idPrefix}-discount-reason`} className="block text-sm font-medium text-dark mb-1">Discount Reason (optional)</label>
            <input
              id={`${idPrefix}-discount-reason`}
              type="text"
              value={paymentForm.discount_reason}
              disabled={paymentForm.payment_type === 'addon' || pricingLocked}
              onChange={e => setPaymentForm(f => ({ ...f, discount_reason: e.target.value }))}
              className={`${fieldClass} ${(paymentForm.payment_type === 'addon' || pricingLocked) ? 'opacity-60 cursor-not-allowed' : ''}`}
              placeholder="e.g. repeat customer, referral"
            />
          </div>
          {hasPayment && pricingLocked && (
            <div className="col-span-2">
              <p className="text-2xs text-dark-muted -mt-2">
                Already paid {formatPrice(enquiry.amount_paid || 0)} Recalculating changes the balance or refund. Use "Unlock to edit" above Package.
              </p>
            </div>
          )}
          <div className="col-span-2">
            <p className="text-sm text-dark-muted">
              Total Amount: <span className="font-semibold text-dark">{paymentForm.total_amount === '' ? 'Not set' : formatPrice(Number(paymentForm.total_amount))}</span>
            </p>
          </div>
        </div>
      ) : (
        <div>
          <label htmlFor={`${idPrefix}-total`} className="block text-sm font-medium text-dark mb-1">Total Amount (₹)</label>
          <input
            id={`${idPrefix}-total`}
            type="number"
            min={0}
            value={paymentForm.payment_type === 'addon' ? '' : paymentForm.total_amount}
            disabled={paymentForm.payment_type === 'addon'}
            onChange={e => updateForm(f => ({ ...f, total_amount: parseNonNegative(e.target.value) }))}
            className={`${fieldClass} ${paymentForm.payment_type === 'addon' ? 'opacity-60 cursor-not-allowed' : ''}`}
            placeholder={paymentForm.payment_type === 'addon' ? 'Updates automatically' : 'e.g. 15000'}
          />
        </div>
      )}

      <div className={pairClass}>
        <div>
          <label htmlFor={`${idPrefix}-amount-paid`} className="block text-sm font-medium text-dark mb-1">
            {paymentForm.payment_type === 'addon' ? 'Add-on Amount (₹)' : 'Amount Being Paid Now (₹)'}
          </label>
          <input
            id={`${idPrefix}-amount-paid`}
            type="number"
            min={0}
            max={capApplies ? (remainingOwed as number) : undefined}
            value={paymentForm.amount_paid}
            disabled={isChildFare}
            onChange={e => {
              const typed = parseNonNegative(e.target.value);
              if (capApplies && typed !== '' && typed > (remainingOwed as number)) {
                setCappedAt(remainingOwed as number);
                updateForm(f => ({ ...f, amount_paid: remainingOwed as number }));
              } else {
                setCappedAt(null);
                updateForm(f => ({ ...f, amount_paid: typed }));
              }
            }}
            aria-invalid={!!paymentErrors.amount_paid}
            aria-describedby={paymentErrors.amount_paid ? `${idPrefix}-amount-paid-error` : (isChildFare ? `${idPrefix}-amount-paid-childfare-hint` : undefined)}
            className={`${fieldClass} ${isChildFare ? 'opacity-60 cursor-not-allowed' : ''}`}
            placeholder="e.g. 5000"
          />
          {isChildFare && (
            <p id={`${idPrefix}-amount-paid-childfare-hint`} className="text-2xs text-dark-muted mt-1">
              Locked to the trip's Child Fare Amount. Change it under Edit Trip → Finances & Profit.
            </p>
          )}
          {capApplies && !isChildFare && (
            <p className={`text-2xs mt-1 ${cappedAt != null ? 'text-amber-700 font-medium' : 'text-dark-muted'}`}>
              {cappedAt != null
                ? `Can't be more than the ${capLabel} — set to ${formatPrice(cappedAt)}.`
                : `Up to ${formatPrice(remainingOwed as number)} (${capLabel}).`}
            </p>
          )}
          {nearMiss && !isChildFare && (
            <div role="status" className="mt-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-800 flex flex-wrap items-center gap-x-2 gap-y-1">
              <span>
                Only <span className="font-semibold">{formatPrice(leftAfter as number)}</span> would still be owed after this. Did you mean the full {formatPrice(remainingOwed as number)}?
              </span>
              <button
                type="button"
                onClick={() => { setCappedAt(null); updateForm(f => ({ ...f, amount_paid: remainingOwed as number })); }}
                className="font-semibold underline underline-offset-2 hover:text-amber-900"
              >
                Use {formatPrice(remainingOwed as number)}
              </button>
            </div>
          )}
          {paymentErrors.amount_paid && <p id={`${idPrefix}-amount-paid-error`} role="alert" className={paymentErrorClass}>{paymentErrors.amount_paid}</p>}
        </div>

        {/* This transaction's own amount + a manually-picked type — same
            shape as Generate Invoice, rather than a running total the
            label gets inferred from. */}
        <div>
          <label htmlFor={`${idPrefix}-type`} className="block text-sm font-medium text-dark mb-1">Payment Type</label>
          <Select
            inputId={`${idPrefix}-type`}
            value={paymentForm.payment_type}
            onChange={val => {
              const type = val as PaymentForm['payment_type'];
              setAutoSwitch(null);
              setPaymentForm(f => {
                // 'Full Payment' means the whole total is being collected
                // right now — only offered when nothing's been paid yet
                // (see availablePaymentTypeOptions) — and 'Balance' means
                // whatever's still owed is being collected right now — only
                // offered once something is — so both fill in what's owed
                // automatically instead of making the admin look up or
                // retype a number they can already see above/below.
                if ((type === 'full_payment' || type === 'balance') && f.total_amount !== '') {
                  const alreadyPaid = enquiry.amount_paid || 0;
                  return { ...f, payment_type: type, amount_paid: Math.max(0, Number(f.total_amount) - alreadyPaid) };
                }
                return { ...f, payment_type: type };
              });
            }}
            options={availablePaymentTypeOptions(paymentForm, enquiry.amount_paid || 0)}
          />
          {autoSwitch && autoSwitch.type === paymentForm.payment_type && autoSwitch.text && (
            <p className="text-2xs text-green-700 mt-1" role="status">{autoSwitch.text}</p>
          )}
          {paymentForm.payment_type === 'addon' && (
            <>
              <p className="text-2xs text-dark-muted mt-1">
                Added to the booking total immediately (e.g. a hotel upgrade), whether or not it is collected now.
              </p>
              {/* Quick preset for the common case: this traveller wants to
                  bring a child along. Ulaa trips aren't built around kids
                  (no separate child pricing/seat type), so this is just a
                  one-off add-on against an existing enquiry rather than a
                  field on the public booking form — same Add-on mechanism
                  as any other add-on, with the note pre-filled. Unlike
                  every other add-on, the amount here is NOT freely typed —
                  it hard-locks to this trip's configured Child Fare Amount
                  (Add/Edit Trip → Finances & Profit) the moment it's
                  toggled on, with no per-child override, so a Child Fare
                  add-on can never drift from the trip's real vendor/entry-
                  ticket/kit costs feeding the Profit Summary. Disabled
                  entirely until that rate is actually configured. */}
              <button
                type="button"
                disabled={!tripChildFareAmount}
                title={!tripChildFareAmount ? "Set this trip's Child Fare Amount under Add/Edit Trip → Finances & Profit first" : undefined}
                onClick={() => setPaymentForm(f => {
                  const turningOn = f.notes !== 'Child fare';
                  return {
                    ...f,
                    notes: turningOn ? 'Child fare' : '',
                    amount_paid: turningOn ? (tripChildFareAmount ?? f.amount_paid) : f.amount_paid,
                  };
                })}
                aria-pressed={isChildFare}
                className={`inline-flex items-center gap-1.5 mt-2 px-3 py-1.5 rounded-full border-2 text-xs font-medium transition-colors ${
                  isChildFare
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-background-warm text-dark-muted hover:border-primary/40'
                } ${!tripChildFareAmount ? 'opacity-50 cursor-not-allowed hover:border-background-warm' : ''}`}
              >
                <Baby size={13} aria-hidden="true" /> Child Fare
              </button>
              {!tripChildFareAmount && (
                <p className="text-2xs text-dark-muted mt-1">
                  {enquiry.trip_id ? "Set the trip's Child Fare Amount under Edit Trip → Finances & Profit to enable this." : 'No trip linked, so no Child Fare rate is available.'}
                </p>
              )}
            </>
          )}
        </div>
      </div>

      <div className={compact ? 'sm:max-w-[calc(50%-0.5rem)]' : ''}>
        <label htmlFor={`${idPrefix}-status`} className="block text-sm font-medium text-dark mb-1">Status</label>
        <Select
          inputId={`${idPrefix}-status`}
          value={paymentForm.status}
          onChange={val => setPaymentForm(f => ({ ...f, status: val as PaymentForm['status'] }))}
          options={GENERATE_INVOICE_STATUS_OPTIONS}
        />
      </div>

      {paymentForm.status === 'paid' && (
        <div className="grid grid-cols-2 gap-3">
          <MethodReferenceFields
            idPrefix={idPrefix}
            methodLabel="Payment Method"
            value={paymentForm.payment_method}
            onChange={val => setPaymentForm(f => ({ ...f, payment_method: val, payment_utr: val === 'Cash' ? '' : f.payment_utr }))}
            utrValue={paymentForm.payment_utr}
            onUtrChange={val => setPaymentForm(f => ({ ...f, payment_utr: val }))}
            options={PAYMENT_METHOD_OPTIONS}
            utrPlaceholderExample="e.g. 426817XXXXXX"
            inputClassName="w-full px-3 py-2 rounded-md border-2 border-background-warm bg-white text-sm focus:border-primary outline-none"
            methodError={paymentErrors.payment_method}
            utrError={paymentErrors.payment_utr}
            errorClassName={paymentErrorClass}
          />
        </div>
      )}

      {(() => {
        const alreadyPaid = enquiry.amount_paid || 0;
        const thisPayment = paymentForm.amount_paid === '' ? 0 : Number(paymentForm.amount_paid);
        const isExtraCharge = paymentForm.payment_type === 'addon';
        const isPending = paymentForm.status === 'pending';
        const projectedTotal = isPending ? alreadyPaid : alreadyPaid + thisPayment;
        const projectedBookingTotal = isExtraCharge && paymentForm.total_amount !== ''
          ? Number(paymentForm.total_amount) + thisPayment
          : paymentForm.total_amount === '' ? null : Number(paymentForm.total_amount);
        const balance = projectedBookingTotal != null ? projectedBookingTotal - projectedTotal : null;
        const isOverpaid = balance != null && balance < 0;
        return (
          <p className="text-sm text-dark-muted">
            Already paid <span className="font-medium text-dark">{formatPrice(alreadyPaid)}</span>
            {thisPayment > 0 && !isPending && <> · after this payment: <span className="font-semibold text-dark">{formatPrice(projectedTotal)}</span></>}
            {thisPayment > 0 && isPending && <> · <span className="font-semibold text-amber-700">{formatPrice(thisPayment)} raised as pending</span>, not yet counted as paid</>}
            {isExtraCharge && thisPayment > 0 && <> · booking total will rise by <span className="font-semibold text-dark">{formatPrice(thisPayment)}</span></>}
            {balance != null && !isOverpaid && (
              <> · Balance due: <span className="font-semibold text-dark">{formatPrice(balance)}</span></>
            )}
            {isOverpaid && (
              <> · <span className="font-semibold text-red-600">Overpaid by {formatPrice(Math.abs(balance))} — refund needed</span></>
            )}
          </p>
        );
      })()}

      <div>
        <label htmlFor={`${idPrefix}-notes`} className="block text-sm font-medium text-dark mb-1">
          {paymentForm.payment_type === 'addon' ? 'Add-on details' : 'Notes (optional)'}
        </label>
        <input
          id={`${idPrefix}-notes`}
          type="text"
          value={paymentForm.notes}
          onChange={e => setPaymentForm(f => ({ ...f, notes: e.target.value }))}
          className={fieldClass}
          placeholder={paymentForm.payment_type === 'addon' ? 'What is this add-on? e.g. Hotel upgrade, Extra night, Child fare' : 'Any additional context for this payment'}
        />
        {paymentErrors.notes && (
          <p className="text-2xs text-red-600 mt-1" role="alert">{paymentErrors.notes}</p>
        )}
        {paymentForm.payment_type === 'addon' && !paymentErrors.notes && (
          <p className="text-2xs text-dark-muted mt-1">Shown next to this charge in the invoice list, the invoice PDF and the booking email.</p>
        )}
      </div>

      <PaymentHistoryList
        payments={payments}
        loading={paymentsLoading}
        showUtrNumber={false}
        discountAmount={enquiry.discount_amount}
        discountReason={enquiry.discount_reason}
      />

      {enquiry.cancelled_at && (
        <div className="bg-red-50 rounded-md p-3 space-y-2">
          <p className="text-red-700 text-xs font-medium">Booking cancelled. Track any refund here.</p>
          <label className="flex items-start gap-2 text-xs text-dark cursor-pointer bg-white/60 rounded px-2 py-1.5">
            <input
              type="checkbox"
              checked={enquiry.is_no_show}
              disabled={togglingNoShow}
              onChange={ev => onToggleNoShow(ev.target.checked)}
              className="mt-0.5"
            />
            <span>
              Mark as <span className="font-medium">no-show</span>
              <span className="block text-2xs text-dark-muted">No refund for no-shows per policy. Refund is locked to ₹0.</span>
            </span>
          </label>
          {!enquiry.is_no_show && (
            <div>
              <label htmlFor={`${idPrefix}-refund-amount`} className="block text-sm font-medium text-dark mb-1">Refund Amount (₹)</label>
              <input
                id={`${idPrefix}-refund-amount`}
                type="number"
                min={0}
                value={paymentForm.refund_amount}
                onChange={e => setPaymentForm(f => ({ ...f, refund_amount: parseNonNegative(e.target.value) }))}
                aria-describedby={paymentErrors.refund_amount ? `${idPrefix}-refund-amount-error` : undefined}
                className="w-full px-3 py-2 rounded-md border-2 border-background-warm bg-white text-sm focus:border-primary outline-none"
                placeholder="How much has been refunded so far"
              />
              {paymentErrors.refund_amount && <p id={`${idPrefix}-refund-amount-error`} role="alert" className={paymentErrorClass}>{paymentErrors.refund_amount}</p>}
            </div>
          )}
          {!enquiry.is_no_show && (
            <div className="grid grid-cols-2 gap-3">
              <MethodReferenceFields
                idPrefix={`${idPrefix}-refund`}
                methodLabel="Refund Method"
                value={paymentForm.refund_method}
                onChange={val => setPaymentForm(f => ({ ...f, refund_method: val, refund_utr: val === 'Cash' ? '' : f.refund_utr }))}
                utrValue={paymentForm.refund_utr}
                onUtrChange={val => setPaymentForm(f => ({ ...f, refund_utr: val }))}
                options={REFUND_METHOD_OPTIONS}
                utrLabel="Refund UTR / Reference"
                utrPlaceholderExample="e.g. 987654XXXX"
                inputClassName="w-full px-3 py-2 rounded-md border-2 border-background-warm bg-white text-sm focus:border-primary outline-none"
                selectSize="sm"
                methodError={paymentErrors.refund_method}
                utrError={paymentErrors.refund_utr}
                errorClassName={paymentErrorClass}
              />
              <div className="col-span-2">
                <label htmlFor={`${idPrefix}-refund-date`} className="block text-sm font-medium text-dark mb-1">Refund Date</label>
                <input
                  id={`${idPrefix}-refund-date`}
                  type="date"
                  value={paymentForm.refund_date}
                  onChange={e => setPaymentForm(f => ({ ...f, refund_date: e.target.value }))}
                  className="w-full px-3 py-2 rounded-md border-2 border-background-warm bg-white text-sm focus:border-primary outline-none"
                />
              </div>
            </div>
          )}
          {!enquiry.is_no_show && (
            <div>
              <label htmlFor={`${idPrefix}-refund-notes`} className="block text-sm font-medium text-dark mb-1">Refund Notes (optional)</label>
              <textarea
                id={`${idPrefix}-refund-notes`}
                value={paymentForm.refund_notes}
                onChange={e => setPaymentForm(f => ({ ...f, refund_notes: e.target.value }))}
                rows={2}
                className="w-full px-3 py-2 rounded-md border-2 border-background-warm bg-white text-sm focus:border-primary outline-none resize-none"
                placeholder="e.g. partial refund after cancellation charges"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
