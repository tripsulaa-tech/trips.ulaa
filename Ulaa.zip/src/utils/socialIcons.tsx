import type { ReactNode } from 'react';
import {
  Globe,
  Envelope as Mail,
} from '@phosphor-icons/react';

// Founder social links store `platform` as free text (admin types it in),
// so this matches loosely on keywords rather than an exact enum. Anything
// unrecognized falls back to a generic globe/link icon rather than being
// hidden — an admin typing "Blog" or "Website" still gets a sensible icon.
const ICONS: { match: RegExp; icon: (size: number) => ReactNode }[] = [
  {
    match: /insta/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M12 2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.217 2.428.465.66.256 1.216.6 1.772 1.153a4.908 4.908 0 011.153 1.772c.247.637.415 1.363.465 2.428.047 1.066.06 1.405.06 4.122 0 2.717-.01 3.056-.06 4.122-.05 1.065-.218 1.79-.465 2.428a4.883 4.883 0 01-1.153 1.772 4.915 4.915 0 01-1.772 1.153c-.637.247-1.363.415-2.428.465-1.066.047-1.405.06-4.122.06-2.717 0-3.056-.01-4.122-.06-1.065-.05-1.79-.218-2.428-.465a4.89 4.89 0 01-1.772-1.153 4.904 4.904 0 01-1.153-1.772c-.248-.637-.415-1.363-.465-2.428C2.013 15.056 2 14.717 2 12c0-2.717.01-3.056.06-4.122.05-1.066.217-1.79.465-2.428a4.88 4.88 0 011.153-1.772A4.897 4.897 0 015.45 2.525c.638-.248 1.362-.415 2.428-.465C8.944 2.013 9.283 2 12 2zm0 5a5 5 0 100 10 5 5 0 000-10zm0 8.25a3.25 3.25 0 110-6.5 3.25 3.25 0 010 6.5zM17.5 6a1.17 1.17 0 100 2.34A1.17 1.17 0 0017.5 6z" />
      </svg>
    ),
  },
  {
    match: /facebook|\bfb\b/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M22 12.06C22 6.507 17.523 2 12 2S2 6.507 2 12.06c0 5.02 3.657 9.184 8.438 9.94v-7.03H7.898v-2.91h2.54V9.845c0-2.522 1.492-3.916 3.777-3.916 1.094 0 2.238.197 2.238.197v2.475h-1.26c-1.243 0-1.63.775-1.63 1.57v1.888h2.773l-.443 2.91h-2.33V22c4.78-.756 8.437-4.92 8.437-9.94z" />
      </svg>
    ),
  },
  {
    match: /twitter|\bx\.com\b|^x$|\btwitter\/x\b/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
      </svg>
    ),
  },
  {
    match: /linkedin/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.446-2.136 2.94v5.666H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 110-4.124 2.062 2.062 0 010 4.124zM7.114 20.452H3.558V9h3.556v11.452z" />
      </svg>
    ),
  },
  {
    match: /youtube|\byt\b/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12z" />
      </svg>
    ),
  },
  {
    match: /whatsapp/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
      </svg>
    ),
  },
  {
    match: /pinterest/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.784c0-1.671.969-2.917 2.176-2.917 1.026 0 1.522.77 1.522 1.692 0 1.031-.655 2.573-.994 4.001-.283 1.196.599 2.171 1.777 2.171 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.003 2.35-1.494 3.146 1.125.348 2.318.535 3.554.535 6.62 0 11.987-5.367 11.987-11.987C24.005 5.367 18.638 0 12.017 0z" />
      </svg>
    ),
  },
  {
    match: /tiktok/i,
    icon: (size) => (
      <svg viewBox="0 0 24 24" fill="currentColor" width={size} height={size}>
        <path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
      </svg>
    ),
  },
  {
    match: /mail|email/i,
    icon: (size) => <Mail size={size} />,
  },
];

/** Resolves the best-fitting brand icon for a founder/team social link
 *  based on the free-text `platform` field. Falls back to a generic globe. */
export function getSocialIcon(platform: string, size = 16): ReactNode {
  const found = ICONS.find(({ match }) => match.test(platform));
  if (found) return found.icon(size);
  return <Globe size={size} />;
}

// Real brand backgrounds for each platform so the icon reads as "Instagram"/
// "Facebook"/etc. at a glance rather than a generic tinted circle. Matched
// with the same loose keyword regexes as ICONS above; unrecognized platforms
// fall back to a neutral translucent circle.
const BRAND_CLASSES: { match: RegExp; className: string }[] = [
  { match: /insta/i, className: 'bg-gradient-to-tr from-[#FFDC80] via-[#F56040] via-[#C13584] to-[#5851DB]' },
  { match: /facebook|\bfb\b/i, className: 'bg-[#1877F2]' },
  { match: /twitter|\bx\.com\b|^x$|\btwitter\/x\b/i, className: 'bg-black' },
  { match: /linkedin/i, className: 'bg-[#0A66C2]' },
  { match: /youtube|\byt\b/i, className: 'bg-[#FF0000]' },
  { match: /whatsapp/i, className: 'bg-[#25D366]' },
  { match: /pinterest/i, className: 'bg-[#E60023]' },
  { match: /tiktok/i, className: 'bg-black' },
  { match: /mail|email/i, className: 'bg-primary' },
];

/** Resolves the real brand background color/gradient for a social link's
 *  platform, for icon buttons that should read as that brand at a glance.
 *  Falls back to a neutral translucent circle for unrecognized platforms. */
export function getSocialBrandClasses(platform: string): string {
  const found = BRAND_CLASSES.find(({ match }) => match.test(platform));
  return found ? found.className : 'bg-white/10 border border-white/10';
}

// Strips a leading "@" and any leading/trailing slashes from a handle, e.g.
// "@justjini_/" or "/justjini_/" both become "justjini_".
function cleanHandle(value: string): string {
  return value.trim().replace(/^@/, '').replace(/^\/+|\/+$/g, '');
}

// Per-platform rule for turning a bare handle/username/number (whatever an
// admin is likely to paste in without thinking about the full URL) into a
// working link. Only consulted when the stored value ISN'T already a full
// URL/mailto/tel link (see getSocialHref below).
const HREF_BUILDERS: { match: RegExp; build: (value: string) => string }[] = [
  // WhatsApp stores a phone number, not a handle — build a wa.me deep link.
  // Digits only; admin should include the country code (e.g. 9198…) for
  // this to resolve to the right person.
  { match: /whatsapp/i, build: value => `https://wa.me/${value.replace(/\D/g, '')}` },
  // Mail/Gmail/Email store a plain address.
  { match: /mail|email/i, build: value => `mailto:${value}` },
  { match: /insta/i, build: value => `https://instagram.com/${cleanHandle(value)}` },
  { match: /linkedin/i, build: value => `https://www.linkedin.com/in/${cleanHandle(value)}` },
  { match: /facebook|\bfb\b/i, build: value => `https://facebook.com/${cleanHandle(value)}` },
  { match: /twitter|\bx\.com\b|^x$|\btwitter\/x\b/i, build: value => `https://x.com/${cleanHandle(value)}` },
  { match: /youtube|\byt\b/i, build: value => `https://youtube.com/${cleanHandle(value)}` },
  { match: /tiktok/i, build: value => `https://tiktok.com/@${cleanHandle(value).replace(/^@/, '')}` },
  { match: /pinterest/i, build: value => `https://pinterest.com/${cleanHandle(value)}` },
];

/** Resolves a working href for a founder/team social link from whatever the
 *  admin typed into the URL field — a full URL, a bare handle/username
 *  ("justjini_", "@justjini_", "jini-varghese-a57777b1"), or (for WhatsApp)
 *  a phone number. If it's already a full URL/mailto/tel link, it's used
 *  as-is; otherwise it's built using the platform-specific rule above, with
 *  the raw value as a last-resort fallback for unrecognized platforms. */
export function getSocialHref(platform: string, value: string): string {
  const trimmed = value.trim();
  if (!trimmed) return '';
  if (/^(https?:|mailto:|tel:)/i.test(trimmed)) return trimmed;
  const found = HREF_BUILDERS.find(({ match }) => match.test(platform));
  return found ? found.build(trimmed) : trimmed;
}
