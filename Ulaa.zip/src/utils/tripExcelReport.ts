// Styled "ULAA Reports" .xlsx export — the "Export Excel" button on the
// Reports page (see AdminReports.tsx). Unlike handleExportCsv (a plain,
// unstyled CSV meant for a full business-wide data dump), this produces a
// single-trip, presentation-ready workbook: a colored banner, a
// traveler/food-preference summary row, a cost/profit summary row, a
// per-person outstanding-balance table, and an itemized cost breakdown for
// both Organiser Costs and ULAA Costs — the same line items the Add/Edit
// Trip → "Finances & Profit" tab collects and computeTripFinanceSummary
// (utils/tripFinance.ts) rolls up into the two totals shown above. The
// caller (AdminReports.tsx) is responsible for building those line items
// from the trip's raw TripFinance record; this module just lays them out.
//
// Deliberately its own small "spreadsheet layout" module rather than
// reusing toCsvRow/downloadCsv from AdminReports.tsx — those helpers only
// know how to write plain, unstyled text rows, and every cell here needs
// its own fill/border/alignment, which a CSV format has no way to carry.
import writeXlsxFile from 'write-excel-file/browser';
import type { Row } from 'write-excel-file/browser';

export interface CostBreakdownItem {
  label: string;
  amount: number;
}

export interface TripExcelReportRow {
  // The one thing this export needs that the Trip dropdown's UpcomingTrip
  // rows don't carry on their own: a title to put in the banner. Passed
  // in separately (rather than requiring a full UpcomingTrip) so the same
  // renderer works for a completed trip too.
  tripTitle: string;
  travelerCount: number;
  vegCount: number;
  nonVegCount: number;
  revenue: number;
  ulaaCosts: number;
  organiserCosts: number;
  totalCosts: number;
  netProfit: number;
  profitPerPerson: number;
  outstandingByPerson: { name: string; total: number; paid: number; balance: number }[];
  // Line items behind the ulaaCosts / organiserCosts totals above — see
  // AdminReports.tsx's buildExcelRowForTrip for how these are derived from
  // the trip's raw TripFinance record. Each block's own line items are
  // expected to sum to that block's total (ulaaCosts / organiserCosts);
  // the sheet prints a "Total" row using the total passed in directly
  // rather than re-summing, so the two can never silently disagree.
  ulaaCostBreakdown: CostBreakdownItem[];
  organiserCostBreakdown: CostBreakdownItem[];
}

// Palette pulled straight from the reference mockup: a warm terracotta
// banner, a dusty-coral section header, a steel-blue column header, and a
// light grey field behind the whole block so the report reads as one
// self-contained card rather than bare cells floating on a white sheet.
const COLORS = {
  banner: '#B5651D',
  bannerText: '#FFFFFF',
  sectionHeader: '#E0A385',
  columnHeader: '#8DA9C4',
  fieldBackground: '#D9D9D9',
  border: '#B0B0B0',
} as const;

const COLUMN_COUNT = 6;

function blankRow(cols = COLUMN_COUNT): Row {
  return Array.from({ length: cols }, () => ({ value: '', backgroundColor: COLORS.fieldBackground }));
}

// Pads a row of real cells out to COLUMN_COUNT with grey filler cells, so
// e.g. a 4-column table (Name/Total/Paid/Balance) still fills the same
// visual rectangle as the 6-column finance row above it, matching how the
// reference mockup keeps one uniform grey field behind every section
// regardless of how many columns that particular row actually uses.
function padRow(cells: Row): Row {
  const padded = [...cells];
  while (padded.length < COLUMN_COUNT) {
    padded.push({ value: '', backgroundColor: COLORS.fieldBackground });
  }
  return padded;
}

function columnHeaderRow(labels: string[]): Row {
  return padRow(labels.map(label => ({
    value: label,
    backgroundColor: COLORS.columnHeader,
    fontWeight: 'bold',
    align: 'center',
    borderColor: COLORS.border,
    borderStyle: 'thin',
  })));
}

// `type` is deliberately left unset — write-excel-file derives String vs.
// Number from the JS value itself, so a plain number here renders as a
// real numeric cell (right-aligned, safe to SUM in a formula) without
// having to redeclare that per call site.
function dataCell(value: string | number, opts: { align?: 'left' | 'center' | 'right' } = {}) {
  return {
    value,
    backgroundColor: COLORS.fieldBackground,
    align: opts.align ?? (typeof value === 'number' ? 'right' as const : 'left' as const),
    borderColor: COLORS.border,
    borderStyle: 'thin' as const,
  };
}

function sectionTitleRow(title: string): Row {
  return [
    { value: title, columnSpan: COLUMN_COUNT, backgroundColor: COLORS.sectionHeader, fontWeight: 'bold', align: 'center' },
    null, null, null, null, null,
  ];
}

// One line of an itemized cost breakdown: a label spanning the first four
// columns (long agency/organiser names routinely overflow a single
// narrow column) and a right-aligned amount in the fifth, matching the
// grey, borderless field style the reference layout uses for this section
// (as opposed to the bordered tables above it).
function breakdownItemRow(label: string, amount: number, opts: { bold?: boolean } = {}): Row {
  const weight = opts.bold ? ({ fontWeight: 'bold' as const }) : {};
  return padRow([
    { value: label, backgroundColor: COLORS.fieldBackground, columnSpan: 4, ...weight },
    null, null, null,
    { value: amount, backgroundColor: COLORS.fieldBackground, align: 'right', ...weight },
  ]);
}

// Itemized cost breakdown block: a bold section label ("Organiser Costs" /
// "ULAA Costs"), one row per underlying TripFinance line item the admin
// actually entered on the Finances tab, and a bold Total row. `total` is
// passed in from the already-computed ulaaCosts/organiserCosts figure
// (not re-summed from `items`) so this can never drift from the summary
// row further up the sheet even if a future line item gets added to one
// but not the other.
function costBreakdownBlock(label: string, items: CostBreakdownItem[], total: number): Row[] {
  const rows: Row[] = [
    padRow([{ value: label, backgroundColor: COLORS.fieldBackground, fontWeight: 'bold', columnSpan: COLUMN_COUNT }, null, null, null, null, null]),
  ];
  if (items.length === 0) {
    rows.push(padRow([{ value: 'No costs entered', backgroundColor: COLORS.fieldBackground, fontStyle: 'italic', textColor: '#7A7A7A', columnSpan: COLUMN_COUNT }, null, null, null, null, null]));
  } else {
    items.forEach(item => rows.push(breakdownItemRow(item.label, item.amount)));
  }
  rows.push(breakdownItemRow('Total', total, { bold: true }));
  return rows;
}

function buildTripSheetRows(trip: TripExcelReportRow): Row[] {
  const rows: Row[] = [];

  rows.push([
    { value: 'ULAA Reports', columnSpan: COLUMN_COUNT, backgroundColor: COLORS.banner, textColor: COLORS.bannerText, fontWeight: 'bold', fontSize: 16, align: 'center', alignVertical: 'center', height: 32 },
    null, null, null, null, null,
  ]);
  rows.push(blankRow());

  rows.push(columnHeaderRow(['Trip', 'Travelers', 'Veg', 'Non Veg']));
  rows.push(padRow([
    dataCell(trip.tripTitle, { align: 'left' }),
    dataCell(trip.travelerCount),
    dataCell(trip.vegCount),
    dataCell(trip.nonVegCount),
  ]));
  rows.push(blankRow());

  rows.push(sectionTitleRow('Outstanding Balances by Person'));
  rows.push(columnHeaderRow(['Revenue', 'ULAA Costs', 'Organiser Costs', 'Total Costs', 'Net Profit', 'Profit/Person']));
  rows.push(padRow([
    dataCell(trip.revenue),
    dataCell(trip.ulaaCosts),
    dataCell(trip.organiserCosts),
    dataCell(trip.totalCosts),
    dataCell(trip.netProfit),
    dataCell(Math.round(trip.profitPerPerson)),
  ]));
  rows.push(blankRow());

  rows.push(columnHeaderRow(['Name', 'Total Amount', 'Paid So Far', 'Balance']));
  if (trip.outstandingByPerson.length === 0) {
    rows.push(padRow([{ value: 'No outstanding balances', backgroundColor: COLORS.fieldBackground, fontStyle: 'italic', textColor: '#7A7A7A', columnSpan: 4 }, null, null, null]));
  } else {
    trip.outstandingByPerson.forEach(p => {
      rows.push(padRow([
        dataCell(p.name, { align: 'left' }),
        dataCell(p.total),
        dataCell(p.paid),
        dataCell(p.balance),
      ]));
    });
  }
  rows.push(blankRow());

  rows.push(...costBreakdownBlock('Organiser Costs', trip.organiserCostBreakdown, trip.organiserCosts));
  rows.push(...costBreakdownBlock('ULAA Costs', trip.ulaaCostBreakdown, trip.ulaaCosts));

  return rows;
}

const SHEET_COLUMNS = [{ width: 28 }, { width: 16 }, { width: 16 }, { width: 14 }, { width: 14 }, { width: 16 }];

// Single-trip export: one sheet named after the trip.
export async function downloadTripExcelReport(trip: TripExcelReportRow): Promise<void> {
  const rows = buildTripSheetRows(trip);
  const safeSheetName = trip.tripTitle.replace(/[\\/*?:[\]]/g, ' ').slice(0, 31) || 'Trip';
  await writeXlsxFile(rows, { sheet: safeSheetName, columns: SHEET_COLUMNS }).toFile(
    `ulaa-report-${trip.tripTitle.replace(/\s+/g, '_')}-${new Date().toISOString().slice(0, 10)}.xlsx`
  );
}

// "All Trips" export: same layout, one sheet per trip, so picking "All
// Trips" in the Trip dropdown before hitting Export Excel doesn't lose
// per-trip detail to a single flattened table the way the CSV export's
// business-wide summary table does.
export async function downloadAllTripsExcelReport(trips: TripExcelReportRow[]): Promise<void> {
  const usedNames = new Set<string>();
  const sheets: { data: Row[]; sheet: string; columns: typeof SHEET_COLUMNS }[] = trips.map(trip => {
    let name = trip.tripTitle.replace(/[\\/*?:[\]]/g, ' ').slice(0, 31) || 'Trip';
    let suffix = 2;
    while (usedNames.has(name)) {
      const base = name.slice(0, 28 - String(suffix).length);
      name = `${base} (${suffix})`;
      suffix += 1;
    }
    usedNames.add(name);
    return { data: buildTripSheetRows(trip), sheet: name, columns: SHEET_COLUMNS };
  });
  await writeXlsxFile(sheets).toFile(`ulaa-report-all-${new Date().toISOString().slice(0, 10)}.xlsx`);
}
