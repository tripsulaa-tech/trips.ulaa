import type { UpcomingTrip, TripHighlightCard, TripIncludedGroup, TripInclusionItem } from '../../../types/types-index';
import { getTripHighlightIcon, type TripHighlightIconType } from '../../../constants/tripHighlightIcons';
import {
  ShirtFolded as Shirt, Footprints, Eyeglasses as Glasses, Beanie as HatGlasses, Hand,
  Headphones, BatteryCharging, Pill, SprayBottle as SprayCan, Drop as Droplet,
  Cookie, Sparkle as Sparkles, FileText, IdentificationCard as IdCard,
  Stamp, Airplane as Plane, ShieldCheck, CreditCard, Backpack,
} from '@phosphor-icons/react';
import { formatPrice, formatDuration } from '../../utils-index';
import { sanitizeForPdf } from '../../pdfText';
import { matchThingsToCarryIconKey, type ThingsToCarryIconKey } from '../../../constants/thingsToCarryIconRules';
import { fetchAsDataUrl, loadImageEl } from '../../pdfImageLoading';
import WaterBottleIcon from '../../../components/icons/WaterBottleIcon';
import UniversalAdapterIcon from '../../../components/icons/UniversalAdapterIcon';
import PassportIcon from '../../../components/icons/PassportIcon';
import PassportPhotoIcon from '../../../components/icons/PassportPhotoIcon';
import DocumentCopiesIcon from '../../../components/icons/DocumentCopiesIcon';
import { BRAND_BASE, COLORS_BASE, type RGB } from '../shared';
import { BRAND_TAGLINE } from '../../../constants/site';
export { tierLabel } from '../../../constants/cancellationPolicy';

export type { RGB } from '../shared';

// Icons drawn into the PDF can come from either the @phosphor-icons/react
// imports above (chrome/fallback glyphs) or from the trip highlight icon
// store (see src/constants/tripHighlightIcons.ts) — both are Phosphor
// components now, so `drawLucideIcon` (see context.ts) renders either the
// same way via `renderToStaticMarkup`.
export type AnyIcon = TripHighlightIconType;

export function rgbToHex([r, g, b]: RGB): string {
  return `#${[r, g, b].map(v => v.toString(16).padStart(2, '0')).join('')}`;
}

/** Resolves an admin-picked icon-library key (e.g. "shield-check") to its
 *  actual Phosphor component, falling back for empty/legacy values. */
export function resolveIcon(key: string | undefined | null, fallback: AnyIcon): AnyIcon {
  const meta = key ? getTripHighlightIcon(key) : undefined;
  return meta ? meta.Icon : fallback;
}

// Keyword→key matching rules are shared with the live site (see
// constants/thingsToCarryIconRules.ts) so an admin-typed "Things to Carry"
// item with no explicit icon still resolves to the same *kind* of glyph in
// the PDF as it does on the live site — both render via
// @phosphor-icons/react now.
const THINGS_TO_CARRY_ICONS: Record<ThingsToCarryIconKey | 'default', AnyIcon> = {
  jacket: Shirt,
  shoe: Footprints,
  sunglasses: Glasses,
  cap: HatGlasses,
  glove: Hand,
  earphone: Headphones,
  adapter: UniversalAdapterIcon as unknown as AnyIcon,
  powerBank: BatteryCharging,
  medicine: Pill,
  sunscreen: SprayCan,
  moisturizer: Droplet,
  waterBottle: WaterBottleIcon as unknown as AnyIcon,
  snack: Cookie,
  wipe: Sparkles,
  tissue: FileText,
  photo: PassportPhotoIcon as unknown as AnyIcon,
  visa: Stamp,
  flight: Plane,
  insurance: ShieldCheck,
  card: CreditCard,
  passport: PassportIcon as unknown as AnyIcon,
  documentCopies: DocumentCopiesIcon as unknown as AnyIcon,
  idProof: IdCard,
  default: Backpack,
};

export function getThingsToCarryFallbackIcon(item: string): AnyIcon {
  return THINGS_TO_CARRY_ICONS[matchThingsToCarryIconKey(item)];
}

// Static, site-wide brand info (not trip data) shown on the cover strip and
// the closing slide — the same constants used in the site footer/contact page.
export const BRAND = {
  ...BRAND_BASE,
  tagline: BRAND_TAGLINE,
};

// PowerPoint's default 16:9 widescreen slide size (13.333in × 7.5in),
// expressed in points (72pt/in) so all layout math below is in whole points.
export const PAGE_W = 960;
export const PAGE_H = 540;
export const MARGIN = 44;
export const CONTENT_W = PAGE_W - MARGIN * 2;
export const CONTENT_BOTTOM = PAGE_H - 40; // leaves room for the page-number badge

export const COLORS = {
  ...COLORS_BASE,
  whiteMuted: [230, 220, 209] as RGB,
} as const;

// Mirrors TRIP_HIGHLIGHT_ICON_PALETTE in src/constants/tripHighlightIcons.ts —
// the same rotating pastel-circle colors the site uses for highlight cards
// and Travel with Confidence items. Kept in sync manually, same as COLORS
// above being kept in sync with @theme in globals.css.
export const CONFIDENCE_PALETTE: { bg: RGB; fg: RGB }[] = [
  { bg: [251, 234, 217], fg: [196, 112, 58] },
  { bg: [243, 231, 220], fg: [139, 72, 32] },
  { bg: [233, 240, 228], fg: [91, 122, 74] },
  { bg: [253, 241, 220], fg: [200, 150, 42] },
  { bg: [251, 234, 217], fg: [217, 138, 58] },
  { bg: [247, 227, 224], fg: [194, 74, 74] },
];

/** `formatPrice()` returns the ₹ glyph, which isn't in the core PDF font's
 *  charset — used directly it renders as a mis-measured stray glyph, which
 *  throws off any layout math based on its width (e.g. positioning a
 *  strike-through price right after it). Every price shown in the PDF goes
 *  through this instead, so it's always the sanitized "Rs. 39,999" form. */
export { money } from '../shared';

/** Same figure as `money()` would have produced, but with the real ₹
 *  glyph instead of the "RS" text fallback — for use only where the
 *  `RupeeSans` font (see rupeeFont.ts) is active, i.e. the hero price on
 *  the "Trip Leader & Booking" slide, matching TripDetailPage's
 *  <BookingForm>. Every other price on this PDF still goes through
 *  `money()`, which keeps the "Rs." text form since it draws with
 *  helvetica, whose Windows-1252 charset can't render ₹. */
export function heroMoneyRupee(amount: number): string {
  return formatPrice(amount); // e.g. "₹39,999" — same shape as TripDetailPage
}

// `included_groups` carries the site's grouped "What's Included" content
// (icon + heading + bulleted sub-items) straight through so the PDF can draw
// the same heading-card layout as TripDetailPage. `included` is a flattened
// fallback (description + icon) used only when a trip has no groups, drawn as
// the plain icon-card grid instead. `not_included` prefers not_included_items'
// descriptions when present, else the legacy plain-text list — same
// precedence TripDetailPage itself uses. `included`/`things_to_carry` keep
// each item's `icon` key (not just its description) so the PDF can resolve
// and draw the exact same Phosphor glyph the live site does — see
// `drawLucideIcon` in context.ts.
export type PdfListItem = Pick<TripInclusionItem, 'description' | 'icon'>;

export type PdfTrip = UpcomingTrip & {
  highlight_cards: TripHighlightCard[];
  included_groups: TripIncludedGroup[];
  included: PdfListItem[];
  things_to_carry: PdfListItem[];
};

export function sanitizeTrip(trip: UpcomingTrip): PdfTrip {
  // Things to Carry now has an icon-based rich variant (things_to_carry_items)
  // that the admin form treats as the source of truth — see AdminTrips.tsx.
  const thingsToCarrySource = (trip.things_to_carry_items?.length ?? 0) > 0
    ? trip.things_to_carry_items!
    : [];
  const hasIncludedGroups = (trip.included_groups?.length ?? 0) > 0;
  const notIncludedSource = (trip.not_included_items?.length ?? 0) > 0
    ? trip.not_included_items!.map(item => item.description)
    : trip.not_included;
  return {
    ...trip,
    title: sanitizeForPdf(trip.title),
    destination: sanitizeForPdf(trip.destination),
    duration: sanitizeForPdf(formatDuration(trip.duration)),
    description: sanitizeForPdf(trip.description),
    highlight_cards: (trip.highlight_cards ?? []).map(card => ({
      ...card,
      heading: sanitizeForPdf(card.heading),
      description: sanitizeForPdf(card.description),
    })),
    itinerary: trip.itinerary.map(day => ({
      ...day,
      title: sanitizeForPdf(day.title),
      description: sanitizeForPdf(day.description),
      bullets: (day.bullets ?? []).map(sanitizeForPdf),
    })),
    included_groups: hasIncludedGroups
      ? trip.included_groups!.map(group => ({
          ...group,
          heading: sanitizeForPdf(group.heading),
          bullets: group.bullets.map(sanitizeForPdf),
        }))
      : [],
    included: hasIncludedGroups
      ? []
      : (trip.included_items ?? []).map(item => ({ description: sanitizeForPdf(item.description), icon: item.icon })),
    not_included: notIncludedSource.map(sanitizeForPdf),
    things_to_carry: thingsToCarrySource.map(item => ({ description: sanitizeForPdf(item.description), icon: item.icon })),
    meeting_point: trip.meeting_point ? sanitizeForPdf(trip.meeting_point) : trip.meeting_point,
    gallery_description: trip.gallery_description ? sanitizeForPdf(trip.gallery_description) : trip.gallery_description,
    gallery_items: trip.gallery_items?.map(item => ({ ...item, description: sanitizeForPdf(item.description) })),
    accommodation_description: trip.accommodation_description ? sanitizeForPdf(trip.accommodation_description) : trip.accommodation_description,
    fashion_description: trip.fashion_description ? sanitizeForPdf(trip.fashion_description) : trip.fashion_description,
    confidence_description: trip.confidence_description ? sanitizeForPdf(trip.confidence_description) : trip.confidence_description,
    confidence_items: trip.confidence_items?.map(item => ({ ...item, description: sanitizeForPdf(item.description) })),
    faqs: trip.faqs.map(faq => ({
      ...faq,
      question: sanitizeForPdf(faq.question),
      answer: sanitizeForPdf(faq.answer),
    })),
    cancellation_policy: trip.cancellation_policy
      ? {
          ...trip.cancellation_policy,
          tiers: trip.cancellation_policy.tiers.map(tier => ({
            ...tier,
            description: sanitizeForPdf(tier.description),
          })),
        }
      : trip.cancellation_policy,
  };
}

/** Fetches a photo and returns it pre-cropped to exactly targetWpt ×
 *  targetHpt using "object-fit: cover" math (scale to fill, crop the
 *  overflow, keep it centered) so it never gets stretched — plus soft
 *  rounded corners baked in via a clip path. */
export async function loadCoverCroppedImage(
  url: string,
  targetWpt: number,
  targetHpt: number,
  cornerRadiusPt = 0,
  backgroundHex = '#ffffff'
): Promise<string | null> {
  try {
    const dataUrl = await fetchAsDataUrl(url);
    if (!dataUrl) return null;
    const img = await loadImageEl(dataUrl);

    const PX_PER_PT = 2.4; // ~230 DPI equivalent: sharp for print, keeps the PDF light
    const w = Math.round(targetWpt * PX_PER_PT);
    const h = Math.round(targetHpt * PX_PER_PT);
    const r = cornerRadiusPt * PX_PER_PT;

    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Fill first with backgroundHex (defaults to white). JPEG has no alpha
    // channel, so any pixels left untouched outside a rounded/circular clip
    // path below would otherwise get flattened to black on export — visible
    // as corners poking out around circular avatars (e.g. the Trip Leader
    // photo). Passing the page's own background color here (rather than the
    // default white) makes those corners blend in instead of standing out
    // as a slightly-off-white patch against a cream page.
    ctx.fillStyle = backgroundHex;
    ctx.fillRect(0, 0, w, h);

    if (r > 0) {
      ctx.beginPath();
      if (r * 2 >= Math.min(w, h)) {
        // Fully rounded — a true circle (e.g. the Trip Leader avatar).
        // The quadratic-corner path below is only a rough approximation
        // of round at this radius (visibly flattens/bulges around the
        // 45° points), so use a real arc instead for a perfect circle.
        ctx.arc(w / 2, h / 2, Math.min(w, h) / 2, 0, Math.PI * 2);
      } else {
        ctx.moveTo(r, 0);
        ctx.lineTo(w - r, 0);
        ctx.quadraticCurveTo(w, 0, w, r);
        ctx.lineTo(w, h - r);
        ctx.quadraticCurveTo(w, h, w - r, h);
        ctx.lineTo(r, h);
        ctx.quadraticCurveTo(0, h, 0, h - r);
        ctx.lineTo(0, r);
        ctx.quadraticCurveTo(0, 0, r, 0);
      }
      ctx.closePath();
      ctx.clip();
    }

    const scale = Math.max(w / img.naturalWidth, h / img.naturalHeight);
    const drawW = img.naturalWidth * scale;
    const drawH = img.naturalHeight * scale;
    ctx.drawImage(img, (w - drawW) / 2, (h - drawH) / 2, drawW, drawH);

    return canvas.toDataURL('image/jpeg', 0.88);
  } catch {
    return null;
  }
}
