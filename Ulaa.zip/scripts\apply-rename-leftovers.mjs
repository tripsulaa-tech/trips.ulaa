// Finishes the Yaaru Avan rename in the app code, tests and routes.
// Run once from the project root:  node scripts/apply-rename-leftovers.mjs
// Safe to run again: every step skips what is already done, and files or
// patterns that are not there are ignored. It prints what it changed.
import fs from 'node:fs';
import path from 'node:path';

const U = 'src/components/ui/';
const rules = [
  [U + 'yaaruAvanWords.ts', [['YARU_AVAN', 'YAARU_AVAN']]],
  [U + 'useGameContentSync.ts', [
    ['STOWAWAY_DEFAULTS', 'YAARU_AVAN_DEFAULTS'], ['applyStowawayContent', 'applyYaaruAvanContent'],
    ['sanitizeStowawayContent', 'sanitizeYaaruAvanContent'], ['useStowawayContentSync', 'useYaaruAvanContentSync'],
    ["useGameContent('stowaway'", "useGameContent('yaaru-avan'"], ['Stowaway and Find My Twin', 'Yaaru Avan and Find My Twin'],
  ]],
  ['src/admin/AdminGames.tsx', [
    ['STOWAWAY_CATEGORIES', 'YAARU_AVAN_CATEGORIES'], ['STOWAWAY_DEFAULTS', 'YAARU_AVAN_DEFAULTS'],
    ['STOWAWAY_LEVELS', 'YAARU_AVAN_LEVELS'], ['sanitizeStowawayContent', 'sanitizeYaaruAvanContent'],
    ['StowawayContent', 'YaaruAvanContent'], ['StowawayEditor', 'YaaruAvanEditor'],
    ["('stowaway', 'stowaway'", "('yaaru-avan', 'yaaru-avan'"], ["'tod' | 'stowaway' | 'charades'", "'tod' | 'yaaru-avan' | 'charades'"],
    ["{ id: 'stowaway', label: 'Yaaru Avan?'", "{ id: 'yaaru-avan', label: 'Yaaru Avan?'"], ["game !== 'stowaway'", "game !== 'yaaru-avan'"],
    ['─ Stowaway ─', '─ Yaaru Avan ─'], ["('tod', 'stowaway', ...)", "('tod', 'yaaru-avan', ...)"],
  ]],
  ['src/admin/games/YaaruAvanOnlineSwitch.tsx', [['getStowawayOnlineOpen', 'getYaaruAvanOnlineOpen'], ['setStowawayOnlineOpen', 'setYaaruAvanOnlineOpen']]],
  ['src/services/api/yaaruAvanOnlineSwitch.ts', [['getStowawayOnlineOpen', 'getYaaruAvanOnlineOpen'], ['setStowawayOnlineOpen', 'setYaaruAvanOnlineOpen']]],
  ['src/services/api/gameContent.ts', [["'charades-tamil' | 'stowaway'", "'charades-tamil' | 'yaaru-avan'"]]],
  [U + 'yaaruAvanEngine.ts', [['explorerWin', 'touristWin'], ['lostSurvive', 'pickpocketSurvive'], ['lostSteal', 'pickpocketSteal'], ['lostWins', 'pickpocketWins']]],
  [U + 'YaaruAvanGame.tsx', [['explorerWin', 'touristWin'], ['lostSurvive', 'pickpocketSurvive'], ['lostSteal', 'pickpocketSteal'], ['lostWins', 'pickpocketWins']]],
  [U + 'YaaruAvanOnline.tsx', [['explorerWin', 'touristWin'], ['lostSurvive', 'pickpocketSurvive'], ['lostSteal', 'pickpocketSteal'], ['lostWins', 'pickpocketWins']]],
  [U + 'TripGames.tsx', [['Truth or Dare, Stowaway, Find', 'Truth or Dare, Yaaru Avan, Find']]],
  ['src/admin/games/RosterGameCard.tsx', [
    ['Truth or Dare, Stowaway)', 'Truth or Dare, Yaaru Avan)'], ['e.g. "stowaway"', 'e.g. "yaaru-avan"'],
    ['/play/stowaway/game', '/play/yaaru-avan/game'], ["(e.g. Stowaway's online switch)", "(e.g. Yaaru Avan's online switch)"],
  ]],
  ['src/admin/games/hostShared.ts', [['Truth or Dare, Stowaway)', 'Truth or Dare, Yaaru Avan)']]],
  ['src/admin/games/YaaruAvanHost.tsx', [['/play/stowaway/:code', '/play/yaaru-avan/:code']]],
  ['src/pages/YaaruAvanJoinPage.tsx', [
    ['a Stowaway invite link opens (/play/stowaway/KBR7)', 'a Yaaru Avan invite link opens (/play/yaaru-avan/KBR7)'],
    ["path: '/play/stowaway'", "path: '/play/yaaru-avan'"],
  ]],
];

let changed = 0;
for (const [file, pairs] of rules) {
  if (!fs.existsSync(file)) { console.log('skip (not found): ' + file); continue; }
  const before = fs.readFileSync(file, 'utf8');
  let after = before;
  for (const [from, to] of pairs) after = after.split(from).join(to);
  if (after !== before) { fs.writeFileSync(file, after); changed++; console.log('updated: ' + file); }
}

// Router: the invite links the app makes are /play/yaaru-avan/:code, so that route
// must exist. The old /play/stowaway links stay as a second route so shared links still open.
const router = 'src/routes/AppRouter.tsx';
if (fs.existsSync(router)) {
  let s = fs.readFileSync(router, 'utf8');
  if (!s.includes('/play/yaaru-avan"')) {
    const nl = s.includes('\r\n') ? '\r\n' : '\n';
    const old = '            <Route path="/play/stowaway" element={<YaaruAvanJoinPage />} />' + nl +
                '            <Route path="/play/stowaway/:code" element={<YaaruAvanJoinPage />} />';
    if (s.includes(old)) {
      const add = '            <Route path="/play/yaaru-avan" element={<YaaruAvanJoinPage />} />' + nl +
                  '            <Route path="/play/yaaru-avan/:code" element={<YaaruAvanJoinPage />} />' + nl +
                  '            {/* Links shared before the rename keep working. */}' + nl;
      fs.writeFileSync(router, s.replace(old, add + old)); changed++; console.log('updated: ' + router);
    } else console.log('CHECK BY HAND: could not find the /play/stowaway routes in ' + router);
  }
}

// supabase/tests/stowaway_tests.py is an old copy of yaaru_avan_tests.py (same checks, old names).
const old = 'supabase/tests/stowaway_tests.py';
if (fs.existsSync(old) && fs.existsSync('supabase/tests/yaaru_avan_tests.py')) {
  fs.rmSync(old); changed++; console.log('deleted: ' + old);
}

// Report anything old-named still left outside the migration history.
const left = [];
(function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (['node_modules', 'migration', '.git', 'dist'].includes(e.name)) continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p);
    else if (/\.(tsx?|py|md|json|mjs)$/.test(e.name) && p !== 'scripts/apply-rename-leftovers.mjs') {
      fs.readFileSync(p, 'utf8').split('\n').forEach((l, i) => { if (/stowaway/i.test(l)) left.push(`${p}:${i + 1}: ${l.trim().slice(0, 110)}`); });
    }
  }
})('src'); (function w2(d){ for (const e of fs.readdirSync(d,{withFileTypes:true})) { const p=path.join(d,e.name); if(e.isDirectory()) { if(e.name!=='migration') w2(p);} else if(/\.(py|md|sql)$/.test(e.name)) fs.readFileSync(p,'utf8').split('\n').forEach((l,i)=>{ if(/stowaway/i.test(l)) left.push(`${p}:${i+1}: ${l.trim().slice(0,110)}`);}); } })('supabase'); 
console.log(`\n${changed} file(s) changed.`);
console.log(left.length ? 'Still mentioning "stowaway" (outside migrations):\n' + left.join('\n') : 'No "stowaway" left outside the migration files.');
