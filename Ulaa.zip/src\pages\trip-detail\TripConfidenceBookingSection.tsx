import type { RefObject } from 'react';
import TripHighlightIconDisplay from '../../components/ui/TripHighlightIconDisplay';
import Button from '../../components/ui/Button';
import PdfDownloadMenu from '../../components/ui/PdfDownloadMenu';
import SectionTitle from '../../components/ui/SectionTitle';
import type { UpcomingTrip, TripConfidenceItem, ButtonLabelsConfig } from '../../types/types-index';
import { formatDateRange, formatDate, formatPrice, formatAgeRange, specialOfferDaysLeft, formatDuration, earlyBirdSeatsLabel, earlyBirdRuleNote } from '../../utils/utils-index';
import { hasPackages } from '../../utils/tripOptions';
import { getGoogleCalendarUrl, downloadTripIcs } from '../../utils/calendar';
import {
  Calendar,
  Clock,
  Users,
  UserCheck,
  ArrowRight,
  CalendarPlus,
  Download,
  ShareNetwork as Share2,
  SealCheck as BadgeCheck,
  ShieldCheck,
  Sparkle,
  Gift,
  Fire,
} from '@phosphor-icons/react';

import { RESPONSE_TIME } from '../../constants/site';
interface TripConfidenceBookingSectionProps {
  trip: UpcomingTrip;
  buttonLabels: ButtonLabelsConfig;
  confidenceItems?: TripConfidenceItem[] | null;
  activeConfidenceItems: Set<number>;
  setActiveConfidenceItems: React.Dispatch<React.SetStateAction<Set<number>>>;
  toggleInSet: (setter: React.Dispatch<React.SetStateAction<Set<number>>>, i: number) => void;
  activePrice: number | null | undefined;
  strikeThroughPrice: number | null | undefined;
  isEarlyBird: boolean;
  isSpecialOffer: boolean;
  deadlinePassed: boolean;
  remainingAfterAdvance: number | null;
  isFull: boolean;
  isAlmostFull: boolean;
  remaining: number;
  calendarMenuOpen: boolean;
  setCalendarMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
  calendarMenuRef: RefObject<HTMLDivElement | null>;
  onBook: () => void;
}

export default function TripConfidenceBookingSection({
  trip,
  buttonLabels,
  confidenceItems,
  activeConfidenceItems,
  setActiveConfidenceItems,
  toggleInSet,
  activePrice,
  strikeThroughPrice,
  isEarlyBird,
  isSpecialOffer,
  deadlinePassed,
  remainingAfterAdvance,
  isFull,
  isAlmostFull,
  remaining,
  calendarMenuOpen,
  setCalendarMenuOpen,
  calendarMenuRef,
  onBook,
}: TripConfidenceBookingSectionProps) {
  const hasConfidenceItems = (confidenceItems?.length ?? 0) > 0;
  // Save = strikeThroughPrice - activePrice (marketing "was ₹X" price vs
  // what they pay). PLUS OFFER = trip.price - activePrice (actual regular
  // price vs what they pay) — same formula and gating as TripCard/
  // SpecialOfferPopupCard/TripStickyBookingBar: only shown for a live,
  // non-hidden special offer, and only when it says something the green
  // badge doesn't.
  const showSpecialOfferPromo = isSpecialOffer && !trip.hide_special_offer_promo;
  const basicPackageName = hasPackages(trip.trip_options) ? trip.trip_options.packages[0].name : null;
  const saveAmount = strikeThroughPrice != null && activePrice != null
    ? strikeThroughPrice - activePrice
    : null;
  const plusOfferAmount = trip.price != null && activePrice != null
    ? trip.price - activePrice
    : null;
  const showPlusOffer = showSpecialOfferPromo && plusOfferAmount != null && plusOfferAmount > 0 && plusOfferAmount !== saveAmount;

  return (
    /* Pack Your Bags — sits directly below Fashion Aesthetics / Gallery, matching the quick-jump nav order.
        Travel with Confidence sits to its left as its own separate card. */
    <div className={`grid grid-cols-1 gap-5 sm:gap-6 ${hasConfidenceItems ? 'lg:grid-cols-[1fr_640px] lg:divide-x lg:divide-background-warm' : ''}`}>
      {hasConfidenceItems && (
        <section id="confidence" className="scroll-mt-44 flex flex-col justify-center lg:pr-10">
          <SectionTitle variant="plain" align="left" label="Book with ease" title="Travel with Confidence" titleClassName="mb-3" />
          {trip.confidence_description && (
            <p className="text-dark-muted text-base leading-relaxed mb-4 sm:mb-6">{trip.confidence_description}</p>
          )}
          <div className="grid grid-cols-1 gap-0.5 w-fit">
            {confidenceItems!.map((item, i) => (
              <div key={i} className="group relative flex items-center justify-start gap-3 p-1">
                <button
                  type="button"
                  onClick={() => toggleInSet(setActiveConfidenceItems, i)}
                  aria-expanded={activeConfidenceItems.has(i)}
                  aria-label={`${item.description} — tap for details`}
                  className="absolute inset-0 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 sm:pointer-events-none"
                />
                {item.icon && (
                  <TripHighlightIconDisplay icon={item.icon} index={i} size="sm" filled={activeConfidenceItems.has(i)} hoverFill />
                )}
                <p className="text-dark text-base leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className={`bg-white rounded-lg shadow-warm-lg border border-background-warm p-5 py-6 sm:p-8 sm:py-10 sm:pl-10 sm:pr-14 ${hasConfidenceItems ? 'lg:ml-10' : 'max-w-2xl mx-auto w-full'}`}>
        <div className="max-w-xl mx-auto text-center">
          <SectionTitle variant="plain" align="center" title="Reserve Your Spot" size="sm" titleClassName="mb-5" />
          {activePrice != null && (
            <div className="mb-5 pb-5 border-b border-background-warm">
              {strikeThroughPrice != null ? (
                <>
                  <div className="flex items-center justify-center gap-2">
                    <span className="font-display text-3xl font-bold text-primary">{formatPrice(activePrice)}</span>
                    <span className="text-dark-muted line-through text-lg">{formatPrice(strikeThroughPrice)}</span>
                  </div>
                  <p className="text-dark-muted text-xs mt-1">per person{basicPackageName ? ` · ${basicPackageName} package` : ''}</p>

                  <div className="flex items-center justify-center gap-2 mt-3 flex-wrap">
                    <span className="bg-green-50 border border-green-200 text-green-700 text-xs font-button font-medium px-2.5 py-1 rounded-md">
                      Save {formatPrice(saveAmount as number)}
                    </span>
                    {showPlusOffer && (
                      <span className="inline-flex items-center gap-1.5 bg-pink-50 border border-pink-200 text-pink-600 text-xs font-button font-bold px-2.5 py-1 rounded-md">
                        <Gift size={12} weight="fill" className="shrink-0" />
                        PLUS {formatPrice(plusOfferAmount as number)} OFFER
                      </span>
                    )}
                    {isSpecialOffer && trip.special_offer_name ? (
                      <span className="offer-badge-gradient-shift inline-flex items-center gap-1.5 text-white text-xs font-button font-bold px-2.5 py-1 rounded-md">
                        <Sparkle size={12} weight="fill" />
                        {trip.special_offer_name}
                      </span>
                    ) : isEarlyBird && (
                      <span className="offer-gradient-shift inline-flex items-center gap-1.5 text-white text-xs font-button font-bold px-2.5 py-1 rounded-md">
                        <Fire size={12} weight="fill" className="text-yellow-300" />
                        Early Bird
                      </span>
                    )}
                  </div>

                  {isSpecialOffer && trip.special_offer_date ? (
                    <p className="flex items-center justify-center gap-1 text-orange-600 text-xs font-medium mt-2">
                      <Clock size={12} className="shrink-0" />
                      {specialOfferDaysLeft(trip.special_offer_date, trip.special_offer_end_date) <= 1
                        ? 'Offer ends today'
                        : `Offer ends ${formatDate(trip.special_offer_end_date || trip.special_offer_date, { day: 'numeric', month: 'long', year: 'numeric' })}`}
                    </p>
                  ) : isEarlyBird && (earlyBirdSeatsLabel(trip) ? (
                    <>
                      <p className="flex items-center justify-center gap-1 text-orange-600 text-xs font-medium mt-2">
                        <Clock size={12} className="shrink-0" />
                        {earlyBirdSeatsLabel(trip)}
                      </p>
                      <p className="text-dark-muted text-2xs mt-1">
                        {earlyBirdRuleNote(trip, activePrice, trip.advance_amount) ?? 'Pay your advance to confirm your early-bird seat.'}
                      </p>
                    </>
                  ) : trip.early_bird_deadline && (
                    <p className="flex items-center justify-center gap-1 text-orange-600 text-xs font-medium mt-2">
                      <Clock size={12} className="shrink-0" />
                      Offer ends {formatDate(trip.early_bird_deadline, { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  ))}
                </>
              ) : (
                <>
                  <span className="font-display text-3xl font-bold text-dark">{formatPrice(activePrice)}</span>
                  <p className="text-dark-muted text-xs mt-1">per person{basicPackageName ? ` · ${basicPackageName} package` : ''}</p>
                  {deadlinePassed && (
                    <p className="text-dark-muted text-xs mt-1">Early-bird offer has ended</p>
                  )}
                </>
              )}
            </div>
          )}
          <div className="mb-6">
            {isFull ? (
              <span className="inline-block bg-red-50 text-red-600 text-sm font-button font-semibold px-4 py-2 rounded-md">
                Sold Out
              </span>
            ) : isAlmostFull ? (
              <span className="inline-block bg-amber-50 text-amber-700 text-sm font-button font-semibold px-4 py-2 rounded-md">
                Only {remaining} seats left — almost full!
              </span>
            ) : trip.advance_amount != null ? (
              <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-lg px-4 py-3 justify-center">
                <span className="shrink-0 w-9 h-9 rounded-full bg-green-600 flex items-center justify-center">
                  <ShieldCheck size={18} className="text-white" strokeWidth={2.5} />
                </span>
                <div className="text-left">
                  <p className="text-dark font-semibold text-sm sm:text-base">
                    Reserve today with only <span className="text-green-600 font-bold">{formatPrice(trip.advance_amount)}</span>
                  </p>
                  {remainingAfterAdvance != null && (
                    <p className="text-dark-muted text-xs sm:text-sm mt-0.5">
                      Remaining <span className="font-bold">{formatPrice(remainingAfterAdvance)}</span> payable before the trip.
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <span className="inline-block bg-green-50 text-green-700 text-sm font-button font-semibold px-4 py-2 rounded-md">
                Seats available
              </span>
            )}
          </div>

          <div className="space-y-3 mb-6 max-w-xs mx-auto">
            <div className="flex justify-between text-sm">
              <span className="flex items-center gap-2 text-dark-muted"><Calendar size={14} className="text-primary shrink-0" /> Dates</span>
              <span className="text-dark font-medium">{formatDateRange(trip.start_date, trip.end_date)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="flex items-center gap-2 text-dark-muted"><Clock size={14} className="text-primary shrink-0" /> Duration</span>
              <span className="text-dark font-medium">{formatDuration(trip.duration)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="flex items-center gap-2 text-dark-muted"><Users size={14} className="text-primary shrink-0" /> Group Size</span>
              <span className="text-dark font-medium">Max {trip.total_seats}</span>
            </div>
            {(trip.min_age != null || trip.max_age != null) && (
              <div className="flex justify-between text-sm">
                <span className="flex items-center gap-2 text-dark-muted"><UserCheck size={14} className="text-primary shrink-0" /> Age Range</span>
                <span className="text-dark font-medium">{formatAgeRange(trip.min_age, trip.max_age)}</span>
              </div>
            )}
          </div>

          <Button
            variant="primary"
            size="lg"
            fullWidth
            onClick={onBook}
            className="group/btn"
          >
            {isFull ? (
              buttonLabels.waitlistCta
            ) : trip.advance_amount != null ? (
              <span className="flex flex-col items-center leading-tight">
                <span className="flex items-center gap-1.5">
                  {buttonLabels.primaryCta}
                  <ArrowRight size={16} className="transition-transform group-hover/btn:translate-x-1" />
                </span>
                <span className="text-xs font-medium opacity-90 mt-0.5">
                  At only {formatPrice(trip.advance_amount)} today
                </span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5">
                {buttonLabels.primaryCta}
                <ArrowRight size={16} className="transition-transform group-hover/btn:translate-x-1" />
              </span>
            )}
          </Button>

          <div className="flex items-center justify-center flex-nowrap gap-x-2 sm:gap-x-3 mt-3">
            <div ref={calendarMenuRef} className="relative">
              <button
                onClick={() => setCalendarMenuOpen(o => !o)}
                className="flex items-center gap-1 sm:gap-1.5 whitespace-nowrap text-xs sm:text-sm text-dark-muted hover:text-primary transition-colors"
              >
                <CalendarPlus size={14} className="shrink-0" /> Add to calendar
              </button>

              {calendarMenuOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 z-20 w-56 rounded-lg border-2 border-background-warm bg-white shadow-warm-lg py-1 overflow-hidden">
                  <a
                    href={getGoogleCalendarUrl(trip)}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setCalendarMenuOpen(false)}
                    className="flex items-center gap-2 px-4 py-2 text-sm text-dark text-left hover:bg-background-warm transition-colors"
                  >
                    <Calendar size={14} className="shrink-0" /> Google Calendar
                  </a>
                  <button
                    type="button"
                    onClick={() => { downloadTripIcs(trip); setCalendarMenuOpen(false); }}
                    className="w-full flex items-center gap-2 px-4 py-2 text-sm text-dark text-left hover:bg-background-warm transition-colors"
                  >
                    <Download size={14} className="shrink-0" /> Apple / Outlook (.ics)
                  </button>
                </div>
              )}
            </div>

            <span className="text-background-warm shrink-0">|</span>

            <button
              onClick={() => navigator.share?.({ title: trip.title, url: window.location.href })}
              className="flex items-center gap-1 sm:gap-1.5 whitespace-nowrap text-xs sm:text-sm text-dark-muted hover:text-primary transition-colors"
            >
              <Share2 size={14} className="shrink-0" /> Share<span className="hidden sm:inline">&nbsp;this trip</span>
            </button>

            {!trip.hide_pdf_download && (
              <>
                <span className="text-background-warm shrink-0">|</span>

                <PdfDownloadMenu trip={trip} variant="text" className="max-sm:!text-xs max-sm:!gap-1" />
              </>
            )}
          </div>

          <div className="flex items-start justify-center gap-1.5 text-xs text-dark-muted mt-4">
            <BadgeCheck size={14} className="text-green-600 shrink-0 mt-0.5" />
            <span className="text-left">
              No payment required to enquire. We'll contact you {RESPONSE_TIME}.
            </span>
          </div>
        </div>
      </section>
    </div>
  );
}
