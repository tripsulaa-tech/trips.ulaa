import type { Enquiry, Payment } from '../types/types-index';
import { invoiceAsFile } from './invoicePdf';
import { formatDate, formatPrice, slugify } from './utils-index';

// Same calculation as AdminEnquiriesShared's paymentBalance() — duplicated
// (rather than imported) so this utils/ module doesn't reach up into the
// admin/ feature folder for a one-line calculation.
function remainingBalance(enquiry: Enquiry): number | null {
  if (!enquiry.total_amount) return null;
  return Math.max(0, enquiry.total_amount - (enquiry.amount_paid || 0));
}

// Best-effort link to the trip's public page. Enquiry only carries
// trip_title (not the trip's actual slug), and a trip's slug is frozen to
// slugify(title) at creation time (see AdminTripFormModal.tsx /
// freeze_trip_and_album_slugs.sql) — so slugify-ing the title reproduces the
// real slug for any trip whose title hasn't been edited since it was
// created. Good enough for a "here's roughly where to click" link without
// threading the full trips list into every place this email can be sent
// from (list rows, mobile cards, the details popup, and the detail page).
function tripPageUrl(enquiry: Enquiry): string | null {
  if (!enquiry.trip_title) return null;
  const slug = slugify(enquiry.trip_title);
  if (!slug) return null;
  return `${window.location.origin}/trips/${slug}`;
}

interface BookingEmailFields {
  to: string;
  subject: string;
  tripName: string;
  advance: string;
  balanceText: string;
  deadlineText: string;
  tripUrl: string | null;
  bookingId: string | null;
}

function bookingEmailFields(enquiry: Enquiry): BookingEmailFields {
  const tripName = enquiry.trip_title || 'your trip';
  const advance = formatPrice(enquiry.booking_amount || enquiry.amount_paid || 0);
  const balance = remainingBalance(enquiry);
  const balanceText = balance != null ? formatPrice(balance) : '—';
  const deadlineText = enquiry.balance_due_date ? formatDate(enquiry.balance_due_date) : 'TBD';
  return {
    to: enquiry.email || '',
    subject: `Booking Confirmation - ${tripName}`,
    tripName,
    advance,
    balanceText,
    deadlineText,
    tripUrl: tripPageUrl(enquiry),
    bookingId: enquiry.booking_id || null,
  };
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/** Rich HTML version of the email — bold section headings and the
 *  non-refundable clause, a real two-column table for the payment
 *  breakdown, and a hyperlink to the trip page. Baked directly into the
 *  .eml file built below, not sent as-is anywhere. */
function buildBookingEmailHtml(enquiry: Enquiry): string {
  const f = bookingEmailFields(enquiry);
  const trip = escapeHtml(f.tripName);
  const name = escapeHtml(enquiry.full_name);
  const tripLink = f.tripUrl
    ? `<a href="${f.tripUrl}">${trip} trip page</a>`
    : `${trip} trip page`;

  return `
<div style="font-family: Arial, sans-serif; font-size: 11pt; color: #1a1a1a; line-height: 1.5;">
  <p>Dear ${name},</p>
  <p>Thank you for choosing Ulaa. We're delighted to have you join us on our ${trip}.</p>
  ${f.bookingId ? `<p><strong>Booking ID:</strong> ${escapeHtml(f.bookingId)}</p>` : ''}
  <p>Your booking has been confirmed. Please find your invoice attached for your reference.</p>

  <p><strong>Payment Details</strong></p>
  <table cellpadding="6" cellspacing="0" style="border-collapse: collapse;">
    <tr>
      <td style="border: 1px solid #ccc;"><strong>Description</strong></td>
      <td style="border: 1px solid #ccc;"><strong>Amount</strong></td>
    </tr>
    <tr>
      <td style="border: 1px solid #ccc;">Advance Payment Received</td>
      <td style="border: 1px solid #ccc;">${f.advance}</td>
    </tr>
    <tr>
      <td style="border: 1px solid #ccc;">Remaining Balance</td>
      <td style="border: 1px solid #ccc;">${f.balanceText}</td>
    </tr>
    <tr>
      <td style="border: 1px solid #ccc;">Final Payment Deadline</td>
      <td style="border: 1px solid #ccc;">${f.deadlineText}</td>
    </tr>
  </table>

  <p><strong>Important Payment Information</strong></p>
  <p>Please note that <strong>the advance payment of ${f.advance} is non-refundable</strong>, as it is used to confirm your booking.<br>
  The remaining balance of ${f.balanceText} must be paid on or before ${f.deadlineText}.<br>
  For complete details regarding our <strong>Terms &amp; Conditions, Cancellation Policy</strong>, and Trip Policies, please refer to the ${tripLink}.</p>

  <p>We look forward to welcoming you on the trip.</p>

  <p>Best regards,<br>Team Ulaa</p>
</div>`.trim();
}

// -----------------------------------------------------------------------
// .eml generation — a .eml is a plain MIME email file. Building one lets a
// single click produce a file that, once opened, is a fully-formed draft in
// Outlook (or any desktop mail app) with the To/Subject filled in, the rich
// HTML body (bold text, the payment table, the trip link) already rendered,
// and the invoice PDF already attached — no copy/paste, no separate
// "Attach file" step. That's as close as a web page can get to "one click,
// fully ready": browsers are not allowed to reach into a desktop app and
// compose something directly (that's an OS-level security boundary, not a
// limitation of this code), so opening the generated file is still one
// manual step — but it's a single double-click, not a multi-step paste.
// -----------------------------------------------------------------------

async function fileToBase64(file: File): Promise<string> {
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

// MIME requires base64 body lines capped at 76 chars.
function wrapBase64(b64: string): string {
  return b64.replace(/.{1,76}/g, '$&\r\n').trim();
}

function utf8ToBase64(str: string): string {
  return btoa(unescape(encodeURIComponent(str)));
}

/** Builds a downloadable .eml file for this booking's confirmation email —
 *  To/Subject headers, the rich HTML body, and the invoice PDF as a real
 *  MIME attachment — and triggers the browser download. */
export async function sendBookingEmail(enquiry: Enquiry, payments: Payment[]): Promise<void> {
  const { to, subject, bookingId } = bookingEmailFields(enquiry);
  const html = buildBookingEmailHtml(enquiry);
  const pdfFile = await invoiceAsFile(enquiry, payments);
  const pdfBase64 = await fileToBase64(pdfFile);

  const boundary = `----ulaa-booking-${Date.now()}`;
  const eml = [
    `To: ${to}`,
    `Subject: ${subject}`,
    // Tells Outlook (and Apple Mail) to open this .eml as a live, editable
    // compose window with a Send button, instead of the read-only
    // "received message" preview .eml files open as by default — that
    // preview only offers Reply/Reply All/Forward, no direct way to send
    // the message itself. This is a real, widely-supported header for
    // exactly this case, not a workaround specific to this app.
    'X-Unsent: 1',
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset="utf-8"',
    'Content-Transfer-Encoding: base64',
    '',
    wrapBase64(utf8ToBase64(html)),
    '',
    `--${boundary}`,
    `Content-Type: application/pdf; name="${pdfFile.name}"`,
    'Content-Transfer-Encoding: base64',
    `Content-Disposition: attachment; filename="${pdfFile.name}"`,
    '',
    wrapBase64(pdfBase64),
    '',
    `--${boundary}--`,
    '',
  ].join('\r\n');

  const blob = new Blob([eml], { type: 'message/rfc822' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Booking-Confirmation-${(bookingId || enquiry.full_name).replace(/[^a-zA-Z0-9-]/g, '-')}.eml`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
