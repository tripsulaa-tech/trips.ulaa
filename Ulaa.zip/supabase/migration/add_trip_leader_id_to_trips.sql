-- ============================================================================
-- Adds `trip_leader_id` to upcoming_trips — an optional reference into the
-- `trip_leaders` directory (see add_trip_leaders.sql) recording which
-- directory entry a trip's Founder/Trip Leader block was assigned from.
--
-- This does NOT replace the existing per-trip `trip_founder` jsonb block —
-- the public site and PDF keep reading trip_founder exactly as before. This
-- column only lets Admin → Add/Edit Trip → Founder pre-fill trip_founder
-- from a chosen trip_leaders row (instead of retyping it) and show which
-- leader a trip is currently linked to.
--
-- `on delete set null` so deleting a trip leader from the directory never
-- fails or cascades into deleting trips — it just unlinks them (their
-- trip_founder text, already copied in, is unaffected).
--
-- Run this once in Supabase → SQL Editor (or `supabase db execute`).
-- Safe to re-run.
-- ============================================================================

alter table public.upcoming_trips
  add column if not exists trip_leader_id uuid references public.trip_leaders(id) on delete set null;
