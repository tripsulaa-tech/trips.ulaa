// Yaaru Fake? special roles: pure assignment logic (no React, no storage).
// A special role sits on top of a core role (Traveller, Pickpocket or Stranger)
// and any player can get one. One special per player, never more.
// This file only decides WHO gets WHAT. What each special does in a round
// (points, vote rules, final guesses) is built on top of it in later phases.

export type SpecialId =
  | 'clown' | 'rivals'                           // Batch 1
  | 'returnTicket' | 'tripLeader' | 'backseatRider' // Batch 2
  | 'payback' | 'luckyDip' | 'lovers';           // Batch 3

/** Specials that sit on one player. Rivals (the Duelists) and Lovers need two. */
export type SoloSpecialId = Exclude<SpecialId, 'rivals' | 'lovers'>;

export interface SpecialDef {
  id: SpecialId;
  name: string;
  batch: 1 | 2 | 3;
  /** Rivals and Lovers are dealt to two players at once. */
  pair: boolean;
}

export const SPECIALS: readonly SpecialDef[] = [
  { id: 'clown', name: 'The Joy Fool', batch: 1, pair: false },
  { id: 'rivals', name: 'The Duelists', batch: 1, pair: true },
  { id: 'returnTicket', name: 'The Boomerang', batch: 2, pair: false },
  { id: 'tripLeader', name: 'Goddess of Justice', batch: 2, pair: false },
  { id: 'backseatRider', name: 'The Ghost', batch: 2, pair: false },
  { id: 'payback', name: 'The Revenger', batch: 3, pair: false },
  { id: 'luckyDip', name: 'The Falafel Vendor', batch: 3, pair: false },
  { id: 'lovers', name: 'The Lovers', batch: 3, pair: true },
];

/** Smallest group each special can appear in. Anything not listed has no minimum. */
export const MIN_PLAYERS: Partial<Record<SpecialId, number>> = {
  luckyDip: 4,
  payback: 5,
  rivals: 5,
  lovers: 5,
};

/** One-line "what is it for" for each special, for the host's picker (not per player). */
export const SPECIAL_BLURB: Record<SpecialId, string> = {
  clown: 'The Joy Fool wins 4 extra points if voted out first!',
  rivals: 'Two players are in a secret duel. The first one to get eliminated loses 2 points, the other one wins 2 points (available from 5 players)',
  returnTicket: 'The 1st time the Boomerang receives the majority of votes, instead of being eliminated, votes against him bounce back to those who cast them!',
  tripLeader: 'In case of equality of votes, she\u2019ll decide who gets eliminated (even if she has already been eliminated)',
  backseatRider: 'The Ghost can still vote even after having been eliminated!',
  payback: 'When the Revenger is eliminated, she can eliminate someone else with her (available from 5 players)',
  luckyDip: 'He receives a random ability each game. Try your luck and see what surprises await! (available from 4 players)',
  lovers: 'Two players are in love. If one of them gets eliminated, the other one too (available from 5 players)',
};

const DEF_BY_ID = new Map(SPECIALS.map(d => [d.id, d]));

export const specialName = (id: SpecialId): string => DEF_BY_ID.get(id)?.name ?? id;

/** At most one special role per 3 players: 5 players -> 1, 9 players -> 3. A pair counts as one role. */
export const maxSpecials = (players: number): number => Math.max(0, Math.floor(players / 3));

export interface SpecialAssignment {
  special: SpecialId;
  /** Lucky Dip only: the ability it turned into (Batch 1 or 2, never a pair). */
  dipAs?: SoloSpecialId;
  /** Rivals and Lovers only: the other player in the pair. */
  partner?: string;
}

/** Anything carrying the special fields (a SpecialAssignment, or a game seat). */
export interface SpecialLike { special?: SpecialId; dipAs?: SoloSpecialId; partner?: string }

/** The ability that actually applies: a Lucky Dip's drawn ability, else the special itself. */
export const activeSpecial = (a: SpecialLike): SpecialId | undefined => a.dipAs ?? a.special;

/** Display name for an ability id; `dip` marks one that came from a Lucky Dip. */
export const specialDisplayName = (id: SpecialId, dip = false): string =>
  (dip ? `${specialName('luckyDip')}: ${specialName(id)}` : specialName(id));

/** Display name of the ability that applies, or null when there is no special. */
export const specialLabel = (a: SpecialLike): string | null => {
  const id = activeSpecial(a);
  if (!id) return null;
  return a.dipAs ? `${specialName('luckyDip')}: ${specialName(id)}` : specialName(id);
};

/** Every special is switched on for pass-and-play. */
export const ENABLED_SPECIALS: readonly SpecialId[] = SPECIALS.map(d => d.id);

function shuffled<T>(arr: readonly T[], rng: () => number): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * Deals specials to a list of unique player names.
 * - `enabled`: which specials may appear (each at most once per round).
 * - `count`: how many specials to hand out; capped at maxSpecials(players).
 *   A pair (Duelists, Lovers) is one role dealt to two players. Omit for the cap.
 * - Specials with a minimum group size (MIN_PLAYERS) are skipped in smaller groups.
 * - One special per player, so pairs can never share a player.
 * - Specials land on any player, whatever their core role.
 * - Lucky Dip draws any solo ability that is enabled and not
 *   already dealt this round. If none is left, the Lucky Dip is dropped.
 * Returns only the players who got one.
 */
export function assignSpecials(
  names: readonly string[],
  enabledAll: readonly SpecialId[],
  count: number = Infinity,
  rng: () => number = Math.random,
): Map<string, SpecialAssignment> {
  const enabled = enabledAll.filter(id => names.length >= (MIN_PLAYERS[id] ?? 0));
  const out = new Map<string, SpecialAssignment>();
  let slots = Math.min(Math.max(0, Math.floor(count)), maxSpecials(names.length));
  if (slots === 0) return out;

  const chosen: SpecialDef[] = [];
  for (const id of shuffled([...new Set(enabled)], rng)) {
    const def = DEF_BY_ID.get(id);
    if (!def) continue;
    const cost = 1;
    if (cost > slots) continue;
    chosen.push(def);
    slots -= cost;
    if (slots === 0) break;
  }

  const order = shuffled(names, rng);
  let next = 0;
  for (const def of chosen) {
    if (def.pair) {
      const a = order[next++];
      const b = order[next++];
      out.set(a, { special: def.id, partner: b });
      out.set(b, { special: def.id, partner: a });
    } else {
      out.set(order[next++], { special: def.id });
    }
  }

  const dealt = new Set<SpecialId>(chosen.map(d => d.id));
  for (const [name, a] of out) {
    if (a.special !== 'luckyDip') continue;
    const pool = SPECIALS.filter(d =>
      !d.pair && d.id !== 'luckyDip' && enabled.includes(d.id) && !dealt.has(d.id));
    if (pool.length === 0) { out.delete(name); continue; }
    const pick = pool[Math.floor(rng() * pool.length)].id as SoloSpecialId;
    dealt.add(pick);
    out.set(name, { ...a, dipAs: pick });
  }
  return out;
}

// ── What the specials do ──
// Tune the numbers here; the game and the tests both read these.

/** The Clown (Joy Fool) scores this if they are the first player voted out. */
export const CLOWN_POINTS = 4;
/** Duelists: the first one voted out loses this, the other gains it. */
export const RIVAL_POINTS = 2;

/** What a player sees on their boarding pass: exactly the words of the role list. */
export function describeSpecial(a: SpecialLike): string | null {
  const id = activeSpecial(a);
  if (!id) return null;
  const base = SPECIAL_BLURB[id].replace(/\s*\(available from \d+ players\)$/, '');
  if ((id === 'rivals' || id === 'lovers') && !a.partner) return null;
  return base;
}

/** Specials everyone can see on the vote screen. None right now: all roles are secret. */
export const PUBLIC_SPECIALS: readonly SpecialId[] = [];

/** The bits of a seat the bonus rules need. */
export interface BonusSeat {
  name: string;
  special?: SpecialId;
  dipAs?: SoloSpecialId;
  partner?: string;
  /** Stop number (1, 2, ...) at which they were voted out. Unset if never voted out. */
  outStop?: number;
  /** 1 for the first player voted out this round, 2 for the next, ... */
  outOrder?: number;
}

/** Extra points from special roles, per player name. Added on top of team points. */
export function specialBonus(seats: readonly BonusSeat[]): Record<string, number> {
  const byName = new Map(seats.map(s => [s.name, s]));
  const out: Record<string, number> = {};
  for (const s of seats) {
    out[s.name] = 0;
    if (!s.special) continue;
    const sp = s.dipAs ?? s.special;
    if (sp === 'clown' && s.outOrder === 1) out[s.name] += CLOWN_POINTS;
    if (sp === 'rivals' && s.partner) {
      // Duel: the first one voted out loses points, the other wins them.
      const mine = s.outOrder ?? Infinity;
      const theirs = byName.get(s.partner)?.outOrder ?? Infinity;
      if (mine < theirs) out[s.name] -= RIVAL_POINTS;
      else if (theirs < mine) out[s.name] += RIVAL_POINTS;
    }
  }
  return out;
}
