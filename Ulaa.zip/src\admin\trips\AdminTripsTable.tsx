import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  PencilSimple as Edit2,
  Trash as Trash2,
  Eye,
  EyeSlash as EyeOff,
  Download,
  Upload,
  ClipboardText as ClipboardList,
  Hourglass,
  FileArrowDown as FileDown,
  FileX,
  TextAa,
  Megaphone,
  SignIn as LogIn,
  CaretUp as ChevronUp,
  CaretDown as ChevronDown,
  MagnifyingGlass,
  X,
} from '@phosphor-icons/react';
import Button from '../../components/ui/Button';
import AddFab from '../../components/ui/AddFab';
import ActionsMenu from '../../components/ui/ActionsMenu';
import type { ActionMenuItem } from '../../components/ui/ActionsMenu';
import type { UpcomingTrip } from '../../types/types-index';
import { formatDate } from '../../utils/utils-index';

interface AdminTripsTableProps {
  trips: UpcomingTrip[];
  loading: boolean;
  pdfDownloadingId: string | null;
  importInputRef: React.RefObject<HTMLInputElement | null>;
  onImportInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onExportTemplate: () => void;
  onAddTrip: () => void;
  onView: (trip: UpcomingTrip) => void;
  onCheckIn: (trip: UpcomingTrip) => void;
  onEdit: (trip: UpcomingTrip) => void;
  onDelete: (trip: UpcomingTrip) => void;
  onTogglePublish: (trip: UpcomingTrip) => void;
  onToggleComingSoon: (trip: UpcomingTrip) => void;
  onToggleHidePdf: (trip: UpcomingTrip) => void;
  onToggleBannerHasText: (trip: UpcomingTrip) => void;
  onToggleSpecialOfferPromo: (trip: UpcomingTrip) => void;
  onMoveTrip: (index: number, dir: -1 | 1) => void;
  onDownloadPdf: (trip: UpcomingTrip) => void;
}

/** The Trips admin page's toolbar (Add Trip, status counts, Import/Export
 *  Template) plus the trips table itself with its per-row quick actions.
 *  Split out of the original single-file AdminTrips.tsx — see that
 *  component's own comment for the rest of the split. */
export default function AdminTripsTable({
  trips, loading, pdfDownloadingId,
  importInputRef, onImportInputChange, onExportTemplate,
  onAddTrip, onView, onCheckIn, onEdit, onDelete,
  onTogglePublish, onToggleComingSoon, onToggleHidePdf, onToggleBannerHasText, onToggleSpecialOfferPromo, onMoveTrip, onDownloadPdf,
}: AdminTripsTableProps) {
  const publishedCount = trips.filter(t => t.status === 'published').length;
  const comingSoonCount = trips.filter(t => t.status === 'coming_soon').length;
  const draftCount = trips.filter(t => t.status === 'draft').length;

  // Filters (search + status) only change what is listed here. Reordering is
  // paused while one is active because the arrows move a trip within the full
  // homepage order, which would look wrong on a partial list.
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<UpcomingTrip['status'] | null>(null);
  const isFiltered = query.trim() !== '' || statusFilter !== null;
  const q = query.trim().toLowerCase();
  const visibleTrips = trips
    .map((trip, index) => ({ trip, index }))
    .filter(({ trip }) =>
      (statusFilter === null || trip.status === statusFilter) &&
      (q === '' || `${trip.title} ${trip.destination ?? ''}`.toLowerCase().includes(q)),
    );
  const clearFilters = () => { setQuery(''); setStatusFilter(null); };
  const toggleStatus = (status: UpcomingTrip['status']) => setStatusFilter(prev => (prev === status ? null : status));
  const pillClass = (status: UpcomingTrip['status'], tone: string) =>
    `inline-flex items-center gap-1.5 text-xs font-button font-semibold pl-1.5 pr-2.5 py-1 rounded-md transition-shadow ${tone} ${
      statusFilter === status ? 'ring-2 ring-primary' : 'hover:ring-1 hover:ring-primary/40'
    }`;

  // Everything except Edit and Delete lives in each row's ⋮ menu, so the
  // Actions column stays short instead of carrying seven icon buttons.
  // Labels name the action the click will perform (e.g. "Unpublish" on a
  // published trip), and the hover title keeps the longer explanation.
  const rowMenuItems = (trip: UpcomingTrip): ActionMenuItem[] => [
    {
      label: 'Preview page',
      icon: Eye,
      onClick: () => window.open(`/admin/trips/${trip.id}/preview`, '_blank', 'noopener'),
      title: 'Open this trip\'s full details page exactly as visitors will see it — works for drafts too, nothing is published',
    },
    {
      label: 'Check-in',
      icon: LogIn,
      onClick: () => onCheckIn(trip),
      title: 'See everyone in Booked status for this trip',
    },
    {
      label: trip.status === 'coming_soon' ? 'Switch to Published' : 'Mark as Coming Soon',
      icon: Hourglass,
      onClick: () => onToggleComingSoon(trip),
      title: trip.status === 'coming_soon' ? 'Switch to fully Published (show full trip)' : 'Mark as Coming Soon (show only cover + title)',
    },
    {
      label: trip.status === 'draft' ? 'Publish' : 'Unpublish',
      icon: trip.status === 'draft' ? Eye : EyeOff,
      onClick: () => onTogglePublish(trip),
      title: trip.status === 'draft' ? 'Publish' : 'Unpublish (move to Draft)',
    },
    {
      label: pdfDownloadingId === trip.id ? 'Downloading PDF…' : 'Download PDF',
      icon: FileDown,
      onClick: () => onDownloadPdf(trip),
      disabled: pdfDownloadingId === trip.id,
      title: 'Download itinerary PDF',
    },
    {
      label: trip.hide_pdf_download ? 'Show PDF Download' : 'Hide PDF Download',
      icon: FileX,
      onClick: () => onToggleHidePdf(trip),
      title: trip.hide_pdf_download ? 'PDF download is hidden from users on the trip page. Click to show it again' : 'Hide the PDF download option from users on the trip page',
    },
    {
      label: trip.banner_has_text ? 'Show Hero Title' : 'Hide Hero Title',
      icon: TextAa,
      onClick: () => onToggleBannerHasText(trip),
      title: trip.banner_has_text ? 'The title is hidden on the trip page hero because the banner already contains it. Click to show it again' : 'Hide the title on the trip page hero — use when the banner image already has the title written on it',
    },
    {
      label: trip.hide_special_offer_promo ? 'Show Offer Popup' : 'Hide Offer Popup',
      icon: Megaphone,
      onClick: () => onToggleSpecialOfferPromo(trip),
      title: trip.hide_special_offer_promo ? 'Special-offer popup & badge are stopped for this trip. Click to show them again' : 'Stop the special-offer popup & badge from showing for this trip',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div className="hidden sm:flex justify-end">
          <Button variant="primary" size="sm" onClick={onAddTrip}>
            <Plus size={16} aria-hidden="true" /> Add Trip
          </Button>
        </div>
        <AddFab onClick={onAddTrip} label="Add trip" />

        {/* Status breakdown + template import/export, grouped into one
            card instead of a bare sentence and two unlabeled icon
            buttons sitting directly on the page background — that read
            as leftover debug UI rather than an intentional toolbar.
            Each status gets its own color-coded pill (scannable at a
            glance, and wraps cleanly on narrow screens instead of one
            long sentence breaking mid-phrase); Import/Export get visible
            text labels instead of relying on a hover-only title. */}
        <div className="bg-white rounded-lg shadow-card px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <ClipboardList size={18} className="text-primary shrink-0" aria-hidden="true" />
            <button type="button" aria-pressed={statusFilter === 'published'} onClick={() => toggleStatus('published')} title="Show only Published trips" className={pillClass('published', 'bg-green-50 text-green-700')}>
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 shrink-0" aria-hidden="true" />
              {publishedCount} Published
            </button>
            <button type="button" aria-pressed={statusFilter === 'coming_soon'} onClick={() => toggleStatus('coming_soon')} title="Show only Coming Soon trips" className={pillClass('coming_soon', 'bg-amber-50 text-amber-700')}>
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" aria-hidden="true" />
              {comingSoonCount} Coming Soon
            </button>
            <button type="button" aria-pressed={statusFilter === 'draft'} onClick={() => toggleStatus('draft')} title="Show only Draft trips" className={pillClass('draft', 'bg-background-warm text-dark-muted')}>
              <span className="w-1.5 h-1.5 rounded-full bg-dark-muted shrink-0" aria-hidden="true" />
              {draftCount} Draft
            </button>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <input
              ref={importInputRef}
              type="file"
              accept="application/json,.json,application/zip,.zip"
              className="hidden"
              onChange={onImportInputChange}
            />
            <button
              onClick={() => importInputRef.current?.click()}
              title="Import Template"
              className="inline-flex items-center gap-1.5 text-xs font-button font-semibold pl-2 pr-3 py-1.5 rounded-md bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors"
            >
              <Upload size={18} weight="duotone" aria-hidden="true" /> Import
            </button>
            <button
              onClick={onExportTemplate}
              title="Export Template"
              className="inline-flex items-center gap-1.5 text-xs font-button font-semibold pl-2 pr-3 py-1.5 rounded-md bg-primary/10 text-primary hover:bg-primary hover:text-white transition-colors"
            >
              <Download size={18} weight="duotone" aria-hidden="true" /> Export
            </button>
          </div>
        </div>
        {trips.length > 1 && (
          <div className="relative">
            <MagnifyingGlass size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-muted pointer-events-none" aria-hidden="true" />
            <input
              type="search"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search trips by name or destination"
              aria-label="Search trips"
              className="w-full bg-white rounded-lg shadow-card pl-9 pr-9 py-2.5 text-sm text-dark placeholder:text-dark-muted focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            {query && (
              <button type="button" onClick={() => setQuery('')} aria-label="Clear search" className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded text-dark-muted hover:text-primary">
                <X size={14} aria-hidden="true" />
              </button>
            )}
          </div>
        )}
        {trips.length > 1 && !isFiltered && (
          <p className="text-xs text-dark-muted flex items-center gap-1.5 px-1">
            <ChevronUp size={12} className="shrink-0" aria-hidden="true" />
            Use the ↑/↓ arrows next to each trip to set the order cards appear in on the homepage and the full Trips page.
          </p>
        )}
      </div>

      {loading ? (
        <div className="text-center py-16 text-dark-muted">Loading...</div>
      ) : trips.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-lg shadow-card">
          <p className="font-display text-xl text-dark-muted mb-4">No trips yet.</p>
          <Button variant="primary" size="md" className="max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]" onClick={onAddTrip}><Plus size={16} aria-hidden="true" /> Add Your First Trip</Button>
        </div>
      ) : visibleTrips.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-card">
          <p className="text-dark-muted mb-3">No trips match your filters.</p>
          <Button variant="outline" size="sm" onClick={clearFilters}>Clear filters</Button>
        </div>
      ) : (
        <>
          {/* Mobile (below sm): a card per trip — the desktop table's hidden
              md/lg columns (destination, date, seats) plus a 112px-wide
              Actions column squeezing a row of icon buttons meant a phone was left
              with a cramped, hard-to-tap row, so this gives every field and
              action room to breathe instead. Same pattern as AdminAlbums /
              AdminTripLeaders. */}
          <div className="sm:hidden space-y-3">
            {visibleTrips.map(({ trip, index }) => {
              const seatsLeft = Math.max(0, trip.total_seats - trip.seats_booked);
              return (
                <motion.div
                  key={trip.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white rounded-lg shadow-card p-4 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="flex flex-col shrink-0">
                        <button onClick={() => onMoveTrip(index, -1)} disabled={isFiltered || index === 0} aria-label={`Move ${trip.title} up`} className="p-0.5 rounded hover:bg-background disabled:opacity-30 text-dark-muted"><ChevronUp size={14} aria-hidden="true" /></button>
                        <button onClick={() => onMoveTrip(index, 1)} disabled={isFiltered || index === trips.length - 1} aria-label={`Move ${trip.title} down`} className="p-0.5 rounded hover:bg-background disabled:opacity-30 text-dark-muted"><ChevronDown size={14} aria-hidden="true" /></button>
                      </div>
                      {trip.cover_image ? (
                        <img src={trip.cover_image} alt={trip.title} className="w-12 h-12 rounded-md object-cover flex-shrink-0" loading="lazy" decoding="async" />
                      ) : (
                        <div className="w-12 h-12 rounded-md bg-background-warm flex-shrink-0" />
                      )}
                      <div className="min-w-0">
                        <button
                          onClick={() => onView(trip)}
                          className="text-sm font-medium text-dark text-left leading-snug w-full line-clamp-2 break-words hover:text-primary hover:underline underline-offset-2 block"
                          aria-label={`View details for ${trip.title}`}
                        >
                          {trip.title}
                        </button>
                        <p className="text-xs text-dark-muted truncate">{trip.destination}</p>
                      </div>
                    </div>
                    <span className={`shrink-0 text-2xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${
                      trip.status === 'published' ? 'bg-green-100 text-green-700'
                      : trip.status === 'coming_soon' ? 'bg-amber-100 text-amber-700'
                      : 'bg-background-warm text-dark-muted'
                    }`}>
                      {trip.status === 'published' ? 'Published' : trip.status === 'coming_soon' ? 'Coming Soon' : 'Draft'}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-xs text-dark-muted whitespace-nowrap">
                      {formatDate(trip.start_date, { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                    <span className="text-xs text-dark-muted whitespace-nowrap">
                      {trip.seats_booked}/{trip.total_seats} seats ({seatsLeft} left)
                    </span>
                  </div>

                  <div className="flex items-center justify-end gap-0.5 pt-1 border-t border-background-warm">
                    <button onClick={() => onEdit(trip)} aria-label={`Edit ${trip.title}`} className="flex-shrink-0 p-2 rounded hover:bg-background text-dark-muted hover:text-primary transition-colors">
                      <Edit2 size={16} aria-hidden="true" />
                    </button>
                    <button onClick={() => onDelete(trip)} aria-label={`Delete ${trip.title}`} className="flex-shrink-0 p-2 rounded hover:bg-primary/5 text-dark-muted hover:text-primary transition-colors">
                      <Trash2 size={16} aria-hidden="true" />
                    </button>
                    <ActionsMenu variant="plain" label={`More actions for ${trip.title}`} items={rowMenuItems(trip)} />
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Desktop (sm and up): the full table. */}
          <div className="hidden sm:block bg-white rounded-lg shadow-card overflow-hidden">
          <div className="overflow-x-auto scrollbar-hide">
            <table className="w-full text-sm">
              <caption className="sr-only">Trips</caption>
              <thead className="bg-background-warm text-dark font-medium">
                <tr>
                  <th className="px-2 py-4 text-center w-8"><span className="sr-only">Reorder</span></th>
                  <th className="px-4 py-4 text-left">Trip</th>
                  <th className="px-4 py-4 text-left hidden md:table-cell">Destination</th>
                  <th className="px-4 py-4 text-left hidden lg:table-cell">Date</th>
                  <th className="px-4 py-4 text-left hidden md:table-cell">Seats</th>
                  <th className="px-2 py-4 text-center whitespace-nowrap">Status</th>
                  <th className="px-3 py-4 text-right whitespace-nowrap w-[112px] sm:w-auto">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-background-warm">
                {visibleTrips.map(({ trip, index }) => (
                  <motion.tr key={trip.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-background/50">
                    <td className="px-2 py-4">
                      <div className="flex flex-col items-center">
                        <button onClick={() => onMoveTrip(index, -1)} disabled={isFiltered || index === 0} aria-label={`Move ${trip.title} up`} title="Move up (homepage order)" className="p-0.5 rounded hover:bg-background disabled:opacity-30 text-dark-muted"><ChevronUp size={13} aria-hidden="true" /></button>
                        <button onClick={() => onMoveTrip(index, 1)} disabled={isFiltered || index === trips.length - 1} aria-label={`Move ${trip.title} down`} title="Move down (homepage order)" className="p-0.5 rounded hover:bg-background disabled:opacity-30 text-dark-muted"><ChevronDown size={13} aria-hidden="true" /></button>
                      </div>
                    </td>
                    <td className="px-4 py-4 font-medium text-dark truncate max-w-[150px] sm:max-w-none">
                      <button
                        onClick={() => onView(trip)}
                        className="text-left hover:text-primary hover:underline underline-offset-2 truncate"
                        title="View details"
                      >
                        {trip.title}
                      </button>
                    </td>
                    <td className="px-4 py-4 text-dark-muted hidden md:table-cell truncate">{trip.destination}</td>
                    <td className="px-4 py-4 text-dark-muted hidden lg:table-cell whitespace-nowrap">{formatDate(trip.start_date, { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                    <td className="px-4 py-4 text-dark-muted hidden md:table-cell whitespace-nowrap">
                      {trip.seats_booked}/{trip.total_seats}
                      <span className="text-xs text-dark-muted/70 ml-1">
                        ({Math.max(0, trip.total_seats - trip.seats_booked)} left)
                      </span>
                    </td>
                    <td className="px-2 py-4 text-center">
                      <span className={`inline-block text-xs font-button font-semibold px-2 py-1 rounded-md whitespace-nowrap ${
                        trip.status === 'published' ? 'bg-green-100 text-green-700'
                        : trip.status === 'coming_soon' ? 'bg-amber-100 text-amber-700'
                        : 'bg-background-warm text-dark-muted'
                      }`}>
                        {trip.status === 'published' ? 'Published' : trip.status === 'coming_soon' ? 'Coming Soon' : 'Draft'}
                      </span>
                    </td>
                    <td className="pl-2 pr-2 sm:pl-4 sm:pr-3 py-4 whitespace-nowrap">
                      <div className="flex items-center justify-end gap-0.5 sm:gap-1.5">
                        <button onClick={() => onEdit(trip)} aria-label={`Edit ${trip.title}`} className="flex-shrink-0 p-2 sm:p-1.5 rounded hover:bg-background active:bg-background text-dark-muted hover:text-primary transition-colors" title="Edit">
                          <Edit2 size={15} aria-hidden="true" />
                        </button>
                        <button onClick={() => onDelete(trip)} aria-label={`Delete ${trip.title}`} className="flex-shrink-0 p-2 sm:p-1.5 rounded hover:bg-primary/5 active:bg-primary/5 text-dark-muted hover:text-primary transition-colors" title="Delete">
                          <Trash2 size={15} aria-hidden="true" />
                        </button>
                        <ActionsMenu variant="plain" label={`More actions for ${trip.title}`} items={rowMenuItems(trip)} />
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
          </div>
        </>
      )}
    </div>
  );
}
