// Creator Commercial Rate Calculator — admin tool for working out what to
// pay/quote an Instagram creator for a collaboration, ported 1:1 from the
// "Creator_Rate_Calculator_final.xlsx" spreadsheet (Rate Calculator +
// Model Settings tabs). All formulas below mirror that workbook's cells
// exactly (see comments citing the original cell refs) so the numbers this
// page produces match the spreadsheet for the same inputs.
//
// Unlike the spreadsheet, every calculation run here can be saved
// (creator_rate_calculations table — see
// supabase/migration/add_creator_rate_calculations.sql) so past quotes are
// a real, searchable record rather than disappearing the moment the page
// is closed. Both the raw inputs and every derived output are stored
// together, so a saved row stays an accurate record of what was actually
// quoted even if the niche benchmarks or multiplier tiers are tuned later.
import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calculator,
  Users,
  Eye,
  ChartLineUp,
  Target,
  ArrowsClockwise as RotateCcw,
  Info,
  FloppyDisk as Save,
  ClockCounterClockwise as History,
  Trash as Trash2,
  CaretDown as ChevronDown,
  CaretUp as ChevronUp,
  InstagramLogo as Instagram,
  Phone,
  ClipboardText,
  Copy,
  WhatsappLogo,
  NotePencil as TemplateIcon,
  PencilSimple as EditIcon,
  Plus,
  Star,
  X,
  TextB as BoldIcon,
  TextItalic as ItalicIcon,
  TextStrikethrough as StrikethroughIcon,
  Code as MonospaceIcon,
} from '@phosphor-icons/react';
import AdminLayout from './AdminLayout';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import { useToast } from '../components/ui/useToast';
import { useConfirm } from '../components/ui/useConfirm';
import { formatPrice, formatDate, getWhatsAppLink } from '../utils/utils-index';
import { FORM_INPUT_CLASS as inputClass } from '../constants/formStyles';
import { getCreatorRateCalculations, saveCreatorRateCalculation, deleteCreatorRateCalculation, getSiteContent, upsertSiteContent } from '../services/api';
import type { CreatorRateCalculation } from '../types/types-index';
import { REEL_COUNT, DEFAULT_CREATOR, PREVIEW_SAMPLE_FOLLOWERS } from '../constants/creatorRate';
import DraftConflictNotice from './DraftConflictNotice';
import { lookupDraft, readDraft, stableStringify, useDraftKeeper, discardDraft } from '../hooks/useSessionDraft';
import {
  NICHE_OPTIONS, extractViewNumbers, calculateCreatorRate,
} from './creatorRate/creatorRateCalc';
import {
  RATE_MESSAGE_TEMPLATE_KEY, DEFAULT_MESSAGE_TEMPLATE, DEFAULT_VARIANT_ID, DEFAULT_MESSAGE_TEMPLATE_VARIANTS, PREVIEW_SAMPLE_ASSETS,
  templateDraftFrom, renderMessageTemplate, renderFormattedPreview,
  type MessageTemplateVariant, type TemplateDraft, type CreatorRateMessageTemplateContent, type MessageTemplateSource,
} from './creatorRate/creatorRateMessage';
import {
  STICKY_HEADER_SCROLL_OFFSET, HISTORY_EXPANDED_KEY, HISTORY_EXPANDED_ID_KEY, TEMPLATE_EXPANDED_KEY,
  readSessionFlag, readSessionString, scrollElementIntoView,
} from './creatorRate/creatorRateSession';

// Default identity fields, so the common case (quoting the same test/house
// creator) doesn't need retyping every time — still fully editable, and
// Reset restores these rather than blanking them out.
const DEFAULT_CREATOR_NAME = DEFAULT_CREATOR.name;
const DEFAULT_INSTAGRAM_HANDLE = DEFAULT_CREATOR.instagramHandle;
const DEFAULT_PHONE = DEFAULT_CREATOR.phone;

// Kept for this browser tab while they differ from a fresh calculator / the saved template, so
// leaving the page (or refreshing) and coming back finds them as they were left.
const INPUTS_DRAFT_KEY = 'creator-rate-inputs';
const TEMPLATE_DRAFT_KEY = 'creator-rate-template';

interface CalculatorInputs {
  creatorName: string; instagramHandle: string; phone: string; notes: string;
  followerCount: string; reelViews: string[]; niche: string;
}
export default function AdminCreatorRateCalculator() {
  const toast = useToast();
  const confirm = useConfirm();

  // Starts from the calculator contents kept for this tab (if any), otherwise a fresh calculator.
  const [keptInputs] = useState(() => readDraft<Partial<CalculatorInputs>>(INPUTS_DRAFT_KEY));

  // ---- Identity (saved alongside the calculation, optional) ----
  const [creatorName, setCreatorName] = useState(keptInputs?.creatorName ?? DEFAULT_CREATOR_NAME);
  const [instagramHandle, setInstagramHandle] = useState(keptInputs?.instagramHandle ?? DEFAULT_INSTAGRAM_HANDLE);
  const [phone, setPhone] = useState(keptInputs?.phone ?? DEFAULT_PHONE);
  const [notes, setNotes] = useState(keptInputs?.notes ?? '');

  // ---- Calculator inputs ----
  const [followerCount, setFollowerCount] = useState<string>(keptInputs?.followerCount ?? '');
  const [reelViews, setReelViews] = useState<string[]>(
    Array.isArray(keptInputs?.reelViews) && keptInputs.reelViews.length === REEL_COUNT ? keptInputs.reelViews : Array(REEL_COUNT).fill(''),
  );
  const [niche, setNiche] = useState<string>(keptInputs?.niche ?? NICHE_OPTIONS[0].value);
  // What "nothing to keep" looks like: a fresh calculator (or, after Save, the calculation just saved).
  const [inputsBase, setInputsBase] = useState(() => stableStringify({
    creatorName: DEFAULT_CREATOR_NAME, instagramHandle: DEFAULT_INSTAGRAM_HANDLE, phone: DEFAULT_PHONE, notes: '',
    followerCount: '', reelViews: Array(REEL_COUNT).fill(''), niche: NICHE_OPTIONS[0].value,
  } satisfies CalculatorInputs));
  const inputsValue = useMemo<CalculatorInputs>(
    () => ({ creatorName, instagramHandle, phone, notes, followerCount, reelViews, niche }),
    [creatorName, instagramHandle, phone, notes, followerCount, reelViews, niche],
  );
  useDraftKeeper({ key: INPUTS_DRAFT_KEY, value: inputsValue, base: inputsBase });
  const reelInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const followers = Number(followerCount) || 0;
  const views = useMemo(() => reelViews.map(v => Number(v) || 0), [reelViews]);
  const reelsEntered = views.filter(v => v > 0).length;

  const result = useMemo(() => calculateCreatorRate(followers, views, niche), [followers, views, niche]);

  const hasInputs = followers > 0 && reelsEntered > 0;

  const handleReset = () => {
    setCreatorName(DEFAULT_CREATOR_NAME);
    setInstagramHandle(DEFAULT_INSTAGRAM_HANDLE);
    setPhone(DEFAULT_PHONE);
    setNotes('');
    setFollowerCount('');
    setReelViews(Array(REEL_COUNT).fill(''));
    setNiche(NICHE_OPTIONS[0].value);
  };

  // ---- Reel views entry helpers ----
  // Filling in 10 values one field at a time is tedious, so a paste into
  // any Reel field that contains more than one number (a column copied
  // from Instagram Insights, Notes, or a spreadsheet) fans out across the
  // remaining fields starting at that box, instead of dumping everything
  // into one input.
  const fillReelViewsFrom = (startIndex: number, parsed: number[]) => {
    if (parsed.length === 0) return;
    setReelViews(prev => {
      const next = [...prev];
      parsed.forEach((val, offset) => {
        const target = startIndex + offset;
        if (target < REEL_COUNT) next[target] = String(val);
      });
      return next;
    });
    const focusIndex = Math.min(startIndex + parsed.length, REEL_COUNT - 1);
    requestAnimationFrame(() => reelInputRefs.current[focusIndex]?.focus());
  };

  const handleReelPaste = (e: React.ClipboardEvent<HTMLInputElement>, index: number) => {
    const parsed = extractViewNumbers(e.clipboardData.getData('text'));
    if (parsed.length === 0) return; // let the browser handle a plain/empty paste as usual
    e.preventDefault();
    fillReelViewsFrom(index, parsed);
  };

  // Spreadsheet-style keyboard navigation between the 10 boxes: Enter (or
  // the mobile keyboard's "Next"/"Go" action) moves to the next Reel,
  // Up/Down jumps a row (5 columns on desktop) so the whole set can be
  // filled without reaching for the mouse.
  const handleReelKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (index + 1 < REEL_COUNT) reelInputRefs.current[index + 1]?.focus();
      else e.currentTarget.blur();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      reelInputRefs.current[Math.min(index + 5, REEL_COUNT - 1)]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      reelInputRefs.current[Math.max(index - 5, 0)]?.focus();
    }
  };

  // One-tap fill for the whole set: read the clipboard directly (no click
  // into a specific box needed) and distribute every number found, in
  // order, into Reels 1–10.
  const handlePasteAllViews = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const parsed = extractViewNumbers(text);
      if (parsed.length === 0) {
        toast.error("Couldn't find any numbers on your clipboard. Copy the 10 view counts first, then try again.");
        return;
      }
      fillReelViewsFrom(0, parsed);
    } catch (err) {
      console.error(err);
      toast.error("Couldn't read your clipboard — paste directly into a Reel field instead.");
    }
  };

  // ---- Save ----
  const [saving, setSaving] = useState(false);
  const handleSave = async () => {
    if (!hasInputs) return;
    if (stableStringify(inputsValue) === inputsBase) {
      toast.info('No changes to save.');
      return;
    }
    setSaving(true);
    try {
      const saved = await saveCreatorRateCalculation({
        creator_name: creatorName.trim() || null,
        instagram_handle: instagramHandle.trim() || null,
        phone: phone.trim() || null,
        follower_count: followers,
        reel_views: views,
        niche,
        avg_views: result.avgViews,
        view_follower_ratio: result.viewFollowerRatio,
        niche_cpv: result.nicheCpv,
        quality_multiplier: result.qualityMultiplier,
        base_rate: result.baseRate,
        min_reel_rate: result.minReelRate,
        max_reel_rate: result.maxReelRate,
        final_commercials: result.assets,
        notes: notes.trim() || null,
      });
      setHistory(prev => [saved, ...prev]);
      setInputsBase(stableStringify(inputsValue));
      toast.success('Calculation saved.');
    } catch (err) {
      console.error(err);
      toast.error("Couldn't save this calculation.", { action: { label: 'Try again', onClick: () => { void handleSave(); } } });
    } finally {
      setSaving(false);
    }
  };

  // ---- History ----
  const [history, setHistory] = useState<CreatorRateCalculation[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(() => readSessionString(HISTORY_EXPANDED_ID_KEY));
  const [deletingId, setDeletingId] = useState<string | null>(null);
  // Row header buttons, keyed by calculation id — so that opening a card
  // (see effect below) can scroll its header up into view. Without this,
  // expanding a row near the bottom of a long history list just grows the
  // page below the fold and the admin has to go hunting for what they just
  // opened.
  const historyRowRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const cleanupScrollRef = useRef<(() => void) | null>(null);
  // Set true only inside an actual row-toggle click/keydown, and consumed
  // (reset to false) the moment the scroll-into-view effect below acts on
  // it. This is what stops that effect from also firing when expandedId is
  // restored from sessionStorage on mount (see HISTORY_EXPANDED_ID_KEY) —
  // a restore isn't a fresh click, and the page's own scroll-position
  // restoration (useScrollRestoration, wired up via AdminLayout above)
  // already puts the admin back exactly where they left off, using the
  // real saved scrollY rather than a recomputed element position. Letting
  // both systems try to move the scroll on the same mount raced against
  // each other and could visibly override one with the other.
  const rowUserToggledRef = useRef(false);
  // Whole-section collapse — same pattern as the Message Template card
  // below (collapsed by default, click the header to expand) instead of
  // this list always taking up space on the page.
  const [historyExpanded, setHistoryExpanded] = useState(() => readSessionFlag(HISTORY_EXPANDED_KEY));
  const historyHeaderRef = useRef<HTMLDivElement | null>(null);
  const historySectionScrollCleanupRef = useRef<(() => void) | null>(null);
  // Same purpose as rowUserToggledRef above, for the card's own header.
  const historyUserToggledRef = useRef(false);

  // Whenever a saved calculation is expanded, bring its header up so the
  // newly-revealed details are actually visible instead of the row sitting
  // wherever it happened to be in a long list. The button being scrolled
  // sits above its own expanding body, so its on-screen position doesn't
  // shift as that body grows — meaning we don't need to wait for the
  // 0.2s expand animation to finish, just for this render's DOM update to
  // land (one rAF). That lets the scroll and the expand happen together
  // as one smooth motion instead of expand-then-jump.
  useEffect(() => {
    if (!expandedId) return;
    if (!rowUserToggledRef.current) return;
    rowUserToggledRef.current = false;
    const frame = requestAnimationFrame(() => {
      const el = historyRowRefs.current[expandedId];
      if (!el) return;
      cleanupScrollRef.current = scrollElementIntoView(el, STICKY_HEADER_SCROLL_OFFSET);
    });
    return () => {
      cancelAnimationFrame(frame);
      cleanupScrollRef.current?.();
    };
  }, [expandedId]);

  // Persist which row (if any) is expanded, so navigating to another admin
  // page and back mid-visit restores it — see HISTORY_EXPANDED_ID_KEY above.
  useEffect(() => {
    try {
      if (expandedId) sessionStorage.setItem(HISTORY_EXPANDED_ID_KEY, expandedId);
      else sessionStorage.removeItem(HISTORY_EXPANDED_ID_KEY);
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — fine to skip.
    }
  }, [expandedId]);

  useEffect(() => {
    (async () => {
      try {
        const rows = await getCreatorRateCalculations();
        setHistory(rows);
      } catch (err) {
        console.error(err);
      } finally {
        setHistoryLoading(false);
      }
    })();
  }, []);

  // Same as Message Template below: the header sits above its own
  // expanding body so its position doesn't shift as that body grows —
  // scroll and expand can run together as one smooth motion.
  useEffect(() => {
    if (!historyExpanded) return;
    if (!historyUserToggledRef.current) return;
    historyUserToggledRef.current = false;
    const frame = requestAnimationFrame(() => {
      const el = historyHeaderRef.current;
      if (!el) return;
      historySectionScrollCleanupRef.current = scrollElementIntoView(el, STICKY_HEADER_SCROLL_OFFSET);
    });
    return () => {
      cancelAnimationFrame(frame);
      historySectionScrollCleanupRef.current?.();
    };
  }, [historyExpanded]);

  // Persist the Saved Calculations card's own open/closed state the same
  // way as the row above.
  useEffect(() => {
    try {
      if (historyExpanded) sessionStorage.setItem(HISTORY_EXPANDED_KEY, '1');
      else sessionStorage.removeItem(HISTORY_EXPANDED_KEY);
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — fine to skip.
    }
  }, [historyExpanded]);

  // ---- Message template variants (site_content row, shared across every
  // admin — see RATE_MESSAGE_TEMPLATE_KEY above). Starts at the factory
  // default variant and is swapped for whatever's saved in the DB as soon
  // as that loads, so the very first render (before the fetch resolves)
  // still has a sensible default to work from. Edited directly in the
  // "Message Template" box above the saved-calculations list — Copy/Share
  // on each saved row render from whichever variant is marked default,
  // unless overridden per row. ----
  const [templateVariants, setTemplateVariants] = useState<MessageTemplateVariant[]>(DEFAULT_MESSAGE_TEMPLATE_VARIANTS);
  const [defaultVariantId, setDefaultVariantId] = useState<string>(DEFAULT_VARIANT_ID);
  const [templateExpanded, setTemplateExpanded] = useState(() => readSessionFlag(TEMPLATE_EXPANDED_KEY));
  const [templateEditing, setTemplateEditing] = useState(false);
  // The saved template the draft is measured against (null until loaded), and a kept draft held
  // back because the saved template changed after the draft was started.
  const [templateBase, setTemplateBase] = useState<string | null>(null);
  const [heldTemplate, setHeldTemplate] = useState<TemplateDraft | null>(null);
  const [templateSaving, setTemplateSaving] = useState(false);
  const templateTextareaRefs = useRef<Record<string, HTMLTextAreaElement | null>>({});
  const templateHeaderRef = useRef<HTMLDivElement | null>(null);
  const templateScrollCleanupRef = useRef<(() => void) | null>(null);
  // Same purpose as rowUserToggledRef/historyUserToggledRef above — only
  // scroll-into-view on an actual click, not when templateExpanded is
  // restored from sessionStorage on mount (the page's own scrollY
  // restoration already handles that case).
  const templateUserToggledRef = useRef(false);

  // Same as the Saved Calculations rows above: the header sits above its
  // own expanding body so its position doesn't shift as that body grows —
  // scroll and expand can run together as one smooth motion instead of
  // waiting for the animation to finish first.
  useEffect(() => {
    if (!templateExpanded) return;
    if (!templateUserToggledRef.current) return;
    templateUserToggledRef.current = false;
    const frame = requestAnimationFrame(() => {
      const el = templateHeaderRef.current;
      if (!el) return;
      templateScrollCleanupRef.current = scrollElementIntoView(el, STICKY_HEADER_SCROLL_OFFSET);
    });
    return () => {
      cancelAnimationFrame(frame);
      templateScrollCleanupRef.current?.();
    };
  }, [templateExpanded]);

  // Persist the Message Template card's open/closed state — same as Saved
  // Calculations above: restored mid-visit when navigating back to this
  // page, but not remembered permanently (sessionStorage, not localStorage)
  // so it still starts collapsed on a fresh tab/next day.
  useEffect(() => {
    try {
      if (templateExpanded) sessionStorage.setItem(TEMPLATE_EXPANDED_KEY, '1');
      else sessionStorage.removeItem(TEMPLATE_EXPANDED_KEY);
    } catch {
      // sessionStorage unavailable (private browsing, etc.) — fine to skip.
    }
  }, [templateExpanded]);

  // ---- Formatting toolbar (Bold / Italic / Strikethrough / Monospace) ----
  // The template ends up as a plain-text WhatsApp message (via Copy or
  // Share) — there's no rich-text renderer on the receiving end, so real
  // bold/italic/colour/table formatting can't actually be sent. WhatsApp
  // does understand its own lightweight markup though (*bold*, _italic_,
  // ~strikethrough~, and ```monospace```), and does render it, so these
  // buttons wrap the current selection in that markup instead. Clicking
  // again on an already-wrapped selection unwraps it (toggle).
  const applyTemplateFormat = (variantId: string, marker: string) => {
    const el = templateTextareaRefs.current[variantId];
    if (!el) return;
    const { selectionStart, selectionEnd, value } = el;
    const selected = value.slice(selectionStart, selectionEnd);
    const before = value.slice(0, selectionStart);
    const after = value.slice(selectionEnd);
    const alreadyWrapped = before.endsWith(marker) && after.startsWith(marker);

    let next: string;
    let newStart: number;
    let newEnd: number;
    if (alreadyWrapped) {
      next = before.slice(0, -marker.length) + selected + after.slice(marker.length);
      newStart = selectionStart - marker.length;
      newEnd = selectionEnd - marker.length;
    } else {
      const content = selected || 'text';
      next = `${before}${marker}${content}${marker}${after}`;
      newStart = selectionStart + marker.length;
      newEnd = newStart + content.length;
    }

    updateVariant(variantId, { template: next });
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(newStart, newEnd);
    });
  };

  // ---- Variant list helpers (add / remove / reorder / rename / edit —
  // same shape as CancellationPolicyEditor's refund tiers). At least one
  // variant must always remain, since Copy/Share need something to fall
  // back to. ----
  const updateVariant = (variantId: string, patch: Partial<MessageTemplateVariant>) => {
    setTemplateVariants(prev => prev.map(v => (v.id === variantId ? { ...v, ...patch } : v)));
  };

  const addVariant = () => {
    const id = crypto.randomUUID();
    setTemplateVariants(prev => [...prev, { id, name: `Variant ${prev.length + 1}`, template: DEFAULT_MESSAGE_TEMPLATE }]);
  };

  const removeVariant = (variantId: string) => {
    setTemplateVariants(prev => {
      if (prev.length <= 1) return prev;
      const next = prev.filter(v => v.id !== variantId);
      if (defaultVariantId === variantId) setDefaultVariantId(next[0].id);
      return next;
    });
  };

  const moveVariant = (index: number, dir: -1 | 1) => {
    setTemplateVariants(prev => {
      const target = index + dir;
      if (target < 0 || target >= prev.length) return prev;
      const copy = [...prev];
      [copy[index], copy[target]] = [copy[target], copy[index]];
      return copy;
    });
  };

  const applyTemplate = (t: TemplateDraft) => {
    setTemplateVariants(t.variants);
    setDefaultVariantId(t.defaultVariantId);
  };

  useEffect(() => {
    (async () => {
      try {
        const saved = templateDraftFrom(await getSiteContent<CreatorRateMessageTemplateContent>(RATE_MESSAGE_TEMPLATE_KEY));
        const base = stableStringify(saved);
        // Template edits from an earlier visit in this browser tab come back as they were left,
        // unless the saved template changed since — then they are held back (heldTemplate).
        const { draft, stale } = lookupDraft<TemplateDraft>(TEMPLATE_DRAFT_KEY, base);
        applyTemplate(draft ?? saved);
        if (draft) {
          setTemplateExpanded(true);
          setTemplateEditing(true);
        }
        setHeldTemplate(stale);
        setTemplateBase(base);
      } catch (err) {
        console.error(err);
      }
    })();
  }, []);

  // Keep the template edits while they differ from the saved template (paused while one is on hold).
  const templateValue = useMemo<TemplateDraft>(() => ({ variants: templateVariants, defaultVariantId }), [templateVariants, defaultVariantId]);
  useDraftKeeper({ key: TEMPLATE_DRAFT_KEY, value: templateValue, base: heldTemplate ? null : templateBase });

  // ---- Preview: shows a variant fully filled in, in a popup, so an admin
  // can check the wording actually reads right before saving it. Uses
  // whatever's currently entered in the calculator above (creator name,
  // niche, follower count, computed Final Commercials) when there's enough
  // to work with, otherwise falls back to sample figures so the popup never
  // shows blank tokens. ----
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewVariantId, setPreviewVariantId] = useState<string | null>(null);
  const previewMessage = useMemo(() => {
    const template = templateVariants.find(v => v.id === previewVariantId)?.template ?? templateVariants[0]?.template ?? '';
    const source: MessageTemplateSource = hasInputs
      ? { creator_name: creatorName.trim() || null, niche, follower_count: followers, final_commercials: result.assets }
      : { creator_name: creatorName.trim() || DEFAULT_CREATOR_NAME, niche, follower_count: PREVIEW_SAMPLE_FOLLOWERS, final_commercials: PREVIEW_SAMPLE_ASSETS };
    return renderMessageTemplate(template, source);
  }, [templateVariants, previewVariantId, hasInputs, creatorName, niche, followers, result.assets]);

  const handleSaveMessageTemplate = async () => {
    if (templateBase !== null && stableStringify(templateValue) === templateBase) {
      toast.info('No changes to save.');
      return;
    }
    setTemplateSaving(true);
    try {
      // Someone may have saved the template since this page was opened; check before overwriting.
      const current = await getSiteContent<CreatorRateMessageTemplateContent>(RATE_MESSAGE_TEMPLATE_KEY).then(templateDraftFrom).catch(() => null);
      if (current && templateBase !== null && stableStringify(current) !== templateBase) {
        if (!(await confirm('The saved message template changed after you opened this page. Saving now replaces those newer changes with what is on your screen. Save anyway?'))) return;
      }
      await upsertSiteContent(RATE_MESSAGE_TEMPLATE_KEY, { variants: templateVariants, defaultVariantId } satisfies CreatorRateMessageTemplateContent);
      setTemplateBase(stableStringify(templateValue));
      setTemplateEditing(false);
      toast.success('Message template saved.');
    } catch (err) {
      console.error(err);
      toast.error("Couldn't save the message template.", { action: { label: 'Try again', onClick: () => { void handleSaveMessageTemplate(); } } });
    } finally {
      setTemplateSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    const ok = await confirm({ message: 'Delete this saved calculation? This cannot be undone.', variant: 'danger' });
    if (!ok) return;
    setDeletingId(id);
    try {
      await deleteCreatorRateCalculation(id);
      setHistory(prev => prev.filter(h => h.id !== id));
      if (expandedId === id) setExpandedId(null);
    } catch (err) {
      console.error(err);
      toast.error("Couldn't delete this calculation. Please try again.");
    } finally {
      setDeletingId(null);
    }
  };

  // ---- Per-row variant override: which variant Copy/Share use for a given
  // saved row, if the admin picked one from that row's variant picker
  // instead of leaving it on the default. Only shown when there's more
  // than one variant to choose from. ----
  const [rowVariantId, setRowVariantId] = useState<Record<string, string>>({});
  const variantForRow = (h: CreatorRateCalculation): MessageTemplateVariant =>
    templateVariants.find(v => v.id === (rowVariantId[h.id] ?? defaultVariantId)) ?? templateVariants[0];

  // ---- Send to creator: Copy (works with any app) + Share (opens
  // WhatsApp pre-filled to the creator's saved number, since that's how
  // these quotes are actually sent out). Both render from this row's
  // chosen variant (default unless overridden above), filled in with this
  // row's own values. ----
  // Copies the message; returns whether it worked (an error dialog has
  // already been shown if not).
  const copyCalculationText = async (h: CreatorRateCalculation): Promise<boolean> => {
    try {
      await navigator.clipboard.writeText(renderMessageTemplate(variantForRow(h).template, h));
      return true;
    } catch (err) {
      console.error(err);
      toast.error("Couldn't copy to clipboard. Please try again.");
      return false;
    }
  };

  const handleCopyCalculation = async (h: CreatorRateCalculation) => {
    if (await copyCalculationText(h)) toast.success('Message copied.');
  };

  const handleShareCalculation = async (h: CreatorRateCalculation) => {
    const message = renderMessageTemplate(variantForRow(h).template, h);
    if (h.phone) {
      window.open(getWhatsAppLink(h.phone, message), '_blank', 'noopener,noreferrer');
      return;
    }
    if (navigator.share) {
      try {
        await navigator.share({ text: message });
      } catch {
        // user cancelled the share sheet — nothing to do
      }
      return;
    }
    // No saved phone and no native share sheet — fall back to copying.
    if (await copyCalculationText(h)) toast.info('No phone number saved for this creator, so the message was copied instead — paste it into WhatsApp, Instagram DM, or email.', { duration: 6000 });
  };

  return (
    <AdminLayout title="Creator Rate Calculator" subtitle="Work out a fair commercial rate from a creator's followers, average views, and niche" scrollRestorationReady={!historyLoading}>
      <div className="space-y-6 max-w-5xl">
        {/* ---- Inputs ---- */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
          <div className="flex items-center justify-between gap-3 mb-4">
            <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                <Users size={15} className="text-primary" aria-hidden="true" />
              </span>
              Inputs
            </h3>
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-dark-muted hover:text-primary transition-colors"
            >
              <RotateCcw size={13} aria-hidden="true" /> Reset
            </button>
          </div>

          <p className="text-xs text-dark-muted mb-4 inline-flex items-start gap-1.5">
            <Info size={14} className="text-primary shrink-0 mt-0.5" aria-hidden="true" />
            Enter the creator's follower count, average views on their last 10 Reels, and niche.
          </p>

          {/* Optional identity — not part of the original spreadsheet, but
              needed to make a saved row identifiable later. */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4 mb-5 pb-5 border-b border-background-warm">
            <div>
              <label htmlFor="cr-name" className="block text-sm font-medium text-dark mb-1">Creator Name</label>
              <input
                id="cr-name"
                type="text"
                value={creatorName}
                onChange={e => setCreatorName(e.target.value)}
                className={inputClass}
                placeholder="e.g. Priya Sharma"
              />
            </div>
            <div>
              <label htmlFor="cr-handle" className="block text-sm font-medium text-dark mb-1">Instagram Handle</label>
              <input
                id="cr-handle"
                type="text"
                value={instagramHandle}
                onChange={e => setInstagramHandle(e.target.value)}
                className={inputClass}
                placeholder="e.g. @priya.travels"
              />
            </div>
            <div>
              <label htmlFor="cr-phone" className="block text-sm font-medium text-dark mb-1">Phone</label>
              <input
                id="cr-phone"
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className={inputClass}
                placeholder="e.g. 98765 43210"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-5">
            <div>
              <label htmlFor="cr-followers" className="block text-sm font-medium text-dark mb-1">Follower Count *</label>
              <input
                id="cr-followers"
                type="number"
                min={0}
                inputMode="numeric"
                value={followerCount}
                onChange={e => setFollowerCount(e.target.value)}
                className={inputClass}
                placeholder="e.g. 15000"
              />
            </div>
            <div>
              <label htmlFor="cr-niche" className="block text-sm font-medium text-dark mb-1">Niche *</label>
              <Select
                inputId="cr-niche"
                value={niche}
                onChange={setNiche}
                options={NICHE_OPTIONS}
                placeholder="Select niche..."
              />
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 mb-2">
            <p className="text-sm font-medium text-dark">Average Views — Last 10 Reels *</p>
            <button
              type="button"
              onClick={handlePasteAllViews}
              className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-primary hover:text-primary-dark transition-colors shrink-0"
            >
              <ClipboardText size={14} aria-hidden="true" /> Paste all 10
            </button>
          </div>
          <p className="text-2xs text-dark-muted mb-2">
            Tip: copy the 10 view counts (one per line) and click "Paste all 10", or paste into any box and press Enter to move on.
          </p>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mb-5">
            {reelViews.map((val, i) => (
              <div key={i}>
                <label htmlFor={`cr-reel-${i}`} className="block text-2xs text-dark-muted mb-1">Reel {i + 1}</label>
                <input
                  id={`cr-reel-${i}`}
                  ref={el => { reelInputRefs.current[i] = el; }}
                  type="number"
                  min={0}
                  inputMode="numeric"
                  enterKeyHint={i + 1 < REEL_COUNT ? 'next' : 'done'}
                  value={val}
                  onChange={e => {
                    const next = [...reelViews];
                    next[i] = e.target.value;
                    setReelViews(next);
                  }}
                  onPaste={e => handleReelPaste(e, i)}
                  onKeyDown={e => handleReelKeyDown(e, i)}
                  className={inputClass}
                  placeholder="0"
                />
              </div>
            ))}
          </div>

          <div>
            <label htmlFor="cr-notes" className="block text-sm font-medium text-dark mb-1">Notes</label>
            <textarea
              id="cr-notes"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className={inputClass}
              rows={2}
              placeholder="Optional — context for this quote, negotiation notes, etc."
            />
          </div>
        </motion.div>

        {!hasInputs ? (
          <div className="bg-white rounded-lg shadow-card p-8 text-center text-dark-muted text-sm">
            Enter a follower count and at least one Reel's average views to see the calculated rate.
          </div>
        ) : (
          <>
            {/* ---- Calculation ---- */}
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
              <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2 mb-3">
                <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                  <ChartLineUp size={15} className="text-primary" aria-hidden="true" />
                </span>
                Calculation
              </h3>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                <CalcCard label="Average Views (10 Reels)" value={Math.round(result.avgViews).toLocaleString('en-IN')} icon={Eye} />
                <CalcCard label="View / Follower Ratio" value={`${Math.round(result.viewFollowerRatio * 100)}%`} icon={ChartLineUp} />
                <CalcCard label="Niche CPV Benchmark" value={formatPrice(result.nicheCpv)} icon={Target} />
                <CalcCard label="View Quality Multiplier" value={`${result.qualityMultiplier}x`} icon={Calculator} />
              </div>
            </motion.div>

            {/* ---- Suggested range ---- */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-primary/5 border-2 border-primary/20 rounded-lg p-5 sm:p-6 text-center"
            >
              <p className="text-2xs font-button font-bold text-primary uppercase tracking-wide mb-1.5">
                Suggested 1-Reel Commercial Range
              </p>
              <p className="font-display text-2xl sm:text-3xl font-bold text-dark">
                {formatPrice(Math.round(result.minReelRate))} – {formatPrice(Math.round(result.maxReelRate))}
              </p>
              <p className="text-xs text-dark-muted mt-2">
                Calculated base rate: {formatPrice(Math.round(result.baseRate))} (Follower Count × Niche CPV Benchmark)
              </p>
            </motion.div>

            {/* ---- Final commercials table ---- */}
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
              <div className="flex items-center justify-between gap-3 mb-3">
                <h3 className="font-display text-base sm:text-lg font-bold text-dark">Final Commercials</h3>
                <Button variant="primary" size="sm" onClick={handleSave} loading={saving}>
                  <Save size={15} aria-hidden="true" /> Save Calculation
                </Button>
              </div>
              <div className="bg-white rounded-lg shadow-card overflow-hidden overflow-x-auto">
                <table className="w-full text-sm min-w-[520px]">
                  <thead>
                    <tr className="border-b border-background-warm text-left">
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">Asset</th>
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Minimum</th>
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide text-right">Maximum</th>
                      <th className="px-4 py-2.5 font-button font-bold text-dark-muted text-xs uppercase tracking-wide">Pricing Logic</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.assets.map(row => (
                      <tr key={row.asset} className="border-b border-background-warm last:border-0 hover:bg-background-warm/30">
                        <td className="px-4 py-2.5 text-dark font-medium">{row.asset}</td>
                        <td className="px-4 py-2.5 text-dark-muted text-right whitespace-nowrap">{formatPrice(row.min)}</td>
                        <td className="px-4 py-2.5 text-dark font-semibold text-right whitespace-nowrap">{formatPrice(row.max)}</td>
                        <td className="px-4 py-2.5 text-dark-muted text-xs">{row.pricing_logic}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-dark-muted mt-3 italic">
                💡 Negotiation tip: these are benchmark rates. Quote higher to leave room for negotiation.
              </p>
            </motion.div>
          </>
        )}

        {heldTemplate && (
          <DraftConflictNotice
            subject="the message template"
            onRestore={() => { applyTemplate(heldTemplate); setTemplateExpanded(true); setTemplateEditing(true); setHeldTemplate(null); }}
            onDiscard={() => { discardDraft(TEMPLATE_DRAFT_KEY); setHeldTemplate(null); }}
          />
        )}

        {/* ---- Message template — edited here, not per saved calculation.
              Copy/Share on every row below (new or old) always sends
              whatever's currently saved here. Collapsed by default (same
              pattern as the Saved Calculations rows below) since this is a
              tweak-it-occasionally tool, not something needed on every
              visit to the page. ---- */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
          <div
            ref={templateHeaderRef}
            role="button"
            tabIndex={0}
            onClick={() => {
              templateUserToggledRef.current = true;
              setTemplateExpanded(v => {
                if (v) setTemplateEditing(false);
                return !v;
              });
            }}
            onKeyDown={e => {
              if (e.key !== 'Enter' && e.key !== ' ') return;
              e.preventDefault();
              templateUserToggledRef.current = true;
              setTemplateExpanded(v => {
                if (v) setTemplateEditing(false);
                return !v;
              });
            }}
            aria-expanded={templateExpanded}
            className="w-full flex items-center justify-between gap-3 text-left cursor-pointer select-none"
          >
            <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                <TemplateIcon size={15} className="text-primary" aria-hidden="true" />
              </span>
              Message Template
            </h3>
            <div className="flex items-center gap-1 shrink-0">
              {templateExpanded && (
                <button
                  type="button"
                  onClick={e => { e.stopPropagation(); setTemplateEditing(v => !v); }}
                  aria-pressed={templateEditing}
                  title={templateEditing ? 'Done editing' : 'Edit variants'}
                  aria-label={templateEditing ? 'Done editing' : 'Edit variants'}
                  className={`inline-flex items-center justify-center w-8 h-8 rounded-md border transition-colors ${
                    templateEditing
                      ? 'bg-primary/10 border-primary/30 text-primary'
                      : 'border-transparent text-dark-muted hover:text-primary hover:bg-primary/5'
                  }`}
                >
                  <EditIcon size={15} aria-hidden="true" />
                </button>
              )}
              {templateExpanded ? <ChevronUp size={18} className="text-dark-muted shrink-0" aria-hidden="true" /> : <ChevronDown size={18} className="text-dark-muted shrink-0" aria-hidden="true" />}
            </div>
          </div>

          <AnimatePresence initial={false}>
            {templateExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="pt-3">
                  <div className="flex items-center justify-between mb-2 gap-3">
                    <span className="text-xs font-button font-bold text-dark-muted">Variants</span>
                    {templateEditing && (
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => {
                            setTemplateVariants(DEFAULT_MESSAGE_TEMPLATE_VARIANTS);
                            setDefaultVariantId(DEFAULT_VARIANT_ID);
                          }}
                          className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-dark-muted hover:text-primary transition-colors"
                        >
                          <RotateCcw size={13} aria-hidden="true" /> Reset to original wording
                        </button>
                        <button
                          type="button"
                          onClick={addVariant}
                          className="inline-flex items-center gap-1 text-xs font-button font-semibold text-primary hover:text-primary/80 transition-colors"
                        >
                          <Plus size={14} aria-hidden="true" /> Add Variant
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 mb-3">
                    {templateVariants.map((variant, index) => (
                      <div key={variant.id} className="bg-background-warm rounded-lg p-3 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            {variant.id === defaultVariantId ? (
                              <span
                                title="Default variant — used for Copy/Share unless overridden per row"
                                aria-label="Default variant"
                                className="inline-flex items-center justify-center text-primary shrink-0"
                              >
                                <Star size={13} weight="fill" aria-hidden="true" />
                              </span>
                            ) : templateEditing ? (
                              <button
                                type="button"
                                onClick={() => setDefaultVariantId(variant.id)}
                                title="Set as default"
                                aria-label={`Set "${variant.name}" as the default variant`}
                                className="inline-flex items-center justify-center text-dark-muted hover:text-primary transition-colors shrink-0"
                              >
                                <Star size={13} aria-hidden="true" />
                              </button>
                            ) : null}
                            <label htmlFor={`cr-template-name-${variant.id}`} className="sr-only">Variant name</label>
                            <input
                              id={`cr-template-name-${variant.id}`}
                              value={variant.name}
                              onChange={e => updateVariant(variant.id, { name: e.target.value })}
                              readOnly={!templateEditing}
                              className={`flex-1 min-w-0 bg-transparent text-xs font-button font-bold text-dark border-0 focus:outline-none focus:ring-0 px-0 ${!templateEditing ? 'cursor-default' : ''}`}
                            />
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => { setPreviewVariantId(variant.id); setPreviewOpen(true); }}
                              title="Preview"
                              aria-label={`Preview "${variant.name}"`}
                              className="p-1 rounded-md hover:bg-white text-dark-muted hover:text-primary transition-colors"
                            >
                              <Eye size={14} aria-hidden="true" />
                            </button>
                            {templateEditing && (
                              <>
                                <button type="button" onClick={() => moveVariant(index, -1)} disabled={index === 0} className="p-1 rounded-md hover:bg-white disabled:opacity-30 text-dark-muted transition-colors" title="Move up" aria-label={`Move "${variant.name}" up`}>
                                  <ChevronUp size={14} aria-hidden="true" />
                                </button>
                                <button type="button" onClick={() => moveVariant(index, 1)} disabled={index === templateVariants.length - 1} className="p-1 rounded-md hover:bg-white disabled:opacity-30 text-dark-muted transition-colors" title="Move down" aria-label={`Move "${variant.name}" down`}>
                                  <ChevronDown size={14} aria-hidden="true" />
                                </button>
                                <button type="button" onClick={() => removeVariant(variant.id)} disabled={templateVariants.length <= 1} className="p-1 rounded-md hover:bg-red-50 disabled:opacity-30 disabled:hover:bg-transparent text-dark-muted hover:text-red-600 transition-colors" title="Remove variant" aria-label={`Remove "${variant.name}"`}>
                                  <X size={14} aria-hidden="true" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                        {templateEditing && (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '*')}
                              title="Bold"
                              aria-label="Bold"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <BoldIcon size={15} weight="bold" aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '_')}
                              title="Italic"
                              aria-label="Italic"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <ItalicIcon size={15} aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '~')}
                              title="Strikethrough"
                              aria-label="Strikethrough"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <StrikethroughIcon size={15} aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyTemplateFormat(variant.id, '```')}
                              title="Monospace"
                              aria-label="Monospace"
                              className="inline-flex items-center justify-center w-8 h-8 rounded-md border border-background-warm bg-white text-dark-muted hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors"
                            >
                              <MonospaceIcon size={15} aria-hidden="true" />
                            </button>
                          </div>
                        )}
                        <label htmlFor={`cr-template-body-${variant.id}`} className="sr-only">{`Message body for "${variant.name}"`}</label>
                        <textarea
                          id={`cr-template-body-${variant.id}`}
                          ref={el => { templateTextareaRefs.current[variant.id] = el; }}
                          value={variant.template}
                          onChange={e => updateVariant(variant.id, { template: e.target.value })}
                          readOnly={!templateEditing}
                          rows={8}
                          className={`${inputClass} font-mono text-xs resize-y ${!templateEditing ? 'bg-white/60 cursor-default' : 'bg-white'}`}
                          placeholder="Message template..."
                        />
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3">
                    <Button variant="outline" size="sm" fullWidth onClick={() => { setPreviewVariantId(defaultVariantId); setPreviewOpen(true); }}>
                      <Eye size={15} aria-hidden="true" /> Preview
                    </Button>
                    <Button variant="primary" size="sm" fullWidth onClick={handleSaveMessageTemplate} loading={templateSaving}>
                      <Save size={15} aria-hidden="true" />
                      Save
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* ---- Template preview popup — read-only, shows exactly what
              Copy/Share would send right now, filled in with either the
              live calculator inputs above or sample figures. ---- */}
        <Modal
          isOpen={previewOpen}
          onClose={() => setPreviewOpen(false)}
          title={(() => {
            const name = templateVariants.find(v => v.id === previewVariantId)?.name;
            return name ? `Preview — ${name}` : 'Template Preview';
          })()}
          size="sm"
          footer={
            <div className="flex justify-end">
              <Button variant="primary" size="sm" onClick={() => setPreviewOpen(false)}>
                Close
              </Button>
            </div>
          }
        >
          <p className="text-xs text-dark-muted mb-3">
            {hasInputs
              ? 'This is how the message looks with the details currently entered above.'
              : `Enter a follower count and Reel views above to preview with a real calculation — showing sample figures for now.`}
          </p>
          <div className="bg-background-warm/40 border border-background-warm rounded-md p-4 whitespace-pre-wrap text-sm text-dark font-sans">
            {renderFormattedPreview(previewMessage)}
          </div>
        </Modal>

        {/* ---- Saved history — collapsed by default, same card/header
              pattern as Message Template above (click to expand, edit-style
              affordances live inside once open, header scrolls into view). ---- */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
          <div
            ref={historyHeaderRef}
            role="button"
            tabIndex={0}
            onClick={() => { historyUserToggledRef.current = true; setHistoryExpanded(v => !v); }}
            onKeyDown={e => {
              if (e.key !== 'Enter' && e.key !== ' ') return;
              e.preventDefault();
              historyUserToggledRef.current = true;
              setHistoryExpanded(v => !v);
            }}
            aria-expanded={historyExpanded}
            className="w-full flex items-center justify-between gap-3 text-left cursor-pointer select-none"
          >
            <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                <History size={15} className="text-primary" aria-hidden="true" />
              </span>
              Saved Calculations
              {!historyLoading && history.length > 0 && (
                <span className="text-dark-muted font-normal text-sm">({history.length})</span>
              )}
            </h3>
            <div className="flex items-center gap-1 shrink-0">
              {historyExpanded ? <ChevronUp size={18} className="text-dark-muted shrink-0" aria-hidden="true" /> : <ChevronDown size={18} className="text-dark-muted shrink-0" aria-hidden="true" />}
            </div>
          </div>

          <AnimatePresence initial={false}>
            {historyExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="pt-3">
                  {historyLoading ? (
                    <div className="text-center text-dark-muted text-sm py-6">Loading…</div>
                  ) : history.length === 0 ? (
                    <div className="text-center text-dark-muted text-sm py-6">
                      No saved calculations yet — save one above to build a history you can look back on.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {history.map(h => {
                const isOpen = expandedId === h.id;
                return (
                  <div key={h.id} className="bg-background-warm rounded-lg overflow-hidden">
                    <button
                      type="button"
                      ref={el => { historyRowRefs.current[h.id] = el; }}
                      onClick={() => { rowUserToggledRef.current = true; setExpandedId(isOpen ? null : h.id); }}
                      aria-expanded={isOpen}
                      className="w-full flex items-center justify-between gap-3 p-4 text-left hover:bg-white/60 transition-colors"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-dark truncate">
                          {h.creator_name || h.instagram_handle || 'Unnamed creator'}
                          <span className="text-dark-muted font-normal"> &middot; {h.niche}</span>
                        </p>
                        <p className="text-xs text-dark-muted mt-0.5">
                          {h.follower_count.toLocaleString('en-IN')} followers &middot; {formatDate(h.created_at)}
                        </p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-sm font-semibold text-primary whitespace-nowrap">
                          {formatPrice(Math.round(h.min_reel_rate))} – {formatPrice(Math.round(h.max_reel_rate))}
                        </span>
                        {isOpen ? <ChevronUp size={16} className="text-dark-muted" aria-hidden="true" /> : <ChevronDown size={16} className="text-dark-muted" aria-hidden="true" />}
                      </div>
                    </button>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="mx-3 mb-3 p-3 rounded-md bg-white space-y-3">
                            {(h.instagram_handle || h.phone) && (
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-dark-muted">
                                {h.instagram_handle && (
                                  <span className="inline-flex items-center gap-1"><Instagram size={13} aria-hidden="true" /> {h.instagram_handle}</span>
                                )}
                                {h.phone && (
                                  <span className="inline-flex items-center gap-1"><Phone size={13} aria-hidden="true" /> {h.phone}</span>
                                )}
                              </div>
                            )}

                            <div className="overflow-x-auto">
                              <table className="w-full text-xs min-w-[480px]">
                                <thead>
                                  <tr className="border-b border-background-warm text-left">
                                    <th className="px-3 py-2 font-button font-bold text-dark-muted uppercase tracking-wide">Asset</th>
                                    <th className="px-3 py-2 font-button font-bold text-dark-muted uppercase tracking-wide text-right">Min</th>
                                    <th className="px-3 py-2 font-button font-bold text-dark-muted uppercase tracking-wide text-right">Max</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {h.final_commercials.map(row => (
                                    <tr key={row.asset} className="border-b border-background-warm last:border-0">
                                      <td className="px-3 py-1.5 text-dark">{row.asset}</td>
                                      <td className="px-3 py-1.5 text-dark-muted text-right whitespace-nowrap">{formatPrice(row.min)}</td>
                                      <td className="px-3 py-1.5 text-dark font-semibold text-right whitespace-nowrap">{formatPrice(row.max)}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>

                            {h.notes && <p className="text-xs text-dark-muted italic">"{h.notes}"</p>}

                            <div className="flex items-center justify-between gap-3 flex-wrap pt-3 mt-1 border-t border-background-warm">
                              <div className="flex items-center gap-2 flex-wrap">
                                {templateVariants.length > 1 && (
                                  <Select
                                    inputId={`cr-row-variant-${h.id}`}
                                    size="sm"
                                    value={rowVariantId[h.id] ?? defaultVariantId}
                                    onChange={val => setRowVariantId(prev => ({ ...prev, [h.id]: val }))}
                                    options={templateVariants.map(v => ({ value: v.id, label: v.name }))}
                                    className="w-36"
                                  />
                                )}
                                <button
                                  type="button"
                                  onClick={() => handleCopyCalculation(h)}
                                  className="inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-button font-semibold transition-colors bg-primary/10 border-primary/20 text-primary hover:bg-primary/20"
                                >
                                  <Copy size={14} weight="bold" aria-hidden="true" />
                                  Copy
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleShareCalculation(h)}
                                  className="inline-flex items-center gap-1.5 rounded-lg border bg-secondary/10 border-secondary/25 text-secondary hover:bg-secondary/20 hover:border-secondary/40 px-3 py-1.5 text-xs font-button font-semibold transition-colors"
                                  title={h.phone ? `Share via WhatsApp to ${h.phone}` : 'Share'}
                                >
                                  <WhatsappLogo size={14} weight="fill" aria-hidden="true" /> Share
                                </button>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleDelete(h.id)}
                                disabled={deletingId === h.id}
                                className="inline-flex items-center gap-1.5 rounded-lg border border-transparent hover:border-red-200 hover:bg-red-50 px-3 py-1.5 text-xs font-button font-semibold text-dark-muted hover:text-red-600 transition-colors disabled:opacity-50"
                              >
                                <Trash2 size={14} aria-hidden="true" /> Delete
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
                      })}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </AdminLayout>
  );
}

function CalcCard({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Eye }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow-card min-w-0">
      <div className="flex items-center gap-2.5">
        <span className="inline-flex items-center justify-center w-9 h-9 rounded-md bg-primary/10 shrink-0">
          <Icon size={18} className="text-primary" aria-hidden="true" />
        </span>
        <p className="font-display text-lg sm:text-xl font-bold text-dark leading-tight truncate">{value}</p>
      </div>
      <p className="text-dark-muted text-xs font-medium truncate mt-2">{label}</p>
    </div>
  );
}
