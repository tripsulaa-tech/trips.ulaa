import { Smiley, Armchair, Sword, ArrowUUpLeft, ArrowsCounterClockwise, DiceFive, Heart, Crown, Check } from '@phosphor-icons/react';
import { glass } from './gameUi';
import { SPECIALS, SPECIAL_BLURB } from './stowawaySpecials';
import type { SpecialId } from './stowawaySpecials';

const SPECIAL_LOOK: Record<SpecialId, { icon: typeof Smiley; tone: string }> = {
  clown: { icon: Smiley, tone: 'from-amber-300 to-orange-400 text-amber-950' },
  rivals: { icon: Sword, tone: 'from-rose-300 to-red-400 text-rose-950' },
  returnTicket: { icon: ArrowsCounterClockwise, tone: 'from-emerald-300 to-teal-400 text-emerald-950' },
  tripLeader: { icon: Crown, tone: 'from-[#F0CE7A] to-gold text-dark' },
  backseatRider: { icon: Armchair, tone: 'from-sky-300 to-blue-400 text-sky-950' },
  payback: { icon: ArrowUUpLeft, tone: 'from-fuchsia-300 to-pink-400 text-fuchsia-950' },
  luckyDip: { icon: DiceFive, tone: 'from-yellow-200 to-amber-300 text-amber-950' },
  lovers: { icon: Heart, tone: 'from-pink-300 to-rose-400 text-rose-950' },
};

/** The role checklist: title, the exact description, and a tick box on the right. */
export default function SpecialList({ on, onToggle }: { on: ReadonlySet<SpecialId>; onToggle: (id: SpecialId) => void }) {
  return (
    <ul className={`${glass} divide-y divide-white/10 mb-4`}>
      {SPECIALS.map(def => {
        const look = SPECIAL_LOOK[def.id];
        const Icon = look.icon;
        const checked = on.has(def.id);
        return (
          <li key={def.id}>
            <button type="button" role="checkbox" aria-checked={checked} onClick={() => onToggle(def.id)}
              className="w-full flex items-center gap-3 px-3 py-3 text-left hover:bg-white/[0.04] transition-colors">
              <span className={`w-11 h-11 rounded-xl bg-gradient-to-br ${look.tone} flex items-center justify-center shrink-0 shadow-md`} aria-hidden="true">
                <Icon size={24} weight="duotone" />
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-sm font-bold text-white leading-tight">{def.name}</span>
                <span className="block text-[12px] leading-snug text-cream/60 mt-0.5">{SPECIAL_BLURB[def.id]}</span>
              </span>
              <span className={`w-6 h-6 rounded-md border-2 flex items-center justify-center shrink-0 transition-colors ${checked ? 'bg-primary border-primary text-white' : 'border-white/30 text-transparent'}`} aria-hidden="true">
                <Check size={14} weight="bold" />
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}
