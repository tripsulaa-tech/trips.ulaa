// Admin > Invoice Generator — a standalone tool (no database record behind
// it) for putting together a one-off invoice: billing address, a short
// line-item table, bank details and a signatory, then downloading it (or
// printing it) as a PDF laid out to match the reference "MEND PROMOTION"
// design exactly. See src/utils/invoiceGeneratorPdf.ts for the actual PDF
// drawing — this file is just the form plus a live preview.
//
// The preview on the right isn't a separate hand-built HTML mockup of the
// invoice (which could quietly drift from what the PDF actually renders):
// it's the real generated PDF, shown in an <iframe>, rebuilt (debounced)
// on every change. What the admin sees while typing is exactly what they
// get when they download.
import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import {
  FileText,
  Plus,
  Trash as Trash2,
  DownloadSimple as Download,
  Printer,
  ArrowsClockwise as RotateCcw,
  ArrowClockwise as NextNumber,
} from '@phosphor-icons/react';
import AdminLayout from './AdminLayout';
import Button from '../components/ui/Button';
import DatePicker from '../components/ui/DatePicker';
import { useAlert } from '../components/ui/useAlert';
import { FORM_INPUT_CLASS as inputClass } from '../constants/formStyles';
import {
  createEmptyLineItem,
  defaultInvoiceGeneratorData,
  downloadInvoiceGeneratorPdf,
  invoiceGeneratorPdfBlobUrl,
  invoiceGeneratorTotal,
  printInvoiceGeneratorPdf,
  reserveNextInvoiceNumber,
  DEFAULT_INVOICE_NUMBER_PREFIX,
  type InvoiceGeneratorData,
  type InvoiceGeneratorBankDetails,
} from '../utils/invoiceGeneratorPdf';
import { formatPrice } from '../utils/utils-index';

const BANK_FIELDS: { key: keyof InvoiceGeneratorBankDetails; label: string; placeholder: string }[] = [
  { key: 'accountNumber', label: 'Account Number', placeholder: 'e.g. 42216749328' },
  { key: 'ifscCode', label: 'IFSC Code', placeholder: 'e.g. SBIN0000796' },
  { key: 'bankName', label: 'Bank Name', placeholder: 'e.g. SBI' },
  { key: 'accountHolderName', label: 'Name', placeholder: 'e.g. Hari krishnan V' },
  { key: 'gpayNumber', label: 'GPAY No.', placeholder: 'e.g. 8248600801' },
];

// Debounce for the live preview rebuild — typing a full sentence
// shouldn't rebuild+re-render a PDF on every keystroke.
const PREVIEW_DEBOUNCE_MS = 500;

export default function AdminInvoiceGenerator() {
  const alert = useAlert();
  const [data, setData] = useState<InvoiceGeneratorData>(() => defaultInvoiceGeneratorData());
  const [downloading, setDownloading] = useState(false);
  const [printing, setPrinting] = useState(false);

  const total = invoiceGeneratorTotal(data.items);

  // ---- Field helpers ----
  const setField = <K extends keyof InvoiceGeneratorData>(key: K, value: InvoiceGeneratorData[K]) => {
    setData(prev => ({ ...prev, [key]: value }));
  };
  const setBankField = (key: keyof InvoiceGeneratorBankDetails, value: string) => {
    setData(prev => ({ ...prev, bank: { ...prev.bank, [key]: value } }));
  };
  const updateItem = (id: string, patch: Partial<InvoiceGeneratorData['items'][number]>) => {
    setData(prev => ({ ...prev, items: prev.items.map(it => (it.id === id ? { ...it, ...patch } : it)) }));
  };
  const addItem = () => {
    setData(prev => ({ ...prev, items: [...prev.items, createEmptyLineItem()] }));
  };
  const removeItem = (id: string) => {
    setData(prev => ({ ...prev, items: prev.items.length <= 1 ? prev.items : prev.items.filter(it => it.id !== id) }));
  };
  const handleNextInvoiceNumber = () => {
    setField('invoiceNumber', reserveNextInvoiceNumber(data.invoiceNumberPrefix || DEFAULT_INVOICE_NUMBER_PREFIX));
  };
  const handleReset = () => setData(defaultInvoiceGeneratorData());

  // ---- Live PDF preview ----
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewError, setPreviewError] = useState(false);
  const previewUrlRef = useRef<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      try {
        const url = await invoiceGeneratorPdfBlobUrl(data);
        if (cancelled) {
          URL.revokeObjectURL(url);
          return;
        }
        if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
        previewUrlRef.current = url;
        setPreviewUrl(url);
        setPreviewError(false);
      } catch (err) {
        console.error('Failed to render invoice preview', err);
        if (!cancelled) setPreviewError(true);
      }
    }, PREVIEW_DEBOUNCE_MS);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [data]);

  useEffect(() => () => {
    if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
  }, []);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadInvoiceGeneratorPdf(data);
    } catch (err) {
      console.error('Failed to generate invoice PDF', err);
      await alert("Couldn't generate the PDF. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  const handlePrint = async () => {
    setPrinting(true);
    try {
      await printInvoiceGeneratorPdf(data);
    } catch (err) {
      console.error('Failed to open invoice PDF for printing', err);
      await alert("Couldn't open the PDF for printing. Please try again.");
    } finally {
      setPrinting(false);
    }
  };

  return (
    <AdminLayout title="Invoice Generator" subtitle="Fill in the details below to generate a printable invoice PDF">
      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_420px] gap-6 items-start">
        {/* ---- Form ---- */}
        <div className="space-y-6 min-w-0">
          {/* Header details */}
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h3 className="font-display text-base sm:text-lg font-bold text-dark flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 shrink-0">
                  <FileText size={15} className="text-primary" aria-hidden="true" />
                </span>
                Invoice Details
              </h3>
              <button
                type="button"
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 text-xs font-button font-semibold text-dark-muted hover:text-primary transition-colors"
              >
                <RotateCcw size={13} aria-hidden="true" /> Reset
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mb-4">
              <div>
                <label htmlFor="inv-title" className="block text-sm font-medium text-dark mb-1">Invoice Title</label>
                <input
                  id="inv-title"
                  type="text"
                  value={data.invoiceTitle}
                  onChange={e => setField('invoiceTitle', e.target.value)}
                  className={inputClass}
                  placeholder="e.g. MEND PROMOTION"
                />
              </div>
              <div>
                <label htmlFor="inv-subtitle" className="block text-sm font-medium text-dark mb-1">Invoice Subtitle</label>
                <input
                  id="inv-subtitle"
                  type="text"
                  value={data.invoiceSubtitle}
                  onChange={e => setField('invoiceSubtitle', e.target.value)}
                  className={inputClass}
                  placeholder="e.g. ORGANIC VIDEO"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label htmlFor="inv-number" className="block text-sm font-medium text-dark mb-1">Invoice No.</label>
                <div className="flex gap-2">
                  <input
                    id="inv-number-prefix"
                    type="text"
                    value={data.invoiceNumberPrefix}
                    onChange={e => setField('invoiceNumberPrefix', e.target.value)}
                    className={`${inputClass} w-16 shrink-0 text-center`}
                    placeholder="JJ"
                    aria-label="Invoice number prefix"
                    title="Invoice number prefix"
                  />
                  <input
                    id="inv-number"
                    type="text"
                    value={data.invoiceNumber}
                    onChange={e => setField('invoiceNumber', e.target.value)}
                    className={`${inputClass} flex-1 min-w-0`}
                    placeholder="01"
                  />
                  <button
                    type="button"
                    onClick={handleNextInvoiceNumber}
                    title="Generate next number"
                    aria-label="Generate next invoice number"
                    className="shrink-0 inline-flex items-center justify-center w-10 rounded-md border-2 border-background-warm text-dark-muted hover:text-primary hover:border-primary/40 transition-colors"
                  >
                    <NextNumber size={16} aria-hidden="true" />
                  </button>
                </div>
                <p className="text-2xs text-dark-muted mt-1">Auto-generated (e.g. JJ01, JJ02…) — tap the arrow for the next number, or type your own.</p>
              </div>
              <div>
                <label htmlFor="inv-date" className="block text-sm font-medium text-dark mb-1">Invoice Date</label>
                <DatePicker
                  id="inv-date"
                  value={data.invoiceDateISO}
                  onChange={val => setField('invoiceDateISO', val)}
                />
              </div>
            </div>
          </motion.div>

          {/* Billing address */}
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
            <h3 className="font-display text-base sm:text-lg font-bold text-dark mb-4">Billing Address</h3>
            <div className="space-y-3 sm:space-y-4">
              <div>
                <label htmlFor="bill-name" className="block text-sm font-medium text-dark mb-1">Company / Client Name</label>
                <input
                  id="bill-name"
                  type="text"
                  value={data.billingCompanyName}
                  onChange={e => setField('billingCompanyName', e.target.value)}
                  className={inputClass}
                  placeholder="e.g. CBE MND FASHION LLP"
                />
              </div>
              <div>
                <label htmlFor="bill-address" className="block text-sm font-medium text-dark mb-1">Address</label>
                <textarea
                  id="bill-address"
                  value={data.billingAddress}
                  onChange={e => setField('billingAddress', e.target.value)}
                  className={inputClass}
                  rows={4}
                  placeholder={'e.g. 739/3, Avinashi Road, Race Course Road\nWARD083, Coimbatore Racecourse,\nC2- Race Course, Coimbatore South,\nCoimbatore- 641018, Tamil Nadu'}
                />
                <p className="text-2xs text-dark-muted mt-1">Each new line here becomes its own line on the invoice.</p>
              </div>
            </div>
          </motion.div>

          {/* Line items */}
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h3 className="font-display text-base sm:text-lg font-bold text-dark">Line Items</h3>
              <Button variant="outline" size="sm" type="button" onClick={addItem}>
                <Plus size={13} aria-hidden="true" /> Add Item
              </Button>
            </div>
            <div className="space-y-3">
              {data.items.map((item, index) => (
                <div key={item.id} className="bg-background-warm rounded-lg p-3 sm:p-4">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-2xs font-button font-bold text-dark-muted">Item {index + 1}</span>
                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      disabled={data.items.length <= 1}
                      className="inline-flex items-center gap-1 text-2xs font-button font-semibold text-dark-muted hover:text-red-600 disabled:opacity-30 disabled:hover:text-dark-muted transition-colors"
                    >
                      <Trash2 size={12} aria-hidden="true" /> Remove
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_140px] gap-2.5">
                    <div>
                      <label htmlFor={`item-desc-${item.id}`} className="block text-2xs text-dark-muted mb-1">Description</label>
                      <input
                        id={`item-desc-${item.id}`}
                        type="text"
                        value={item.description}
                        onChange={e => updateItem(item.id, { description: e.target.value })}
                        className={inputClass}
                        placeholder="e.g. MEND PROMOTION"
                      />
                    </div>
                    <div>
                      <label htmlFor={`item-sub-${item.id}`} className="block text-2xs text-dark-muted mb-1">Sub-description</label>
                      <input
                        id={`item-sub-${item.id}`}
                        type="text"
                        value={item.subDescription}
                        onChange={e => updateItem(item.id, { subDescription: e.target.value })}
                        className={inputClass}
                        placeholder="e.g. Hari krishnan (ORGANIC VIDEO)"
                      />
                    </div>
                    <div>
                      <label htmlFor={`item-amt-${item.id}`} className="block text-2xs text-dark-muted mb-1">Amount (INR)</label>
                      <input
                        id={`item-amt-${item.id}`}
                        type="number"
                        inputMode="decimal"
                        value={item.amount || ''}
                        onChange={e => updateItem(item.id, { amount: Number(e.target.value) || 0 })}
                        className={inputClass}
                        placeholder="0"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between gap-3 mt-4 pt-4 border-t border-background-warm">
              <span className="text-sm font-button font-bold text-dark">Total</span>
              <span className="font-display text-lg font-bold text-dark">{formatPrice(total)}</span>
            </div>
          </motion.div>

          {/* Bank details */}
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
            <h3 className="font-display text-base sm:text-lg font-bold text-dark mb-4">Bank Details</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              {BANK_FIELDS.map(f => (
                <div key={f.key}>
                  <label htmlFor={`bank-${f.key}`} className="block text-sm font-medium text-dark mb-1">{f.label}</label>
                  <input
                    id={`bank-${f.key}`}
                    type="text"
                    value={data.bank[f.key]}
                    onChange={e => setBankField(f.key, e.target.value)}
                    className={inputClass}
                    placeholder={f.placeholder}
                  />
                </div>
              ))}
            </div>
          </motion.div>

          {/* Signatory */}
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-lg shadow-card p-4 sm:p-6">
            <h3 className="font-display text-base sm:text-lg font-bold text-dark mb-4">Signature</h3>
            <div className="max-w-sm">
              <label htmlFor="signatory" className="block text-sm font-medium text-dark mb-1">Signatory Name</label>
              <input
                id="signatory"
                type="text"
                value={data.signatoryName}
                onChange={e => setField('signatoryName', e.target.value)}
                className={inputClass}
                placeholder="e.g. Hari krishnan V"
              />
              <p className="text-2xs text-dark-muted mt-1">Printed under the signature line at the bottom of the invoice. Defaults to the bank account Name above if left blank.</p>
            </div>
          </motion.div>

          {/* Actions — repeated here (in addition to the sticky preview
              panel's own buttons) so they're reachable without scrolling
              back up on narrower screens where the two columns stack. */}
          <div className="flex flex-col sm:flex-row gap-3 xl:hidden">
            <Button variant="primary" size="md" fullWidth onClick={handleDownload} loading={downloading}>
              <Download size={16} aria-hidden="true" /> Download PDF
            </Button>
            <Button variant="outline" size="md" fullWidth onClick={handlePrint} loading={printing}>
              <Printer size={16} aria-hidden="true" /> Print
            </Button>
          </div>
        </div>

        {/* ---- Live preview — the actual generated PDF, not a mockup ---- */}
        <div className="xl:sticky xl:top-24">
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-lg shadow-card p-3 sm:p-4">
            <div className="flex items-center justify-between gap-2 mb-3 px-1">
              <p className="text-sm font-button font-bold text-dark">Preview</p>
              <p className="text-2xs text-dark-muted">Updates as you type</p>
            </div>
            <div className="rounded-md border border-background-warm bg-background-warm/40 overflow-hidden" style={{ aspectRatio: '595 / 842' }}>
              {previewError ? (
                <div className="w-full h-full flex items-center justify-center text-center text-dark-muted text-xs p-6">
                  Couldn't render the preview. Try Download or Print below — the PDF may still generate correctly.
                </div>
              ) : previewUrl ? (
                <iframe title="Invoice preview" src={previewUrl} className="w-full h-full border-0" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-dark-muted text-xs">Generating preview…</div>
              )}
            </div>
            <div className="hidden xl:flex flex-col gap-2 mt-4">
              <Button variant="primary" size="md" fullWidth onClick={handleDownload} loading={downloading}>
                <Download size={16} aria-hidden="true" /> Download PDF
              </Button>
              <Button variant="outline" size="md" fullWidth onClick={handlePrint} loading={printing}>
                <Printer size={16} aria-hidden="true" /> Print
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </AdminLayout>
  );
}
