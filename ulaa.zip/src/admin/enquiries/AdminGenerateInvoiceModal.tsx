import { useEffect, type Dispatch, type SetStateAction } from 'react';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import Select from '../../components/ui/Select';
import { useConfirm } from '../../components/ui/useConfirm';
import { parseNonNegative, availableInvoiceTypeOptions, clearsBalanceForInvoice, GENERATE_INVOICE_STATUS_OPTIONS, PAYMENT_METHOD_OPTIONS } from './AdminEnquiryCommon';
import type { GenerateInvoiceForm } from './AdminEnquiryCommon';
import type { Enquiry } from '../../types/types-index';
import { formatPrice } from '../../utils/utils-index';
import { inputClass } from './AdminEnquiriesShared';

// Raises one invoice line (Full Payment / Advance / Balance / Installment /
// Extra Charge) against whichever booking it was opened from. "Paid now"
// records real money via recordTypedPayment/addExtraCharge; "Pending"
// raises the invoice without touching amount_paid, via
// generatePendingInvoice, for later settlement with the Mark Paid button
// in the Invoices list.
export default function GenerateInvoiceModal({
  generateInvoiceTarget,
  onClose,
  generateInvoiceForm,
  setGenerateInvoiceForm,
  onSave,
  savingInvoice,
}: {
  generateInvoiceTarget: Enquiry | null;
  onClose: () => void;
  generateInvoiceForm: GenerateInvoiceForm;
  setGenerateInvoiceForm: Dispatch<SetStateAction<GenerateInvoiceForm>>;
  onSave: () => void;
  savingInvoice: boolean;
}) {
  const confirm = useConfirm();

  // 'Balance' is only meant for the invoice that actually zeroes out the
  // amount due — if the admin picked it and then edits the amount so it
  // no longer does, drop back to 'Installment' rather than leaving
  // 'Balance' selected but no longer true. See clearsBalanceForInvoice in
  // AdminEnquiryCommon.
  useEffect(() => {
    if (!generateInvoiceTarget) return;
    if (generateInvoiceForm.type === 'balance' && !clearsBalanceForInvoice(generateInvoiceForm, generateInvoiceTarget.total_amount || 0, generateInvoiceTarget.amount_paid || 0)) {
      setGenerateInvoiceForm(f => ({ ...f, type: 'installment' }));
    }
  }, [generateInvoiceTarget, generateInvoiceForm, setGenerateInvoiceForm]);

  const isDirty =
    generateInvoiceForm.amount !== '' ||
    generateInvoiceForm.notes !== '' ||
    generateInvoiceForm.payment_method !== '' ||
    generateInvoiceForm.utr_number !== '';

  const requestClose = async () => {
    if (isDirty) {
      const ok = await confirm({
        title: 'Discard unsaved changes?',
        message: "You've entered invoice details that haven't been saved yet.",
        confirmLabel: 'Discard',
        cancelLabel: 'Continue Editing',
        variant: 'danger',
      });
      if (!ok) return;
    }
    onClose();
  };

  return (
    <Modal isOpen={!!generateInvoiceTarget} onClose={requestClose} title="Generate Invoice" size="sm">
      {generateInvoiceTarget && (
        <div className="space-y-4">
          <div className="bg-background-warm rounded-md px-4 py-3">
            <p className="font-medium text-dark">{generateInvoiceTarget.full_name}</p>
            <p className="text-dark-muted text-xs">{generateInvoiceTarget.trip_title || 'No trip linked'}</p>
            <p className="text-dark-muted text-xs mt-1">
              Total {formatPrice(generateInvoiceTarget.total_amount || 0)} · Paid {formatPrice(generateInvoiceTarget.amount_paid || 0)}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-dark mb-1">Type</label>
            <Select
              value={generateInvoiceForm.type}
              onChange={val => setGenerateInvoiceForm(f => ({ ...f, type: val }))}
              options={availableInvoiceTypeOptions(generateInvoiceForm, generateInvoiceTarget.total_amount || 0, generateInvoiceTarget.amount_paid || 0)}
            />
            {generateInvoiceForm.type === 'extra_charge' && (
              <p className="text-[11px] text-dark-muted mt-1">
                Adds this amount on top of the booking's total amount right away — e.g. a hotel upgrade — whether or not it's collected now.
              </p>
            )}
            {generateInvoiceForm.type !== 'extra_charge' && !clearsBalanceForInvoice(generateInvoiceForm, generateInvoiceTarget.total_amount || 0, generateInvoiceTarget.amount_paid || 0) && (
              <p className="text-[11px] text-dark-muted mt-1">
                'Balance' will appear here once the amount below clears what's still owed.
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-dark mb-1">Amount (₹)</label>
            <input
              type="number"
              min={0}
              value={generateInvoiceForm.amount}
              onChange={ev => setGenerateInvoiceForm(f => ({ ...f, amount: parseNonNegative(ev.target.value) }))}
              className={inputClass}
              placeholder="Amount for this invoice"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-dark mb-1">Status</label>
            <Select
              value={generateInvoiceForm.status}
              onChange={val => setGenerateInvoiceForm(f => ({ ...f, status: val }))}
              options={GENERATE_INVOICE_STATUS_OPTIONS}
            />
          </div>

          {generateInvoiceForm.status === 'paid' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-dark mb-1">Payment Method</label>
                <Select
                  value={generateInvoiceForm.payment_method}
                  onChange={val => setGenerateInvoiceForm(f => ({ ...f, payment_method: val, utr_number: val === 'Cash' ? '' : f.utr_number }))}
                  options={PAYMENT_METHOD_OPTIONS}
                  placeholder="Select method"
                  size="sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-dark mb-1">UTR / Reference</label>
                <input
                  type="text"
                  value={generateInvoiceForm.utr_number}
                  disabled={generateInvoiceForm.payment_method === 'Cash'}
                  onChange={ev => setGenerateInvoiceForm(f => ({ ...f, utr_number: ev.target.value }))}
                  className={`${inputClass} ${generateInvoiceForm.payment_method === 'Cash' ? 'opacity-60 cursor-not-allowed' : ''}`}
                  placeholder={generateInvoiceForm.payment_method === 'Cash' ? 'N/A for cash' : 'e.g. 426817XXXXXX'}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-dark mb-1">Notes (optional)</label>
            <input
              type="text"
              value={generateInvoiceForm.notes}
              onChange={ev => setGenerateInvoiceForm(f => ({ ...f, notes: ev.target.value }))}
              className={inputClass}
              placeholder="Any additional context for this invoice"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="outline" size="md" className="max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]" onClick={onClose}>Cancel</Button>
            <Button variant="primary" size="md" className="max-sm:!px-4 max-sm:!py-2.5 max-sm:!text-sm max-sm:!min-h-[44px]" onClick={onSave} loading={savingInvoice}>
              Generate Invoice
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
